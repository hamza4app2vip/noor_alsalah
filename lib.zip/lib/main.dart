import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/rendering.dart' show debugPaintBaselinesEnabled;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'firebase_options.dart';
import 'core/services/internet_service.dart';
import 'core/services/push_notification_service.dart';
import 'core/services/server_service.dart';
import 'core/services/update_checker_service.dart';
import 'core/theme/luxury_glass_theme.dart';
import 'core/tv/tv_remote_support.dart';
import 'features/contact_us/infrastructure/telegram_remote_config_service.dart';
import 'features/prayer_times/presentation/screens/home_screen.dart';
import 'features/settings/presentation/providers/settings_provider.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';
import 'features/settings/presentation/screens/language_selection_screen.dart';

class AppScrollBehavior extends MaterialScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.trackpad,
        PointerDeviceKind.stylus,
        PointerDeviceKind.unknown,
      };
}

bool _isFirebaseSupportedPlatform() {
  if (kIsWeb) return true;
  return defaultTargetPlatform == TargetPlatform.android;
}

Future<void> _initializeFirebase() async {
  if (!_isFirebaseSupportedPlatform()) return;

  PushNotificationService.registerBackgroundHandler();

  if (Firebase.apps.isEmpty) {
    await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform);
  }

  await PushNotificationService.instance.initialize();
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  assert(() {
    debugPaintBaselinesEnabled = false;
    return true;
  }());

  await _initializeFirebase();

  final sharedPrefs = await SharedPreferences.getInstance();

  runApp(
    ProviderScope(
      overrides: [
        sharedPreferencesProvider.overrideWithValue(sharedPrefs),
      ],
      child: const TawkitApp(),
    ),
  );
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class TawkitApp extends ConsumerStatefulWidget {
  const TawkitApp({super.key});

  @override
  ConsumerState<TawkitApp> createState() => _TawkitAppState();
}

class _TawkitAppState extends ConsumerState<TawkitApp> {
  @override
  void initState() {
    super.initState();
    InternetService().init();
    UpdateCheckerService.instance.init();
    ref.read(serverServiceProvider).start(port: 8080);
    TelegramRemoteConfigService.ensureInitialized();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);

    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'نور الصلاة',
      debugShowCheckedModeBanner: false,
      scrollBehavior: AppScrollBehavior(),
      theme: LuxuryGlassTheme.getTheme(settings, context),
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      supportedLocales: AppLocalizations.supportedLocales,
      locale: Locale(settings.languageCode),
      builder: (context, child) {
        return Directionality(
          textDirection: settings.languageCode == 'ar' 
              ? TextDirection.rtl 
              : TextDirection.ltr,
          child: TvRemoteScope(
            enableDebugLogging: true,
            confirmExitOnRoot: true,
            child: child!,
          ),
        );
      },
      home: settings.hasSelectedLanguage 
          ? const HomeScreen() 
          : const LanguageSelectionScreen(isFirstRun: true),
    );
  }
}
