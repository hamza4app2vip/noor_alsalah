import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show TargetPlatform, defaultTargetPlatform, kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not configured for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCXGYuC6KlSvu9GL61NCdx6cGl9iOzPUHU',
    appId: '1:229039942624:web:7cafa623f210c6020f1985',
    messagingSenderId: '229039942624',
    projectId: 'noor-admin-web',
    authDomain: 'noor-admin-web.firebaseapp.com',
    storageBucket: 'noor-admin-web.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBEnPq_CaQPSJSXAWVpnyJPWn3zpgKRcGg',
    appId: '1:229039942624:android:c9d8e2fbeffa03ce0f1985',
    messagingSenderId: '229039942624',
    projectId: 'noor-admin-web',
    storageBucket: 'noor-admin-web.firebasestorage.app',
  );
}
