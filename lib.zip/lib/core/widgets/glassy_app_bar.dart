import 'dart:ui';
import 'package:flutter/material.dart';

class GlassyAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final Widget? leading;
  final double height;
  final double borderRadius;
  final bool showBackButton;
  final Color emeraldPrimary = const Color(0xFF08452F);

  const GlassyAppBar({
    super.key,
    required this.title,
    this.actions,
    this.leading,
    this.height = 70,
    this.borderRadius = 25,
    this.showBackButton = true,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final titleColor = isDark ? const Color(0xFFDCB881) : emeraldPrimary;

    return PreferredSize(
      preferredSize: Size.fromHeight(height),
      child: ClipRRect(
        borderRadius:
            BorderRadius.vertical(bottom: Radius.circular(borderRadius)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            decoration: BoxDecoration(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.06)
                  : Colors.white.withValues(alpha: 0.10),
              borderRadius:
                  BorderRadius.vertical(bottom: Radius.circular(borderRadius)),
              border: Border.all(
                color: Colors.white.withValues(alpha: isDark ? 0.22 : 0.28),
                width: 0.6,
              ),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isDark
                    ? [
                        const Color(0xFF7DD3FC).withValues(alpha: 0.10),
                        Colors.white.withValues(alpha: 0.03),
                      ]
                    : [
                        Colors.white.withValues(alpha: 0.34),
                        Colors.white.withValues(alpha: 0.08),
                      ],
              ),
            ),
            child: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              iconTheme: IconThemeData(
                  color: isDark ? Colors.white70 : Colors.black87),
              centerTitle: true,
              automaticallyImplyLeading: false,
              leading: leading ??
                  (showBackButton && Navigator.of(context).canPop()
                      ? IconButton(
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              color: isDark ? Colors.white70 : Colors.black54,
                              size: 20),
                          onPressed: () => Navigator.of(context).pop(),
                        )
                      : null),
              title: Text(
                title,
                style: TextStyle(
                  color: titleColor,
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                ),
              ),
              actions: actions,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(height);
}
