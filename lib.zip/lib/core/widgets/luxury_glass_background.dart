import 'dart:ui';
import 'package:flutter/material.dart';

class LuxuryGlassBackground extends StatelessWidget {
  final Widget child;
  final Color? backgroundColor;
  final DecorationImage? imageProvider;

  const LuxuryGlassBackground({
    super.key,
    required this.child,
    this.backgroundColor,
    this.imageProvider,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor, // use color if provided
        image: imageProvider ?? 
           (backgroundColor == null 
               ? const DecorationImage(
                   image: AssetImage('assets/images/backphone/back1.png'),
                   fit: BoxFit.cover,
                 ) 
               : null),
      ),
      child: Stack(
        children: [
          // طبقة تمويه (Blur) خفيفة على الخلفية
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
            child: Container(color: Colors.transparent),
          ),
          
          // المحتوى
          child,
        ],
      ),
    );
  }
}
