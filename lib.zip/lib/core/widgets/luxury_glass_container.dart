import 'dart:ui';
import 'package:flutter/material.dart';

import 'package:noor_prayer_tv/core/theme/app_colors.dart';

class LuxuryGlassContainer extends StatelessWidget {
  final Widget child;
  final double? width;
  final double? height;
  final double borderRadius;
  final double blurSigmaX;
  final double blurSigmaY;
  final EdgeInsetsGeometry padding;
  final bool isHighlighted;

  const LuxuryGlassContainer({
    super.key,
    required this.child,
    this.width,
    this.height,
    this.borderRadius = 25.0,
    this.blurSigmaX = 12.0,
    this.blurSigmaY = 12.0,
    this.padding = EdgeInsets.zero,
    this.isHighlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigmaX, sigmaY: blurSigmaY),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: width,
          height: height,
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                isHighlighted 
                  ? AppColors.primaryGold.withValues(alpha: 0.25) 
                  : (Theme.of(context).brightness == Brightness.dark 
                      ? Colors.white.withValues(alpha: 0.12)
                      : Colors.white.withValues(alpha: 0.7)),
                Theme.of(context).brightness == Brightness.dark 
                  ? Colors.white.withValues(alpha: 0.03) 
                  : Colors.white.withValues(alpha: 0.4),
                Theme.of(context).brightness == Brightness.dark 
                  ? Colors.white.withValues(alpha: 0.08)
                  : Colors.white.withValues(alpha: 0.5),
              ],
              stops: const [0.0, 0.4, 1.0],
            ),
            border: Border.all(
              color: isHighlighted 
                ? AppColors.primaryGold 
                : (Theme.of(context).brightness == Brightness.dark 
                    ? Colors.white.withValues(alpha: 0.15) 
                    : Colors.black.withValues(alpha: 0.05)),
              width: isHighlighted ? 1.5 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black.withValues(alpha: 0.1)
                  : Colors.black.withValues(alpha: 0.03),
                blurRadius: 20,
                spreadRadius: -5,
                offset: const Offset(0, 10),
              ),
              if (isHighlighted)
                BoxShadow(
                  color: AppColors.primaryGold.withValues(alpha: 0.2),
                  blurRadius: 15,
                  spreadRadius: 1,
                ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}
