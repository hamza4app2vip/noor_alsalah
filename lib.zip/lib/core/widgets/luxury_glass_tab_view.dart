import 'package:flutter/material.dart';
import '../theme/luxury_glass_theme.dart';
import '../tv/tv_remote_support.dart';

class LuxuryGlassTabView extends StatefulWidget {
  final List<String> tabNames;
  final List<Widget> tabViews;
  final Color activeTabColor;
  final Color inactiveTabColor;
  final EdgeInsetsGeometry tabsPadding;

  const LuxuryGlassTabView({
    super.key,
    required this.tabNames,
    required this.tabViews,
    this.activeTabColor = LuxuryGlassTheme.primaryOrange,
    this.inactiveTabColor = Colors.white60,
    this.tabsPadding = const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
  }) : assert(tabNames.length == tabViews.length,
            "Tab names and views length must match");

  @override
  State<LuxuryGlassTabView> createState() => _LuxuryGlassTabViewState();
}

class _LuxuryGlassTabViewState extends State<LuxuryGlassTabView> {
  int _selectedTabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Tabs Header
        Padding(
          padding: widget.tabsPadding,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(widget.tabNames.length, (index) {
                final isActive = index == _selectedTabIndex;
                return TvFocusable(
                  onPressed: () {
                    setState(() {
                      _selectedTabIndex = index;
                    });
                  },
                  borderRadius: BorderRadius.circular(10),
                  focusColor: widget.activeTabColor,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 15),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: isActive
                              ? widget.activeTabColor
                              : Colors.transparent,
                          width: 2,
                        ),
                      ),
                    ),
                    child: Text(
                      widget.tabNames[index],
                      style: TextStyle(
                        fontSize: 16,
                        color: isActive
                            ? widget.activeTabColor
                            : widget.inactiveTabColor,
                        fontWeight:
                            isActive ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),

        // Custom Divider from the original style
        Container(height: 1, color: Colors.white.withValues(alpha: 0.1)),

        // Tab Content
        Expanded(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: widget.tabViews[_selectedTabIndex],
          ),
        ),
      ],
    );
  }
}
