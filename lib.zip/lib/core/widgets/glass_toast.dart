import 'package:flutter/material.dart';
import 'dart:ui';
import 'dart:math' as math;

import '../theme/app_styles.dart';

class GlassToast {
  static void show(BuildContext context, String message,
      {bool isError = false}) {
    if (!context.mounted) return;

    final overlayState = Overlay.of(context);
    late OverlayEntry overlayEntry;

    overlayEntry = OverlayEntry(
      builder: (context) {
        return _GlassToastWidget(
          message: message,
          isError: isError,
          onDismiss: () {
            if (overlayEntry.mounted) {
              overlayEntry.remove();
            }
          },
        );
      },
    );

    overlayState.insert(overlayEntry);

    // Auto-remove after 3 seconds
    Future.delayed(const Duration(seconds: 3)).then((_) {
      if (overlayEntry.mounted) {
        overlayEntry.remove();
      }
    });
  }
}

class _GlassToastWidget extends StatefulWidget {
  final String message;
  final bool isError;
  final VoidCallback onDismiss;

  const _GlassToastWidget({
    required this.message,
    required this.isError,
    required this.onDismiss,
  });

  @override
  State<_GlassToastWidget> createState() => _GlassToastWidgetState();
}

class _GlassToastWidgetState extends State<_GlassToastWidget>
    with TickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  late AnimationController _shineController;
  late Animation<double> _shineAnimation;

  @override
  void initState() {
    super.initState();

    // Entry Animation (0.6s cubic-bezier(0.16, 1, 0.3, 1))
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    final CurvedAnimation entryCurve = CurvedAnimation(
      parent: _entryController,
      curve: const Cubic(0.16, 1.0, 0.3, 1.0),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(entryCurve);

    // 100px translate Y / 40px height = 2.5 factor
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.0, 2.5),
      end: Offset.zero,
    ).animate(entryCurve);

    _entryController.forward();

    // Shine Animation (4s infinite, active for the first 40%)
    _shineController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _shineAnimation = Tween<double>(begin: -1.5, end: 1.5).animate(
      CurvedAnimation(
        parent: _shineController,
        curve: const Interval(0.0, 0.40, curve: Curves.easeInOut),
      ),
    );
    _syncShineState();
  }

  void _syncShineState() {
    final shineEnabled = AppStyles.currentSettings?.glassShineEnabled ?? true;
    if (shineEnabled) {
      _shineController.repeat();
    } else {
      _shineController
        ..stop()
        ..value = 0;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _syncShineState();
  }

  @override
  void dispose() {
    _entryController.dispose();
    _shineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double frameWidth = math.min(screenWidth - 80, 280.0);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : const Color(0xFF111827);
    final iconColor = isDark ? Colors.white70 : const Color(0xFF4B5563);

    return Positioned(
      bottom: 24.0,
      left: 0,
      right: 0,
      child: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Container(
              width: frameWidth,
              height: 48.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16.0),
                boxShadow: [
                  BoxShadow(
                    color: isDark
                        ? Colors.black.withValues(alpha: 0.3)
                        : Colors.black.withValues(alpha: 0.08),
                    offset: const Offset(0, 15),
                    blurRadius: 30.0,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16.0),
                clipBehavior: Clip.antiAlias, // Improved edge rendering
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: isDark
                          ? Colors.white.withValues(alpha: 0.02)
                          : Colors.black.withValues(alpha: 0.01),
                      borderRadius: BorderRadius.circular(16.0),
                      border: Border.all(
                        color:
                            Colors.white.withValues(alpha: isDark ? 0.1 : 0.4),
                        width: 0.5,
                      ),
                    ),
                    child: Stack(
                      children: [
                        // Glass Highlights
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16.0),
                              border: Border(
                                top: BorderSide(
                                  color: Colors.white
                                      .withValues(alpha: isDark ? 0.3 : 0.6),
                                  width: 1.5,
                                ),
                                left: BorderSide(
                                  color: Colors.white
                                      .withValues(alpha: isDark ? 0.2 : 0.4),
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                        // Shine Effect
                        if (AppStyles.currentSettings?.glassShineEnabled ??
                            true)
                          Positioned.fill(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(15.0),
                              child: AnimatedBuilder(
                                animation: _shineController,
                                builder: (context, child) {
                                  return FractionalTranslation(
                                    translation:
                                        Offset(_shineAnimation.value, 0),
                                    child: child,
                                  );
                                },
                                child: Transform(
                                  transform: Matrix4.skewX(-25 * math.pi / 180),
                                  alignment: Alignment.center,
                                  child: Container(
                                    width: frameWidth,
                                    height: 48.0,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Color.fromRGBO(255, 255, 255, 0),
                                          Color.fromRGBO(255, 255, 255, 0.1),
                                          Color.fromRGBO(255, 255, 255, 0.4),
                                          Color.fromRGBO(255, 255, 255, 0),
                                          Color.fromRGBO(255, 255, 255, 0),
                                          Color.fromRGBO(255, 255, 255, 0.15),
                                          Color.fromRGBO(255, 255, 255, 0),
                                          Color.fromRGBO(255, 255, 255, 0),
                                        ],
                                        stops: [
                                          0.0,
                                          0.20,
                                          0.25,
                                          0.30,
                                          0.50,
                                          0.55,
                                          0.60,
                                          1.0
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        // Content
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Center(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  widget.isError
                                      ? Icons.error_outline_rounded
                                      : Icons.info_outline_rounded,
                                  color: iconColor,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Flexible(
                                  child: Material(
                                    color: Colors.transparent,
                                    child: Text(
                                      widget.message,
                                      textDirection: TextDirection.rtl,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: textColor,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        fontFamily: 'Cairo',
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
