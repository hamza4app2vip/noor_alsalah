import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../tv/tv_remote_support.dart';

/// مكوّن موحّد لصفوف الإعدادات بترتيب RTL حقيقي:
/// [ أيقونة (يمين) ]  [ عنوان + وصف (وسط، محاذاة يمين) ]  [ trailing (يسار) ]
class SettingRow extends StatelessWidget {
  const SettingRow({
    super.key,
    required this.title,
    this.subtitle,
    required this.icon,
    required this.iconColor,
    this.trailing,
    this.onTap,
    this.enabled = true,
  });

  final String title;
  final String? subtitle;
  final IconData icon;
  final Color iconColor;

  /// السويتش أو السهم أو أي عنصر يظهر أقصى اليسار
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    final subTextColor = isDark ? Colors.white70 : Colors.black45;

    final content = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          // ① أيقونة — أقصى اليمين
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.13),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 12),
          // ② نص — وسط
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Cairo',
                  ),
                ),
                if (subtitle != null && subtitle!.isNotEmpty)
                  Text(
                    subtitle!,
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: subTextColor,
                      fontSize: 11,
                      fontFamily: 'Cairo',
                    ),
                  ),
              ],
            ),
          ),
          // ③ trailing — أقصى اليسار
          if (trailing != null) ...[
            const SizedBox(width: 12),
            trailing!,
          ],
        ],
      ),
    );

    return Opacity(
      opacity: enabled ? 1.0 : 0.45,
      child: TvFocusable(
        enabled: enabled,
        onPressed: onTap,
        borderRadius: BorderRadius.circular(14),
        focusColor: iconColor,
        child: content,
      ),
    );
  }
}

/// نسخة SettingRow مع CupertinoSwitch جاهز
class SettingToggleRow extends StatelessWidget {
  const SettingToggleRow({
    super.key,
    required this.title,
    this.subtitle,
    required this.icon,
    required this.iconColor,
    required this.value,
    required this.onChanged,
    this.enabled = true,
    this.activeColor,
  });

  final String title;
  final String? subtitle;
  final IconData icon;
  final Color iconColor;
  final bool value;
  final ValueChanged<bool> onChanged;
  final bool enabled;
  final Color? activeColor;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final defaultActive =
        isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    final inactive =
        isDark ? Colors.white24 : Colors.black.withValues(alpha: 0.10);

    return SettingRow(
      title: title,
      subtitle: subtitle,
      icon: icon,
      iconColor: iconColor,
      enabled: enabled,
      onTap: enabled ? () => onChanged(!value) : null,
      trailing: ExcludeFocus(
        child: CupertinoSwitch(
          value: value,
          activeTrackColor: activeColor ?? defaultActive,
          inactiveTrackColor: inactive,
          onChanged: enabled ? onChanged : null,
        ),
      ),
    );
  }
}

/// نسخة SettingRow مع سهم للتنقل
class SettingNavRow extends StatelessWidget {
  const SettingNavRow({
    super.key,
    required this.title,
    this.subtitle,
    required this.icon,
    required this.iconColor,
    required this.onTap,
  });

  final String title;
  final String? subtitle;
  final IconData icon;
  final Color iconColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SettingRow(
      title: title,
      subtitle: subtitle,
      icon: icon,
      iconColor: iconColor,
      onTap: onTap,
      trailing: Icon(
        Icons.arrow_back_ios_new_rounded,
        color: isDark ? Colors.white54 : Colors.black26,
        size: 14,
      ),
    );
  }
}
