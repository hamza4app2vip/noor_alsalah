import 'package:flutter/material.dart';
import 'dart:ui';
import 'dart:math' as math;
import '../tv/tv_remote_support.dart';

class PremiumGlassNavbar extends StatefulWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final VoidCallback? onNotificationTap;
  final bool hasNotifications;
  final bool showBell;
  final bool showBackButton;
  final Widget? leading;
  final List<Widget>? actions;

  const PremiumGlassNavbar({
    super.key,
    required this.title,
    this.onBackTap,
    this.onNotificationTap,
    this.hasNotifications = false,
    this.showBell = false,
    this.showBackButton = true,
    this.leading,
    this.actions,
  });

  @override
  Size get preferredSize => const Size.fromHeight(100.0);

  @override
  State<PremiumGlassNavbar> createState() => _PremiumGlassNavbarState();
}

class _PremiumGlassNavbarState extends State<PremiumGlassNavbar>
    with TickerProviderStateMixin {
  // Back button jelly animation
  late AnimationController _jellyController;
  late Animation<double> _scaleXAnimation;
  late Animation<double> _scaleYAnimation;

  // Bell ring animation
  late AnimationController _bellController;
  late Animation<double> _bellRotationAnimation;
  late Animation<double> _bellScaleAnimation;

  // Bell dot animation
  late AnimationController _bellDotController;
  late Animation<double> _bellDotOpacityAnimation;
  late Animation<double> _bellDotScaleAnimation;
  late Animation<double> _bellDotTranslateYAnimation;

  @override
  void initState() {
    super.initState();

    // 1. Jelly Squish Animation Setup (0.6s)
    _jellyController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _scaleXAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.25), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 1.25, end: 0.75), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 0.75, end: 1.15), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 1.15, end: 0.95), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 0.95, end: 1.05), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 1.05, end: 1.0), weight: 20),
    ]).animate(CurvedAnimation(
      parent: _jellyController,
      curve: const Cubic(0.25, 0.46, 0.45, 0.94),
    ));

    _scaleYAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.75), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 0.75, end: 1.25), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 1.25, end: 0.85), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 0.85, end: 1.05), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 1.05, end: 0.95), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 0.95, end: 1.0), weight: 20),
    ]).animate(CurvedAnimation(
      parent: _jellyController,
      curve: const Cubic(0.25, 0.46, 0.45, 0.94),
    ));

    // 2. Bell Ring Animation Setup (0.8s)
    _bellController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    final bellCurve = CurvedAnimation(
      parent: _bellController,
      curve: const Cubic(0.16, 1.0, 0.3, 1.0),
    );

    _bellScaleAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.1), weight: 10),
      TweenSequenceItem(tween: ConstantTween(1.1), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.1, end: 1.0), weight: 10),
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 30),
    ]).animate(bellCurve);

    _bellRotationAnimation = TweenSequence<double>([
      TweenSequenceItem(
          tween: Tween(begin: 0.0, end: 5.0 * math.pi / 180), weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: 5.0 * math.pi / 180, end: -5.0 * math.pi / 180),
          weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: -5.0 * math.pi / 180, end: 5.0 * math.pi / 180),
          weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: 5.0 * math.pi / 180, end: -5.0 * math.pi / 180),
          weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: -5.0 * math.pi / 180, end: 0.0), weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: 0.0, end: 5.0 * math.pi / 180), weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: 5.0 * math.pi / 180, end: -5.0 * math.pi / 180),
          weight: 10),
      TweenSequenceItem(
          tween: Tween(begin: -5.0 * math.pi / 180, end: 0.0), weight: 10),
      TweenSequenceItem(tween: ConstantTween(0.0), weight: 20),
    ]).animate(bellCurve);

    // 3. Bell Dot Slide Up Animation
    _bellDotController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    final bellDotCurve = CurvedAnimation(
      parent: _bellDotController,
      curve: const Cubic(0.16, 1.0, 0.3, 1.0),
    );

    _bellDotScaleAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.2), weight: 60),
      TweenSequenceItem(tween: Tween(begin: 1.2, end: 1.0), weight: 40),
    ]).animate(bellDotCurve);

    _bellDotTranslateYAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -2.0), weight: 60),
      TweenSequenceItem(tween: Tween(begin: -2.0, end: 0.0), weight: 40),
    ]).animate(bellDotCurve);

    _bellDotOpacityAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 60),
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 40),
    ]).animate(bellDotCurve);

    if (widget.hasNotifications) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _bellController.forward();
        _bellDotController.forward();
      });
    }
  }

  @override
  void didUpdateWidget(PremiumGlassNavbar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.hasNotifications != oldWidget.hasNotifications) {
      if (widget.hasNotifications) {
        _bellController.forward(from: 0.0);
        _bellDotController.forward(from: 0.0);
      } else {
        _bellController.reverse();
        _bellDotController.reverse();
      }
    }
  }

  @override
  void dispose() {
    _jellyController.dispose();
    _bellController.dispose();
    _bellDotController.dispose();
    super.dispose();
  }

  void _onBackBtnTap() {
    if (_jellyController.isAnimating) return;
    _jellyController.forward(from: 0.0);
    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      if (widget.onBackTap != null) {
        widget.onBackTap!();
      } else {
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color textColor = isDark ? Colors.white : Colors.black;
    final Color shadowColor =
        isDark ? const Color.fromRGBO(0, 0, 0, 0.3) : Colors.transparent;
    final textDirection = Directionality.of(context);
    final bool hasActions =
        widget.actions != null && widget.actions!.isNotEmpty;
    final bool hasLeadingControl =
        widget.leading != null || widget.showBackButton;
    double estimatedActionsWidth(List<Widget>? actions) {
      if (actions == null || actions.isEmpty) return 0.0;
      final width = actions.fold<double>(0.0, (sum, child) {
        if (child is SizedBox) {
          return sum + (child.width ?? 8.0);
        }
        return sum + 40.0;
      });
      return width.clamp(48.0, 160.0).toDouble();
    }

    Widget? leadingControl;
    if (widget.leading != null) {
      leadingControl = widget.leading!;
    } else if (widget.showBackButton) {
      leadingControl = AnimatedBuilder(
        animation: _jellyController,
        builder: (context, child) {
          return Transform(
            transform: Matrix4.diagonal3Values(
                _scaleXAnimation.value, _scaleYAnimation.value, 1.0),
            alignment: Alignment.center,
            child: child,
          );
        },
        child: TvFocusable(
          onPressed: _onBackBtnTap,
          borderRadius: BorderRadius.circular(26.0),
          child: PremiumGlassSurface(
            key: const ValueKey('premium-navbar-back'),
            width: 52.0,
            height: 52.0,
            borderRadius: 26.0,
            shadowColor: shadowColor,
            child: Icon(
              textDirection == TextDirection.rtl
                  ? Icons.arrow_forward_ios_rounded
                  : Icons.arrow_back_ios_new_rounded,
              color: textColor,
              size: 18.0,
            ),
          ),
        ),
      );
    }

    final double leadingSlotWidth = widget.showBell ? 40.0 : 0.0;
    final double trailingSlotWidth = estimatedActionsWidth(widget.actions);
    final double titleHorizontalPadding =
        18.0 + math.max(leadingSlotWidth, trailingSlotWidth);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 24.0,
        left: 20.0,
        right: 20.0,
        bottom: 16.0,
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 800),
          child: Row(
            textDirection: textDirection,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (leadingControl != null) leadingControl,
              if (hasLeadingControl) const SizedBox(width: 12.0),
              Expanded(
                child: PremiumGlassSurface(
                  height: 52.0,
                  borderRadius: 26.0,
                  shadowColor: shadowColor,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Positioned.fill(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 14.0),
                          child: Row(
                            children: [
                              SizedBox(
                                width: leadingSlotWidth,
                                child: widget.showBell
                                    ? Align(
                                        alignment:
                                            AlignmentDirectional.centerStart,
                                        child: _buildBellBtn(textColor),
                                      )
                                    : const SizedBox.shrink(),
                              ),
                              const Spacer(),
                              SizedBox(
                                width: trailingSlotWidth,
                                child: hasActions
                                    ? Align(
                                        alignment:
                                            AlignmentDirectional.centerEnd,
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: widget.actions!,
                                        ),
                                      )
                                    : const SizedBox.shrink(),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                            horizontal: titleHorizontalPadding,
                          ),
                          child: Center(
                            child: Text(
                              widget.title,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 15.0,
                                fontWeight: FontWeight.w600,
                                color: textColor,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBellBtn(Color iconColor) {
    return TvFocusable(
      onPressed: () {
        if (widget.onNotificationTap != null) {
          widget.onNotificationTap!();
        }
      },
      borderRadius: BorderRadius.circular(12.0),
      child: SizedBox(
        width: 40.0,
        height: 40.0,
        child: Stack(
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: [
            AnimatedBuilder(
              animation: _bellController,
              builder: (context, child) {
                return Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..multiply(Matrix4.diagonal3Values(
                        _bellScaleAnimation.value,
                        _bellScaleAnimation.value,
                        1.0))
                    ..multiply(Matrix4.rotationZ(_bellRotationAnimation.value)),
                  child: child,
                );
              },
              child: CustomPaint(
                size: const Size(20, 20),
                painter: _BellIconPainter(color: iconColor),
              ),
            ),
            Positioned(
              top: 8.0,
              right: 8.0,
              child: AnimatedBuilder(
                animation: _bellDotController,
                builder: (context, child) {
                  return Opacity(
                    opacity: _bellDotOpacityAnimation.value,
                    child: Transform.translate(
                      offset: Offset(0, _bellDotTranslateYAnimation.value),
                      child: Transform.scale(
                        scale: _bellDotScaleAnimation.value,
                        child: child,
                      ),
                    ),
                  );
                },
                child: Container(
                  width: 7.0,
                  height: 7.0,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFF3B30),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PremiumGlassSurface extends StatelessWidget {
  final Widget child;
  final double? width;
  final double? height;
  final double borderRadius;
  final EdgeInsets padding;
  final Color shadowColor;
  final bool useBackdropBlur;

  const PremiumGlassSurface({
    super.key,
    required this.child,
    this.width,
    this.height,
    required this.borderRadius,
    this.padding = EdgeInsets.zero,
    this.shadowColor = const Color.fromRGBO(0, 0, 0, 0.3),
    this.useBackdropBlur = true,
  });

  @override
  Widget build(BuildContext context) {
    final body = Container(
      decoration: BoxDecoration(
        color: const Color.fromRGBO(255, 255, 255, 0.02),
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
          color: const Color.fromRGBO(255, 255, 255, 0.12),
          width: 1.0,
        ),
      ),
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(borderRadius - 1),
              border: const Border(
                top: BorderSide(
                  color: Color.fromRGBO(255, 255, 255, 0.3),
                  width: 1.0,
                ),
              ),
            ),
          ),
          Padding(
            padding: padding,
            child: child,
          ),
        ],
      ),
    );

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            offset: const Offset(0, 15),
            blurRadius: 30.0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: useBackdropBlur
            ? BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
                child: body,
              )
            : body,
      ),
    );
  }
}

class _BellIconPainter extends CustomPainter {
  final Color color;
  _BellIconPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final Path path1 = Path()
      ..moveTo(18, 8)
      ..arcToPoint(
        const Offset(6, 8),
        radius: const Radius.circular(6),
        clockwise: false,
      )
      ..cubicTo(6, 15, 3, 17, 3, 17)
      ..lineTo(21, 17)
      ..cubicTo(21, 17, 18, 15, 18, 8)
      ..close();

    final Path path2 = Path()
      ..moveTo(13.73, 21)
      ..cubicTo(13.5542, 21.3031, 13.3019, 21.5547, 12.9982, 21.7295)
      ..cubicTo(12.6946, 21.9044, 12.3504, 21.9965, 12, 21.9965)
      ..cubicTo(11.6496, 21.9965, 11.3054, 21.9044, 11.0018, 21.7295)
      ..cubicTo(10.6982, 21.5547, 10.4458, 21.3031, 10.27, 21);

    final Matrix4 matrix =
        Matrix4.diagonal3Values(size.width / 24, size.height / 24, 1.0);

    canvas.drawPath(path1.transform(matrix.storage), paint);
    canvas.drawPath(path2.transform(matrix.storage), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
