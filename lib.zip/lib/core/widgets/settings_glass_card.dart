import 'dart:ui';
import 'package:flutter/material.dart';

class SettingsGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final Widget? header;

  const SettingsGlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 24.0,
    this.header,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final glassTop = isDark ? const Color(0xFF0F172A).withValues(alpha: 0.26) : Colors.white.withValues(alpha: 0.12);
    final glassBottom = isDark ? const Color(0xFF17233F).withValues(alpha: 0.14) : Colors.white.withValues(alpha: 0.04);
    final borderColor = isDark ? Colors.white.withValues(alpha: 0.10) : Colors.white.withValues(alpha: 0.12);
    final shadowColor = isDark ? Colors.black.withValues(alpha: 0.18) : Colors.black.withValues(alpha: 0.08);
    final highlightColor = isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white.withValues(alpha: 0.06);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 7, sigmaY: 7),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [glassTop, glassBottom],
              ),
              border: Border.all(
                color: borderColor,
                width: 1.4,
              ),
              borderRadius: BorderRadius.circular(borderRadius),
              boxShadow: [
                BoxShadow(
                  color: shadowColor,
                  blurRadius: 30,
                  offset: const Offset(0, 18),
                ),
                BoxShadow(
                  color: highlightColor,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}
