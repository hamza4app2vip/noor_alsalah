import 'dart:ui';
import 'package:flutter/material.dart';
import '../tv/tv_remote_support.dart';

class LuxuryTimePicker extends StatefulWidget {
  final TimeOfDay initialTime;
  final String title;

  const LuxuryTimePicker({
    super.key,
    required this.initialTime,
    this.title = 'اختر الوقت',
  });

  @override
  State<LuxuryTimePicker> createState() => _LuxuryTimePickerState();

  static Future<TimeOfDay?> show(BuildContext context, {TimeOfDay? initialTime, String? title}) {
    return showDialog<TimeOfDay>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.6),
      builder: (context) => LuxuryTimePicker(
        initialTime: initialTime ?? TimeOfDay.now(),
        title: title ?? 'اختر الوقت',
      ),
    );
  }
}

class _LuxuryTimePickerState extends State<LuxuryTimePicker> {
  late int _hour;
  late int _minute;
  late DayPeriod _period;

  @override
  void initState() {
    super.initState();
    _hour = widget.initialTime.hourOfPeriod == 0 ? 12 : widget.initialTime.hourOfPeriod;
    _minute = widget.initialTime.minute;
    _period = widget.initialTime.period;
  }

  void _incrementHour() {
    setState(() {
      _hour = (_hour % 12) + 1;
    });
  }

  void _decrementHour() {
    setState(() {
      _hour = _hour == 1 ? 12 : _hour - 1;
    });
  }

  void _incrementMinute() {
    setState(() {
      _minute = (_minute + 1) % 60;
    });
  }

  void _decrementMinute() {
    setState(() {
      _minute = _minute == 0 ? 59 : _minute - 1;
    });
  }

  void _togglePeriod() {
    setState(() {
      _period = _period == DayPeriod.am ? DayPeriod.pm : DayPeriod.am;
    });
  }

  TimeOfDay _getResult() {
    int h = _hour % 12;
    if (_period == DayPeriod.pm) h += 12;
    return TimeOfDay(hour: h, minute: _minute);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    final darkGreenText = isDark ? Colors.white : const Color(0xFF08452F);

    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 400),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.1)
                    : Colors.white.withValues(alpha: 0.4),
                width: 1.5,
              ),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isDark
                    ? [
                        Colors.black.withValues(alpha: 0.4),
                        Colors.black.withValues(alpha: 0.2),
                      ]
                    : [
                        Colors.white.withValues(alpha: 0.5),
                        Colors.white.withValues(alpha: 0.2),
                      ],
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 30,
                  spreadRadius: 5,
                )
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Expanded(
                        child: Text(
                          widget.title,
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: darkGreenText,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.close,
                            color: isDark ? Colors.white54 : Colors.black54),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // Time Pickers
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  textDirection: TextDirection.ltr,
                  children: [
                    _buildPickerColumn(
                      context,
                      value: _hour.toString().padLeft(2, '0'),
                      onIncrement: _incrementHour,
                      onDecrement: _decrementHour,
                      label: 'ساعة',
                      accent: accent,
                      isDark: isDark,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text(
                        ':',
                        style: TextStyle(
                          color: darkGreenText.withValues(alpha: 0.8),
                          fontSize: 48,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    _buildPickerColumn(
                      context,
                      value: _minute.toString().padLeft(2, '0'),
                      onIncrement: _incrementMinute,
                      onDecrement: _decrementMinute,
                      label: 'دقيقة',
                      accent: accent,
                      isDark: isDark,
                    ),
                    const SizedBox(width: 20),
                    _buildPeriodToggle(context, accent, isDark, darkGreenText),
                  ],
                ),

                const SizedBox(height: 40),

                // Actions
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 30),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildActionButton(
                          context,
                          label: 'إلغاء',
                          onPressed: () => Navigator.pop(context),
                          isPrimary: false,
                          accent: accent,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildActionButton(
                          context,
                          label: 'تم',
                          onPressed: () => Navigator.pop(context, _getResult()),
                          isPrimary: true,
                          accent: accent,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPickerColumn(
    BuildContext context, {
    required String value,
    required VoidCallback onIncrement,
    required VoidCallback onDecrement,
    required String label,
    required Color accent,
    required bool isDark,
  }) {
    return Column(
      children: [
        _buildCounterBtn(Icons.keyboard_arrow_up_rounded, onIncrement, accent, isDark),
        const SizedBox(height: 12),
        Container(
          width: 80,
          height: 90,
          decoration: BoxDecoration(
            color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.05),
            ),
          ),
          alignment: Alignment.center,
          child: Text(
            value,
            style: TextStyle(
              color: isDark ? Colors.white : const Color(0xFF08452F),
              fontSize: 42,
              fontWeight: FontWeight.bold,
              fontFamily: 'Cairo', // Using Cairo for numerical consistency if possible or system
            ),
          ),
        ),
        const SizedBox(height: 12),
        _buildCounterBtn(Icons.keyboard_arrow_down_rounded, onDecrement, accent, isDark),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isDark ? Colors.white54 : Colors.black45,
            fontSize: 12,
            fontFamily: 'Cairo',
          ),
        ),
      ],
    );
  }

  Widget _buildCounterBtn(IconData icon, VoidCallback onTap, Color accent, bool isDark) {
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(15),
      focusColor: accent,
      child: Container(
        width: 50,
        height: 40,
        decoration: BoxDecoration(
          color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Icon(
          icon,
          color: isDark ? Colors.white70 : Colors.black54,
          size: 32,
        ),
      ),
    );
  }

  Widget _buildPeriodToggle(BuildContext context, Color accent, bool isDark, Color darkGreenText) {
    return Container(
      width: 55,
      height: 90,
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.05),
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(19),
        child: Column(
          children: [
            _buildPeriodOption('ص', DayPeriod.am, accent, isDark, darkGreenText),
            Container(
              height: 1,
              color: isDark ? Colors.white10 : Colors.black12,
            ),
            _buildPeriodOption('م', DayPeriod.pm, accent, isDark, darkGreenText),
          ],
        ),
      ),
    );
  }

  Widget _buildPeriodOption(String text, DayPeriod period, Color accent, bool isDark, Color darkGreenText) {
    final isSelected = _period == period;
    return Expanded(
      child: TvFocusable(
        onPressed: _togglePeriod,
        borderRadius: BorderRadius.zero,
        focusColor: accent.withValues(alpha: 0.3),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          decoration: BoxDecoration(
            color: isSelected ? accent : Colors.transparent,
          ),
          alignment: Alignment.center,
          child: Text(
            text,
            style: TextStyle(
              color: isSelected
                  ? (isDark ? Colors.black : Colors.white)
                  : (isDark ? Colors.white60 : Colors.black54),
              fontWeight: FontWeight.bold,
              fontSize: 18,
              fontFamily: 'Cairo',
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required String label,
    required VoidCallback onPressed,
    required bool isPrimary,
    required Color accent,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return TvFocusable(
      onPressed: onPressed,
      borderRadius: BorderRadius.circular(20),
      focusColor: isPrimary ? accent : (isDark ? Colors.white24 : Colors.black12),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 55,
        decoration: BoxDecoration(
          color: isPrimary
              ? accent
              : (isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.05)),
          borderRadius: BorderRadius.circular(20),
          border: isPrimary
              ? null
              : Border.all(
                  color: isDark ? Colors.white10 : Colors.black12,
                ),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            color: isPrimary
                ? (isDark ? Colors.black : Colors.white)
                : (isDark ? Colors.white : Colors.black87),
            fontWeight: FontWeight.bold,
            fontSize: 18,
            fontFamily: 'Cairo',
          ),
        ),
      ),
    );
  }
}
