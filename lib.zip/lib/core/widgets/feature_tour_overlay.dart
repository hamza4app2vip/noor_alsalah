import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class FeatureTourStep {
  final String titleAr;
  final String bodyAr;
  final String titleEn;
  final String bodyEn;
  final GlobalKey? targetKey;
  final EdgeInsets targetPadding;
  final double targetRadius;

  const FeatureTourStep({
    required this.titleAr,
    required this.bodyAr,
    required this.titleEn,
    required this.bodyEn,
    this.targetKey,
    this.targetPadding = EdgeInsets.zero,
    this.targetRadius = 22.0,
  });
}

class FeatureTourOverlay extends StatefulWidget {
  final List<FeatureTourStep> steps;
  final ValueChanged<bool> onFinish; // returns bool dontShowAgain
  final Color? activeColor;

  const FeatureTourOverlay({
    super.key,
    required this.steps,
    required this.onFinish,
    this.activeColor,
  });

  static Future<bool> show(
    BuildContext context, {
    required List<FeatureTourStep> steps,
    Color? activeColor,
  }) async {
    if (steps.isEmpty) return false;
    final overlay = Overlay.of(context, rootOverlay: true);

    final completer = Completer<bool>();
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => FeatureTourOverlay(
        steps: steps,
        activeColor: activeColor,
        onFinish: (dontShowAgain) {
          entry.remove();
          if (!completer.isCompleted) completer.complete(dontShowAgain);
        },
      ),
    );
    overlay.insert(entry);
    return completer.future;
  }

  @override
  State<FeatureTourOverlay> createState() => _FeatureTourOverlayState();
}

class _FeatureTourOverlayState extends State<FeatureTourOverlay> {
  int _index = 0;
  Rect? _targetRect;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initializeStep());
  }

  Future<void> _initializeStep() async {
    final step = widget.steps[_index];
    if (step.targetKey?.currentContext != null) {
      await Scrollable.ensureVisible(
        step.targetKey!.currentContext!,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeInOutCubic,
        alignment: 0.18,
      );
      await WidgetsBinding.instance.endOfFrame;
      await Future<void>.delayed(const Duration(milliseconds: 24));
    }
    if (mounted) {
      _updateTargetRect();
    }
  }

  Rect? _resolveTargetRect(FeatureTourStep step) {
    final key = step.targetKey;
    if (key == null || key.currentContext == null) {
      return null;
    }

    final render = key.currentContext!.findRenderObject();
    if (render is! RenderBox || !render.hasSize) {
      return null;
    }

    final mediaQuery = MediaQuery.maybeOf(context);
    final screenSize = mediaQuery?.size;
    final mediaPadding = mediaQuery?.padding ?? EdgeInsets.zero;
    if (screenSize == null) {
      return null;
    }

    Rect rect = MatrixUtils.transformRect(
      render.getTransformTo(null),
      Offset.zero & render.size,
    );

    rect = Rect.fromLTRB(
      rect.left - step.targetPadding.left,
      rect.top - step.targetPadding.top,
      rect.right + step.targetPadding.right,
      rect.bottom + step.targetPadding.bottom,
    );

    final safeRect = Rect.fromLTRB(
      8.0,
      mediaPadding.top + 8.0,
      screenSize.width - 8.0,
      screenSize.height - mediaPadding.bottom - 8.0,
    );

    return Rect.fromLTRB(
      rect.left.clamp(safeRect.left, safeRect.right),
      rect.top.clamp(safeRect.top, safeRect.bottom),
      rect.right.clamp(safeRect.left, safeRect.right),
      rect.bottom.clamp(safeRect.top, safeRect.bottom),
    );
  }

  void _updateTargetRect() {
    final step = widget.steps[_index];
    setState(() {
      _targetRect = _resolveTargetRect(step);
    });
  }

  Future<void> _next() async {
    if (_index + 1 >= widget.steps.length) {
      widget.onFinish(false); // Completed normally, show again next time
      return;
    }

    setState(() {
      _index++;
      _targetRect = null; // hide ring while scrolling
    });

    await _initializeStep(); // Scroll and update rect
  }

  void _skip() {
    widget.onFinish(true); // Don't show again
  }

  @override
  Widget build(BuildContext context) {
    final isAr = Localizations.localeOf(context).languageCode == 'ar';
    final step = widget.steps[_index];
    final title = isAr ? step.titleAr : step.titleEn;
    final body = isAr ? step.bodyAr : step.bodyEn;

    final size = MediaQuery.of(context).size;
    final target = _targetRect;
    final themeColor =
        widget.activeColor ?? Theme.of(context).colorScheme.primary;
    final targetRadius = widget.steps[_index].targetRadius;

    return Directionality(
        textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
        child: Material(
            type: MaterialType.transparency,
            child: FocusScope(
              autofocus: true,
              child: Focus(
                onKeyEvent: (node, event) {
                  if (event is KeyDownEvent) {
                    if (event.logicalKey == LogicalKeyboardKey.escape ||
                        event.logicalKey == LogicalKeyboardKey.goBack) {
                      widget.onFinish(false); // Cancelled, show again next time
                      return KeyEventResult.handled;
                    }
                  }
                  return KeyEventResult.ignored;
                },
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: ClipPath(
                        clipper:
                            _BlurClipper(target: target, radius: targetRadius),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                          child: Container(
                            color: Colors.black.withValues(alpha: 0.18),
                          ),
                        ),
                      ),
                    ),
                    if (target != null)
                      Positioned.fromRect(
                        rect: target,
                        child: const IgnorePointer(
                          child: SizedBox(
                            key: ValueKey('feature-tour-target-frame'),
                          ),
                        ),
                      ),
                    FocusScope(
                      child: Stack(
                        children: [
                          if (target != null)
                            Positioned(
                              left: 20,
                              right: 20,
                              top: (target.center.dy < size.height / 2)
                                  ? target.bottom + 20
                                  : null,
                              bottom: (target.center.dy >= size.height / 2)
                                  ? (size.height - target.top) + 20
                                  : null,
                              child: SafeArea(
                                child: _buildInfoCard(
                                    title, body, themeColor, isAr, size),
                              ),
                            )
                          else
                            Positioned.fill(
                              child: SafeArea(
                                child: Center(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20),
                                    child: _buildInfoCard(
                                        title, body, themeColor, isAr, size),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )));
  }

  Widget _buildFocusableButton({
    required Widget child,
    required VoidCallback onPressed,
    required Color baseColor,
    required Color textColor,
    Color? outlineColor,
    bool autoFocus = false,
  }) {
    return Focus(
      autofocus: autoFocus,
      onKeyEvent: (node, event) {
        if (event is KeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.select ||
              event.logicalKey == LogicalKeyboardKey.enter ||
              event.logicalKey == LogicalKeyboardKey.numpadEnter ||
              event.logicalKey == LogicalKeyboardKey.mediaPlayPause ||
              event.logicalKey == LogicalKeyboardKey.space) {
            onPressed();
            return KeyEventResult.handled;
          }
        }
        return KeyEventResult.ignored;
      },
      child: Builder(builder: (context) {
        final isFocused = Focus.of(context).hasFocus;
        return AnimatedScale(
          scale: isFocused ? 1.05 : 1.0,
          duration: const Duration(milliseconds: 200),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              boxShadow: isFocused
                  ? [
                      BoxShadow(
                          color: baseColor.withValues(alpha: 0.6),
                          blurRadius: 12,
                          spreadRadius: 2)
                    ]
                  : null,
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: baseColor,
                foregroundColor: textColor,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                side: isFocused
                    ? BorderSide(color: outlineColor ?? Colors.white, width: 2)
                    : BorderSide.none,
                elevation: 0,
              ),
              onPressed: onPressed,
              child: child,
            ),
          ),
        );
      }),
    );
  }

  Widget _buildInfoCard(
      String title, String body, Color themeColor, bool isAr, Size size) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final dontShowTextColor = isDark ? Colors.white70 : Colors.black87;
    final dontShowBaseColor = isDark
        ? Colors.white.withValues(alpha: 0.1)
        : Colors.black.withValues(alpha: 0.05);
    final outlineColor = isDark ? Colors.white : Colors.black87;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              width: math.min(size.width, size.width > 900 ? 840 : 640),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: themeColor.withValues(alpha: 0.6), width: 1.5),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withValues(alpha: 0.15),
                    Colors.black.withValues(alpha: 0.3),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 20,
                    spreadRadius: 5,
                  )
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    body,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '(${_index + 1}/${widget.steps.length})',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        FocusTraversalGroup(
          policy: OrderedTraversalPolicy(),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final stackVertically = constraints.maxWidth < 420;
              final secondaryButton = FocusTraversalOrder(
                order: const NumericFocusOrder(2),
                child: _buildFocusableButton(
                  baseColor: dontShowBaseColor,
                  textColor: dontShowTextColor,
                  outlineColor: outlineColor,
                  onPressed: _skip,
                  child: Text(
                    isAr ? 'عدم العرض مرة أخرى' : "Don't show again",
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
              );
              final primaryButton = FocusTraversalOrder(
                order: const NumericFocusOrder(1),
                child: _buildFocusableButton(
                  autoFocus: true,
                  baseColor: themeColor,
                  textColor: Colors.white,
                  outlineColor: outlineColor,
                  onPressed: _next,
                  child: Text(
                    _index + 1 >= widget.steps.length
                        ? (isAr ? 'إنهاء' : 'Finish')
                        : (isAr ? 'متابعة' : 'Next'),
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                ),
              );

              if (stackVertically) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    secondaryButton,
                    const SizedBox(height: 12),
                    primaryButton,
                  ],
                );
              }

              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(child: secondaryButton),
                  const SizedBox(width: 12),
                  Flexible(child: primaryButton),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}

class _BlurClipper extends CustomClipper<Path> {
  final Rect? target;
  final double radius;
  const _BlurClipper({this.target, this.radius = 22.0});

  @override
  Path getClip(Size size) {
    final full = Path()..addRect(Rect.fromLTWH(0, 0, size.width, size.height));
    if (target == null) return full;
    final hole = Path()
      ..addRRect(RRect.fromRectAndRadius(target!, Radius.circular(radius)));
    return Path.combine(PathOperation.difference, full, hole);
  }

  @override
  bool shouldReclip(_BlurClipper oldClipper) {
    return oldClipper.target != target;
  }
}
