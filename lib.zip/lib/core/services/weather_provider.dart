import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'weather_service.dart';
import '../../features/settings/presentation/providers/settings_provider.dart';

final weatherServiceProvider = Provider<WeatherService>((ref) {
  return WeatherService();
});

final weatherForecastProvider = FutureProvider<List<WeatherForecast>?>((ref) async {
  final settings = ref.watch(settingsNotifierProvider);
  if (!settings.weatherEnabled) return null;
  
  final service = ref.watch(weatherServiceProvider);
  return await service.getDailyForecast(settings);
});
