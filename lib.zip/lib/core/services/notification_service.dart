import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

class NotificationConfig {
  final String title;
  final String message;
  final String? titleEn;
  final String? messageEn;
  final String? icon;
  final String? color;
  final List<String>? items;
  final List<String>? itemsEn;

  const NotificationConfig({
    required this.title,
    required this.message,
    this.titleEn,
    this.messageEn,
    this.icon,
    this.color,
    this.items,
    this.itemsEn,
  });

  factory NotificationConfig.fromJson(Map<String, dynamic> json) {
    return NotificationConfig(
      title: json['title']?.toString() ?? '',
      message: json['message']?.toString() ?? '',
      titleEn: json['title_en']?.toString(),
      messageEn: json['message_en']?.toString(),
      icon: json['icon']?.toString(),
      color: json['color']?.toString(),
      items: json['items'] != null
          ? List<String>.from(
              json['items'].map((item) => item.toString()),
            )
          : null,
      itemsEn: json['items_en'] != null
          ? List<String>.from(
              json['items_en'].map((item) => item.toString()),
            )
          : null,
    );
  }
}

class NotificationService {
  static NotificationService? _instance;
  static NotificationService get instance {
    _instance ??= NotificationService._();
    return _instance!;
  }

  NotificationService._();

  final Dio _dio = Dio();
  static const List<String> _remoteConfigUrls = [
    'https://raw.githubusercontent.com/hamza4app2vip/UPDATE_zinab/refs/heads/main/update.json',
    'https://raw.githubusercontent.com/hamza4app2vip/noor_alsalah/refs/heads/main/update.json',
  ];
  Map<String, dynamic>? _configCache;
  bool _autoPrompt = false;

  Future<Map<String, dynamic>> _loadConfig() async {
    if (_configCache != null) return _configCache!;

    try {
      _configCache = {}; // Start with empty if no cache

      for (final url in _remoteConfigUrls) {
        try {
          final response = await _dio.get(url);
          if (response.statusCode == 200 && response.data != null) {
            String rawStr = response.data.toString();
            // Lenient JSON: handle Python-style booleans
            rawStr = rawStr
                .replaceAll(': True', ': true')
                .replaceAll(': False', ': false')
                .replaceAll(':True', ':true')
                .replaceAll(':False', ':false');
                
            _configCache = json.decode(rawStr);
            _autoPrompt = _configCache?['auto_prompt'] == true;
            break;
          }
        } catch (e) {
          debugPrint('Failed to load remote notification config ($url): $e');
        }
      }

      return _configCache!;
    } catch (e) {
      debugPrint('Failed to load notification config: $e');
      return {};
    }
  }

  Future<NotificationConfig> getUpdateAvailableConfig() async {
    final config = await _loadConfig();
    return NotificationConfig.fromJson(config['update_available'] ?? {});
  }

  Future<NotificationConfig> getWhatsNewConfig() async {
    final config = await _loadConfig();
    return NotificationConfig.fromJson(config['whats_new'] ?? {});
  }

  Future<NotificationConfig> getAppUsageConfig() async {
    final config = await _loadConfig();
    return NotificationConfig.fromJson(config['app_usage'] ?? {});
  }

  Future<bool> shouldAutoPromptUpdate() async {
    await _loadConfig();
    return _autoPrompt;
  }

  void clearCache() {
    _configCache = null;
    _autoPrompt = false;
  }
}
