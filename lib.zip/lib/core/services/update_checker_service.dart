import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'dart:io';

import 'update_service.dart';
import '../../../features/settings/presentation/screens/app_update_screen.dart';
import '../../main.dart';

class UpdateCheckerService {
  static final UpdateCheckerService instance = UpdateCheckerService._internal();
  factory UpdateCheckerService() => instance;
  UpdateCheckerService._internal();

  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  final UpdateService _updateService = const UpdateService();
  bool _initialized = false;
  bool _hasUpdate = false;
  UpdateInfo? _latestUpdate;
  String _currentVersion = '';
 
  bool get hasUpdate => _hasUpdate;
  UpdateInfo? get latestUpdate => _latestUpdate;
  String get currentVersion => _currentVersion;

  Future<void> init() async {
    if (_initialized) return;

    const androidSettings = AndroidInitializationSettings('@mipmap/launcher_icon');
    const initSettings = InitializationSettings(android: androidSettings);

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        navigatorKey.currentState?.push(
          MaterialPageRoute(builder: (context) => const AppUpdateScreen()),
        );
      },
    );

    if (Platform.isAndroid) {
      await _notificationsPlugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    }

    _initialized = true;
    _checkForUpdateSilent();
  }

  Future<void> _checkForUpdateSilent() async {
    try {
      final current = await PackageInfo.fromPlatform();
      _currentVersion = current.version;
      final remoteInfo = await _updateService.fetchRemoteInfo(allowBundledFallback: false);
      final candidate = remoteInfo;

      if (candidate != null && _updateService.isNewerThanVersion(candidate, current.version)) {
        _hasUpdate = true;
        _latestUpdate = candidate;
        
        // Show notification
        const androidDetails = AndroidNotificationDetails(
          'update_channel',
          'تحديثات التطبيق',
          channelDescription: 'إشعارات توفر تحديثات جديدة للتطبيق',
          importance: Importance.high,
          priority: Priority.high,
        );
        const details = NotificationDetails(android: androidDetails);
        await _notificationsPlugin.show(
          0,
          'تحديث جديد متوفر!',
          'يتوفر إصدار جديد من تطبيق نور الصلاة (${candidate.version})، يرجى التحديث للحصول على أحدث الميزات.',
          details,
        );
      }
    } catch (e) {
      debugPrint('UpdateCheckerService: Silent check failed: $e');
    }
  }
}
