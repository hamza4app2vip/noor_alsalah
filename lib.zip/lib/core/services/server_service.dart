import 'dart:convert';
import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';
import 'package:shelf_cors_headers/shelf_cors_headers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'package:noor_prayer_tv/features/settings/presentation/providers/settings_provider.dart';
import 'package:noor_prayer_tv/features/settings/domain/entities/app_settings.dart';
import 'package:noor_prayer_tv/features/prayer_times/presentation/providers/timer_engine_provider.dart';

// Provider للتحكم في دورة حياة السيرفر
final serverServiceProvider = Provider<ServerService>((ref) {
  final service = ServerService(ref);
  ref.onDispose(() => service.stop()); // الإيقاف عند غلق التطبيق
  return service;
});

class ServerService {
  final Ref _ref;
  HttpServer? _server;

  ServerService(this._ref);

  Future<void> start({int port = 8080}) async {
    if (_server != null) return; // السيرفر يعمل بالفعل

    final router = Router();

    // مسار 0: واجهة التحكم عبر الويب
    router.get('/', (Request request) async {
      try {
        final htmlContent = await rootBundle.loadString('assets/web/remote.html');
        return Response.ok(
          htmlContent,
          headers: {'Content-Type': 'text/html; charset=utf-8'},
        );
      } catch (e) {
        return Response.internalServerError(body: 'Failed to load remote interface');
      }
    });

    // مسار 0.1: كود الجافا سكريبت للواجهة
    router.get('/remote.i18n.js', (Request request) async {
      try {
        final jsContent = await rootBundle.loadString('assets/web/remote.i18n.js');
        return Response.ok(
          jsContent,
          headers: {'Content-Type': 'application/javascript'},
        );
      } catch (e) {
        return Response.notFound('remote.i18n.js not found');
      }
    });

    router.get('/remote.js', (Request request) async {
      try {
        final jsContent = await rootBundle.loadString('assets/web/remote.js');
        return Response.ok(
          jsContent,
          headers: {'Content-Type': 'application/javascript'},
        );
      } catch (e) {
        return Response.notFound('remote.js not found');
      }
    });

    // مسار 0.2: كود التنسيق CSS للواجهة
    router.get('/remote.css', (Request request) async {
      try {
        final cssContent = await rootBundle.loadString('assets/web/remote.css');
        return Response.ok(
          cssContent,
          headers: {'Content-Type': 'text/css'},
        );
      } catch (e) {
        return Response.notFound('remote.css not found');
      }
    });

    // مسار 1: استرجاع الإعدادات الحالية
    router.get('/api/settings', (Request request) {
      final settings = _ref.read(settingsNotifierProvider);
      return Response.ok(
        jsonEncode(settings.toJson()),
        headers: {'Content-Type': 'application/json'},
      );
    });

    // مسار 2: تحديث الإعدادات (يتطلب JSON Body)
    router.post('/api/settings', (Request request) async {
       try {
         final payload = await request.readAsString();
         final map = jsonDecode(payload) as Map<String, dynamic>;
         
         // استرجاع الإعدادات الحالية حتى نقوم بتحديث الحقول المبعوثة فقط
         final currentSettings = _ref.read(settingsNotifierProvider);
         final currentMap = currentSettings.toJson();
         
         // دمج الإعدادات المرسلة مع الحالية
         final updatedMap = {...currentMap, ...map};
         
         final newSettings = AppSettings.fromJson(updatedMap);
         
         // حفظ الإعدادات وتحديث الواجهة
         _ref.read(settingsNotifierProvider.notifier).updateSettings(newSettings);

         return Response.ok(
           jsonEncode({'status': 'success', 'message': 'Settings updated successfully'}),
           headers: {'Content-Type': 'application/json'},
         );
       } catch (e) {
         return Response.internalServerError(
           body: jsonEncode({'status': 'error', 'message': e.toString()}),
           headers: {'Content-Type': 'application/json'},
         );
       }
    });

    // مسار 3: استرجاع معلومات الوقت ومرحلة الصلاة الحالية
    router.get('/api/state', (Request request) {
      final timerState = _ref.read(timerEngineProvider);
      
      final stateMap = {
        'timeUntilNextSeconds': timerState.timeUntilNext.inSeconds,
        'currentOrNextPrayer': timerState.currentOrNextPrayer.name,
        'phase': timerState.phase.name,
      };

      return Response.ok(
        jsonEncode(stateMap),
        headers: {'Content-Type': 'application/json'},
      );
    });

    // إعداد الـ Pipeline لإضافة الـ CORS والـ Logging
    final handler = const Pipeline()
        .addMiddleware(corsHeaders())
        .addMiddleware(logRequests())
        .addHandler(router.call);

    // تشغيل السيرفر على جميع الواجهات الشبكية
    _server = await io.serve(handler, InternetAddress.anyIPv4, port);
    debugPrint('Local server listening on port ${_server!.port}');
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
    debugPrint('Local server stopped.');
  }
}

