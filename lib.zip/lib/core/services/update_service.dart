import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'internet_service.dart';
import 'notification_service.dart';

class UpdateInfo {
  final String version;
  final String apkUrl;
  final int? sizeBytes;
  final String changelog;
  final String changelogEn;
  final NotificationConfig? updateAvailable;
  final NotificationConfig? whatsNew;
  final NotificationConfig? appUsage;
  final bool autoPrompt;
  final bool isMandatory;
  final bool showUpdateUi;
  final bool allowSkip;

  const UpdateInfo({
    required this.version,
    required this.apkUrl,
    this.sizeBytes,
    this.changelog = '',
    this.changelogEn = '',
    this.updateAvailable,
    this.whatsNew,
    this.appUsage,
    this.autoPrompt = false,
    this.isMandatory = false,
    this.showUpdateUi = true,
    this.allowSkip = false,
  });

  factory UpdateInfo.fromJson(Map<String, dynamic> json) {
    final changeLogValue = json['changelog'];
    final changeLogEnValue = json['changelog_en'];
    String changeLogText = '';
    String changeLogEnText = '';
    if (changeLogValue is String) {
      changeLogText = changeLogValue;
    } else if (changeLogValue is List) {
      changeLogText = changeLogValue.join('\n');
    }
    if (changeLogEnValue is String) {
      changeLogEnText = changeLogEnValue;
    } else if (changeLogEnValue is List) {
      changeLogEnText = changeLogEnValue.join('\n');
    }

    return UpdateInfo(
      version: json['version']?.toString() ?? '',
      apkUrl: json['apkUrl']?.toString() ?? '',
      sizeBytes: json['sizeBytes'] is int
          ? json['sizeBytes'] as int
          : int.tryParse(json['sizeBytes']?.toString() ?? ''),
      changelog: changeLogText,
      changelogEn: changeLogEnText,
      updateAvailable: json['update_available'] != null
          ? NotificationConfig.fromJson(json['update_available'])
          : null,
      whatsNew: json['whats_new'] != null
          ? NotificationConfig.fromJson(json['whats_new'])
          : null,
      appUsage: json['app_usage'] != null
          ? NotificationConfig.fromJson(json['app_usage'])
          : null,
      autoPrompt: json['auto_prompt'] == true,
      isMandatory: json['is_mandatory'] == true,
      showUpdateUi: json['show_update_ui'] ?? true,
      allowSkip: json['allow_skip'] == true,
    );
  }
}

class UpdateDownloadState {
  final String finalPath;
  final String partialPath;
  final int receivedBytes;
  final int totalBytes;
  final bool isCompleted;

  const UpdateDownloadState({
    required this.finalPath,
    required this.partialPath,
    required this.receivedBytes,
    required this.totalBytes,
    required this.isCompleted,
  });
}

class UpdateService {
  const UpdateService();

  static const List<String> updateJsonUrls = [
    'https://raw.githubusercontent.com/hamza4app2vip/UPDATE_zinab/refs/heads/main/update.json',
    'https://raw.githubusercontent.com/hamza4app2vip/noor_alsalah/refs/heads/main/update.json',
  ];

  Dio _dio() => Dio(
        BaseOptions(
          connectTimeout: const Duration(seconds: 12),
          receiveTimeout: const Duration(seconds: 20),
          sendTimeout: const Duration(seconds: 12),
        ),
      );

  Future<UpdateInfo?> fetchRemoteInfo(
      {bool allowBundledFallback = false}) async {
    final hasInternet = await InternetService().hasInternet();
    if (!hasInternet) {
      debugPrint('UpdateService: No internet connection detected.');
      return null;
    }

    for (final url in updateJsonUrls) {
      try {
        final response = await _dio().get(url);
        if (response.statusCode != 200 || response.data == null) continue;

        final info = _parseInfo(response.data);
        if (info != null) return info;
      } catch (e) {
        debugPrint('UpdateService: failed to load $url -> $e');
      }
    }

    return null;
  }

  Future<UpdateInfo?> loadBundledInfo() async => null;

  UpdateInfo? _parseInfo(dynamic raw) {
    try {
      Map<String, dynamic> payload;

      if (raw is Map<String, dynamic>) {
        payload = Map<String, dynamic>.from(raw);
      } else {
        String rawStr = raw.toString();
        rawStr = rawStr
            .replaceAll(': True', ': true')
            .replaceAll(': False', ': false')
            .replaceAll(':True', ':true')
            .replaceAll(':False', ':false');

        payload = Map<String, dynamic>.from(
          jsonDecode(rawStr) as Map<String, dynamic>,
        );
      }

      final info = UpdateInfo.fromJson(payload);
      if (info.version.isEmpty || info.apkUrl.isEmpty) return null;
      return info;
    } catch (e) {
      debugPrint('UpdateService: parse error -> $e');
      return null;
    }
  }

  Future<bool> isRemoteNewer(UpdateInfo remote, PackageInfo current) async {
    return _compareVersions(remote.version, current.version) > 0;
  }

  bool isNewerThanVersion(UpdateInfo candidate, String currentVersion) {
    return _compareVersions(candidate.version, currentVersion) > 0;
  }

  UpdateInfo? pickNewer(UpdateInfo? a, UpdateInfo? b) {
    if (a == null) return b;
    if (b == null) return a;
    return _compareVersions(a.version, b.version) >= 0 ? a : b;
  }

  int _compareVersions(String a, String b) {
    List<int> parse(String value) {
      final parts = value.split('+');
      final versionCore =
          parts.first.split('.').map(int.tryParse).map((e) => e ?? 0).toList();
      while (versionCore.length < 3) {
        versionCore.add(0);
      }
      final buildNumber = parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0;
      versionCore.add(buildNumber);
      return versionCore;
    }

    final left = parse(a);
    final right = parse(b);
    final length = left.length > right.length ? left.length : right.length;
    for (var i = 0; i < length; i++) {
      final l = i < left.length ? left[i] : 0;
      final r = i < right.length ? right[i] : 0;
      if (l > r) return 1;
      if (l < r) return -1;
    }
    return 0;
  }

  Future<Directory> _getUpdatesDir() async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(root.path, 'updates'));
    if (!dir.existsSync()) {
      dir.createSync(recursive: true);
    }
    return dir;
  }

  String _safeVersion(String version) {
    return version.replaceAll(RegExp(r'[^0-9A-Za-z._-]+'), '_');
  }

  Future<String> _getFinalApkPath(UpdateInfo info) async {
    final dir = await _getUpdatesDir();
    return p.join(dir.path, 'noor_update_${_safeVersion(info.version)}.apk');
  }

  Future<String> _getPartialApkPath(UpdateInfo info) async {
    final finalPath = await _getFinalApkPath(info);
    return '$finalPath.part';
  }

  int? _parseTotalFromContentRange(String? contentRange) {
    if (contentRange == null || contentRange.isEmpty) return null;
    final match = RegExp(r'/(\d+)$').firstMatch(contentRange);
    if (match == null) return null;
    return int.tryParse(match.group(1)!);
  }

  Future<UpdateDownloadState> getDownloadState(UpdateInfo info) async {
    final finalPath = await _getFinalApkPath(info);
    final partialPath = await _getPartialApkPath(info);

    final finalFile = File(finalPath);
    final partialFile = File(partialPath);

    if (await finalFile.exists()) {
      final completedBytes = await finalFile.length();
      return UpdateDownloadState(
        finalPath: finalPath,
        partialPath: partialPath,
        receivedBytes: completedBytes,
        totalBytes: info.sizeBytes ?? completedBytes,
        isCompleted: true,
      );
    }

    final partialBytes =
        await partialFile.exists() ? await partialFile.length() : 0;
    return UpdateDownloadState(
      finalPath: finalPath,
      partialPath: partialPath,
      receivedBytes: partialBytes,
      totalBytes: info.sizeBytes ?? 0,
      isCompleted: false,
    );
  }

  Future<String> downloadApk(
    UpdateInfo info, {
    ProgressCallback? onReceiveProgress,
    CancelToken? cancelToken,
  }) async {
    final downloadState = await getDownloadState(info);
    final finalFile = File(downloadState.finalPath);
    final partialFile = File(downloadState.partialPath);

    if (downloadState.isCompleted) {
      final completedLen = await finalFile.length();
      if (info.sizeBytes == null ||
          info.sizeBytes! <= 0 ||
          completedLen >= info.sizeBytes!) {
        return finalFile.path;
      }
      await finalFile.delete();
    }

    var received = downloadState.receivedBytes;
    var expectedTotal = downloadState.totalBytes > 0
        ? downloadState.totalBytes
        : (info.sizeBytes ?? 0);
    final wantRange = received > 0;

    final headers = <String, String>{};
    if (wantRange) {
      headers['Range'] = 'bytes=$received-';
    }

    late final Response<ResponseBody> response;
    try {
      response = await _dio().get<ResponseBody>(
        info.apkUrl,
        cancelToken: cancelToken,
        options: Options(
          headers: headers,
          responseType: ResponseType.stream,
          followRedirects: true,
          validateStatus: (status) => status != null && status < 500,
        ),
      );
    } on DioException catch (e) {
      final statusCode = e.response?.statusCode;
      if (wantRange && statusCode == 416) {
        if (info.sizeBytes != null &&
            info.sizeBytes! > 0 &&
            await partialFile.exists()) {
          final partialLen = await partialFile.length();
          if (partialLen >= info.sizeBytes!) {
            if (await finalFile.exists()) {
              await finalFile.delete();
            }
            await partialFile.rename(finalFile.path);
            return finalFile.path;
          }
        }
      }
      rethrow;
    }

    final statusCode = response.statusCode ?? 0;
    final rangeAccepted = wantRange && statusCode == 206;

    if (wantRange && !rangeAccepted) {
      received = 0;
      if (await partialFile.exists()) {
        await partialFile.delete();
      }
    }

    if (rangeAccepted) {
      final contentRange = response.headers.value('content-range');
      final parsedTotal = _parseTotalFromContentRange(contentRange);
      if (parsedTotal != null && parsedTotal > 0) {
        expectedTotal = parsedTotal;
      }
    }

    final contentLength =
        int.tryParse(response.headers.value(Headers.contentLengthHeader) ?? '');
    if (contentLength != null && contentLength > 0) {
      expectedTotal = rangeAccepted ? received + contentLength : contentLength;
    }

    if (expectedTotal <= 0 && info.sizeBytes != null && info.sizeBytes! > 0) {
      expectedTotal = info.sizeBytes!;
    }

    onReceiveProgress?.call(received, expectedTotal > 0 ? expectedTotal : -1);

    final sink = partialFile.openWrite(
        mode: rangeAccepted ? FileMode.append : FileMode.write);
    try {
      final stream = response.data?.stream;
      if (stream == null) {
        throw StateError('استجابة تنزيل غير صالحة.');
      }

      await for (final chunk in stream) {
        sink.add(chunk);
        received += chunk.length;
        onReceiveProgress?.call(
            received, expectedTotal > 0 ? expectedTotal : -1);
      }
    } finally {
      await sink.flush();
      await sink.close();
    }

    final partialLen = await partialFile.length();
    if (expectedTotal > 0 && partialLen < expectedTotal) {
      throw StateError('تم إيقاف التنزيل قبل اكتماله.');
    }

    if (await finalFile.exists()) {
      await finalFile.delete();
    }
    await partialFile.rename(finalFile.path);
    return finalFile.path;
  }
}
