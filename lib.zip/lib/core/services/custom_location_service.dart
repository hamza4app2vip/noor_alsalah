import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class CustomLocationService {
  static const String _countriesKey = 'custom_countries';
  static const String _citiesKey = 'custom_cities';

  // Format for custom_countries: Map<String code, String name>
  // Format for custom_cities: Map<String countryCode, List<String> cityNames>

  Future<void> saveCountry(String code, String name) async {
    final prefs = await SharedPreferences.getInstance();
    final countriesJson = prefs.getString(_countriesKey) ?? '{}';
    final Map<String, dynamic> countries = jsonDecode(countriesJson);
    countries[code.toUpperCase()] = name;
    await prefs.setString(_countriesKey, jsonEncode(countries));
  }

  Future<Map<String, String>> getCustomCountries() async {
    final prefs = await SharedPreferences.getInstance();
    final countriesJson = prefs.getString(_countriesKey) ?? '{}';
    final Map<String, dynamic> countries = jsonDecode(countriesJson);
    return countries.map((key, value) => MapEntry(key, value.toString()));
  }

  Future<void> saveCity(String countryCode, String cityName) async {
    final prefs = await SharedPreferences.getInstance();
    final citiesJson = prefs.getString(_citiesKey) ?? '{}';
    final Map<String, dynamic> cities = jsonDecode(citiesJson);
    
    final upperCode = countryCode.toUpperCase();
    final List<String> cityList = List<String>.from(cities[upperCode] ?? []);
    if (!cityList.contains(cityName)) {
      cityList.add(cityName);
    }
    cities[upperCode] = cityList;
    await prefs.setString(_citiesKey, jsonEncode(cities));
  }

  Future<Map<String, List<String>>> getCustomCities() async {
    final prefs = await SharedPreferences.getInstance();
    final citiesJson = prefs.getString(_citiesKey) ?? '{}';
    final Map<String, dynamic> cities = jsonDecode(citiesJson);
    
    return cities.map((key, value) {
      if (value is List) {
        return MapEntry(key, value.map((e) => e.toString()).toList());
      }
      return MapEntry(key, <String>[]);
    });
  }
}
