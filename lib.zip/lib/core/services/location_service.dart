import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../features/settings/presentation/providers/settings_provider.dart';
import '../../features/prayer_times/presentation/providers/prayer_times_provider.dart';
import 'location_result.dart';

final locationServiceProvider = Provider((ref) => LocationService(ref));

class LocationService {
  final Ref _ref;
  LocationService(this._ref);

  Future<bool> handleLocationPermission() async {
    PermissionStatus status = await Permission.location.status;
    if (status.isPermanentlyDenied) {
      return false;
    }

    if (!status.isGranted) {
      status = await Permission.location.request();
    }
    
    return status.isGranted;
  }

  Future<LocationResult> fetchAutoLocationData() async {
    final hasPermission = await handleLocationPermission();
    if (!hasPermission) {
      return LocationResult.failure(errorMessage: 'تم رفض صلاحية الموقع');
    }

    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
       return LocationResult.failure(errorMessage: 'خدمة الموقع (GPS) مغلقة، يرجى تفعيلها');
    }

    try {
      // 1. Try GPS with timeout
      Position? position;
      try {
        position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium),
        ).timeout(const Duration(seconds: 10)); // Request Timeout
      } catch (e) {
        // Timeout or other error -> try last known
        position = await Geolocator.getLastKnownPosition();
      }

      if (position == null) {
        return LocationResult.failure(errorMessage: 'فشل في التقاط إحداثيات الموقع');
      }

      // 2. Reverse geocoding
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      ).timeout(const Duration(seconds: 5));

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        final country = place.country ?? '';
        final countryCode = place.isoCountryCode ?? '';
        final city = place.locality ?? place.administrativeArea ?? '';
        
        if (country.isEmpty || city.isEmpty) {
           return LocationResult.failure(errorMessage: 'تعذر تحديد اسم الدولة أو المدينة من الإحداثيات');
        }

        return await _matchWithLocalDatabase(
          lat: position.latitude,
          lon: position.longitude,
          country: country, 
          countryCode: countryCode,
          city: city,
          source: 'gps/network',
        );
      }
    } catch (e) {
      return LocationResult.failure(errorMessage: 'حدث خطأ أثناء الاتصال بخدمات الموقع الجغرافي');
    }
    return LocationResult.failure(errorMessage: 'فشل غير متوقع في تحديد الموقع');
  }

  Future<LocationResult> _matchWithLocalDatabase({
    required double lat,
    required double lon,
    required String country, 
    required String countryCode,
    required String city,
    required String source,
  }) async {
    try {
      final localDataSource = _ref.read(localDataSourceProvider);
      
      final countriesMap = await localDataSource.loadCountriesNames(); 
      final locationsIndex = await localDataSource.loadAvailableLocations(); 
      
      String? matchedCountryCode;
      
      // Try exact iso code match first
      if (countryCode.isNotEmpty && countriesMap.containsKey(countryCode.toLowerCase())) {
        matchedCountryCode = countryCode.toLowerCase();
      } else {
        for (var entry in countriesMap.entries) {
          if (entry.value.toLowerCase() == country.toLowerCase() || 
              entry.key.toLowerCase() == country.toLowerCase()) {
            matchedCountryCode = entry.key; 
            break;
          }
        }
      }

      // Fallback
      matchedCountryCode ??= 'sa';

      String? matchedCityCode;
      final upperCountryCode = matchedCountryCode.toUpperCase();
      
      if (locationsIndex.containsKey(upperCountryCode)) {
        final availableCities = locationsIndex[upperCountryCode]!;
        
        for (var c in availableCities) {
          if (c.toLowerCase() == city.toLowerCase() || 
              city.toLowerCase().contains(c.toLowerCase()) ||
              c.toLowerCase().contains(city.toLowerCase())) {
            matchedCityCode = c;
            break;
          }
        }
        
        // Custom fallbacks for common mismatched cities
        if (matchedCityCode == null) {
           if (upperCountryCode == 'YE' && (city.contains('صنعاء') || city.toLowerCase().contains('sanaa'))) {
             matchedCityCode = 'sanaa';
           } else if (upperCountryCode == 'YE' && (city.contains('عدن') || city.toLowerCase().contains('aden'))) {
             matchedCityCode = 'aden';
           } else if (upperCountryCode == 'EG' && (city.contains('قاهرة') || city.toLowerCase().contains('cairo'))) {
             matchedCityCode = 'cairo';
           } else if (upperCountryCode == 'SA' && (city.contains('رياض') || city.toLowerCase().contains('riyadh'))) {
             matchedCityCode = 'riyadh';
           } else if (upperCountryCode == 'SA' && (city.contains('مكة') || city.toLowerCase().contains('makkah'))) {
             matchedCityCode = 'makkah';
           } else if (upperCountryCode == 'SA' && (city.contains('مدينة') || city.toLowerCase().contains('madinah'))) {
             matchedCityCode = 'al-madinah';
           }
        }
        
        if (matchedCityCode == null && availableCities.isNotEmpty) {
          matchedCityCode = availableCities.first;
        }
      }
      
      // Fallback
      matchedCityCode ??= 'makkah';

      // Update AppSettings if valid matches are found
      await _ref.read(settingsNotifierProvider.notifier).updateSettings(
        _ref.read(settingsNotifierProvider).copyWith(
          country: matchedCountryCode,
          city: matchedCityCode,
        )
      );
      
      return LocationResult.success(
        latitude: lat,
        longitude: lon,
        country: matchedCountryCode,
        city: matchedCityCode,
        source: source,
      );
    } catch (e) {
      return LocationResult.failure(errorMessage: 'خطأ في معالجة بيانات الموقع');
    }
  }
}
