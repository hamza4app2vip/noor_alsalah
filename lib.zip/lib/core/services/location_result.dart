class LocationResult {
  final double? latitude;
  final double? longitude;
  final String? country;
  final String? city;
  final String source; // 'gps', 'network', 'ip', 'lastKnown'
  final bool isSuccess;
  final String? errorMessage;

  LocationResult({
    this.latitude,
    this.longitude,
    this.country,
    this.city,
    required this.source,
    required this.isSuccess,
    this.errorMessage,
  });

  factory LocationResult.success({
    required double latitude,
    required double longitude,
    required String country,
    required String city,
    required String source,
  }) {
    return LocationResult(
      latitude: latitude,
      longitude: longitude,
      country: country,
      city: city,
      source: source,
      isSuccess: true,
    );
  }

  factory LocationResult.failure({required String errorMessage}) {
    return LocationResult(
      source: 'none',
      isSuccess: false,
      errorMessage: errorMessage,
    );
  }
  
  @override
  String toString() {
    return 'LocationResult(success: $isSuccess, source: $source, country: $country, city: $city, error: $errorMessage)';
  }
}
