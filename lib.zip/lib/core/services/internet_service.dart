import 'dart:async';
import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';

class InternetService {
  static final InternetService _instance = InternetService._internal();
  factory InternetService() => _instance;
  InternetService._internal();

  final Connectivity _connectivity = Connectivity();
  final _connectivityController = StreamController<bool>.broadcast();

  Stream<bool> get onConnectivityChanged => _connectivityController.stream;

  Future<void> init() async {
    // Initial check
    final result = await _connectivity.checkConnectivity();
    _connectivityController.add(_isConnected(result));

    // Listen for changes
    _connectivity.onConnectivityChanged.listen((List<ConnectivityResult> results) {
      _connectivityController.add(_isConnected(results));
    });
  }

  bool _isConnected(List<ConnectivityResult> results) {
    return results.isNotEmpty && !results.contains(ConnectivityResult.none);
  }

  Future<bool> hasInternet() async {
    try {
      final result = await _connectivity.checkConnectivity();
      if (_isConnected(result)) return true;
      
      // Fallback: try to reach a known reliable host
      final lookup = await InternetAddress.lookup('google.com').timeout(
        const Duration(seconds: 5),
      );
      return lookup.isNotEmpty && lookup[0].rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void dispose() {
    _connectivityController.close();
  }
}
