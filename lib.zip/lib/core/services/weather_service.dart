import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../features/settings/domain/entities/app_settings.dart';

class WeatherForecast {
  final DateTime date;
  final double minTemp;
  final double maxTemp;
  final int weatherCode;

  WeatherForecast({required this.date, required this.minTemp, required this.maxTemp, required this.weatherCode});

  factory WeatherForecast.fromJson(Map<String, dynamic> json) {
    return WeatherForecast(
      date: DateTime.parse(json['date'] as String),
      minTemp: (json['minTemp'] as num).toDouble(),
      maxTemp: (json['maxTemp'] as num).toDouble(),
      weatherCode: json['weatherCode'] as int,
    );
  }

  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(),
    'minTemp': minTemp,
    'maxTemp': maxTemp,
    'weatherCode': weatherCode,
  };
}

class WeatherService {
  static const String _cacheKey = 'weather_cache';
  static const String _lastFetchKey = 'weather_last_fetch';

  Future<List<WeatherForecast>?> getDailyForecast(AppSettings settings) async {
    if (!settings.weatherEnabled) return null;
    
    // Check Cache
    final prefs = await SharedPreferences.getInstance();
    final lastFetchStr = prefs.getString(_lastFetchKey);
    bool shouldFetch = true;

    if (lastFetchStr != null) {
      final lastFetch = DateTime.parse(lastFetchStr);
      // "يحتاج إنترنت مرة واحدة أسبوعيًا (كما النص)" -> fetch if older than 7 days
      if (DateTime.now().difference(lastFetch).inDays < 7) {
        shouldFetch = false;
      }
    }

    if (!shouldFetch) {
      final cacheStr = prefs.getString(_cacheKey);
      if (cacheStr != null) {
        final List<dynamic> decoded = jsonDecode(cacheStr);
        return decoded.map((e) => WeatherForecast.fromJson(e)).toList();
      }
    }

    // Need to Fetch
    final lat = settings.gpsLat;
    final lng = settings.gpsLng;
    if (lat == 0.0 && lng == 0.0) return null; // No valid GPS

    try {
      final url = Uri.parse('https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lng&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=auto');
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final daily = data['daily'];
        final times = daily['time'] as List;
        final minTemps = daily['temperature_2m_min'] as List;
        final maxTemps = daily['temperature_2m_max'] as List;
        final codes = daily['weathercode'] as List;

        List<WeatherForecast> forecasts = [];
        for (int i = 0; i < times.length; i++) {
          forecasts.add(WeatherForecast(
            date: DateTime.parse(times[i]),
            minTemp: (minTemps[i] as num).toDouble(),
            maxTemp: (maxTemps[i] as num).toDouble(),
            weatherCode: codes[i] as int,
          ));
        }

        // Save to cache
        await prefs.setString(_cacheKey, jsonEncode(forecasts.map((e) => e.toJson()).toList()));
        await prefs.setString(_lastFetchKey, DateTime.now().toIso8601String());

        return forecasts;
      }
    } catch (e) {
      // Fallback to cache if offline
      final cacheStr = prefs.getString(_cacheKey);
      if (cacheStr != null) {
        final List<dynamic> decoded = jsonDecode(cacheStr);
        return decoded.map((e) => WeatherForecast.fromJson(e)).toList();
      }
    }
    return null;
  }
}
