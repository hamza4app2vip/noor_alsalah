import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class ExcelImportService {
  static const String customFileName = 'custom_prayer_times.json';

  final _ExcelPrayerTimesParser _parser = _ExcelPrayerTimesParser();

  Future<String?> pickAndImportExcel(
    String durationKey,
    String country,
    String city,
  ) async {
    final preview = await pickAndPreviewExcel(durationKey, country, city);
    if (preview == null) {
      return null;
    }
    return saveImportPreview(preview);
  }

  Future<ExcelImportPreview?> pickAndPreviewExcel(
    String durationKey,
    String country,
    String city,
  ) async {
    _validateLocation(country, city);

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['xlsx'],
    );
    final path = result?.files.single.path;
    if (path == null) {
      return null;
    }
    return previewImportFromPath(
      filePath: path,
      durationKey: durationKey,
      country: country,
      city: city,
    );
  }

  Future<ExcelImportPreview> previewImportFromPath({
    required String filePath,
    required String durationKey,
    required String country,
    required String city,
  }) async {
    _validateLocation(country, city);
    final normalizedCountry = _normalizeCountryKey(country);
    final normalizedCity = _normalizeCityKey(city);
    final sourceFile = File(filePath);

    if (!await sourceFile.exists()) {
      throw ExcelImportException(
        userMessage: 'الملف المحدد غير موجود. يرجى إعادة اختيار ملف Excel.',
        technicalDetails: 'Excel file not found at path: $filePath',
      );
    }

    try {
      final bytes = await sourceFile.readAsBytes();
      final excel = _decodeExcelWithCompatibility(bytes);
      final parseResult = _parser.parse(
        excel: excel,
        durationKey: durationKey,
        countryKey: normalizedCountry,
        cityKey: normalizedCity,
        sourceFilePath: filePath,
      );

      _log(
        'Parsed file="${sourceFile.path}" '
        'sheet="${parseResult.selectedSheet}" '
        'rows=${parseResult.daysData.length}',
      );

      final payload = <String, dynamic>{
        normalizedCountry: <String, dynamic>{
          normalizedCity: parseResult.daysData,
        },
      };

      return ExcelImportPreview(
        sourceFilePath: filePath,
        sourceFileName: p.basename(filePath),
        selectedSheetName: parseResult.selectedSheet,
        headerRowNumber: parseResult.headerRow + 1,
        importedRowsCount: parseResult.daysData.length,
        countryKey: normalizedCountry,
        cityKey: normalizedCity,
        mappedColumns: parseResult.mappedColumns,
        sampleRows: parseResult.sampleRows,
        warnings: parseResult.warnings,
        payload: payload,
        durationKey: durationKey,
      );
    } on ExcelImportException {
      rethrow;
    } catch (e, st) {
      _log('Unhandled parse error: $e\n$st');
      final raw = e.toString();
      if (raw.contains('numFmtId')) {
        throw ExcelImportException(
          userMessage:
              'فشل قراءة ملف Excel بسبب تنسيق غير مدعوم. افتح الملف في Excel ثم احفظه كـ Workbook عادي (xlsx) وأعد المحاولة.',
          technicalDetails: raw,
        );
      }
      throw ExcelImportException(
        userMessage:
            'تعذر معالجة ملف Excel. تأكد أن الملف يحتوي جدول أوقات صلاة صالحًا.',
        technicalDetails: raw,
      );
    }
  }

  Future<String> saveImportPreview(ExcelImportPreview preview) async {
    final file = await getCustomFile(preview.countryKey, preview.cityKey);
    await file.writeAsString(jsonEncode(preview.payload));
    _log('Saved custom prayer times file: ${file.path}');
    return file.path;
  }

  Future<bool> migrateExcelData({
    required String oldCountry,
    required String oldCity,
    required String newCountry,
    required String newCity,
  }) async {
    try {
      final oldFile = await getCustomFile(
        _normalizeCountryKey(oldCountry),
        _normalizeCityKey(oldCity),
      );

      if (!await oldFile.exists()) {
        _log('Source file for migration not found: ${oldFile.path}');
        return false;
      }

      final String content = await oldFile.readAsString();
      final Map<String, dynamic> oldData = jsonDecode(content);

      // Extract the dynamic data from the old key structure
      // Structure is: { "COUNTRY": { "city": [days...] } }
      final oldCountryKey = _normalizeCountryKey(oldCountry);
      final oldCityKey = _normalizeCityKey(oldCity);

      final daysData = oldData[oldCountryKey]?[oldCityKey];
      if (daysData == null) {
        _log('No data found in source file for $oldCountry/$oldCity');
        return false;
      }

      // Create new structure
      final newCountryKey = _normalizeCountryKey(newCountry);
      final newCityKey = _normalizeCityKey(newCity);
      final newData = {
        newCountryKey: {
          newCityKey: daysData,
        },
      };

      final newFile = await getCustomFile(newCountryKey, newCityKey);
      await newFile.writeAsString(jsonEncode(newData));
      _log('Migrated data from $oldCountry/$oldCity to $newCountry/$newCity');
      return true;
    } catch (e) {
      _log('Migration failed: $e');
      return false;
    }
  }

  Future<bool> existsCustomData(String country, String city) async {
    final file = await getCustomFile(
      _normalizeCountryKey(country),
      _normalizeCityKey(city),
    );
    return await file.exists();
  }

  Future<void> deleteCustomFile(String country, String city) async {
    final file = await getCustomFile(
      _normalizeCountryKey(country),
      _normalizeCityKey(city),
    );
    if (await file.exists()) {
      await file.delete();
      _log('Deleted custom prayer times file: ${file.path}');
    }
  }

  void _validateLocation(String country, String city) {
    if (country.trim().isEmpty || city.trim().isEmpty) {
      throw const ExcelImportException(
        userMessage: 'يرجى اختيار الدولة والمدينة في الإعدادات أولًا قبل الاستيراد.',
      );
    }
  }

  String _normalizeCountryKey(String country) {
    final compact = country.trim().replaceAll(RegExp(r'\s+'), '_');
    return compact.toUpperCase();
  }

  String _normalizeCityKey(String city) {
    final compact = city.trim().replaceAll(RegExp(r'\s+'), '_');
    return compact.toLowerCase();
  }

  Future<File> getCustomFile(String countryKey, String cityKey) async {
    final directory = await getApplicationDocumentsDirectory();
    final path = '${directory.path}/custom_times/$countryKey';
    final dir = Directory(path);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return File('$path/$cityKey.json');
  }

  Excel _decodeExcelWithCompatibility(Uint8List bytes) {
    try {
      return Excel.decodeBytes(bytes);
    } catch (firstError) {
      final patched = _patchWorkbookRelationships(bytes);
      if (patched == null) {
        rethrow;
      }

      try {
        _log('Retry Excel decode after workbook rels target patch.');
        return Excel.decodeBytes(patched);
      } catch (_) {
        rethrow;
      }
    }
  }

  Uint8List? _patchWorkbookRelationships(Uint8List originalBytes) {
    try {
      final archive = ZipDecoder().decodeBytes(originalBytes, verify: false);
      final patchedArchive = Archive();
      var changed = false;

      for (final file in archive.files) {
        final name = file.name.replaceAll('\\', '/').toLowerCase();
        if (name == 'xl/_rels/workbook.xml.rels') {
          final raw = file.content;
          if (raw is! List<int>) {
            patchedArchive.addFile(file);
            continue;
          }

          final relsText = utf8.decode(raw);
          final patchedText = relsText.replaceAllMapped(
            RegExp(r'Target="/xl/([^\"]+)"'),
            (m) => 'Target="${m.group(1)}"',
          );

          if (patchedText != relsText) {
            final patchedBytes = utf8.encode(patchedText);
            final patchedFile = ArchiveFile(file.name, patchedBytes.length, patchedBytes)
              ..compress = file.compress
              ..mode = file.mode
              ..lastModTime = file.lastModTime
              ..isFile = file.isFile;
            patchedArchive.addFile(patchedFile);
            changed = true;
          } else {
            patchedArchive.addFile(file);
          }
        } else {
          patchedArchive.addFile(file);
        }
      }

      if (!changed) {
        return null;
      }

      final encoded = ZipEncoder().encode(patchedArchive);
      if (encoded == null) {
        return null;
      }

      return Uint8List.fromList(encoded);
    } catch (e) {
      _log('Failed to patch workbook rels: $e');
      return null;
    }
  }

  void _log(String message) {
    debugPrint('[ExcelImportService] $message');
  }
}

class ExcelImportPreview {
  final String sourceFilePath;
  final String sourceFileName;
  final String selectedSheetName;
  final int headerRowNumber;
  final int importedRowsCount;
  final String countryKey;
  final String cityKey;
  final Map<String, String> mappedColumns;
  final List<Map<String, String>> sampleRows;
  final List<String> warnings;
  final Map<String, dynamic> payload;
  final String durationKey;

  const ExcelImportPreview({
    required this.sourceFilePath,
    required this.sourceFileName,
    required this.selectedSheetName,
    required this.headerRowNumber,
    required this.importedRowsCount,
    required this.countryKey,
    required this.cityKey,
    required this.mappedColumns,
    required this.sampleRows,
    required this.warnings,
    required this.payload,
    required this.durationKey,
  });
}

class ExcelImportException implements Exception {
  final String userMessage;
  final String? technicalDetails;

  const ExcelImportException({
    required this.userMessage,
    this.technicalDetails,
  });

  @override
  String toString() => userMessage;
}

class _ExcelPrayerTimesParser {
  static const List<String> _requiredColumns = <String>[
    'date',
    'fajr',
    'sunrise',
    'dhuhr',
    'asr',
    'maghrib',
    'isha',
  ];

  final _HeaderMatcher _headerMatcher = _HeaderMatcher();
  final _DateNormalizer _dateNormalizer = _DateNormalizer();
  final _TimeNormalizer _timeNormalizer = _TimeNormalizer();

  _ParseSuccess parse({
    required Excel excel,
    required String durationKey,
    required String countryKey,
    required String cityKey,
    required String sourceFilePath,
  }) {
    final sheetResults = <_SheetParseResult>[];

    for (final entry in excel.tables.entries) {
      final sheet = entry.value;
      if (sheet.maxRows <= 1 || sheet.maxColumns <= 1) {
        continue;
      }
      final result = _parseSingleSheet(
        sheetName: entry.key,
        sheet: sheet,
        durationKey: durationKey,
      );
      if (result != null) {
        sheetResults.add(result);
      }
    }

    if (sheetResults.isEmpty) {
      throw const ExcelImportException(
        userMessage:
            'الملف لا يحتوي جدول أوقات صلاة صالح. تأكد من وجود أعمدة التاريخ والفجر والشروق والظهر والعصر والمغرب والعشاء.',
      );
    }

    sheetResults.sort((a, b) => b.score.compareTo(a.score));
    final best = sheetResults.first;
    final runnerUp = sheetResults.length > 1 ? sheetResults[1] : null;

    final warnings = <String>[]..addAll(best.warnings);
    if (runnerUp != null && best.score == runnerUp.score) {
      warnings.add(
        'تم العثور على أكثر من ورقة مرشحة متشابهة. تم اختيار "${best.sheetName}".',
      );
    } else if (runnerUp != null) {
      warnings.add(
        'تم اختيار الورقة "${best.sheetName}" تلقائيًا لكونها الأكثر تطابقًا.',
      );
    }

    if (best.daysData.isEmpty) {
      throw ExcelImportException(
        userMessage: 'تعذر استخراج بيانات صالحة من الورقة "${best.sheetName}".',
        technicalDetails: best.errors.join(' | '),
      );
    }

    if (best.errors.isNotEmpty) {
      final shown = best.errors.take(6).join('\n- ');
      throw ExcelImportException(
        userMessage:
            'تعذر اعتماد الاستيراد بسبب أخطاء في البيانات:\n- $shown${best.errors.length > 6 ? '\n- ...' : ''}',
        technicalDetails: best.errors.join(' | '),
      );
    }

    return _ParseSuccess(
      selectedSheet: best.sheetName,
      headerRow: best.headerRowIndex,
      mappedColumns: best.mappedColumns,
      daysData: best.daysData,
      sampleRows: best.sampleRows,
      warnings: warnings,
      countryKey: countryKey,
      cityKey: cityKey,
      sourceFilePath: sourceFilePath,
    );
  }

  _SheetParseResult? _parseSingleSheet({
    required String sheetName,
    required Sheet sheet,
    required String durationKey,
  }) {
    final headerCandidates = _findHeaderCandidates(sheet);
    if (headerCandidates.isEmpty) {
      return null;
    }

    _SheetParseResult? best;
    for (final candidate in headerCandidates) {
      final parsed = _parseRowsForCandidate(
        sheetName: sheetName,
        sheet: sheet,
        candidate: candidate,
        durationKey: durationKey,
      );
      if (best == null || parsed.score > best.score) {
        best = parsed;
      }
    }
    return best;
  }

  List<_HeaderCandidate> _findHeaderCandidates(Sheet sheet) {
    final candidates = <_HeaderCandidate>[];
    final maxRowScan = sheet.maxRows < 30 ? sheet.maxRows : 30;

    for (var rowIndex = 0; rowIndex < maxRowScan; rowIndex++) {
      final row = rowIndex < sheet.rows.length ? sheet.rows[rowIndex] : <Data?>[];
      final mapped = <String, int>{};
      final originalLabels = <String, String>{};

      for (var col = 0; col < sheet.maxColumns; col++) {
        final data = col < row.length ? row[col] : null;
        final rawHeader = _cellToRawText(data?.value).trim();
        if (rawHeader.isEmpty) {
          continue;
        }
        final key = _headerMatcher.match(rawHeader);
        if (key == null || mapped.containsKey(key)) {
          continue;
        }
        mapped[key] = col;
        originalLabels[key] = rawHeader;
      }

      final hasDate = mapped.containsKey('date');
      final prayersFound =
          _requiredColumns.where((e) => e != 'date' && mapped.containsKey(e)).length;

      if (!hasDate || prayersFound < 2) {
        continue;
      }

      final confidence =
          (mapped.length * 10) + (prayersFound * 12) - rowIndex;
      candidates.add(
        _HeaderCandidate(
          rowIndex: rowIndex,
          mappedColumns: mapped,
          originalLabels: originalLabels,
          confidence: confidence,
        ),
      );
    }

    candidates.sort((a, b) => b.confidence.compareTo(a.confidence));
    return candidates;
  }

  _SheetParseResult _parseRowsForCandidate({
    required String sheetName,
    required Sheet sheet,
    required _HeaderCandidate candidate,
    required String durationKey,
  }) {
    final errors = <String>[];
    final warnings = <String>[];

    final missing = _requiredColumns
        .where((key) => !candidate.mappedColumns.containsKey(key))
        .toList();

    if (missing.isNotEmpty) {
      for (final key in missing) {
        errors.add('لم يتم العثور على عمود "${_columnLabelAr(key)}" في الورقة "$sheetName".');
      }
      return _SheetParseResult(
        sheetName: sheetName,
        headerRowIndex: candidate.rowIndex,
        mappedColumns: candidate.mappedForPreview(),
        daysData: <String, Map<String, String>>{},
        sampleRows: const <Map<String, String>>[],
        errors: errors,
        warnings: warnings,
        score: -1000 + candidate.confidence,
      );
    }

    final rowsLimit = _rowsLimitForDuration(durationKey);
    final preferDayFirst = _inferPreferDayFirst(sheet, candidate);
    final data = <String, Map<String, String>>{};
    final sample = <Map<String, String>>[];

    for (var rowIndex = candidate.rowIndex + 1; rowIndex < sheet.maxRows; rowIndex++) {
      if (rowsLimit != null && data.length >= rowsLimit) {
        break;
      }

      final row = rowIndex < sheet.rows.length ? sheet.rows[rowIndex] : <Data?>[];
      final rowNumber = rowIndex + 1;
      if (_isRowBlank(row)) {
        continue;
      }

      final dateValue = _valueAt(row, candidate.mappedColumns['date']!);
      final dateKey = _dateNormalizer.normalize(dateValue, preferDayFirst: preferDayFirst);

      if (dateKey == null) {
        if (_rowHasRelevantData(row, candidate.mappedColumns.values)) {
          errors.add('الصف $rowNumber يحتوي تاريخًا غير قابل للتحويل.');
        }
        continue;
      }

      if (data.containsKey(dateKey)) {
        errors.add('التاريخ "$dateKey" مكرر في الصف $rowNumber.');
        continue;
      }

      final prayerTimes = <String, String>{};
      var invalidRow = false;

      for (final key in _requiredColumns.where((c) => c != 'date')) {
        final colIndex = candidate.mappedColumns[key]!;
        final value = _valueAt(row, colIndex);
        final normalized = _timeNormalizer.normalize(value);
        if (normalized == null) {
          errors.add(
            'الصف $rowNumber يحتوي وقتًا غير صالح في عمود "${_columnLabelAr(key)}".',
          );
          invalidRow = true;
          break;
        }
        prayerTimes[key] = normalized;
      }

      if (invalidRow) {
        continue;
      }

      final orderWarning = _validatePrayerOrder(rowNumber, prayerTimes);
      if (orderWarning != null) {
        warnings.add(orderWarning);
      }

      data[dateKey] = prayerTimes;
      if (sample.length < 5) {
        sample.add(<String, String>{'date': dateKey, ...prayerTimes});
      }
    }

    if (data.isEmpty && errors.isEmpty) {
      errors.add('الورقة "$sheetName" لا تحتوي صفوف بيانات قابلة للاستيراد.');
    }

    final score = (data.length * 100) +
        (candidate.mappedColumns.length * 10) -
        (errors.length * 25) +
        candidate.confidence;

    return _SheetParseResult(
      sheetName: sheetName,
      headerRowIndex: candidate.rowIndex,
      mappedColumns: candidate.mappedForPreview(),
      daysData: data,
      sampleRows: sample,
      errors: errors,
      warnings: warnings,
      score: score,
    );
  }

  String? _validatePrayerOrder(int rowNumber, Map<String, String> times) {
    final fajr = _timeToMinutes(times['fajr']!);
    final sunrise = _timeToMinutes(times['sunrise']!);
    final dhuhr = _timeToMinutes(times['dhuhr']!);
    final asr = _timeToMinutes(times['asr']!);
    final maghrib = _timeToMinutes(times['maghrib']!);
    final isha = _timeToMinutes(times['isha']!);

    if (fajr < sunrise &&
        sunrise < dhuhr &&
        dhuhr < asr &&
        asr < maghrib &&
        maghrib < isha) {
      return null;
    }

    return 'تنبيه: ترتيب الأوقات في الصف $rowNumber غير منطقي بالكامل، راجع القيم قبل الاعتماد.';
  }

  int _timeToMinutes(String hhmm) {
    final split = hhmm.split(':');
    return (int.parse(split[0]) * 60) + int.parse(split[1]);
  }

  bool _inferPreferDayFirst(Sheet sheet, _HeaderCandidate candidate) {
    final dateCol = candidate.mappedColumns['date'];
    if (dateCol == null) {
      return false;
    }

    var dayFirst = 0;
    var monthFirst = 0;
    final maxScan = candidate.rowIndex + 40;

    for (var rowIndex = candidate.rowIndex + 1;
        rowIndex < sheet.maxRows && rowIndex < maxScan;
        rowIndex++) {
      final row = rowIndex < sheet.rows.length ? sheet.rows[rowIndex] : <Data?>[];
      final rawDate = _cellToRawText(_valueAt(row, dateCol)).trim();
      final hint = _dateNormalizer.inspectOrderHint(rawDate);
      if (hint == _DateOrderHint.dayFirst) {
        dayFirst++;
      } else if (hint == _DateOrderHint.monthFirst) {
        monthFirst++;
      }
    }

    return dayFirst > monthFirst;
  }

  bool _isRowBlank(List<Data?> row) {
    for (final cell in row) {
      final text = _cellToRawText(cell?.value).trim();
      if (text.isNotEmpty) {
        return false;
      }
    }
    return true;
  }

  bool _rowHasRelevantData(List<Data?> row, Iterable<int> relevantColumns) {
    for (final col in relevantColumns) {
      final value = _valueAt(row, col);
      if (_cellToRawText(value).trim().isNotEmpty) {
        return true;
      }
    }
    return false;
  }

  CellValue? _valueAt(List<Data?> row, int col) {
    if (col < 0 || col >= row.length) {
      return null;
    }
    return row[col]?.value;
  }

  int? _rowsLimitForDuration(String key) {
    switch (key) {
      case 'YEAR':
        return 366;
      case 'MONTH_6':
        return 181;
      case 'MONTH_2':
        return 61;
      case 'MONTH_1':
        return 31;
      case 'WEEK_2':
        return 15;
      case 'WEEK_1':
        return 8;
      case 'DAY_2':
        return 2;
      case 'DAY_1':
        return 1;
      case 'AUTO':
      default:
        return null;
    }
  }

  String _columnLabelAr(String key) {
    switch (key) {
      case 'date':
        return 'التاريخ';
      case 'fajr':
        return 'الفجر';
      case 'sunrise':
        return 'الشروق';
      case 'dhuhr':
        return 'الظهر';
      case 'asr':
        return 'العصر';
      case 'maghrib':
        return 'المغرب';
      case 'isha':
        return 'العشاء';
      default:
        return key;
    }
  }

  String _cellToRawText(CellValue? value) {
    if (value == null) {
      return '';
    }
    if (value is TextCellValue) {
      return value.value.toString();
    }
    if (value is FormulaCellValue) {
      return value.formula;
    }
    return value.toString();
  }
}

class _ParseSuccess {
  final String selectedSheet;
  final int headerRow;
  final Map<String, String> mappedColumns;
  final Map<String, Map<String, String>> daysData;
  final List<Map<String, String>> sampleRows;
  final List<String> warnings;
  final String countryKey;
  final String cityKey;
  final String sourceFilePath;

  const _ParseSuccess({
    required this.selectedSheet,
    required this.headerRow,
    required this.mappedColumns,
    required this.daysData,
    required this.sampleRows,
    required this.warnings,
    required this.countryKey,
    required this.cityKey,
    required this.sourceFilePath,
  });
}

class _SheetParseResult {
  final String sheetName;
  final int headerRowIndex;
  final Map<String, String> mappedColumns;
  final Map<String, Map<String, String>> daysData;
  final List<Map<String, String>> sampleRows;
  final List<String> errors;
  final List<String> warnings;
  final int score;

  const _SheetParseResult({
    required this.sheetName,
    required this.headerRowIndex,
    required this.mappedColumns,
    required this.daysData,
    required this.sampleRows,
    required this.errors,
    required this.warnings,
    required this.score,
  });
}

class _HeaderCandidate {
  final int rowIndex;
  final Map<String, int> mappedColumns;
  final Map<String, String> originalLabels;
  final int confidence;

  const _HeaderCandidate({
    required this.rowIndex,
    required this.mappedColumns,
    required this.originalLabels,
    required this.confidence,
  });

  Map<String, String> mappedForPreview() {
    final map = <String, String>{};
    for (final entry in mappedColumns.entries) {
      final colName = _colName(entry.value);
      final sourceHeader = originalLabels[entry.key] ?? entry.key;
      map[entry.key] = '$sourceHeader ($colName)';
    }
    return map;
  }

  String _colName(int colIndex) {
    var dividend = colIndex + 1;
    var name = '';
    while (dividend > 0) {
      final modulo = (dividend - 1) % 26;
      name = String.fromCharCode(65 + modulo) + name;
      dividend = (dividend - modulo) ~/ 26;
    }
    return name;
  }
}

class _HeaderMatcher {
  static final Map<String, List<String>> _aliases = <String, List<String>>{
    'date': <String>[
      'التاريخ',
      'تاريخ',
      'يوم',
      'date',
      'day',
      'mm-dd',
      'month-day',
      'month day',
      'm-d',
      'mm/dd',
      'monthday',
    ],
    'fajr': <String>[
      'الفجر',
      'فجر',
      'fajr',
      'fajer',
      'fager',
      'dawn',
    ],
    'sunrise': <String>[
      'الشروق',
      'شروق',
      'sunrise',
      'sun rise',
      'shurooq',
      'shorooq',
    ],
    'dhuhr': <String>[
      'الظهر',
      'ظهر',
      'dhuhr',
      'duhr',
      'zuhr',
      'zuhur',
      'noon',
    ],
    'asr': <String>[
      'العصر',
      'عصر',
      'asr',
    ],
    'maghrib': <String>[
      'المغرب',
      'مغرب',
      'maghrib',
      'magrib',
    ],
    'isha': <String>[
      'العشاء',
      'عشاء',
      'isha',
      'esha',
      'ishaa',
    ],
  };

  String? match(String rawHeader) {
    final normalized = _normalizeToken(rawHeader);
    if (normalized.isEmpty) {
      return null;
    }
    final compact = _compact(normalized);

    String? bestKey;
    var bestScore = 0;

    for (final entry in _aliases.entries) {
      for (final alias in entry.value) {
        final aliasNorm = _normalizeToken(alias);
        if (aliasNorm.isEmpty) {
          continue;
        }
        final aliasCompact = _compact(aliasNorm);
        var score = 0;

        if (normalized == aliasNorm) {
          score = 4;
        } else if (compact == aliasCompact) {
          score = 3;
        } else if (aliasNorm.length > 2 &&
            (normalized.contains(aliasNorm) || compact.contains(aliasCompact))) {
          score = 2;
        }

        if (score > bestScore) {
          bestScore = score;
          bestKey = entry.key;
        }
      }
    }
    return bestKey;
  }

  static String _normalizeToken(String input) {
    var s = _normalizeDigits(input).toLowerCase().trim();
    s = s.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u06D6-\u06ED]'), '');
    s = s.replaceAll(RegExp(r'[_\-/\\|:;.,(){}\[\]]'), ' ');
    s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return s;
  }

  static String _compact(String input) {
    return input.replaceAll(RegExp(r'[^a-z0-9\u0600-\u06FF]'), '');
  }
}

class _DateNormalizer {
  String? normalize(CellValue? value, {bool preferDayFirst = false}) {
    if (value == null) {
      return null;
    }

    if (value is DateCellValue) {
      return _formatMonthDay(value.month, value.day);
    }

    if (value is DateTimeCellValue) {
      return _formatMonthDay(value.month, value.day);
    }

    if (value is IntCellValue) {
      return _fromNumeric(value.value.toDouble());
    }

    if (value is DoubleCellValue) {
      return _fromNumeric(value.value);
    }

    if (value is TextCellValue) {
      return _fromText(value.value.toString(), preferDayFirst: preferDayFirst);
    }

    if (value is FormulaCellValue) {
      return _fromText(value.formula, preferDayFirst: preferDayFirst);
    }

    return _fromText(value.toString(), preferDayFirst: preferDayFirst);
  }

  String? _fromNumeric(double raw) {
    if (!raw.isFinite || raw <= 0) {
      return null;
    }

    final asInt = raw.round();
    if ((raw - asInt).abs() < 0.000001) {
      final asText = asInt.toString();
      if (asText.length == 8) {
        final y = int.tryParse(asText.substring(0, 4));
        final m = int.tryParse(asText.substring(4, 6));
        final d = int.tryParse(asText.substring(6, 8));
        if (y != null && m != null && d != null) {
          return _formatMonthDay(m, d);
        }
      }
      if (asInt >= 101 && asInt <= 1231) {
        final m = asInt ~/ 100;
        final d = asInt % 100;
        final key = _formatMonthDay(m, d);
        if (key != null) {
          return key;
        }
      }
    }

    if (raw < 1) {
      return null;
    }

    final days = raw.floor();
    final excelEpoch = DateTime.utc(1899, 12, 30);
    final date = excelEpoch.add(Duration(days: days));
    return _formatMonthDay(date.month, date.day);
  }

  String? _fromText(String rawInput, {required bool preferDayFirst}) {
    var s = _normalizeDigits(rawInput).trim();
    if (s.isEmpty) {
      return null;
    }

    s = s
        .replaceAll(RegExp(r'[\u200E\u200F]'), '')
        .replaceAll(RegExp(r'[./_]'), '-')
        .replaceAll(RegExp(r'\s+'), '');

    final dateToken = RegExp(r'(\d{1,4}-\d{1,2}-\d{1,4}|\d{1,2}-\d{1,2}|\d{8})')
        .firstMatch(s)
        ?.group(0);
    if (dateToken == null || dateToken.isEmpty) {
      return null;
    }

    if (!dateToken.contains('-') && dateToken.length == 8) {
      final y = int.tryParse(dateToken.substring(0, 4));
      final m = int.tryParse(dateToken.substring(4, 6));
      final d = int.tryParse(dateToken.substring(6, 8));
      if (y != null && m != null && d != null) {
        return _formatMonthDay(m, d);
      }
      return null;
    }

    final parts = dateToken.split('-');
    if (parts.length == 2) {
      final a = int.tryParse(parts[0]);
      final b = int.tryParse(parts[1]);
      if (a == null || b == null) {
        return null;
      }
      if (a > 12 && b <= 12) {
        return _formatMonthDay(b, a);
      }
      if (b > 12 && a <= 12) {
        return preferDayFirst ? _formatMonthDay(b, a) : _formatMonthDay(a, b);
      }
      return preferDayFirst ? _formatMonthDay(b, a) : _formatMonthDay(a, b);
    }

    if (parts.length == 3) {
      final a = int.tryParse(parts[0]);
      final b = int.tryParse(parts[1]);
      final c = int.tryParse(parts[2]);
      if (a == null || b == null || c == null) {
        return null;
      }

      if (parts[0].length == 4) {
        return _formatMonthDay(b, c);
      }
      if (parts[2].length == 4) {
        if (a > 12 && b <= 12) {
          return _formatMonthDay(b, a);
        }
        return preferDayFirst ? _formatMonthDay(b, a) : _formatMonthDay(a, b);
      }
    }

    return null;
  }

  String? _formatMonthDay(int month, int day) {
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return null;
    }
    final check = DateTime(2024, month, day);
    if (check.month != month || check.day != day) {
      return null;
    }
    return '${month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';
  }

  _DateOrderHint inspectOrderHint(String rawInput) {
    var s = _normalizeDigits(rawInput).trim();
    if (s.isEmpty) {
      return _DateOrderHint.unknown;
    }

    s = s
        .replaceAll(RegExp(r'[\u200E\u200F]'), '')
        .replaceAll(RegExp(r'[./_]'), '-')
        .replaceAll(RegExp(r'\s+'), '');

    final dateToken = RegExp(r'(\d{1,4}-\d{1,2}-\d{1,4}|\d{1,2}-\d{1,2})')
        .firstMatch(s)
        ?.group(0);

    if (dateToken == null) {
      return _DateOrderHint.unknown;
    }

    final parts = dateToken.split('-');
    if (parts.length == 2) {
      final a = int.tryParse(parts[0]);
      final b = int.tryParse(parts[1]);
      if (a == null || b == null) {
        return _DateOrderHint.unknown;
      }
      if (a > 12 && b <= 12) {
        return _DateOrderHint.dayFirst;
      }
      if (b > 12 && a <= 12) {
        return _DateOrderHint.monthFirst;
      }
      return _DateOrderHint.unknown;
    }

    if (parts.length == 3 && parts[2].length == 4) {
      final a = int.tryParse(parts[0]);
      final b = int.tryParse(parts[1]);
      if (a == null || b == null) {
        return _DateOrderHint.unknown;
      }
      if (a > 12 && b <= 12) {
        return _DateOrderHint.dayFirst;
      }
      if (b > 12 && a <= 12) {
        return _DateOrderHint.monthFirst;
      }
    }

    return _DateOrderHint.unknown;
  }
}

enum _DateOrderHint { unknown, monthFirst, dayFirst }

class _TimeNormalizer {
  String? normalize(CellValue? value, {bool preferDayFirst = false}) {
    if (value == null) {
      return null;
    }

    if (value is TimeCellValue) {
      return _formatTime(value.hour, value.minute);
    }

    if (value is DateTimeCellValue) {
      return _formatTime(value.hour, value.minute);
    }

    if (value is IntCellValue) {
      return _fromNumeric(value.value.toDouble());
    }

    if (value is DoubleCellValue) {
      return _fromNumeric(value.value);
    }

    if (value is TextCellValue) {
      return _fromText(value.value.toString(), preferDayFirst: preferDayFirst);
    }

    if (value is FormulaCellValue) {
      return _fromText(value.formula, preferDayFirst: preferDayFirst);
    }

    return _fromText(value.toString(), preferDayFirst: preferDayFirst);
  }

  String? _fromNumeric(double raw) {
    if (!raw.isFinite || raw < 0) {
      return null;
    }

    if (raw < 1) {
      return _fromFraction(raw);
    }

    final fraction = raw - raw.floor();
    if (fraction > 0) {
      return _fromFraction(fraction);
    }

    final asInt = raw.round();
    if ((raw - asInt).abs() < 0.000001) {
      if (asInt >= 0 && asInt <= 2359) {
        final h = asInt ~/ 100;
        final m = asInt % 100;
        final parsed = _formatTime(h, m);
        if (parsed != null) {
          return parsed;
        }
      }
      if (asInt >= 0 && asInt <= 86400) {
        final h = (asInt ~/ 3600) % 24;
        final m = (asInt % 3600) ~/ 60;
        return _formatTime(h, m);
      }
    }

    return null;
  }

  String? _fromFraction(double fraction) {
    var totalMinutes = (fraction * 24 * 60).round();
    if (totalMinutes == 24 * 60) {
      totalMinutes = 0;
    }
    final h = totalMinutes ~/ 60;
    final m = totalMinutes % 60;
    return _formatTime(h, m);
  }

  String? _fromText(String rawInput, {required bool preferDayFirst}) {
    var s = _normalizeDigits(rawInput).trim();
    if (s.isEmpty) {
      return null;
    }

    s = s
        .replaceAll(RegExp(r'[\u200E\u200F]'), '')
        .replaceAll('ص', ' am ')
        .replaceAll('م', ' pm ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim()
        .toLowerCase();

    final timeMatch = RegExp(
      r'(\d{1,2})\s*[:٫]\s*(\d{1,2})(?:\s*[:٫]\s*(\d{1,2}))?\s*([ap]\.?m\.?)?',
      caseSensitive: false,
    ).firstMatch(s);

    if (timeMatch != null) {
      var hour = int.tryParse(timeMatch.group(1)!);
      final minute = int.tryParse(timeMatch.group(2)!);
      final ampm = timeMatch.group(4)?.toLowerCase().replaceAll('.', '');

      if (hour == null || minute == null) {
        return null;
      }

      if (ampm == 'am') {
        if (hour == 12) {
          hour = 0;
        }
      } else if (ampm == 'pm') {
        if (hour < 12) {
          hour += 12;
        }
      }

      return _formatTime(hour, minute);
    }

    final digitsOnly = s.replaceAll(RegExp(r'[^0-9]'), '');
    if (digitsOnly.length == 3 || digitsOnly.length == 4) {
      final h = int.tryParse(digitsOnly.substring(0, digitsOnly.length - 2));
      final m = int.tryParse(digitsOnly.substring(digitsOnly.length - 2));
      if (h != null && m != null) {
        return _formatTime(h, m);
      }
    }

    return null;
  }

  String? _formatTime(int hour, int minute) {
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      return null;
    }
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }
}

String _normalizeDigits(String input) {
  const easternArabic = <String, String>{
    '٠': '0',
    '١': '1',
    '٢': '2',
    '٣': '3',
    '٤': '4',
    '٥': '5',
    '٦': '6',
    '٧': '7',
    '٨': '8',
    '٩': '9',
  };
  const persianArabic = <String, String>{
    '۰': '0',
    '۱': '1',
    '۲': '2',
    '۳': '3',
    '۴': '4',
    '۵': '5',
    '۶': '6',
    '۷': '7',
    '۸': '8',
    '۹': '9',
  };

  var out = input;
  easternArabic.forEach((k, v) => out = out.replaceAll(k, v));
  persianArabic.forEach((k, v) => out = out.replaceAll(k, v));
  return out;
}







