import 'package:audioplayers/audioplayers.dart';
import '../theme/app_styles.dart';

// خدمة بسيطة مخصصة لتشغيل الأصوات الموجودة داخل الجهاز دون أي اعتماد على الإنترنت
class AudioService {
  static final AudioPlayer _audioPlayer = AudioPlayer();

  static Future<void> playAdhan({bool isShort = false, String? prayerId}) async {
    final settings = AppStyles.currentSettings;
    if (settings != null) {
      if (settings.isGlobalAudioMuted || settings.isAzanAudioMuted) return;
    }

    // PRIORITY 1: Short Adhan (if enabled in settings)
    if (isShort) {
      try {
        await _audioPlayer.play(AssetSource('audio/short_azan.mp3'));
        return;
      } catch (_) {}
    }

    // PRIORITY 2: Custom Adhan Sounds (if any)
    try {
      if (prayerId != null && settings != null) {
        final customSounds = settings.customAdhanSounds;
        final targetSoundId = settings.prayerAdhanSoundIds[prayerId] ?? settings.defaultAdhanSoundId;
        
        if (targetSoundId != null) {
          final customSound = customSounds.where((s) => s.id == targetSoundId).firstOrNull;
          if (customSound != null) {
            await _audioPlayer.play(DeviceFileSource(customSound.filePath));
            return;
          }
        }
      }
    } catch (_) {}

    // PRIORITY 3: Built-in Default Sounds
    String file;
    if (prayerId == 'fajr') {
      file = 'audio/audio_fajr.mp3';
    } else {
      file = 'audio/audio_azan.mp3';
    }
    
    try {
      await _audioPlayer.play(AssetSource(file));
    } catch (_) {}
  }
  
  static Future<void> playPreIqamaAlert() async {
    if (AppStyles.currentSettings?.isGlobalAudioMuted ?? false) return;
    try {
      await _audioPlayer.play(AssetSource('audio/alert1.mp3'));
    } catch (_) {}
  }

  static Future<void> playDeviceFile(String path) async {
    // We don't mute preview/manual play? Usually we don't, but let's check global mute.
    if (AppStyles.currentSettings?.isGlobalAudioMuted ?? false) return;
    await stop();
    try {
      await _audioPlayer.play(DeviceFileSource(path));
    } catch (_) {}
  }
  
  static Future<void> playIqama({bool isShort = false}) async {
    if (AppStyles.currentSettings?.isGlobalAudioMuted ?? false) return;
    final file = isShort ? 'audio/short_iqama.mp3' : 'audio/iqama.mp3';
    try {
      await _audioPlayer.play(AssetSource(file));
    } catch (_) {}
  }
  
  static Future<void> playBeep() async {
    if (AppStyles.currentSettings?.isGlobalAudioMuted ?? false) return;
    try {
      await _audioPlayer.play(AssetSource('audio/beep.mp3'));
    } catch (_) {}
  }

  static Future<void> stop() async {
    await _audioPlayer.stop();
  }
}
