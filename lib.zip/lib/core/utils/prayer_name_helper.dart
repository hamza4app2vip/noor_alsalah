import '../../l10n/app_localizations_ar.dart';
import '../../l10n/app_localizations_en.dart';
import '../../features/prayer_times/presentation/providers/timer_engine_provider.dart';

class PrayerNameHelper {
  static final _l10nAr = AppLocalizationsAr();
  static final _l10nEn = AppLocalizationsEn();

  /// Gets the primary localized name based on app language.
  static String getName(PrayerName name, String lang) {
    if (lang == 'ar') return getArName(name);
    return getEnName(name);
  }

  /// Gets the secondary (alternative) localized name based on app language.
  static String getAltName(PrayerName name, String lang) {
    if (lang == 'ar') return getEnName(name);
    return getArName(name);
  }

  static String getArName(dynamic name) {
    if (name is String) {
      if (name == 'midnight') return _l10nAr.midnight;
      if (name == 'last_third') return _l10nAr.lastThird;
      return '';
    }
    switch (name) {
      case PrayerName.fajr: return _l10nAr.fajr;
      case PrayerName.sunrise: return _l10nAr.sunrise;
      case PrayerName.dhuhr: return _l10nAr.dhuhr;
      case PrayerName.asr: return _l10nAr.asr;
      case PrayerName.maghrib: return _l10nAr.maghrib;
      case PrayerName.isha: return _l10nAr.isha;
      default: return '';
    }
  }

  static String getEnName(dynamic name) {
    if (name is String) {
      if (name == 'midnight') return _l10nEn.midnight;
      if (name == 'last_third') return _l10nEn.lastThird;
      return '';
    }
    switch (name) {
      case PrayerName.fajr: return _l10nEn.fajr;
      case PrayerName.sunrise: return _l10nEn.sunrise;
      case PrayerName.dhuhr: return _l10nEn.dhuhr;
      case PrayerName.asr: return _l10nEn.asr;
      case PrayerName.maghrib: return _l10nEn.maghrib;
      case PrayerName.isha: return _l10nEn.isha;
      default: return '';
    }
  }
}
