class NumberHelper {
  static const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  static const arabicIndic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  // Backward compatibility for existing call sites.
  static const arabic = arabicIndic;
  static const easternArabic = [
    '۰',
    '۱',
    '۲',
    '۳',
    '۴',
    '۵',
    '۶',
    '۷',
    '۸',
    '۹'
  ];

  static String format(dynamic input, bool useArabicIndic) {
    if (input == null) return '';

    // Always normalize any Arabic/Persian numerals first so English mode
    // is guaranteed to render Latin digits everywhere.
    String normalized = input.toString();
    for (int i = 0; i < english.length; i++) {
      normalized = normalized.replaceAll(arabicIndic[i], english[i]);
      normalized = normalized.replaceAll(easternArabic[i], english[i]);
    }

    if (!useArabicIndic) return normalized;

    String result = normalized;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], arabicIndic[i]);
    }
    return result;
  }
}
