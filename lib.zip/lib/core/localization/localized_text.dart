import '../../l10n/app_localizations.dart';

extension LocalizedTextX on AppLocalizations {
  String tr({required String ar, required String en}) {
    return localeName.toLowerCase().startsWith('ar') ? ar : en;
  }
}
