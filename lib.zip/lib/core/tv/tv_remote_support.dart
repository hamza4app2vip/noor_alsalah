import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../main.dart';

class TvDigitIntent extends Intent {
  const TvDigitIntent(this.digit);

  final int digit;
}

/// Root keyboard/remote handler for TV-style navigation.
///
/// - D-pad arrows move focus.
/// - OK/Enter/Select activates focused controls.
/// - Back/Escape closes overlays/routes, and can confirm app exit on root.
class TvRemoteScope extends StatefulWidget {
  const TvRemoteScope({
    super.key,
    required this.child,
    this.enableDebugLogging = false,
    this.confirmExitOnRoot = false,
    this.exitDialogTitle = 'الخروج من التطبيق',
    this.exitDialogMessage = 'هل تريد إغلاق التطبيق؟',
  });

  final Widget child;
  final bool enableDebugLogging;
  final bool confirmExitOnRoot;
  final String exitDialogTitle;
  final String exitDialogMessage;

  @override
  State<TvRemoteScope> createState() => _TvRemoteScopeState();
}

class _TvRemoteScopeState extends State<TvRemoteScope> {
  final FocusNode _rootFocusNode = FocusNode(debugLabel: 'tv_remote_root');
  static const Duration _backKeyDebounce = Duration(milliseconds: 650);
  DateTime? _lastBackHandledAt;
  bool _isHandlingBack = false;

  @override
  void dispose() {
    _rootFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FocusTraversalGroup(
      policy: ReadingOrderTraversalPolicy(),
      child: Focus(
        focusNode: _rootFocusNode,
        autofocus: true,
        onKeyEvent: _onKeyEvent,
        child: widget.child,
      ),
    );
  }

  KeyEventResult _onKeyEvent(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) {
      return KeyEventResult.ignored;
    }

    final key = event.logicalKey;
    _logKey(key);

    if (_isDirectionalKey(key) && !_isEditableFocused()) {
      _moveFocusByKey(key);
      return KeyEventResult.handled;
    }

    if (_isActivateKey(key) && !_isEditableFocused()) {
      final focusContext =
          FocusManager.instance.primaryFocus?.context ?? context;
      final invoked = Actions.maybeInvoke(focusContext, const ActivateIntent());
      if (invoked != null) {
        return KeyEventResult.handled;
      }
    }

    final digit = _extractDigit(key);
    if (digit != null) {
      if (_isEditableFocused()) {
        return KeyEventResult.ignored;
      }
      final focusContext =
          FocusManager.instance.primaryFocus?.context ?? context;
      final invoked = Actions.maybeInvoke(focusContext, TvDigitIntent(digit));
      if (invoked != null) {
        return KeyEventResult.handled;
      }
    }

    if (_isBackKey(key) || _isExitLikeKey(key)) {
      if (_shouldIgnoreBackOrExit()) {
        return KeyEventResult.handled;
      }
      _isHandlingBack = true;
      unawaited(_handleBackOrExit().whenComplete(() {
        _lastBackHandledAt = DateTime.now();
        _isHandlingBack = false;
      }));
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  void _moveFocusByKey(LogicalKeyboardKey key) {
    final primary = FocusManager.instance.primaryFocus;
    if (primary == null) {
      _rootFocusNode.requestFocus();
      return;
    }

    final direction = _directionFromKey(key);
    if (direction == null) return;

    if (direction == TraversalDirection.up) {
      primary.focusInDirection(TraversalDirection.up);
    } else if (direction == TraversalDirection.down) {
      primary.focusInDirection(TraversalDirection.down);
    } else if (direction == TraversalDirection.left) {
      primary.focusInDirection(TraversalDirection.left);
    } else if (direction == TraversalDirection.right) {
      primary.focusInDirection(TraversalDirection.right);
    }
  }

  Future<void> _handleBackOrExit() async {
    // While editing text, first exit edit mode instead of closing routes.
    if (_isEditableFocused()) {
      FocusManager.instance.primaryFocus?.unfocus();
      return;
    }

    // Prefer popping the navigator closest to focused element (dialog/menu first).
    final focusedContext = FocusManager.instance.primaryFocus?.context;
    final focusedNavigator =
        focusedContext != null ? Navigator.maybeOf(focusedContext) : null;
    if (focusedNavigator != null && focusedNavigator.canPop()) {
      focusedNavigator.pop();
      return;
    }

    final localNavigator = Navigator.maybeOf(context);
    if (localNavigator != null &&
        !identical(localNavigator, focusedNavigator) &&
        localNavigator.canPop()) {
      localNavigator.pop();
      return;
    }

    final rootNavigator = navigatorKey.currentState;
    if (rootNavigator != null && rootNavigator.canPop()) {
      rootNavigator.pop();
      return;
    }

    // Nothing to pop — we're at root.
    if (!widget.confirmExitOnRoot) {
      await SystemNavigator.pop();
      return;
    }

    final shouldExit = await showDialog<bool>(
          context: context,
          barrierDismissible: true,
          builder: (ctx) {
            return AlertDialog(
              title: Text(widget.exitDialogTitle),
              content: Text(widget.exitDialogMessage),
              actions: [
                TextButton(
                  autofocus: true,
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('إلغاء'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(ctx).pop(true),
                  child: const Text('خروج'),
                ),
              ],
            );
          },
        ) ??
        false;

    if (shouldExit) {
      await SystemNavigator.pop();
    }
  }

  bool _isEditableFocused() {
    final focusedContext = FocusManager.instance.primaryFocus?.context;
    if (focusedContext == null) return false;
    return focusedContext.findAncestorWidgetOfExactType<EditableText>() != null;
  }

  bool _isDirectionalKey(LogicalKeyboardKey key) {
    return _directionFromKey(key) != null;
  }

  TraversalDirection? _directionFromKey(LogicalKeyboardKey key) {
    if (key == LogicalKeyboardKey.arrowUp ||
        _matchesDirectionByName(key, direction: 'up')) {
      return TraversalDirection.up;
    }
    if (key == LogicalKeyboardKey.arrowDown ||
        _matchesDirectionByName(key, direction: 'down')) {
      return TraversalDirection.down;
    }
    if (key == LogicalKeyboardKey.arrowLeft ||
        _matchesDirectionByName(key, direction: 'left')) {
      return TraversalDirection.left;
    }
    if (key == LogicalKeyboardKey.arrowRight ||
        _matchesDirectionByName(key, direction: 'right')) {
      return TraversalDirection.right;
    }
    return null;
  }

  bool _matchesDirectionByName(LogicalKeyboardKey key,
      {required String direction}) {
    final keyLabel = key.keyLabel.toLowerCase();
    final debugName = (key.debugName ?? '').toLowerCase();
    if (keyLabel == direction) return true;
    if (debugName.contains('arrow $direction')) return true;
    if (debugName.contains('dpad') && debugName.contains(direction)) {
      return true;
    }
    return false;
  }

  bool _shouldIgnoreBackOrExit() {
    if (_isHandlingBack) return true;
    final last = _lastBackHandledAt;
    if (last == null) return false;
    return DateTime.now().difference(last) < _backKeyDebounce;
  }

  bool _isActivateKey(LogicalKeyboardKey key) {
    final keyLabel = key.keyLabel.toLowerCase();
    final debugName = (key.debugName ?? '').toLowerCase();
    return key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.numpadEnter ||
        key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.gameButtonA ||
        key == LogicalKeyboardKey.space ||
        keyLabel == 'select' ||
        keyLabel.contains('center') ||
        debugName.contains('select') ||
        debugName.contains('center') ||
        debugName.contains('enter');
  }

  bool _isBackKey(LogicalKeyboardKey key) {
    final keyLabel = key.keyLabel.toLowerCase();
    final debugName = (key.debugName ?? '').toLowerCase();
    return key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.browserBack ||
        key == LogicalKeyboardKey.gameButtonB ||
        keyLabel == 'back' ||
        keyLabel == 'go back' ||
        debugName.contains('go back') ||
        debugName.contains('back');
  }

  bool _isExitLikeKey(LogicalKeyboardKey key) {
    final keyLabel = key.keyLabel.toLowerCase();
    final debugName = (key.debugName ?? '').toLowerCase();
    return keyLabel == 'exit' || debugName.contains('exit');
  }

  int? _extractDigit(LogicalKeyboardKey key) {
    final label = key.keyLabel;
    if (label.length == 1) {
      final digit = int.tryParse(label);
      if (digit != null) return digit;
    }

    final debugName = (key.debugName ?? '').toLowerCase();
    final numpadMatch = RegExp(r'numpad ([0-9])').firstMatch(debugName);
    if (numpadMatch != null) {
      return int.tryParse(numpadMatch.group(1)!);
    }

    return null;
  }

  void _logKey(LogicalKeyboardKey key) {
    if (!widget.enableDebugLogging || !kDebugMode) return;
    final keyLabel = key.keyLabel;
    final debugName = key.debugName;
    final keyId = key.keyId;
    debugPrint('[TV-KEY] label=$keyLabel debug=$debugName id=$keyId');
  }
}

/// Focus decorator for custom tappable widgets that were touch-first.
class TvFocusable extends StatefulWidget {
  const TvFocusable({
    super.key,
    required this.child,
    this.onPressed,
    this.autofocus = false,
    this.enabled = true,
    this.focusedScale = 1.0,
    this.borderRadius = const BorderRadius.all(Radius.circular(14)),
    this.focusColor,
    this.ensureVisibleOnFocus = true,
  });

  final Widget child;
  final VoidCallback? onPressed;
  final bool autofocus;
  final bool enabled;
  final double focusedScale;
  final BorderRadius borderRadius;
  final Color? focusColor;
  final bool ensureVisibleOnFocus;

  @override
  State<TvFocusable> createState() => _TvFocusableState();
}

class _TvFocusableState extends State<TvFocusable> {
  bool _isFocused = false;

  Color _effectiveBorderColor(Color requestedColor) {
    // Some call-sites pass low-alpha colors intended for fills.
    // Enforce a visible border color so TV focus is always obvious.
    if (requestedColor.a < 0.65) {
      return requestedColor.withValues(alpha: 0.95);
    }
    return requestedColor;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final highlightColor = widget.focusColor ?? theme.colorScheme.primary;
    final borderColor = _effectiveBorderColor(highlightColor);
    Widget child = widget.child;
    if (widget.onPressed != null) {
      child = GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: widget.enabled ? widget.onPressed : null,
        child: child,
      );
    }

    return FocusableActionDetector(
      enabled: widget.enabled,
      autofocus: widget.autofocus,
      shortcuts: const {
        SingleActivator(LogicalKeyboardKey.enter): ActivateIntent(),
        SingleActivator(LogicalKeyboardKey.numpadEnter): ActivateIntent(),
        SingleActivator(LogicalKeyboardKey.select): ActivateIntent(),
        SingleActivator(LogicalKeyboardKey.space): ActivateIntent(),
      },
      actions: {
        ActivateIntent: CallbackAction<ActivateIntent>(
          onInvoke: (intent) {
            if (widget.enabled) {
              widget.onPressed?.call();
            }
            return null;
          },
        ),
      },
      onFocusChange: (focused) {
        if (!mounted) return;
        setState(() => _isFocused = focused);
        if (focused && widget.ensureVisibleOnFocus) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            Scrollable.ensureVisible(
              context,
              alignment: 0.35,
              duration: const Duration(milliseconds: 180),
              curve: Curves.easeOut,
            );
          });
        }
      },
      child: AnimatedScale(
        scale: _isFocused ? widget.focusedScale : 1,
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOutCubic,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOutCubic,
          decoration: BoxDecoration(
            borderRadius: widget.borderRadius,
            border: Border.all(
              color: _isFocused ? borderColor : Colors.transparent,
              width: 2,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}
