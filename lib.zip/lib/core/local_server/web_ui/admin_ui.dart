// ignore_for_file: lines_longer_than_80_chars
/// The complete admin Web UI served as a Single-Page App.
const String adminUiHtml = r'''
<!DOCTYPE html>
<html dir="rtl" lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم نور — الشريط الإخباري</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0
        }

        :root {
            --gold: #DCB881;
            --gold2: #C9A96E;
            --bg: #0F172A;
            --card: #1E293B;
            --card2: #2D3748;
            --text: #F1F5F9;
            --sub: #94A3B8;
            --danger: #EF4444;
            --success: #22C55E;
            --border: #334155;
            --radius: 16px;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            direction: rtl;
            overflow-x: hidden
        }

        h1,
        h2,
        h3 {
            color: var(--gold);
            font-weight: 900
        }

        button {
            cursor: pointer;
            border: none;
            border-radius: 12px;
            font-family: inherit;
            font-size: 14px;
            padding: 12px 20px;
            transition: all .25s ease;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 14px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: rgba(30, 41, 59, 0.7);
            color: var(--text);
            font-family: inherit;
            font-size: 15px;
            direction: rtl;
            outline: none;
            transition: all .2s ease;
            backdrop-filter: blur(10px)
        }

        input:focus,
        textarea:focus,
        select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 2px rgba(220, 184, 129, 0.2)
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: var(--sub);
            font-size: 13px;
            font-weight: 600
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate {
            animation: fadeIn 0.4s ease forwards
        }

        .card {
            background: var(--card);
            border-radius: var(--radius);
            padding: 24px;
            border: 1px solid var(--border);
            margin-bottom: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3)
        }

        .btn-gold {
            background: linear-gradient(135deg, var(--gold), var(--gold2));
            color: #0F172A;
            box-shadow: 0 4px 15px rgba(220, 184, 129, 0.3)
        }

        .btn-gold:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(220, 184, 129, 0.4)
        }

        .btn-gold:active {
            transform: translateY(0)
        }

        .btn-outline {
            background: transparent;
            color: var(--sub);
            border: 1px solid var(--border)
        }

        .btn-outline:hover {
            border-color: var(--gold);
            color: var(--gold);
            background: rgba(220, 184, 129, 0.05)
        }

        .btn-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid var(--danger)
        }

        .btn-danger:hover {
            background: rgba(239, 68, 68, 0.2)
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 25px;
            font-size: 12px;
            font-weight: 800
        }

        .badge-gold {
            background: rgba(220, 184, 129, .15);
            color: var(--gold);
            border: 1px solid rgba(220, 184, 129, 0.2)
        }

        .badge-red {
            background: rgba(239, 68, 68, .15);
            color: var(--danger)
        }

        .badge-green {
            background: rgba(34, 197, 94, .15);
            color: var(--success)
        }

        /* Header */
        .header {
            background: rgba(30, 41, 59, 0.85);
            backdrop-filter: blur(20px);
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 99
        }

        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #64748B;
            display: inline-block;
            margin-left: 8px;
            position: relative
        }

        .status-dot.live {
            background: var(--success);
            box-shadow: 0 0 10px var(--success)
        }

        .status-dot.live::after {
            content: '';
            position: absolute;
            inset: -4px;
            border-radius: 50%;
            border: 2px solid var(--success);
            animation: pulse 1.5s infinite
        }

        @keyframes pulse {
            0% {
                opacity: 0.8;
                transform: scale(1)
            }

            100% {
                opacity: 0;
                transform: scale(2)
            }
        }

        /* Auth Screens */
        .auth-container {
            max-width: 420px;
            margin: 80px auto;
            padding: 20px
        }

        .auth-step {
            display: none
        }

        .auth-step.active {
            display: block
        }

        .step-indicator {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px
        }

        /* Loader component */
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid var(--border);
            border-top-color: var(--gold);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px auto;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* News List */
        .page {
            display: none;
            padding: 24px;
            max-width: 800px;
            margin: 0 auto
        }

        .page.active {
            display: block
        }

        .news-item {
            background: rgba(30, 41, 59, 0.6);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 18px;
            margin-bottom: 12px;
            display: flex;
            align-items: start;
            gap: 16px;
            transition: all .3s ease
        }

        .news-item:hover {
            border-color: rgba(220, 184, 129, 0.5);
            transform: translateX(-4px);
            background: var(--card)
        }

        /* FAB */
        .fab {
            position: fixed;
            bottom: 30px;
            left: 30px;
            background: var(--gold);
            color: #0F172A;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 25px rgba(220, 184, 129, 0.5);
            z-index: 100;
            transition: all .3s ease
        }

        .fab:hover {
            transform: scale(1.1) rotate(90deg)
        }

        /* Modal */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .8);
            backdrop-filter: blur(8px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 200;
            padding: 20px
        }

        .hidden {
            display: none !important
        }

        .modal {
            background: var(--card);
            border-radius: 24px;
            padding: 30px;
            width: 100%;
            max-width: 550px;
            border: 1px solid var(--border);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5)
        }

        .net-warn {
            background: rgba(239, 68, 68, .1);
            border: 1px solid rgba(239, 68, 68, .3);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 20px;
            display: none;
            font-size: 13px
        }

        .net-warn.show {
            display: flex;
            gap: 12px;
            align-items: center
        }

        /* Slider Range overrides */
        input[type=range] {
            -webkit-appearance: none;
            appearance: none;
            width: 100%;
            background: transparent;
            padding: 0;
            border: none;
            backdrop-filter: none;
        }

        input[type=range]::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            height: 24px;
            width: 24px;
            border-radius: 50%;
            background: var(--gold);
            cursor: pointer;
            margin-top: -8px;
            box-shadow: 0 0 10px rgba(220, 184, 129, 0.5);
        }

        input[type=range]::-webkit-slider-runnable-track {
            width: 100%;
            height: 8px;
            cursor: pointer;
            background: var(--border);
            border-radius: 4px;
            border: none;
        }

        svg {
            width: 20px;
            height: 20px;
            pointer-events: none;
        }

        .icon-sm {
            width: 16px;
            height: 16px;
        }

        .icon-lg {
            width: 32px;
            height: 32px;
            stroke: var(--gold);
        }

        .settings-shell {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .settings-head-card {
            margin-bottom: 0;
            background: linear-gradient(180deg, rgba(220, 184, 129, 0.08), rgba(30, 41, 59, 0.95));
        }

        .settings-head-title {
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .khushoo-state-strip {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 12px;
        }

        .mode-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 10px;
            border-radius: 999px;
            border: 1px solid var(--border);
            color: var(--sub);
            background: rgba(15, 23, 42, 0.45);
            font-size: 12px;
            font-weight: 700;
        }

        .mode-badge.active {
            color: #0F172A;
            border-color: rgba(220, 184, 129, 0.9);
            background: linear-gradient(135deg, var(--gold), var(--gold2));
        }

        .settings-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 14px;
        }

        @media (min-width: 900px) {
            .settings-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        .settings-panel {
            margin-bottom: 0;
        }

        .settings-panel h4 {
            color: var(--gold);
            margin-bottom: 6px;
            font-size: 16px;
        }

        .setting-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            padding: 14px 0;
            border-bottom: 1px solid rgba(148, 163, 184, 0.18);
        }

        .setting-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        .setting-meta {
            flex: 1;
            min-width: 0;
        }

        .setting-title {
            font-weight: 700;
            font-size: 15px;
        }

        .setting-sub {
            font-size: 12px;
            color: var(--sub);
            margin-top: 4px;
            line-height: 1.45;
        }

        .duration-wrap {
            background: rgba(15, 23, 42, 0.5);
            border: 1px solid rgba(148, 163, 184, 0.2);
            border-radius: 12px;
            padding: 12px;
            margin-top: 2px;
        }

        .duration-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            color: var(--sub);
            font-size: 13px;
            font-weight: 700;
        }

        .manual-row {
            margin-top: 10px;
            border: 1px dashed rgba(220, 184, 129, 0.6);
            border-radius: 12px;
            padding: 14px;
            background: rgba(220, 184, 129, 0.06);
        }

        .manual-row .setting-title {
            color: var(--gold);
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 52px;
            height: 30px;
            flex-shrink: 0;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background: var(--border);
            border-radius: 999px;
            transition: 0.25s ease;
        }

        .slider::before {
            content: '';
            position: absolute;
            right: 4px;
            top: 4px;
            width: 22px;
            height: 22px;
            background: #fff;
            border-radius: 50%;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35);
            transition: 0.25s ease;
        }

        .switch input:checked + .slider {
            background: linear-gradient(135deg, var(--gold), var(--gold2));
        }

        .switch input:checked + .slider::before {
            transform: translateX(-22px);
        }

        .sync-row {
            min-height: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
        }

        .sync-indicator {
            display: none;
            padding: 8px 14px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
        }

        .sync-indicator.pending {
            display: inline-flex;
            color: var(--gold);
            background: rgba(220, 184, 129, 0.12);
            border: 1px solid rgba(220, 184, 129, 0.35);
        }

        .sync-indicator.ok {
            display: inline-flex;
            color: var(--success);
            background: rgba(34, 197, 94, 0.12);
            border: 1px solid rgba(34, 197, 94, 0.35);
        }

        .sync-error {
            display: none;
            color: var(--danger);
            font-size: 12px;
            font-weight: 700;
        }

        .settings-footnote {
            text-align: center;
            color: var(--sub);
            font-size: 12px;
        }

        /* Slides Management */
        .slides-container {
            margin-top: 24px;
        }

        .slide-card {
            background: rgba(30, 41, 59, 0.4);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 14px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 14px;
            transition: all 0.2s ease;
        }

        .slide-card:hover {
            border-color: rgba(220, 184, 129, 0.4);
            background: rgba(30, 41, 59, 0.6);
        }

        .slide-card.disabled {
            opacity: 0.6;
            background: rgba(15, 23, 42, 0.3);
        }

        .slide-preview {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            background: var(--card2);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            flex-shrink: 0;
            border: 1px solid var(--border);
        }

        .slide-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .slide-info {
            flex: 1;
            min-width: 0;
        }

        .slide-type-badge {
            font-size: 10px;
            font-weight: 800;
            padding: 2px 8px;
            border-radius: 4px;
            margin-bottom: 4px;
            display: inline-block;
            text-transform: uppercase;
        }

        .type-text { background: rgba(34, 197, 94, 0.15); color: #22C55E; }
        .type-file { background: rgba(220, 184, 129, 0.15); color: var(--gold); }
        .type-link { background: rgba(59, 130, 246, 0.15); color: #3B82F6; }

        .progress-container {
            width: 100%;
            height: 8px;
            background: var(--border);
            border-radius: 4px;
            margin-top: 10px;
            overflow: hidden;
            display: none;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--gold2), var(--gold));
            width: 0%;
            transition: width 0.1s linear;
        }

        .type-options {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 10px;
            margin-bottom: 20px;
        }

        .type-opt {
            padding: 12px;
            border-radius: 12px;
            border: 1px solid var(--border);
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 13px;
            font-weight: 700;
            color: var(--sub);
        }

        .type-opt.active {
            border-color: var(--gold);
            background: rgba(220, 184, 129, 0.1);
            color: var(--gold);
        }
    </style>
</head>

<body>

    <!-- HEADER -->
    <div class="header" id="main-header" style="display:none">
        <div style="display:flex;align-items:center;gap:15px">
            <span class="status-dot" id="status-dot"></span>
            <h2 style="font-size:18px">لوحة تحكم نور</h2>
            <nav style="display:flex;gap:10px;margin-right:20px">
                <button class="btn-outline tab-btn active" id="tab-news" onclick="switchPage('news')"
                    style="padding:6px 15px;font-size:13px">الإعلانات</button>
                <button class="btn-outline tab-btn" id="tab-settings" onclick="switchPage('settings')"
                    style="padding:6px 15px;font-size:13px">برنامج الخشوع</button>
                <button class="btn-outline tab-btn" id="tab-media" onclick="switchPage('media')"
                    style="padding:6px 15px;font-size:13px">الخلفيات والأذان</button>
            </nav>
        </div>
        <div style="display:flex;gap:12px;align-items:center">
            <span id="header-count" class="badge badge-gold" style="display:none"></span>
            <button class="btn-outline" onclick="logout()" style="padding:8px 16px;font-size:13px">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                خروج
            </button>
        </div>
    </div>

    <!-- AUTH CONTAINER -->
    <div class="auth-container" id="auth-container">
        <div class="net-warn" id="net-warn">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <span id="net-warn-msg">تأكد من الاتصال بنفس شبكة Wi-Fi مع الشاشة.</span>
        </div>

        <div class="card">
            <div style="text-align:center;margin-bottom:24px">
                <h1 style="font-size: 24px;display:flex;align-items:center;justify-content:center;gap:8px">
                    <svg fill="none" stroke="var(--gold)" viewBox="0 0 24 24" stroke-width="2"
                        style="width:28px;height:28px;">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" />
                    </svg>
                    نور للمواقيت
                </h1>
                <p id="auth-subtitle" style="color:var(--sub);margin-top:8px;font-size:14px">لوحة تحكم شريط الأخبار</p>
            </div>

            <div class="auth-step active animate" id="step-login">
                <div style="margin-bottom:16px">
                    <label>اسم المستخدم</label>
                    <input type="text" id="user-input" placeholder="admin">
                </div>
                <div style="margin-bottom:16px">
                    <label>كلمة المرور</label>
                    <input type="password" id="pass-input" placeholder="••••••••"
                        onkeydown="if(event.key==='Enter') requestLogin()">
                </div>
                <div style="margin-bottom:24px">
                    <label>اسم جهازك (سوف يظهر على الشاشة)</label>
                    <input type="text" id="device-input" placeholder="مثلاً: هاتف المشرف">
                </div>

                <button class="btn-gold" style="width:100%" id="btn-login" onclick="requestLogin()">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                    </svg>
                    تسجيل الدخول
                </button>
                <p id="auth-error-login"
                    style="color:var(--danger);margin-top:16px;text-align:center;display:none;font-weight:700;font-size:14px">
                </p>
            </div>

            <!-- PENDING APPROVAL OVERLAY -->
            <div class="auth-step animate" id="step-waiting">
                <div style="text-align:center; padding: 20px 0;">
                    <div class="spinner"></div>
                    <h3 style="font-size: 18px; margin-bottom: 8px;">بانتظار الموافقة</h3>
                    <p style="color: var(--sub); font-size: 14px; line-height: 1.5; margin-bottom: 24px;">
                        يرجى تأكيد طلب الدخول من خلال الريموت كنترول على شاشة التلفاز.
                    </p>
                    <button class="btn-danger" style="width:100%" onclick="cancelLogin()">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        إلغاء الطلب
                    </button>
                    <p id="auth-error-wait"
                        style="color:var(--danger);margin-top:16px;text-align:center;display:none;font-weight:700;font-size:14px">
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- NEWS PAGE -->
    <div class="page" id="page-news">
        <div id="news-list" class="animate"></div>

        <div class="empty" id="news-empty" style="display:none;text-align:center;padding:80px 20px;color:var(--sub)">
            <svg class="icon-lg" style="margin-bottom:16px" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
            </svg>
            <h3 style="margin-bottom:8px">لا توجد رسائل حالياً</h3>
            <p>اضغط على زر الإضافة أدناه لإنشاء رسالتك الأولى</p>
        </div>

        <button class="fab" onclick="openAddModal()">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:28px;height:28px">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4" />
            </svg>
        </button>
    </div>

    <!-- SETTINGS PAGE (Khushoo Program) -->
    <div class="page" id="page-settings">
        <div class="animate settings-shell">
            <div class="card settings-head-card">
                <h3 class="settings-head-title">
                    <svg class="icon-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    الإعدادات المتقدمة (برنامج الخشوع)
                </h3>
                <p style="color:var(--sub);font-size:13px;line-height:1.5">
                    نفس خيارات التطبيق في قسم الصوتيات والمنبهات، وتُطبَّق مباشرة على شاشة المواقيت.
                </p>
                <div class="khushoo-state-strip">
                    <span class="mode-badge" id="status-khushoo-mode">الوضع التلقائي: غير مفعّل</span>
                    <span class="mode-badge" id="status-khushoo-manual">التحكم اليدوي: غير مفعّل</span>
                </div>
            </div>

            <div class="settings-grid">
                <div class="card settings-panel">
                    <h4>التحكم في الصوت</h4>
                    <div class="setting-row">
                        <div class="setting-meta">
                            <div class="setting-title">كتم الصوت العام</div>
                            <div class="setting-sub">إيقاف جميع الأصوات في التطبيق</div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="set-global-mute" onchange="updateLiveSettings()">
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="setting-row">
                        <div class="setting-meta">
                            <div class="setting-title">كتم إشعارات الأذان فقط</div>
                            <div class="setting-sub">إيقاف صوت الأذان بشكل منفصل</div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="set-azan-mute" onchange="updateLiveSettings()">
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>

                <div class="card settings-panel">
                    <h4>برنامج الخشوع</h4>
                    <div class="setting-row">
                        <div class="setting-meta">
                            <div class="setting-title">تفعيل الشاشة السوداء (بعد الأذان)</div>
                            <div class="setting-sub">حجب الشاشة لعدم التشتيت بعد الأذان مباشرة</div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="set-khushoo-enabled" onchange="updateLiveSettings()">
                            <span class="slider"></span>
                        </label>
                    </div>

                    <div id="khushoo-duration-container" class="duration-wrap" style="display:none;">
                        <div class="duration-label">
                            <span>مدة الشاشة السوداء</span>
                            <span id="khushoo-dur-label" style="color:var(--gold);font-weight:800">10 دقيقة</span>
                        </div>
                        <input type="range" id="set-khushoo-duration" min="1" max="60" value="10"
                            oninput="document.getElementById('khushoo-dur-label').textContent = Math.floor(this.value) + ' دقيقة'"
                            onchange="updateLiveSettings()">
                    </div>

                    <div class="setting-row manual-row">
                        <div class="setting-meta">
                            <div class="setting-title">تشغيل الشاشة السوداء يدوياً</div>
                            <div class="setting-sub">تفعيل أو إلغاء فوري على شاشة المواقيت</div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="set-khushoo-manual" onchange="updateLiveSettings()">
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>

                <div class="card settings-panel">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                        <h4>إدارة شرائح الإعلانات</h4>
                        <button class="btn-gold" style="padding:6px 12px;font-size:12px" onclick="openSlideModal()">
                            <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4" /></svg>
                            إضافة شريحة
                        </button>
                    </div>
                    
                    <div class="setting-row">
                        <div class="setting-meta">
                            <div class="setting-title">تفعيل عرض الشرائح</div>
                            <div class="setting-sub">عرض الصور والنصوص بالتناوب</div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="set-slides-enabled" onchange="updateLiveSettings()">
                            <span class="slider"></span>
                        </label>
                    </div>

                    <div id="slides-config-container" style="display:none">
                        <div class="setting-row">
                            <div class="setting-meta">
                                <div class="setting-title">ترتيب عشوائي</div>
                                <div class="setting-sub">عرض الشرائح بدون ترتيب محدد</div>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="set-slides-shuffle" onchange="updateLiveSettings()">
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div id="slides-mode-container" style="margin-top: 14px; border-top: 1px dashed var(--border); padding-top: 14px; margin-bottom: 14px;">
                            <label>وضع عرض الشرائح</label>
                            <div class="khushoo-state-strip" style="margin-top: 8px;">
                                <button class="mode-badge" id="btn-slides-after-prayer" onclick="setSlidesMode('AFTER_PRAYER')">بعد الصلاة</button>
                                <button class="mode-badge" id="btn-slides-manual" onclick="setSlidesMode('MANUAL')">يدوي الآن</button>
                            </div>
                            <p style="color:var(--sub);font-size:11px;margin-top:10px;">* وضع "يدوي الآن" لتشغيل العرض فوراً. و "بعد الصلاة" لتشغيلها آلياً بعد الفراغ من الصلاة.</p>
                        </div>
                        
                        <div class="duration-wrap">
                            <div class="duration-label">
                                <span>مدة عرض الشريحة</span>
                                <span id="slide-dur-label" style="color:var(--gold);font-weight:800">15 ثانية</span>
                            </div>
                            <input type="range" id="set-slide-duration" min="1" max="120" value="15"
                                oninput="document.getElementById('slide-dur-label').textContent = this.value + ' ثانية'"
                                onchange="updateLiveSettings()">
                        </div>

                        <div class="duration-wrap" style="margin-top:10px">
                            <div class="duration-label">
                                <span>وقت الشاشة الرئيسية</span>
                                <span id="main-dur-label" style="color:var(--gold);font-weight:800">12 ثانية</span>
                            </div>
                            <input type="range" id="set-main-duration" min="1" max="120" value="12"
                                oninput="document.getElementById('main-dur-label').textContent = this.value + ' ثانية'"
                                onchange="updateLiveSettings()">
                        </div>

                        <div class="slides-container" id="slides-list">
                            <!-- Slides will be rendered here -->
                        </div>
                    </div>
                </div>
            </div>
            </div>

            <div class="sync-row">
                <span id="save-indicator" class="sync-indicator"></span>
                <span id="save-error" class="sync-error"></span>
            </div>

            <p class="settings-footnote">جميع التغييرات يتم تطبيقها فورًا وبشكل لحظي على التطبيق.</p>
        </div>
    </div>

    <!-- MEDIA PAGE (Backgrounds & Adhan) -->
    <div class="page" id="page-media">
        <div class="animate settings-shell">
            <div class="card settings-head-card">
                <h3 class="settings-head-title">
                    <svg class="icon-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    إدارة الخلفيات وأصوات الأذان
                </h3>
                <p style="color:var(--sub);font-size:13px;line-height:1.5">
                    ارفع خلفيات جديدة أو أصوات أذان من هاتفك مباشرة إلى الشاشة.
                </p>
            </div>

            <!-- Backgrounds Section -->
            <div class="card settings-panel">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                    <h4>الخلفيات</h4>
                    <button class="btn-gold" style="padding:6px 12px;font-size:12px" onclick="document.getElementById('bg-file-input').click()">
                        <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4" /></svg>
                        رفع خلفية
                    </button>
                    <input type="file" id="bg-file-input" style="display:none" accept="image/*" onchange="uploadBackground(this)">
                </div>
                <div class="progress-container" id="bg-progress-container">
                    <div class="progress-fill" id="bg-progress-fill"></div>
                </div>
                <p id="bg-upload-status" style="font-size:12px;color:var(--gold);margin-top:5px;text-align:center;display:none"></p>
                <div id="bg-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:10px;margin-top:16px"></div>
                <p id="bg-empty" style="text-align:center;color:var(--sub);font-size:14px;padding:30px 0;display:none">لا توجد خلفيات مرفوعة بعد</p>
            </div>

            <!-- Adhan Sounds Section -->
            <div class="card settings-panel">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                    <h4>أصوات الأذان</h4>
                    <button class="btn-gold" style="padding:6px 12px;font-size:12px" onclick="document.getElementById('adhan-file-input').click()">
                        <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4" /></svg>
                        رفع صوت أذان
                    </button>
                    <input type="file" id="adhan-file-input" style="display:none" accept="audio/*" onchange="uploadAdhan(this)">
                </div>
                <div class="progress-container" id="adhan-progress-container">
                    <div class="progress-fill" id="adhan-progress-fill"></div>
                </div>
                <p id="adhan-upload-status" style="font-size:12px;color:var(--gold);margin-top:5px;text-align:center;display:none"></p>
                <div id="adhan-list" style="display:flex;flex-direction:column;gap:10px;margin-top:16px"></div>
                <p id="adhan-empty" style="text-align:center;color:var(--sub);font-size:14px;padding:30px 0;display:none">لا توجد أصوات أذان مرفوعة بعد</p>
            </div>
        </div>
    </div>
    <div class="modal-overlay hidden" id="modal-slide">
        <div class="modal animate">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
                <h2 id="slide-modal-title">إضافة شريحة جديدة</h2>
                <button onclick="closeSlideModal()"
                    style="background:var(--card2);padding:8px;border-radius:50%;width:36px;height:36px">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <input type="hidden" id="slide-edit-id">
            
            <label>نوع الشريحة</label>
            <div class="type-options">
                <div class="type-opt active" id="opt-TEXT" onclick="setSlideType('TEXT')">نص</div>
                <div class="type-opt" id="opt-FILE" onclick="setSlideType('FILE')">صورة</div>
                <div class="type-opt" id="opt-LINK" onclick="setSlideType('LINK')">رابط</div>
            </div>

            <div id="slide-content-text">
                <label>محتوى النص</label>
                <textarea id="slide-text" rows="4" placeholder="أدخل نص الشريحة هنا... (استخدم | لتقسيم الأسطر)"></textarea>
            </div>

            <div id="slide-content-file" style="display:none">
                <label>اختيار صورة</label>
                <button class="btn-outline" style="width:100%;padding:20px;border-style:dashed" onclick="document.getElementById('file-input').click()">
                    <svg class="icon-lg" style="margin-bottom:8px" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <div id="file-name-label">اضغط لاختيار صورة من جهازك</div>
                </button>
                <input type="file" id="file-input" style="display:none" accept="image/*" onchange="onFileSelected(this)">
                
                <div class="progress-container" id="upload-progress-container">
                    <div class="progress-fill" id="upload-progress-fill"></div>
                </div>
                <p id="upload-status" style="font-size:12px;color:var(--gold);margin-top:5px;text-align:center;display:none"></p>
            </div>

            <div id="slide-content-link" style="display:none">
                <label>رابط الصورة (URL)</label>
                <input type="text" id="slide-link" placeholder="https://example.com/image.jpg" oninput="previewUrlImage(this.value)">
                <div id="url-preview" style="margin-top:15px;border-radius:12px;overflow:hidden;background:rgba(0,0,0,0.2);display:none;height:120px;align-items:center;justify-content:center">
                    <img id="url-preview-img" style="max-width:100%;max-height:100%;object-fit:contain">
                </div>
            </div>

            <div style="display:flex;gap:12px;margin-top:30px">
                <button class="btn-outline" style="flex:1" onclick="closeSlideModal()">إلغاء</button>
                <button class="btn-gold" style="flex:2" id="btn-save-slide" onclick="saveSlide()">
                    حفظ الشريحة
                </button>
            </div>
        </div>
    </div>

    <script>
        'use strict';
        let token = localStorage.getItem('noor_token') || '';
        let pollTimer = null;
        let authReqId = null;
        let currentSlides = [];
        let activeSlideType = 'TEXT';
        let selectedFile = null;
        let currentSlidesShowMode = 'AFTER_PRAYER';

        function setSlidesMode(mode) {
            currentSlidesShowMode = mode;
            updateSlidesModeButtons(mode);
            updateLiveSettings();
        }

        function updateSlidesModeButtons(mode) {
            const btnAfter = document.getElementById('btn-slides-after-prayer');
            const btnManual = document.getElementById('btn-slides-manual');
            if (btnAfter) btnAfter.classList.toggle('active', mode === 'AFTER_PRAYER');
            if (btnManual) btnManual.classList.toggle('active', mode === 'MANUAL');
        }

        // Convert Hours to Seconds for Backend
        function getDurSeconds() {
            return parseInt(document.getElementById('news-duration').value) * 3600;
        }

        // Format Duration Display
        function formatDur(hours) {
            if (hours == 1) return 'ساعة واحدة';
            if (hours == 2) return 'ساعتان';
            if (hours < 24) return hours + ' ساعات';
            const days = Math.floor(hours / 24);
            if (days == 1) return 'يوم واحد';
            if (days == 2) return 'يومان';
            if (days < 7) return days + ' أيام';
            if (days == 7) return 'أسبوع واحد';
            if (days == 14) return 'أسبوعان';
            if (days == 30) return 'شهر واحد';
            const weeks = Math.round(days / 7);
            return weeks + ' أسابيع';
        }

        function updateDurLabel(val) {
            document.getElementById('dur-label').textContent = formatDur(val);
        }

        // Handle reverse lookup (seconds to slider val)
        function setDurSliderFromSeconds(sec) {
            let hrs = Math.round((sec || 86400) / 3600);
            if (hrs < 1) hrs = 1;
            if (hrs > 720) hrs = 720;
            document.getElementById('news-duration').value = hrs;
            updateDurLabel(hrs);
        }

        // ─── Initialization ────────────────────────────────────────────────────────
        window.onload = async () => {
            const health = await checkHealth();
            if (!health) {
                showStatus('error', '⚠️ غير متصل بالشاشة. تأكد من البقاء على نفس الشبكة المحلية.');
                document.getElementById('step-login').style.pointerEvents = 'none';
                document.getElementById('step-login').style.opacity = '0.5';
                return;
            }

            if (token) {
                const ok = await loadNews();
                if (ok) return showApp();
                token = ''; // token invalid
                localStorage.removeItem('noor_token');
            }
        };

        async function checkHealth() {
            try {
                const r = await fetch('/health', { signal: AbortSignal.timeout(3000) });
                if (!r.ok) return null;
                return await r.json();
            } catch (e) { return null; }
        }

        // ─── Auth Flow ─────────────────────────────────────────────────────────────

        async function requestLogin() {
            const username = document.getElementById('user-input').value || 'admin';
            const password = document.getElementById('pass-input').value;
            const deviceName = document.getElementById('device-input').value || 'متصفح ويب';
            const btn = document.getElementById('btn-login');

            if (!password) return showError('login', 'كلمة المرور مطلوبة');

            btn.disabled = true;
            btn.innerHTML = 'جاري الطلب... <span class="spinner" style="width:20px;height:20px;border-width:2px;margin:0 0 0 8px;display:inline-block;vertical-align:middle"></span>';
            showError('login', '');

            try {
                const r = await fetch('/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password, deviceName })
                });
                const data = await r.json();

                if (!r.ok) {
                    showError('login', data.error || 'فشل تسجيل الدخول');
                    btn.disabled = false;
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg> تسجيل الدخول';
                    return;
                }

                if (data.status === 'pending_approval' && data.requestId) {
                    authReqId = data.requestId;
                    document.getElementById('step-login').classList.remove('active');
                    document.getElementById('step-waiting').classList.add('active');
                    startPolling();
                } else if (data.token) {
                    token = data.token;
                    localStorage.setItem('noor_token', token);
                    showApp();
                }
            } catch (e) {
                showError('login', 'خطأ في الاتصال بالشبكة');
                btn.disabled = false;
                btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg> تسجيل الدخول';
            }
        }

        function startPolling() {
            if (pollTimer) clearInterval(pollTimer);
            pollTimer = setInterval(async () => {
                try {
                    const r = await fetch('/login/status?requestId=' + authReqId);
                    const data = await r.json();

                    if (r.status === 404 || r.status === 401 || data.error) {
                        clearInterval(pollTimer);
                        showError('wait', 'تم رفض الطلب أو انتهت صلاحيته من قبل الشاشة');
                        setTimeout(() => cancelLogin(), 3000); // go back automatically
                        return;
                    }

                    if (data.status === 'confirmed' && data.token) {
                        clearInterval(pollTimer);
                        token = data.token;
                        localStorage.setItem('noor_token', token);
                        showApp();
                    }
                } catch (e) {
                    console.error('Polling error', e);
                }
            }, 2000);
        }

        function cancelLogin() {
            if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
            authReqId = null;
            showError('wait', '');
            document.getElementById('step-waiting').classList.remove('active');
            document.getElementById('btn-login').disabled = false;
            document.getElementById('btn-login').innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg> تسجيل الدخول';
            document.getElementById('step-login').classList.add('active');
        }

        function showError(step, m) {
            const e = document.getElementById('auth-error-' + step);
            if (!e) return;
            e.textContent = m;
            e.style.display = m ? 'block' : 'none';
        }

        function showStatus(type, msg) {
            const warn = document.getElementById('net-warn');
            const msgEl = document.getElementById('net-warn-msg');
            if (warn) {
                warn.className = 'net-warn show';
                if (type === 'error') warn.style.borderColor = 'var(--danger)';
            }
            if (msgEl) msgEl.textContent = msg;
        }

        function showApp() {
            document.getElementById('auth-container').style.display = 'none';
            document.getElementById('main-header').style.display = 'flex';
            document.getElementById('page-news').classList.add('active');
            startSSE();
            loadNews(); // initial load
        }

        function logout() {
            localStorage.removeItem('noor_token');
            location.reload();
        }

        // ─── SSE & Dashboard ────────────────────────────────────────────────────────

        let sse;
        function startSSE() {
            if (sse) sse.close();
            sse = new EventSource('/events?token=' + encodeURIComponent(token));
            sse.onopen = () => document.getElementById('status-dot').classList.add('live');
            sse.onerror = () => document.getElementById('status-dot').classList.remove('live');
            sse.addEventListener('news_updated', () => loadNews());
            sse.addEventListener('settings_updated', (event) => {
                try {
                    const payload = JSON.parse(event.data || '{}');
                    if (payload.settings) applySettingsToUi(payload.settings);
                } catch (e) {
                    console.warn('Failed to parse settings SSE event', e);
                }
            });
        }

        const getSvgIcon = (type) => {
            if (type === 'daily') return '<svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>';
            if (type === 'jomoa') return '<svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" /></svg>';
            return '<svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>';
        };

        async function loadNews() {
            try {
                const r = await fetch('/news', { headers: { 'Authorization': 'Bearer ' + token } });
                if (r.status === 401 || r.status === 403) {
                    logout();
                    return false;
                }
                if (!r.ok) return false;
                const data = await r.json();
                renderNews(data.items);
                return true;
            } catch (e) { return false; }
        }

        function renderNews(items) {
            const list = document.getElementById('news-list');
            const empty = document.getElementById('news-empty');
            if (!items || items.length === 0) {
                list.innerHTML = ''; empty.style.display = 'block';
                document.getElementById('header-count').style.display = 'none';
                return;
            }
            empty.style.display = 'none';
            document.getElementById('header-count').style.display = 'inline-flex';
            document.getElementById('header-count').textContent = `${items.length} رسائل`;

            list.innerHTML = items.map(item => `
    <div class="news-item">
      <div style="flex:1">
        <div style="font-size:15px;line-height:1.6;font-weight:500;padding-bottom:10px;">${item.text}</div>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
          <button type="button" onclick="toggleNews('${item.id}', ${item.enabled})" class="badge ${item.enabled ? 'badge-green' : 'badge-red'}" style="cursor:pointer;border:none;font-family:inherit;padding:6px 14px;box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
              ${item.enabled ? '<svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7" /></svg> نشط (إيقاف)' : '<svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> متوقف (تفعيل)'}
          </button>
          <span class="badge badge-gold">
            ${getSvgIcon(item.scheduleType)}
            ${item.scheduleType === 'daily' ? 'يومياً' : item.scheduleType === 'jomoa' ? 'الجمعة' : item.date}
          </span>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-direction:column">
        <button type="button" class="btn-outline" style="padding:10px" onclick="openEditModal('${item.id}')">
            <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
        </button>
        <button type="button" class="btn-outline" style="padding:10px;color:var(--danger);border-color:rgba(239,68,68,0.2)" onclick="deleteNews('${item.id}')">
            <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
        </button>
      </div>
    </div>
  `).join('');
        }

        async function toggleNews(id, currentState) {
            try {
                const r = await fetch('/news', { headers: { 'Authorization': 'Bearer ' + token } });
                const data = await r.json();
                const item = data.items.find(i => i.id === id);
                if (!item) return;

                const body = {
                    text: item.text,
                    scheduleType: item.scheduleType,
                    date: item.date,
                    displayDurationSeconds: item.displayDurationSeconds,
                    enabled: !currentState
                };

                await fetch('/news/' + id, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
                    body: JSON.stringify(body)
                });
                loadNews();
            } catch (e) { console.error('Error toggling news:', e); }
        }

        async function saveNews() {
            const text = document.getElementById('news-text').value;
            const id = document.getElementById('edit-id').value;
            if (!text.trim()) {
                alert("يرجى إدخال نص الإعلان");
                return;
            }

            const btn = document.querySelector('#modal .btn-gold');
            const originalHtml = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = 'جاري الحفظ...';

            const body = {
                text,
                scheduleType: document.getElementById('news-schedule').value,
                date: document.getElementById('news-date').value,
                displayDurationSeconds: getDurSeconds(),
                enabled: true
            };

            try {
                const r = await fetch(id ? `/news/${id}` : '/news', {
                    method: id ? 'PUT' : 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
                    body: JSON.stringify(body)
                });
                if (r.ok) { closeModal(); loadNews(); }
                else { alert('فشل الحفظ'); }
            } catch (e) {
                console.error(e);
                alert('حدث خطأ');
            }
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }

        async function deleteNews(id) {
            if (!confirm('هل متأكد من حذف هذه الرسالة حقاً؟')) return;
            try {
                await fetch(`/news/${id}`, { method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token } });
                loadNews();
            } catch (e) { console.error('Error deleting news:', e); }
        }

        function onScheduleChange() {
            document.getElementById('date-group').style.display = document.getElementById('news-schedule').value === 'date' ? 'block' : 'none';
        }

        function openAddModal() {
            document.getElementById('edit-id').value = '';
            document.getElementById('news-text').value = '';
            document.getElementById('news-schedule').value = 'daily';
            setDurSliderFromSeconds(86400); // 1 Day default
            onScheduleChange();
            document.getElementById('modal').classList.remove('hidden');
        }

        async function openEditModal(id) {
            const r = await fetch('/news', { headers: { 'Authorization': 'Bearer ' + token } });
            const data = await r.json();
            const item = data.items.find(i => i.id === id);
            if (!item) return;

            document.getElementById('edit-id').value = id;
            document.getElementById('news-text').value = item.text;
            document.getElementById('news-schedule').value = item.scheduleType;
            document.getElementById('news-date').value = item.date || '';
            setDurSliderFromSeconds(item.displayDurationSeconds);
            onScheduleChange();
            document.getElementById('modal').classList.remove('hidden');
        }

        function closeModal() { document.getElementById('modal').classList.add('hidden'); }

        // --- Multi-Page Navigation ---
        function switchPage(pageId) {
            document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));

            document.getElementById('page-' + pageId).classList.add('active');
            document.getElementById('tab-' + pageId).classList.add('active');

            if (pageId === 'settings') loadSettings();
            if (pageId === 'media') { loadBackgrounds(); loadAdhanSounds(); }
        }

        // --- Settings Management ---
        let settingsSyncTimer;

        function updateKhushooBadges(settings) {
            const modeBadge = document.getElementById('status-khushoo-mode');
            const manualBadge = document.getElementById('status-khushoo-manual');

            const modeOn = !!settings.khushooModeEnabled;
            const manualOn = !!settings.isKhushooManualActive;

            modeBadge.textContent = modeOn ? 'الوضع التلقائي: مفعّل' : 'الوضع التلقائي: غير مفعّل';
            manualBadge.textContent = manualOn ? 'التحكم اليدوي: مفعّل الآن' : 'التحكم اليدوي: غير مفعّل';

            modeBadge.classList.toggle('active', modeOn);
            manualBadge.classList.toggle('active', manualOn);
        }

        function applySettingsToUi(settings) {
            document.getElementById('set-global-mute').checked = !!settings.isGlobalAudioMuted;
            document.getElementById('set-azan-mute').checked = !!settings.isAzanAudioMuted;
            document.getElementById('set-khushoo-enabled').checked = !!settings.khushooModeEnabled;

            const duration = Number.isFinite(Number(settings.khushooModeDuration))
                ? Math.min(60, Math.max(1, Number(settings.khushooModeDuration)))
                : 5;
            document.getElementById('set-khushoo-duration').value = duration;
            document.getElementById('khushoo-dur-label').textContent = duration + ' دقيقة';
            document.getElementById('set-khushoo-manual').checked = !!settings.isKhushooManualActive;

            document.getElementById('khushoo-duration-container').style.display = settings.khushooModeEnabled ? 'block' : 'none';
            document.getElementById('slides-config-container').style.display = settings.slidesEnabled ? 'block' : 'none';
            
            document.getElementById('set-slides-enabled').checked = !!settings.slidesEnabled;
            document.getElementById('set-slides-shuffle').checked = !!settings.slidesShuffle;
            
            const slideDur = settings.slideDurationSeconds || 15;
            document.getElementById('set-slide-duration').value = slideDur;
            document.getElementById('slide-dur-label').textContent = slideDur + ' ثانية';
            
            const mainDur = settings.mainScreenDurationSeconds || 12;
            document.getElementById('set-main-duration').value = mainDur;
            document.getElementById('main-dur-label').textContent = mainDur + ' ثانية';

            currentSlides = settings.slidesList || [];
            currentSlidesShowMode = settings.slidesShowMode || 'AFTER_PRAYER';
            updateSlidesModeButtons(currentSlidesShowMode);
            renderSlides(currentSlides);
            updateKhushooBadges(settings);
        }

        function renderSlides(slides) {
            const list = document.getElementById('slides-list');
            if (slides.length === 0) {
                list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--sub);font-size:13px">لا توجد شرائح حالياً</div>';
                return;
            }

            list.innerHTML = slides.map((s, idx) => {
                let preview = '<svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" /></svg>';
                if (s.type === 'FILE' && s.content) {
                    preview = `<img src="/slides/${s.content}" alt="preview">`;
                } else if (s.type === 'LINK' && s.content) {
                    preview = `<img src="${s.content}" alt="preview" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22none%22 stroke=%22%2394A3B8%22 stroke-width=%221.5%22><path d=%22M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z%22/></svg>'">`;
                }

                return `
                    <div class="slide-card ${s.enabled ? '' : 'disabled'}">
                        <div class="slide-preview">${preview}</div>
                        <div class="slide-info">
                            <span class="slide-type-badge type-${s.type.toLowerCase()}">${s.type === 'TEXT' ? 'نص' : s.type === 'FILE' ? 'صورة' : 'رابط'}</span>
                            <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${s.type === 'TEXT' ? s.content.replace(/\|/g, ' ') : s.content}</div>
                        </div>
                        <div style="display:flex;gap:4px">
                            <button class="btn-outline" style="padding:6px" onclick="openSlideModal('${s.id}')">
                                <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                            </button>
                            <button class="btn-outline" style="padding:6px;color:var(--danger)" onclick="deleteSlide('${s.id}')">
                                <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </button>
                            <label class="switch" style="width:40px;height:24px">
                                <input type="checkbox" ${s.enabled ? 'checked' : ''} onchange="toggleSlide('${s.id}', this.checked)">
                                <span class="slider" style="before:width:16px;before:height:16px;before:right:3px;before:top:4px"></span>
                            </label>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // --- Slide Modal Functions ---
        function openSlideModal(id = null) {
            const modal = document.getElementById('modal-slide');
            const title = document.getElementById('slide-modal-title');
            const editId = document.getElementById('slide-edit-id');
            
            // Reset
            editId.value = id || '';
            title.textContent = id ? 'تعديل الشريحة' : 'إضافة شريحة جديدة';
            document.getElementById('slide-text').value = '';
            document.getElementById('slide-link').value = '';
            document.getElementById('file-name-label').textContent = 'اضغط لاختيار صورة من جهازك';
            document.getElementById('url-preview').style.display = 'none';
            selectedFile = null;
            resetUploadUI();

            if (id) {
                const slide = currentSlides.find(s => s.id === id);
                if (slide) {
                    setSlideType(slide.type);
                    if (slide.type === 'TEXT') document.getElementById('slide-text').value = slide.content;
                    if (slide.type === 'LINK') {
                        document.getElementById('slide-link').value = slide.content;
                        previewUrlImage(slide.content);
                    }
                    if (slide.type === 'FILE') document.getElementById('file-name-label').textContent = slide.content;
                }
            } else {
                setSlideType('TEXT');
            }

            modal.classList.remove('hidden');
        }

        function closeSlideModal() {
            document.getElementById('modal-slide').classList.add('hidden');
        }

        function setSlideType(type) {
            activeSlideType = type;
            document.querySelectorAll('.type-opt').forEach(opt => opt.classList.remove('active'));
            document.getElementById('opt-' + type).classList.add('active');
            
            document.getElementById('slide-content-text').style.display = type === 'TEXT' ? 'block' : 'none';
            document.getElementById('slide-content-file').style.display = type === 'FILE' ? 'block' : 'none';
            document.getElementById('slide-content-link').style.display = type === 'LINK' ? 'block' : 'none';
        }

        function onFileSelected(input) {
            if (input.files && input.files[0]) {
                selectedFile = input.files[0];
                document.getElementById('file-name-label').textContent = selectedFile.name;
            }
        }

        function previewUrlImage(url) {
            const container = document.getElementById('url-preview');
            const img = document.getElementById('url-preview-img');
            if (url && (url.startsWith('http') || url.startsWith('https'))) {
                img.src = url;
                container.style.display = 'flex';
                img.onerror = () => container.style.display = 'none';
            } else {
                container.style.display = 'none';
            }
        }

        function resetUploadUI() {
            document.getElementById('upload-progress-container').style.display = 'none';
            document.getElementById('upload-progress-fill').style.width = '0%';
            document.getElementById('upload-status').style.display = 'none';
        }

        async function saveSlide() {
            const editId = document.getElementById('slide-edit-id').value;
            let content = '';

            if (activeSlideType === 'TEXT') content = document.getElementById('slide-text').value;
            if (activeSlideType === 'LINK') content = document.getElementById('slide-link').value;
            
            if (activeSlideType === 'FILE') {
                if (selectedFile) {
                    // Upload first
                    content = await uploadFile(selectedFile);
                    if (!content) return; // Upload failed
                } else if (editId) {
                    const slide = currentSlides.find(s => s.id === editId);
                    content = slide ? slide.content : '';
                }
            }

            if (!content) {
                alert('يرجى إكمال بيانات الشريحة');
                return;
            }

            const newSlide = {
                id: editId || 'ws_' + Date.now(),
                type: activeSlideType,
                content: content,
                enabled: editId ? (currentSlides.find(s => s.id === editId)?.enabled ?? true) : true,
                order: editId ? (currentSlides.find(s => s.id === editId)?.order ?? 0) : currentSlides.length
            };

            let updatedList = [...currentSlides];
            if (editId) {
                const idx = updatedList.findIndex(s => s.id === editId);
                if (idx !== -1) updatedList[idx] = newSlide;
            } else {
                updatedList.push(newSlide);
            }

            // Sync all settings including new slidesList
            await syncSlidesList(updatedList);
            closeSlideModal();
        }

        async function uploadFile(file) {
            const progressContainer = document.getElementById('upload-progress-container');
            const progressFill = document.getElementById('upload-progress-fill');
            const statusLabel = document.getElementById('upload-status');
            const btn = document.getElementById('btn-save-slide');

            progressContainer.style.display = 'block';
            statusLabel.style.display = 'block';
            statusLabel.textContent = 'جاري رفع الصورة...';
            btn.disabled = true;

            const safeName = Date.now() + '_' + file.name.replace(/\s+/g, '_');
            
            return new Promise((resolve, reject) => {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '/api/upload', true);
                xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                xhr.setRequestHeader('X-File-Name', encodeURIComponent(safeName));
                
                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) {
                        const percent = (e.loaded / e.total) * 100;
                        progressFill.style.width = percent + '%';
                        statusLabel.textContent = `جاري الرفع: ${Math.round(percent)}%`;
                    }
                };

                xhr.onload = () => {
                    if (xhr.status === 200) {
                        const res = JSON.parse(xhr.responseText);
                        statusLabel.textContent = 'تم الرفع بنجاح!';
                        btn.disabled = false;
                        resolve(res.fileName);
                    } else {
                        statusLabel.textContent = 'فشل الرفع!';
                        btn.disabled = false;
                        alert('فشل رفع الملف. حاول مرة أخرى.');
                        resolve(null);
                    }
                };

                xhr.onerror = () => {
                    statusLabel.textContent = 'خطأ في الاتصال!';
                    btn.disabled = false;
                    resolve(null);
                };

                // Send raw bytes
                xhr.send(file);
            });
        }

        async function deleteSlide(id) {
            if (!confirm('هل متأكد من حذف هذه الشريحة؟')) return;
            const updated = currentSlides.filter(s => s.id !== id);
            await syncSlidesList(updated);
        }

        async function toggleSlide(id, enabled) {
            const updated = currentSlides.map(s => s.id === id ? { ...s, enabled } : s);
            await syncSlidesList(updated);
        }

        async function syncSlidesList(newList) {
            // We reuse updateLiveSettings but with a manual object if called from here
            const settings = {
                isGlobalAudioMuted: document.getElementById('set-global-mute').checked,
                isAzanAudioMuted: document.getElementById('set-azan-mute').checked,
                khushooModeEnabled: document.getElementById('set-khushoo-enabled').checked,
                khushooModeDuration: parseInt(document.getElementById('set-khushoo-duration').value, 10),
                isKhushooManualActive: document.getElementById('set-khushoo-manual').checked,
                slidesEnabled: document.getElementById('set-slides-enabled').checked,
                slidesShuffle: document.getElementById('set-slides-shuffle').checked,
                slideDurationSeconds: parseInt(document.getElementById('set-slide-duration').value, 10),
                mainScreenDurationSeconds: parseInt(document.getElementById('set-main-duration').value, 10),
                slidesShowMode: currentSlidesShowMode,
                slidesList: newList
            };
            await sendSettingsUpdate(settings);
        }

        async function loadSettings() {
            const error = document.getElementById('save-error');
            error.style.display = 'none';

            try {
                const r = await fetch('/api/settings', { headers: { 'Authorization': 'Bearer ' + token } });
                if (r.status === 401 || r.status === 403) {
                    logout();
                    return;
                }
                if (!r.ok) {
                    throw new Error('HTTP ' + r.status);
                }

                const settings = await r.json();
                applySettingsToUi(settings);
            } catch (e) {
                console.error('Failed to load settings', e);
                error.textContent = 'تعذر تحميل إعدادات برنامج الخشوع.';
                error.style.display = 'block';
            }
        }

        async function updateLiveSettings() {
            const khushooEnabled = document.getElementById('set-khushoo-enabled').checked;
            const slidesEnabled = document.getElementById('set-slides-enabled').checked;
            
            document.getElementById('khushoo-duration-container').style.display = khushooEnabled ? 'block' : 'none';
            document.getElementById('slides-config-container').style.display = slidesEnabled ? 'block' : 'none';

            const settings = {
                isGlobalAudioMuted: document.getElementById('set-global-mute').checked,
                isAzanAudioMuted: document.getElementById('set-azan-mute').checked,
                khushooModeEnabled: khushooEnabled,
                khushooModeDuration: parseInt(document.getElementById('set-khushoo-duration').value, 10),
                isKhushooManualActive: document.getElementById('set-khushoo-manual').checked,
                slidesEnabled: slidesEnabled,
                slidesShuffle: document.getElementById('set-slides-shuffle').checked,
                slideDurationSeconds: parseInt(document.getElementById('set-slide-duration').value, 10),
                mainScreenDurationSeconds: parseInt(document.getElementById('set-main-duration').value, 10),
                slidesShowMode: currentSlidesShowMode,
                slidesList: currentSlides
            };

            await sendSettingsUpdate(settings);
        }

        async function sendSettingsUpdate(settings) {
            const indicator = document.getElementById('save-indicator');
            const error = document.getElementById('save-error');

            clearTimeout(settingsSyncTimer);
            error.style.display = 'none';
            indicator.className = 'sync-indicator pending';
            indicator.style.display = 'inline-flex';
            indicator.textContent = 'جاري المزامنة...';

            try {
                const r = await fetch('/api/settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
                    body: JSON.stringify(settings)
                });

                if (!r.ok) {
                    const body = await r.text();
                    throw new Error(body || ('HTTP ' + r.status));
                }

                const result = await r.json();
                if (result.settings) {
                    applySettingsToUi(result.settings);
                } else {
                    applySettingsToUi(settings);
                }

                indicator.className = 'sync-indicator ok';
                indicator.style.display = 'inline-flex';
                indicator.textContent = 'تمت المزامنة الفورية';
                settingsSyncTimer = setTimeout(() => {
                    indicator.style.display = 'none';
                }, 1500);
            } catch (e) {
                console.error('Failed to sync settings', e);
                indicator.style.display = 'none';
                error.textContent = 'فشل إرسال التعديل إلى الشاشة.';
                error.style.display = 'block';
            }
        }

        // ─── Media Management (Backgrounds & Adhan) ──────────────────────────────

        async function loadBackgrounds() {
            try {
                const r = await fetch('/api/backgrounds', { headers: { 'Authorization': 'Bearer ' + token } });
                const data = await r.json();
                const grid = document.getElementById('bg-grid');
                const empty = document.getElementById('bg-empty');
                grid.innerHTML = '';
                if (!data.backgrounds || data.backgrounds.length === 0) {
                    empty.style.display = 'block';
                    return;
                }
                empty.style.display = 'none';
                data.backgrounds.forEach(bg => {
                    const div = document.createElement('div');
                    div.style.cssText = 'border-radius:12px;overflow:hidden;border:1px solid var(--border);aspect-ratio:16/9;background:var(--card2);position:relative';
                    div.innerHTML = '<img src="' + bg.url + '" style="width:100%;height:100%;object-fit:cover" alt="' + bg.fileName + '">' +
                        '<div style="position:absolute;bottom:0;left:0;right:0;padding:4px;background:rgba(0,0,0,0.7);font-size:10px;color:#fff;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + bg.fileName + '</div>';
                    grid.appendChild(div);
                });
            } catch(e) { console.error('Failed to load backgrounds', e); }
        }

        async function uploadBackground(input) {
            if (!input.files || !input.files[0]) return;
            const file = input.files[0];
            const progressContainer = document.getElementById('bg-progress-container');
            const progressFill = document.getElementById('bg-progress-fill');
            const status = document.getElementById('bg-upload-status');

            progressContainer.style.display = 'block';
            progressFill.style.width = '0%';
            status.style.display = 'block';
            status.textContent = 'جاري الرفع...';

            try {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '/api/backgrounds/upload');
                xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                xhr.setRequestHeader('x-file-name', encodeURIComponent(file.name));
                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) progressFill.style.width = Math.round(e.loaded / e.total * 100) + '%';
                };
                xhr.onload = () => {
                    progressContainer.style.display = 'none';
                    if (xhr.status === 200) {
                        status.textContent = 'تم رفع الخلفية بنجاح ✅';
                        loadBackgrounds();
                    } else {
                        status.textContent = 'فشل الرفع ❌';
                    }
                    input.value = '';
                    setTimeout(() => { status.style.display = 'none'; }, 3000);
                };
                xhr.onerror = () => {
                    progressContainer.style.display = 'none';
                    status.textContent = 'خطأ في الاتصال ❌';
                    input.value = '';
                    setTimeout(() => { status.style.display = 'none'; }, 3000);
                };
                xhr.send(file);
            } catch(e) {
                status.textContent = 'خطأ: ' + e.message;
                input.value = '';
            }
        }

        async function loadAdhanSounds() {
            try {
                const r = await fetch('/api/adhan', { headers: { 'Authorization': 'Bearer ' + token } });
                const data = await r.json();
                const list = document.getElementById('adhan-list');
                const empty = document.getElementById('adhan-empty');
                list.innerHTML = '';
                if (!data.adhan || data.adhan.length === 0) {
                    empty.style.display = 'block';
                    return;
                }
                empty.style.display = 'none';
                data.adhan.forEach(a => {
                    const div = document.createElement('div');
                    div.style.cssText = 'display:flex;align-items:center;gap:12px;padding:14px;background:rgba(30,41,59,0.4);border:1px solid var(--border);border-radius:12px';
                    div.innerHTML = '<svg style="width:24px;height:24px;flex-shrink:0" fill="none" stroke="var(--gold)" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>' +
                        '<div style="flex:1;min-width:0"><div style="font-weight:700;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + a.fileName + '</div></div>' +
                        '<audio controls src="' + a.url + '" style="height:32px;max-width:150px"></audio>';
                    list.appendChild(div);
                });
            } catch(e) { console.error('Failed to load adhan', e); }
        }

        async function uploadAdhan(input) {
            if (!input.files || !input.files[0]) return;
            const file = input.files[0];
            const progressContainer = document.getElementById('adhan-progress-container');
            const progressFill = document.getElementById('adhan-progress-fill');
            const status = document.getElementById('adhan-upload-status');

            progressContainer.style.display = 'block';
            progressFill.style.width = '0%';
            status.style.display = 'block';
            status.textContent = 'جاري الرفع...';

            try {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '/api/adhan/upload');
                xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                xhr.setRequestHeader('x-file-name', encodeURIComponent(file.name));
                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) progressFill.style.width = Math.round(e.loaded / e.total * 100) + '%';
                };
                xhr.onload = () => {
                    progressContainer.style.display = 'none';
                    if (xhr.status === 200) {
                        status.textContent = 'تم رفع صوت الأذان بنجاح ✅';
                        loadAdhanSounds();
                    } else {
                        status.textContent = 'فشل الرفع ❌';
                    }
                    input.value = '';
                    setTimeout(() => { status.style.display = 'none'; }, 3000);
                };
                xhr.onerror = () => {
                    progressContainer.style.display = 'none';
                    status.textContent = 'خطأ في الاتصال ❌';
                    input.value = '';
                    setTimeout(() => { status.style.display = 'none'; }, 3000);
                };
                xhr.send(file);
            } catch(e) {
                status.textContent = 'خطأ: ' + e.message;
                input.value = '';
            }
        }
    </script>
</body>

</html>
''';
