import 'package:flutter_riverpod/flutter_riverpod.dart';

/// A simple provider that emits a string (the news message) 
/// whenever the web admin server pushes a high-priority update.
final marqueeTriggerProvider = StateProvider<String?>((ref) => null);

/// Helper function to trigger a temporary override on the main screen
void triggerInstantMarquee(WidgetRef ref, String message) {
  ref.read(marqueeTriggerProvider.notifier).state = message;
  
  // Reset after 30 seconds (or duration of one scroll)
  Future.delayed(const Duration(seconds: 30), () {
    if (ref.read(marqueeTriggerProvider) == message) {
      ref.read(marqueeTriggerProvider.notifier).state = null;
    }
  });
}
