import 'dart:async';
import 'package:uuid/uuid.dart';
import '../../features/settings/domain/entities/ticker_item.dart';

/// Unified News Store that bridges the Local Admin Server with Flutter's SettingsNotifier.
class NewsStore {
  final _uuid = const Uuid();

  // Callbacks passed from AdminServerNotifier to interact with the app's centralized state
  final List<TickerItem> Function() loadItems;
  final Future<void> Function(List<TickerItem>) saveItems;
  
  // Callback to trigger instant display on the main screen
  final Function(String)? onInstantTrigger;

  // Change notifier for SSE (notifies web clients when data changes)
  final _changeController = StreamController<void>.broadcast();

  NewsStore({
    required this.loadItems,
    required this.saveItems,
    this.onInstantTrigger,
  });

  Stream<void> get changes => _changeController.stream;

  Future<void> init() async {}

  void _notify() => _changeController.add(null);

  // ─── CRUD ───────────────────────────────────────────────────────────────

  List<TickerItem> getAll() => loadItems();

  TickerItem? getById(String id) {
    try {
      return loadItems().firstWhere((e) => e.id == id);
    } catch (_) {
      return null;
    }
  }

  Future<TickerItem> create({
    required String text,
    bool enabled = true,
    String scheduleType = 'daily',
    String? date,
    int displayDurationSeconds = 86400,
  }) async {
    final currentItems = List<TickerItem>.from(loadItems());
    final item = TickerItem(
      id: _uuid.v4(),
      text: text,
      enabled: enabled,
      scheduleType: _parseScheduleType(scheduleType),
      date: date,
      displayDurationSeconds: displayDurationSeconds,
      order: (currentItems.isEmpty ? 0 : currentItems.last.order + 1),
      createdAt: DateTime.now(),
    );
    
    currentItems.add(item);
    await saveItems(currentItems);
    _notify();
    
    if (enabled) {
      onInstantTrigger?.call(text);
    }
    
    return item;
  }

  Future<TickerItem?> update(String id, Map<String, dynamic> fields) async {
    final currentItems = List<TickerItem>.from(loadItems());
    final index = currentItems.indexWhere((e) => e.id == id);
    if (index == -1) return null;

    final existing = currentItems[index];
    final updated = existing.copyWith(
      text: fields['text'] as String? ?? existing.text,
      enabled: fields['enabled'] as bool? ?? existing.enabled,
      scheduleType: fields['scheduleType'] != null 
          ? _parseScheduleType(fields['scheduleType'].toString()) 
          : existing.scheduleType,
      date: fields['date'] as String? ?? existing.date,
      displayDurationSeconds: fields['displayDurationSeconds'] as int? ?? existing.displayDurationSeconds,
    );

    currentItems[index] = updated;
    await saveItems(currentItems);
    _notify();

    // Trigger instant display if it was just enabled
    if (updated.enabled && !existing.enabled) {
      onInstantTrigger?.call(updated.text);
    }

    return updated;
  }

  Future<bool> delete(String id) async {
    final currentItems = List<TickerItem>.from(loadItems());
    final before = currentItems.length;
    currentItems.removeWhere((e) => e.id == id);
    if (currentItems.length == before) return false;

    // Re-index order
    for (int i = 0; i < currentItems.length; i++) {
        currentItems[i] = currentItems[i].copyWith(order: i);
    }

    await saveItems(currentItems);
    _notify();
    return true;
  }

  Future<void> reorder(List<String> orderedIds) async {
    final allItems = loadItems();
    final map = {for (final item in allItems) item.id: item};
    final reordered = <TickerItem>[];
    
    for (int i = 0; i < orderedIds.length; i++) {
      final item = map[orderedIds[i]];
      if (item != null) {
        reordered.add(item.copyWith(order: i));
      }
    }
    
    await saveItems(reordered);
    _notify();
  }

  TickerScheduleType _parseScheduleType(String type) {
    switch (type) {
      case 'jomoa': return TickerScheduleType.jomoa;
      case 'date': return TickerScheduleType.date;
      default: return TickerScheduleType.daily;
    }
  }

  void notifyExternalChange() => _notify();

  void dispose() {
    _changeController.close();
  }
}
