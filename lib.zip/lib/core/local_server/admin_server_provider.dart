import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'auth_service.dart';
import 'package:path_provider/path_provider.dart';
import 'local_admin_server.dart';
import 'news_store.dart';
import 'sse_broadcaster.dart';
import '../../features/settings/presentation/providers/settings_provider.dart';
import '../../features/settings/domain/entities/app_settings.dart';
import '../../features/settings/domain/entities/activity_source.dart';
import '../../features/settings/domain/entities/adhan_sound.dart';
import '../../features/settings/presentation/providers/custom_backgrounds_provider.dart';
import '../../features/prayer_times/presentation/providers/location_provider.dart'
    as loc;
import '../../core/services/excel_import_service.dart';

class AdminServerState {
  final bool isRunning;
  final String? ip;
  final int port;
  final int connectedDevices;
  final bool ipChanged;
  final String? error;

  // For TV UI confirmation
  final LoginRequest? pendingRequest;

  AdminServerState({
    this.isRunning = false,
    this.ip,
    this.port = 8080,
    this.connectedDevices = 0,
    this.ipChanged = false,
    this.error,
    this.pendingRequest,
  });

  String get url => ip != null ? 'http://$ip:$port' : '';

  AdminServerState copyWith({
    bool? isRunning,
    String? ip,
    int? port,
    int? connectedDevices,
    bool? ipChanged,
    String? error,
    LoginRequest? pendingRequest,
    bool clearPending = false,
  }) =>
      AdminServerState(
        isRunning: isRunning ?? this.isRunning,
        ip: ip ?? this.ip,
        port: port ?? this.port,
        connectedDevices: connectedDevices ?? this.connectedDevices,
        ipChanged: ipChanged ?? this.ipChanged,
        error: error,
        pendingRequest:
            clearPending ? null : (pendingRequest ?? this.pendingRequest),
      );
}

final adminServerProvider =
    AsyncNotifierProvider<AdminServerNotifier, AdminServerState>(
  AdminServerNotifier.new,
);

class AdminServerNotifier extends AsyncNotifier<AdminServerState> {
  LocalAdminServer? _server;
  AuthService? _auth;
  Timer? _pollingTimer;
  String _appVersion = '1.3.0';
  String _companyName = 'X Team';

  @override
  FutureOr<AdminServerState> build() {
    ref.onDispose(() {
      _stopInternal();
    });
    return AdminServerState();
  }

  Future<void> startServer(String user, String pass, bool saveUser) async {
    state = const AsyncLoading();
    try {
      if (saveUser) {
        await ref
            .read(settingsNotifierProvider.notifier)
            .updateAdminUsername(user);
      }

      final auth = AuthService();
      auth.setCredentials(user, pass);

      final news = NewsStore(
        loadItems: () => ref.read(settingsNotifierProvider).tickerItems,
        saveItems: (items) async {
          await ref.read(settingsNotifierProvider.notifier).updateSettings(
              ref.read(settingsNotifierProvider).copyWith(tickerItems: items),
              source: ActivitySource.web);
        },
      );
      await news.init();
      final sse = SseBroadcaster();

      final appDir = await getApplicationDocumentsDirectory();
      final slidesDir = '${appDir.path}/slides';

      try {
        final packageInfo = await PackageInfo.fromPlatform();
        _appVersion =
            _formatVersion(packageInfo.version, packageInfo.buildNumber);
      } catch (_) {
        _appVersion = '1.3.0';
      }
      _companyName = 'X Team';

      // Determine web assets path (for development/troubleshooting)
      final webAssetsPath = Platform.isWindows
          ? 'C:/Users/Elite/Desktop/Nour/noor_prayer_tv/assets/web'
          : null;

      _server = LocalAdminServer(
        auth: auth,
        news: news,
        sse: sse,
        slidesDirPath: slidesDir,
        webAssetsDirPath: webAssetsPath,
        appVersion: _appVersion,
        companyName: _companyName,
        loadSettings: () =>
            _khushooSettingsToMap(ref.read(settingsNotifierProvider)),
        saveSettings: (incoming) async {
          if (incoming['RESET_TO_DEFAULT'] == true) {
            await ref.read(settingsNotifierProvider.notifier).resetToDefault();
            return _khushooSettingsToMap(ref.read(settingsNotifierProvider));
          }
          final current = ref.read(settingsNotifierProvider);
          final updated = _applyKhushooPatch(current, incoming);
          await ref
              .read(settingsNotifierProvider.notifier)
              .updateSettings(updated, source: ActivitySource.web);
          return _khushooSettingsToMap(updated);
        },
        onAdhanUploaded: (name, path) async {
          final settings = ref.read(settingsNotifierProvider);
          final soundName = name.split('.').first;
          final newSound = AdhanSound(
            id: 'web_${DateTime.now().millisecondsSinceEpoch}',
            name: soundName,
            filePath: path,
          );

          final updatedSounds = [...settings.customAdhanSounds, newSound];
          await ref.read(settingsNotifierProvider.notifier).updateSettings(
                settings.copyWith(customAdhanSounds: updatedSounds),
                source: ActivitySource.web,
              );
        },
        onBackgroundUploaded: (name, path) async {
          ref.read(customBackgroundsProvider.notifier).refresh();

          final normalized = path.replaceAll('\\', '/');
          if (normalized.contains('/mosque_icons/')) {
            final settings = ref.read(settingsNotifierProvider);
            await ref.read(settingsNotifierProvider.notifier).updateSettings(
                  settings.copyWith(mosqueIconPath: path),
                  source: ActivitySource.web,
                );
          }
        },
        onCountryFlagUploaded: (name, path) async {
          final settings = ref.read(settingsNotifierProvider);
          await ref.read(settingsNotifierProvider.notifier).updateSettings(
                settings.copyWith(
                  customFlagPath: path,
                  showCountryFlag: true,
                ),
                source: ActivitySource.web,
              );
        },
        getLocations: () async {
          final countriesList =
              await ref.read(loc.availableLocationsProvider.future);
          final countriesNames =
              await ref.read(loc.countriesNameProvider.future);
          return {
            'locations': countriesList,
            'names': countriesNames,
          };
        },
        onExcelPreview: (path, duration, country, city) async {
          final service = ExcelImportService();
          final preview = await service.previewImportFromPath(
            filePath: path,
            durationKey: duration,
            country: country,
            city: city,
          );

          return {
            'sourceFileName': preview.sourceFileName,
            'selectedSheetName': preview.selectedSheetName,
            'headerRowNumber': preview.headerRowNumber,
            'importedRowsCount': preview.importedRowsCount,
            'countryKey': preview.countryKey,
            'cityKey': preview.cityKey,
            'mappedColumns': preview.mappedColumns,
            'sampleRows': preview.sampleRows,
            'warnings': preview.warnings,
            'durationKey': preview.durationKey,
            'payload': preview.payload,
          };
        },
        onExcelImport: (payload) async {
          final service = ExcelImportService();
          final countryKey = payload.keys.first;
          final cityKey = (payload[countryKey] as Map).keys.first;

          final file = await service.getCustomFile(countryKey, cityKey);
          await file.writeAsString(jsonEncode(payload));
        },
        onExcelDelete: (country, city) async {
          final service = ExcelImportService();
          await service.deleteCustomFile(country, city);
        },
        onExcelExists: (country, city) async {
          final service = ExcelImportService();
          return service.existsCustomData(country, city);
        },
      );
      final ip = await _getLocalIp();
      final port = await _server!.start(ip ?? '0.0.0.0');
      _auth = auth;

      _startPolling();

      state = AsyncData(AdminServerState(
        isRunning: true,
        ip: ip,
        port: port,
        connectedDevices: 0,
      ));
    } catch (e) {
      state = AsyncData(AdminServerState(error: e.toString()));
    }
  }

  void _startPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (_auth == null) return;
      final pending = _auth!.getPendingRequests();
      if (pending.isNotEmpty) {
        final currentState = state.valueOrNull;
        if (currentState != null &&
            currentState.pendingRequest?.id != pending.first.id) {
          state =
              AsyncData(currentState.copyWith(pendingRequest: pending.first));
        }
      } else {
        final currentState = state.valueOrNull;
        if (currentState != null && currentState.pendingRequest != null) {
          state = AsyncData(currentState.copyWith(clearPending: true));
        }
      }
    });
  }

  Future<void> stopServer() async {
    await _stopInternal();
    state = AsyncData(AdminServerState());
  }

  Future<void> _stopInternal() async {
    _pollingTimer?.cancel();
    _pollingTimer = null;
    await _server?.stop();
    _server = null;
    _auth = null;
  }

  Future<String?> _getLocalIp() async {
    // 1) Try network_info_plus first (WiFi IP)
    try {
      final info = NetworkInfo();
      final wifiIp = await info.getWifiIP();
      if (wifiIp != null && wifiIp.isNotEmpty && _isRealLanIp(wifiIp)) {
        return wifiIp;
      }
    } catch (_) {}

    // 2) Fallback: scan all network interfaces for a real LAN address
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      // Prefer 192.168.x.x addresses (most common home/office WiFi)
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          if (addr.address.startsWith('192.168.')) return addr.address;
        }
      }
      // Then try 172.16-31.x.x (some corporate networks)
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          if (_isRealLanIp(addr.address)) return addr.address;
        }
      }
    } catch (_) {}

    return null;
  }

  /// Returns true only for real LAN IPs (not emulator/VPN internal ranges)
  bool _isRealLanIp(String ip) {
    if (ip.startsWith('192.168.')) return true;
    if (ip.startsWith('172.')) {
      final second = int.tryParse(ip.split('.')[1]) ?? 0;
      if (second >= 16 && second <= 31) return true;
    }
    // Accept 10.x.x.x ONLY if not emulator (10.0.2.x / 10.2.0.x)
    if (ip.startsWith('10.')) {
      if (ip.startsWith('10.0.2.') || ip.startsWith('10.2.0.')) return false;
      return true;
    }
    return false;
  }

  void confirmRequest() {
    final req = state.valueOrNull?.pendingRequest;
    if (req != null) {
      _auth?.approveRequest(req.id);
      state = AsyncData(state.value!.copyWith(clearPending: true));
    }
  }

  void denyRequest() {
    final req = state.valueOrNull?.pendingRequest;
    if (req != null) {
      _auth?.denyRequest(req.id);
      state = AsyncData(state.value!.copyWith(clearPending: true));
    }
  }

  void notifyNewsChanged() {
    final items = _server?.news.getAll().map((e) => e.toJson()).toList();
    if (items != null) {
      _server?.sse.broadcastNewsUpdate(items);
    }
  }

  Map<String, dynamic> _khushooSettingsToMap(AppSettings settings) {
    return {
      'isGlobalAudioMuted': settings.isGlobalAudioMuted,
      'isAzanAudioMuted': settings.isAzanAudioMuted,
      'khushooModeEnabled': settings.khushooModeEnabled,
      'khushooModeDuration': settings.khushooModeDuration,
      'isKhushooManualActive': settings.isKhushooManualActive,
      'slidesEnabled': settings.slidesEnabled,
      'slidesShuffle': settings.slidesShuffle,
      'slideDurationSeconds': settings.slideDurationSeconds,
      'mainScreenDurationSeconds': settings.mainScreenDurationSeconds,
      'slidesShowMode': settings.slidesShowMode,
      'slidesList': settings.slidesList,
      'useCustomPrayerTimes': settings.useCustomPrayerTimes,
      'selectedCustomBgPath': settings.selectedCustomBgPath,
      'selectedBackgroundId': settings.selectedBackgroundId,
      'bgMode': settings.bgMode,

      // General Settings
      'mosqueName': settings.mosqueName,
      'clockOffsetMinutes': settings.clockOffsetMinutes,
      'showHijriDate': settings.showHijriDate,
      'isManualTimeEnabled': settings.isManualTimeEnabled,
      'manualTimeValue': settings.manualTimeValue,
      'country': settings.country,
      'city': settings.city,
      'languageCode': settings.languageCode,
      'showCountryFlag': settings.showCountryFlag,
      'themeMode': settings.themeMode,
      'appTheme': settings.appTheme,
      'is24HourFormat': settings.is24HourFormat,
      'padTimesWithZero': settings.padTimesWithZero,
      'showFullClock': settings.showFullClock,
      'enableAnalogGlassClock': settings.enableAnalogGlassClock,
      'analogClockStyle': settings.analogClockStyle,
      'showAnalogClockDateFrame': settings.showAnalogClockDateFrame,
      'showAnalogClockNumbers': settings.showAnalogClockNumbers,
      'showNightPrayers': settings.showNightPrayers,
      'centerPrayerNamesLandscape': settings.centerPrayerNamesLandscape,
      'enlargePrayerNamesLandscape': settings.enlargePrayerNamesLandscape,
      'showIqamaWithClock': settings.showIqamaWithClock,
      'showCountdown': settings.showCountdown,
      'enlargeCountdown': settings.enlargeCountdown,
      'showFullscreenCountdownAtThreshold':
          settings.showFullscreenCountdownAtThreshold,
      'useArabicIndicDigits': settings.useArabicIndicDigits,
      'hideIqamaTime': settings.hideIqamaTime,
      'centerPrayerNamesPortrait': settings.centerPrayerNamesPortrait,
      'centerNameWithTimesOnSides': settings.centerNameWithTimesOnSides,
      'showPrayerNameInOtherLanguage': settings.showPrayerNameInOtherLanguage,
      'prayerNameFontSize': settings.prayerNameFontSize,
      'prayerTimeFontSize': settings.prayerTimeFontSize,
      'iqamaTimeFontSize': settings.iqamaTimeFontSize,
      'blackClockModeEnabled': settings.blackClockModeEnabled,
      'blackClockModeUseGlass': settings.blackClockModeUseGlass,
      'countdownGreenLast90s': settings.countdownGreenLast90s,
      'enlargeNextPrayerCountdown': settings.enlargeNextPrayerCountdown,
      'swapDateAndMosqueLandscape': settings.swapDateAndMosqueLandscape,
      'showInternetStatus': settings.showInternetStatus,
      'showBackgroundShadingBehindTimes':
          settings.showBackgroundShadingBehindTimes,
      'useTranslucentScreens': settings.useTranslucentScreens,
      'showMarqueeTicker': settings.showMarqueeTicker,
      'navbarPosition': settings.navbarPosition,
      'appOrientation': settings.appOrientation,
      'pureGlassTextColor': settings.pureGlassTextColor,
      'glassShineEnabled': settings.glassShineEnabled,
      'pureGlassColor1': settings.pureGlassColor1,
      'pureGlassColor2': settings.pureGlassColor2,
      'pureGlassColor3': settings.pureGlassColor3,
      'mosqueIconPath': settings.mosqueIconPath,
      'customFlagPath': settings.customFlagPath,
      'mosqueIconWebUrl':
          _toWebAssetUrl(settings.mosqueIconPath, '/mosque-icon'),
      'customFlagWebUrl':
          _toWebAssetUrl(settings.customFlagPath, '/country-flag'),

      // App meta
      'appVersion': _appVersion,
      'companyName': _companyName,
    };
  }

  AppSettings _applyKhushooPatch(
      AppSettings current, Map<String, dynamic> incoming) {
    final duration = _readInt(
      incoming['khushooModeDuration'],
      fallback: current.khushooModeDuration,
      min: 1,
      max: 60,
    );

    final slideDur = _readInt(
      incoming['slideDurationSeconds'],
      fallback: current.slideDurationSeconds,
      min: 1,
      max: 300,
    );

    final mainDur = _readInt(
      incoming['mainScreenDurationSeconds'],
      fallback: current.mainScreenDurationSeconds,
      min: 1,
      max: 300,
    );

    return current.copyWith(
      isGlobalAudioMuted: _readBool(incoming['isGlobalAudioMuted'],
          fallback: current.isGlobalAudioMuted),
      isAzanAudioMuted: _readBool(incoming['isAzanAudioMuted'],
          fallback: current.isAzanAudioMuted),
      khushooModeEnabled: _readBool(incoming['khushooModeEnabled'],
          fallback: current.khushooModeEnabled),
      khushooModeDuration: duration,
      isKhushooManualActive: _readBool(incoming['isKhushooManualActive'],
          fallback: current.isKhushooManualActive),
      slidesEnabled:
          _readBool(incoming['slidesEnabled'], fallback: current.slidesEnabled),
      slidesShuffle:
          _readBool(incoming['slidesShuffle'], fallback: current.slidesShuffle),
      slideDurationSeconds: slideDur,
      mainScreenDurationSeconds: mainDur,
      slidesShowMode:
          incoming['slidesShowMode']?.toString() ?? current.slidesShowMode,
      slidesList: (incoming['slidesList'] as List?)
              ?.map((e) => Map<String, dynamic>.from(e as Map))
              .toList() ??
          current.slidesList,
      useCustomPrayerTimes: _readBool(incoming['useCustomPrayerTimes'],
          fallback: current.useCustomPrayerTimes),
      selectedCustomBgPath: incoming['selectedCustomBgPath']?.toString() ??
          current.selectedCustomBgPath,
      selectedBackgroundId: _readInt(incoming['selectedBackgroundId'],
          fallback: current.selectedBackgroundId, min: -1, max: 9999),
      bgMode: _readStringChoice(incoming['bgMode'],
          fallback: current.bgMode,
          allowed: const {
            'MANUAL',
            'PER_PRAYER',
            'PER_DAY',
            'DAILY_RANDOM_FROM_LIST'
          }),

      // General Settings
      mosqueName: incoming['mosqueName']?.toString() ?? current.mosqueName,
      clockOffsetMinutes: _readInt(incoming['clockOffsetMinutes'],
          fallback: current.clockOffsetMinutes, min: -1440, max: 1440),
      showHijriDate:
          _readBool(incoming['showHijriDate'], fallback: current.showHijriDate),
      isManualTimeEnabled: _readBool(incoming['isManualTimeEnabled'],
          fallback: current.isManualTimeEnabled),
      manualTimeValue:
          incoming['manualTimeValue']?.toString() ?? current.manualTimeValue,
      country: incoming['country']?.toString() ?? current.country,
      languageCode: _readStringChoice(incoming['languageCode'],
          fallback: current.languageCode, allowed: const {'ar', 'en'}),
      city: incoming['city']?.toString() ?? current.city,
      showCountryFlag: _readBool(incoming['showCountryFlag'],
          fallback: current.showCountryFlag),
      themeMode: _readStringChoice(incoming['themeMode'],
          fallback: current.themeMode,
          allowed: const {'SYSTEM', 'LIGHT', 'DARK'}),
      appTheme: _readStringChoice(incoming['appTheme'],
          fallback: current.appTheme, allowed: const {'EMERALD', 'PURE_GLASS'}),
      is24HourFormat: _readBool(incoming['is24HourFormat'],
          fallback: current.is24HourFormat),
      padTimesWithZero: _readBool(incoming['padTimesWithZero'],
          fallback: current.padTimesWithZero),
      showFullClock:
          _readBool(incoming['showFullClock'], fallback: current.showFullClock),
      enableAnalogGlassClock: _readBool(incoming['enableAnalogGlassClock'],
          fallback: current.enableAnalogGlassClock),
      analogClockStyle: _readStringChoice(incoming['analogClockStyle'],
          fallback: current.analogClockStyle,
          allowed: const {'GLASS', 'GOLDEN', 'ROYAL', 'GREEN_GOLD'}),
      showAnalogClockDateFrame: _readBool(incoming['showAnalogClockDateFrame'],
          fallback: current.showAnalogClockDateFrame),
      showAnalogClockNumbers: _readBool(incoming['showAnalogClockNumbers'],
          fallback: current.showAnalogClockNumbers),
      showNightPrayers: _readBool(incoming['showNightPrayers'],
          fallback: current.showNightPrayers),
      centerPrayerNamesLandscape: _readBool(
          incoming['centerPrayerNamesLandscape'],
          fallback: current.centerPrayerNamesLandscape),
      enlargePrayerNamesLandscape: _readBool(
          incoming['enlargePrayerNamesLandscape'],
          fallback: current.enlargePrayerNamesLandscape),
      showIqamaWithClock: _readBool(incoming['showIqamaWithClock'],
          fallback: current.showIqamaWithClock),
      showCountdown:
          _readBool(incoming['showCountdown'], fallback: current.showCountdown),
      enlargeCountdown: _readBool(incoming['enlargeCountdown'],
          fallback: current.enlargeCountdown),
      showFullscreenCountdownAtThreshold: _readBool(
          incoming['showFullscreenCountdownAtThreshold'],
          fallback: current.showFullscreenCountdownAtThreshold),
      useArabicIndicDigits: _readBool(incoming['useArabicIndicDigits'],
          fallback: current.useArabicIndicDigits),
      hideIqamaTime:
          _readBool(incoming['hideIqamaTime'], fallback: current.hideIqamaTime),
      centerPrayerNamesPortrait: _readBool(
          incoming['centerPrayerNamesPortrait'],
          fallback: current.centerPrayerNamesPortrait),
      centerNameWithTimesOnSides: _readBool(
          incoming['centerNameWithTimesOnSides'],
          fallback: current.centerNameWithTimesOnSides),
      showPrayerNameInOtherLanguage: _readBool(
          incoming['showPrayerNameInOtherLanguage'],
          fallback: current.showPrayerNameInOtherLanguage),
      prayerNameFontSize: _readDouble(incoming['prayerNameFontSize'],
          fallback: current.prayerNameFontSize, min: 14, max: 50),
      prayerTimeFontSize: _readDouble(incoming['prayerTimeFontSize'],
          fallback: current.prayerTimeFontSize, min: 14, max: 55),
      iqamaTimeFontSize: _readDouble(incoming['iqamaTimeFontSize'],
          fallback: current.iqamaTimeFontSize, min: 12, max: 45),
      blackClockModeEnabled: _readBool(incoming['blackClockModeEnabled'],
          fallback: current.blackClockModeEnabled),
      blackClockModeUseGlass: _readBool(incoming['blackClockModeUseGlass'],
          fallback: current.blackClockModeUseGlass),
      countdownGreenLast90s: _readBool(incoming['countdownGreenLast90s'],
          fallback: current.countdownGreenLast90s),
      enlargeNextPrayerCountdown: _readBool(
          incoming['enlargeNextPrayerCountdown'],
          fallback: current.enlargeNextPrayerCountdown),
      swapDateAndMosqueLandscape: _readBool(
          incoming['swapDateAndMosqueLandscape'],
          fallback: current.swapDateAndMosqueLandscape),
      showInternetStatus: _readBool(incoming['showInternetStatus'],
          fallback: current.showInternetStatus),
      showBackgroundShadingBehindTimes: _readBool(
          incoming['showBackgroundShadingBehindTimes'],
          fallback: current.showBackgroundShadingBehindTimes),
      useTranslucentScreens: _readBool(incoming['useTranslucentScreens'],
          fallback: current.useTranslucentScreens),
      showMarqueeTicker: _readBool(incoming['showMarqueeTicker'],
          fallback: current.showMarqueeTicker),
      navbarPosition: _readStringChoice(incoming['navbarPosition'],
          fallback: current.navbarPosition,
          allowed: const {'FULL', 'CENTER', 'SIDE'}),
      appOrientation: _readStringChoice(incoming['appOrientation'],
          fallback: current.appOrientation,
          allowed: const {'AUTO', 'PORTRAIT', 'LANDSCAPE'}),
      pureGlassTextColor: _readHexColor(incoming['pureGlassTextColor'],
          fallback: current.pureGlassTextColor),
      glassShineEnabled: _readBool(incoming['glassShineEnabled'],
          fallback: current.glassShineEnabled),
      pureGlassColor1: _readHexColor(incoming['pureGlassColor1'],
          fallback: current.pureGlassColor1),
      pureGlassColor2: _readHexColor(incoming['pureGlassColor2'],
          fallback: current.pureGlassColor2),
      pureGlassColor3: _readHexColor(incoming['pureGlassColor3'],
          fallback: current.pureGlassColor3),
      mosqueIconPath:
          incoming['mosqueIconPath']?.toString() ?? current.mosqueIconPath,
      customFlagPath:
          incoming['customFlagPath']?.toString() ?? current.customFlagPath,
    );
  }

  String _formatVersion(String version, String buildNumber) {
    final cleanVersion = version.trim();
    final cleanBuild = buildNumber.trim();
    if (cleanBuild.isEmpty || cleanBuild == '0') return cleanVersion;
    return '$cleanVersion+$cleanBuild';
  }

  String? _toWebAssetUrl(String? filePath, String routePrefix) {
    if (filePath == null || filePath.trim().isEmpty) return null;
    final normalized = filePath.replaceAll('\\', '/');
    final idx = normalized.lastIndexOf('/');
    final fileName = idx == -1 ? normalized : normalized.substring(idx + 1);
    if (fileName.isEmpty) return null;
    return '$routePrefix/${Uri.encodeComponent(fileName)}';
  }

  String _readStringChoice(dynamic value,
      {required String fallback, required Set<String> allowed}) {
    final normalized = value?.toString().trim().toUpperCase();
    if (normalized == null || normalized.isEmpty) return fallback;
    if (!allowed.contains(normalized)) return fallback;
    return normalized;
  }

  String _readHexColor(dynamic value, {required String fallback}) {
    final normalized = value?.toString().trim().toUpperCase();
    if (normalized == null || normalized.isEmpty) return fallback;
    final hex = RegExp(r'^#([0-9A-F]{6}|[0-9A-F]{8})$');
    if (!hex.hasMatch(normalized)) return fallback;
    return normalized;
  }

  bool _readBool(dynamic value, {required bool fallback}) {
    if (value is bool) return value;
    if (value is num) return value != 0;
    if (value is String) {
      final normalized = value.trim().toLowerCase();
      if (normalized == 'true' ||
          normalized == '1' ||
          normalized == 'yes' ||
          normalized == 'on') {
        return true;
      }
      if (normalized == 'false' ||
          normalized == '0' ||
          normalized == 'no' ||
          normalized == 'off') {
        return false;
      }
    }
    return fallback;
  }

  int _readInt(dynamic value,
      {required int fallback, required int min, required int max}) {
    int? parsed;
    if (value is int) {
      parsed = value;
    } else if (value is double) {
      parsed = value.round();
    } else if (value is String) {
      parsed = int.tryParse(value.trim());
    }

    if (parsed == null) return fallback;
    if (parsed < min) return min;
    if (parsed > max) return max;
    return parsed;
  }

  double _readDouble(dynamic value,
      {required double fallback, required double min, required double max}) {
    double? parsed;
    if (value is num) {
      parsed = value.toDouble();
    } else if (value is String) {
      parsed = double.tryParse(value.trim());
    }

    if (parsed == null) return fallback;
    if (parsed < min) return min;
    if (parsed > max) return max;
    return parsed;
  }

  void acknowledgeIpChange() {
    final currentState = state.valueOrNull;
    if (currentState != null) {
      state = AsyncData(currentState.copyWith(ipChanged: false));
    }
  }
}
