import 'dart:async';
import 'dart:convert';

/// Server-Sent Events broadcaster.
/// Each connected client gets its own StreamController.
/// On news change, all clients receive a 'news_updated' event.
class SseBroadcaster {
  final Map<String, StreamController<String>> _clients = {};

  /// Register a new SSE client. Returns its unique ID.
  String addClient(String clientId, StreamController<String> controller) {
    _clients[clientId] = controller;
    // Send initial connected event
    _sendTo(clientId, 'connected', {'message': 'متصل بالسيرفر'});
    return clientId;
  }

  /// Remove a disconnected client.
  void removeClient(String clientId) {
    _clients.remove(clientId)?.close();
  }

  /// Broadcast a 'news_updated' event to all clients.
  void broadcastNewsUpdate(List<Map<String, dynamic>> newsJsonList) {
    _broadcastAll('news_updated', {'items': newsJsonList});
  }

  /// Broadcast a 'settings_updated' event to all clients.
  void broadcastSettingsUpdate(Map<String, dynamic> settingsJson) {
    _broadcastAll('settings_updated', {'settings': settingsJson});
  }

  /// Broadcast any custom event publicly.
  void broadcast(String event, Map<String, dynamic> data) {
    _broadcastAll(event, data);
  }

  /// Broadcast any custom event to all clients.
  void _broadcastAll(String event, Map<String, dynamic> data) {
    final sseMessage = _formatSSE(event, data);
    final deadClients = <String>[];
    for (final entry in _clients.entries) {
      try {
        if (!entry.value.isClosed) {
          entry.value.add(sseMessage);
        } else {
          deadClients.add(entry.key);
        }
      } catch (_) {
        deadClients.add(entry.key);
      }
    }
    for (final id in deadClients) {
      _clients.remove(id);
    }
  }

  void _sendTo(String clientId, String event, Map<String, dynamic> data) {
    final controller = _clients[clientId];
    if (controller == null || controller.isClosed) return;
    try {
      controller.add(_formatSSE(event, data));
    } catch (_) {}
  }

  String _formatSSE(String event, Map<String, dynamic> data) {
    return 'event: $event\ndata: ${jsonEncode(data)}\n\n';
  }

  int get clientCount => _clients.length;

  void dispose() {
    for (final c in _clients.values) {
      if (!c.isClosed) c.close();
    }
    _clients.clear();
  }
}
