import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:uuid/uuid.dart';

class DeviceInfo {
  final String id;
  final String name;
  final String token;
  final DateTime pairedAt;
  DateTime lastSeen;
  bool isFullyAuthenticated;

  DeviceInfo({
    required this.id,
    required this.name,
    required this.token,
    required this.pairedAt,
    required this.lastSeen,
    this.isFullyAuthenticated = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'token': token,
        'pairedAt': pairedAt.toIso8601String(),
        'lastSeen': lastSeen.toIso8601String(),
        'isFullyAuthenticated': isFullyAuthenticated,
      };
}


class LoginRequest {
  final String id;
  final String username;
  final DateTime expiresAt;
  String deviceName;
  String clientIp;
  bool isConfirmed; // TV user clicked "Allow"
  bool isDenied;    // TV user clicked "Deny"
  bool used;

  LoginRequest({
    required this.id,
    required this.username,
    required this.expiresAt,
    this.deviceName = '',
    this.clientIp = '',
    this.isConfirmed = false,
    this.isDenied = false,
    this.used = false,
  });

  bool get isExpired => DateTime.now().isAfter(expiresAt);
}

class AuthService {
  static const int _maxAttemptsBeforeLock = 10;
  static const int _lockoutMinutes = 15;
  static const int _requestTtlMinutes = 5;

  final _uuid = const Uuid();

  String? _username;
  String? _passwordHash;
  String? _salt;

  // Active login requests pending TV approval
  final Map<String, LoginRequest> _pendingRequests = {};
  
  // token → DeviceInfo
  final Map<String, DeviceInfo> _tokens = {};

  // ip → Lockout status
  final Map<String, int> _failureCount = {};
  final Map<String, DateTime> _lockoutUntil = {};

  // ─── Setup ───────────────────────────────────────────────────────────────

  void setCredentials(String username, String password) {
    _username = username.isNotEmpty ? username : 'admin';
    _salt = _uuid.v4().substring(0, 8);
    _passwordHash = _hash(password + _salt!);
  }

  bool get isConfigured => _passwordHash != null;

  String _hash(String input) {
    final bytes = utf8.encode(input);
    return sha256.convert(bytes).toString();
  }

  // ─── Login Flow ─────────────────────────────────────────────────────────

  /// Step 1: Web client submits username/password
  String? requestLogin(String username, String password, String deviceName, String clientIp) {
    if (isLocked(clientIp)) return 'LOCKED';
    if (!isConfigured) return 'NOT_CONFIGURED';

    final targetUser = username.isEmpty ? 'admin' : username;

    if (targetUser != _username || _hash(password + _salt!) != _passwordHash) {
      _recordFailure(clientIp);
      return 'INVALID_CREDENTIALS';
    }

    // Credentials valid -> create pending request for TV approval
    _purgeExpiredRequests();
    final id = _uuid.v4();
    final request = LoginRequest(
      id: id,
      username: targetUser,
      deviceName: deviceName.isNotEmpty ? deviceName : 'جهاز متصفح',
      clientIp: clientIp,
      expiresAt: DateTime.now().add(const Duration(minutes: _requestTtlMinutes)),
    );
    _pendingRequests[id] = request;
    return id; // Return request ID for polling
  }

  LoginRequest? getRequest(String id) {
    final req = _pendingRequests[id];
    if (req == null || req.isExpired || req.used) return null;
    return req;
  }

  /// Step 2: TV user clicks "Allow"
  bool approveRequest(String requestId) {
    final req = _pendingRequests[requestId];
    if (req == null || req.isExpired) return false;
    req.isConfirmed = true;
    return true;
  }

  /// Step 2: TV user clicks "Deny"
  bool denyRequest(String requestId) {
    final req = _pendingRequests[requestId];
    if (req == null) return false;
    req.isDenied = true;
    req.used = true; // Invalidates it
    return true;
  }

  /// Step 3: Web client polling to get token
  String? confirmLogin(String requestId) {
    final req = _pendingRequests[requestId];
    if (req == null || req.isExpired || !req.isConfirmed || req.used) return null;

    req.used = true;

    final token = _generateToken();
    final device = DeviceInfo(
      id: _uuid.v4(),
      name: req.deviceName,
      token: token,
      pairedAt: DateTime.now(),
      lastSeen: DateTime.now(),
      isFullyAuthenticated: true, 
    );
    _tokens[token] = device;
    return token;
  }

  void _purgeExpiredRequests() {
    _pendingRequests.removeWhere((_, req) => req.isExpired || req.used);
  }


  List<LoginRequest> getPendingRequests() {
    _purgeExpiredRequests();
    return _pendingRequests.values.where((r) => !r.isConfirmed && !r.isDenied).toList();
  }

  bool isLocked(String ip) {
    if (_lockoutUntil.containsKey(ip)) {
      if (DateTime.now().isBefore(_lockoutUntil[ip]!)) return true;
      _lockoutUntil.remove(ip);
      _failureCount.remove(ip);
    }
    return false;
  }

  void _recordFailure(String ip) {
    if (isLocked(ip)) return;
    final count = (_failureCount[ip] ?? 0) + 1;
    _failureCount[ip] = count;
    if (count >= _maxAttemptsBeforeLock) {
      _lockoutUntil[ip] = DateTime.now().add(const Duration(minutes: _lockoutMinutes));
    }
  }

  String _generateToken() {
    return _uuid.v4();
  }

  DeviceInfo? validate(String token) {
    final device = _tokens[token];
    if (device == null) return null;
    device.lastSeen = DateTime.now();
    return device;
  }

  void logout(String token) {
    _tokens.remove(token);
  }

  List<DeviceInfo> getDevices() {
    return _tokens.values.toList();
  }

  bool revokeDevice(String id) {
    final entry = _tokens.entries.where((e) => e.value.id == id).toList();
    if (entry.isEmpty) return false;
    _tokens.remove(entry.first.key);
    return true;
  }
}

