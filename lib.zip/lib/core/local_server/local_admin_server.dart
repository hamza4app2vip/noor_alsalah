import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_router/shelf_router.dart';
import 'package:shelf_cors_headers/shelf_cors_headers.dart';
import 'package:uuid/uuid.dart';
import 'auth_service.dart';
import 'news_store.dart';
import 'sse_broadcaster.dart';
import 'web_ui/admin_ui.dart';

/// LocalAdminServer
/// ─────────────────
/// shelf HTTP server embedded in the Flutter app.
/// Handles: pairing, login, news CRUD, SSE live-update, devices.
/// Port: 8080 (fallback 8081, 8082).
class LocalAdminServer {
  final AuthService auth;
  final NewsStore news;
  final SseBroadcaster sse;
  final Map<String, dynamic> Function() loadSettings;
  final Future<Map<String, dynamic>> Function(Map<String, dynamic> incoming)
      saveSettings;
  final Future<void> Function(String name, String path)? onAdhanUploaded;
  final Future<void> Function(String name, String path)? onBackgroundUploaded;
  final Future<Map<String, dynamic>> Function()? getLocations;
  final Future<Map<String, dynamic>> Function(
          String filePath, String durationKey, String country, String city)?
      onExcelPreview;
  final Future<void> Function(Map<String, dynamic> payload)? onExcelImport;
  final Future<void> Function(String country, String city)? onExcelDelete;
  final Future<bool> Function(String country, String city)? onExcelExists;
  final Future<void> Function(String name, String path)? onCountryFlagUploaded;
  final String appVersion;
  final String companyName;
  final String slidesDirPath;
  final String? webAssetsDirPath;

  HttpServer? _server;
  int _port = 8080;
  StreamSubscription? _newsSub;
  final _uuid = const Uuid();

  static const int _maxBodyBytes = 1024 * 1024; // 1 MB
  static const List<int> _portCandidates = [8080, 8081, 8082, 8083];

  LocalAdminServer({
    required this.auth,
    required this.news,
    required this.sse,
    required this.loadSettings,
    required this.saveSettings,
    this.onAdhanUploaded,
    this.onBackgroundUploaded,
    this.getLocations,
    this.onExcelPreview,
    this.onExcelImport,
    this.onExcelDelete,
    this.onExcelExists,
    this.onCountryFlagUploaded,
    this.appVersion = '1.3.0',
    this.companyName = 'X Team',
    required this.slidesDirPath,
    this.webAssetsDirPath,
  });

  int get port => _port;

  // ─── Lifecycle ──────────────────────────────────────────────────────────────

  Future<int> start(String listenIp) async {
    final router = _buildRouter();
    final handler = const Pipeline()
        .addMiddleware(corsHeaders())
        .addMiddleware(_jsonErrorMiddleware())
        .addMiddleware(_rateLimitMiddleware())
        .addMiddleware(_requestSizeLimitMiddleware())
        .addMiddleware(logRequests())
        .addHandler(router.call);

    for (final candidate in _portCandidates) {
      try {
        _server = await shelf_io.serve(handler, listenIp, candidate);
        _port = candidate;
        break;
      } on SocketException {
        continue;
      }
    }

    if (_server == null) throw Exception('كل المنافذ محجوزة (8080-8083)');

    // Subscribe to news changes → broadcast via SSE
    _newsSub = news.changes.listen((_) {
      final items = news.getAll().map((e) => e.toJson()).toList();
      sse.broadcastNewsUpdate(items);
    });

    return _port;
  }

  Future<void> stop() async {
    await _newsSub?.cancel();
    sse.dispose();
    await _server?.close(force: true);
    _server = null;
  }

  bool get isRunning => _server != null;

  // ─── Router ─────────────────────────────────────────────────────────────────

  Router _buildRouter() {
    final router = Router();

    // ── Public ──
    router.get('/health', _handleHealth);

    router.get('/login/status', _handleLoginStatus);
    router.post('/login', _handleLogin);
    router.get('/', _handleUi);
    router.get('/remote.i18n.js', _handleRemoteI18nJs);
    router.get('/remote.js', _handleRemoteJs);
    router.get('/remote.css', _handleRemoteCss);
    router.get('/pair', _handleUi);
    router.get('/pair/', _handleUi);

    // ── Protected ──
    router.post('/logout', _withAuth(_handleLogout));
    router.get('/news', _withAuth(_handleGetNews));
    router.post('/news', _withAuth(_handleCreateNews));
    router.post('/news/reorder', _withAuth(_handleReorder));
    router.put('/news/<id>', _withAuth(_handleUpdateNews));
    router.delete('/news/<id>', _withAuth(_handleDeleteNews));
    router.get('/api/settings', _withAuth(_handleGetSettings));
    router.post('/api/settings', _withAuth(_handleUpdateSettings));
    router.post('/api/settings/reset', _withAuth(_handleFactoryReset)); // New
    router.post('/api/upload', _withAuth(_handleUpload));
    router.get('/slides/<filename>', _handleServeSlide);
    router.get('/devices', _withAuth(_handleGetDevices));
    router.delete('/devices/<id>', _withAuth(_handleRevokeDevice));
    router.get('/events', _handleSSE);

    // ── Background & Adhan Upload ──
    router.post('/api/backgrounds/upload', _withAuth(_handleBackgroundUpload));
    router.get('/api/backgrounds', _withAuth(_handleListBackgrounds));
    router.post('/api/backgrounds/select/<filename>',
        _withAuth(_handleSelectBackground));
    router.delete(
        '/api/backgrounds/<filename>', _withAuth(_handleDeleteBackground));
    router.get('/backgrounds/<filename>', _handleServeBackground);
    router.post('/api/adhan/upload', _withAuth(_handleAdhanUpload));
    router.get('/api/adhan', _withAuth(_handleListAdhan));
    router.delete('/api/adhan/<filename>', _withAuth(_handleDeleteAdhan));
    router.get('/adhan/<filename>', _handleServeAdhan);

    // ── Mosque Icon ──
    router.post('/api/mosque-icon/upload', _withAuth(_handleMosqueIconUpload));
    router.get('/mosque-icon/<filename>', _handleServeMosqueIcon);

    // ── Country Flag ──
    router.post(
        '/api/country-flag/upload', _withAuth(_handleCountryFlagUpload));
    router.get('/country-flag/<filename>', _handleServeCountryFlag);

    // ── Locations & Excel ──
    router.get('/api/locations', _withAuth(_handleGetLocations));
    router.post('/api/excel/preview', _withAuth(_handleExcelPreview));
    router.post('/api/excel/import', _withAuth(_handleExcelImport));
    router.delete('/api/excel/custom', _withAuth(_handleExcelDelete));
    router.get('/api/excel/custom/exists', _withAuth(_handleExcelExists));

    router.all('/<path|.*>', _handle404);
    return router;
  }

  // ─── Middleware ──────────────────────────────────────────────────────────────

  Middleware _jsonErrorMiddleware() {
    return (Handler next) => (Request req) async {
          try {
            return await next(req);
          } catch (e, st) {
            print('Admin API Error on ${req.url.path}: $e\n$st');
            return Response.internalServerError(
              body: jsonEncode(
                  {'error': 'خطأ داخلي في الخادم', 'details': e.toString()}),
              headers: {'content-type': 'application/json; charset=utf-8'},
            );
          }
        };
  }

  Middleware _rateLimitMiddleware() {
    return (Handler next) => (Request req) {
          final ip = _clientIp(req);
          if (auth.isLocked(ip)) {
            return _json({
              'error':
                  'تم قفل المحاولات مؤقتاً (15 دقيقة) بسبب محاولات خاطئة كثيرة.',
              'code': 'LOCKED'
            }, 429);
          }
          return next(req);
        };
  }

  Middleware _requestSizeLimitMiddleware() {
    return (Handler next) => (Request req) async {
          if (req.method == 'POST' || req.method == 'PUT') {
            final isUpload = req.url.path == 'api/upload' ||
                req.url.path == 'api/backgrounds/upload' ||
                req.url.path == 'api/adhan/upload' ||
                req.url.path == 'api/excel/preview' ||
                req.url.path == 'api/mosque-icon/upload' ||
                req.url.path == 'api/country-flag/upload';
            final maxBytes =
                isUpload ? 20 * 1024 * 1024 : _maxBodyBytes; // 20MB for uploads
            final len = int.tryParse(req.headers['content-length'] ?? '0') ?? 0;
            if (len > maxBytes) {
              return _json({'error': 'الطلب كبير جداً.'}, 413);
            }
          }
          return next(req);
        };
  }

  Handler _withAuth(Handler handler) {
    return (Request req) {
      final authHeader = req.headers['authorization'] ?? '';
      if (!authHeader.startsWith('Bearer ')) {
        return _json(
            {'error': 'غير مصرح. يرجى تسجيل الدخول.', 'code': 'UNAUTHORIZED'},
            401);
      }
      final token = authHeader.substring(7);
      final device = auth.validate(token);
      if (device == null) {
        return _json({
          'error': 'انتهت الجلسة. يرجى تسجيل الدخول مرة أخرى.',
          'code': 'SESSION_EXPIRED'
        }, 401);
      }

      return handler(req.change(context: {'device': device}));
    };
  }

  // ─── Handlers ────────────────────────────────────────────────────────────────

  Future<Response> _handleHealth(Request req) async {
    final settings = loadSettings();
    return _json({
      'status': 'ok',
      'version': appVersion,
      'appVersion': appVersion,
      'companyName': companyName,
      'isConfigured': auth.isConfigured,
      'languageCode': settings['languageCode']?.toString() ?? 'ar',
      'serverTime': DateTime.now().toIso8601String(),
    });
  }

  Future<Response> _handleUi(Request req) async {
    final html = await _loadWebAsset('remote.html');
    if (html != null) {
      return Response.ok(
        html,
        headers: _webAssetHeaders('text/html; charset=utf-8'),
      );
    }
    return Response.ok(
      adminUiHtml,
      headers: _webAssetHeaders('text/html; charset=utf-8'),
    );
  }

  Future<Response> _handleRemoteI18nJs(Request req) async {
    final js = await _loadWebAsset('remote.i18n.js');
    if (js != null) {
      return Response.ok(
        js,
        headers: _webAssetHeaders('application/javascript; charset=utf-8'),
      );
    }
    return Response.notFound(
      'remote.i18n.js not found',
      headers: _webAssetHeaders('text/plain; charset=utf-8'),
    );
  }

  Future<Response> _handleRemoteJs(Request req) async {
    final js = await _loadWebAsset('remote.js');
    if (js != null) {
      return Response.ok(
        js,
        headers: _webAssetHeaders('application/javascript; charset=utf-8'),
      );
    }
    return Response.notFound(
      'remote.js not found',
      headers: _webAssetHeaders('text/plain; charset=utf-8'),
    );
  }

  Future<Response> _handleRemoteCss(Request req) async {
    final css = await _loadWebAsset('remote.css');
    if (css != null) {
      return Response.ok(
        css,
        headers: _webAssetHeaders('text/css; charset=utf-8'),
      );
    }
    return Response.notFound(
      'remote.css not found',
      headers: _webAssetHeaders('text/plain; charset=utf-8'),
    );
  }

  /// Step 1: Web client sumbits credentials to request TV approval
  Future<Response> _handleLogin(Request req) async {
    final ip = _clientIp(req);
    final body = await _readBody(req);
    if (body == null) return _json({'error': 'طلب غير صالح.'}, 400);

    final username = (body['username'] ?? '').toString().trim();
    final password = (body['password'] ?? '').toString();
    final deviceName = (body['deviceName'] ?? '').toString().trim();

    final result = auth.requestLogin(username, password, deviceName, ip);

    if (result == 'LOCKED') {
      return _json({'error': 'الجهاز محظور مؤقتاً.', 'code': 'LOCKED'}, 429);
    }
    if (result == 'NOT_CONFIGURED') {
      return _json(
          {'error': 'السيرفر غير مهيأ.', 'code': 'NOT_CONFIGURED'}, 500);
    }
    if (result == 'INVALID_CREDENTIALS') {
      return _json(
          {'error': 'بيانات الدخول غير صحيحة.', 'code': 'INVALID_CREDENTIALS'},
          401);
    }

    return _json({
      'status': 'pending_approval',
      'requestId': result,
      'message': 'يرجى تأكيد الدخول من شاشة التلفاز.'
    });
  }

  /// Step 2: Poll for confirmation on TV
  Future<Response> _handleLoginStatus(Request req) async {
    final requestId = req.url.queryParameters['requestId'] ?? '';
    if (requestId.isEmpty) return _json({'error': 'requestId مطلوب.'}, 400);

    final request = auth.getRequest(requestId);
    if (request == null) {
      return _json({'error': 'الطلب منتهي الصلاحية.', 'code': 'EXPIRED'}, 401);
    }

    if (request.isDenied) {
      return _json(
          {'error': 'تم رفض الطلب من قِبل التلفاز.', 'code': 'DENIED'}, 403);
    }

    if (request.isConfirmed) {
      final token = auth.confirmLogin(requestId);
      if (token == null) return _json({'error': 'فشل الحصول على التوكن.'}, 500);
      return _json({
        'status': 'confirmed',
        'token': token,
      });
    }

    return _json({'status': 'pending'});
  }

  Future<Response> _handleLogout(Request req) async {
    final authHeader = req.headers['authorization'] ?? '';
    if (authHeader.startsWith('Bearer ')) {
      auth.logout(authHeader.substring(7));
    }
    return _json({'message': 'تم تسجيل الخروج.'});
  }

  Future<Response> _handleGetNews(Request req) async {
    final items = news.getAll().map((e) => e.toJson()).toList();
    return _json({'items': items, 'count': items.length});
  }

  Future<Response> _handleCreateNews(Request req) async {
    final body = await _readBody(req);
    if (body == null || body['text'] == null) {
      return _json({'error': 'حقل النص مطلوب.'}, 400);
    }
    final text = body['text'].toString().trim();
    if (text.length < 2) {
      return _json({'error': 'النص قصير جداً.'}, 400);
    }
    if (text.length > 2000) {
      return _json({'error': 'النص طويل جداً (الحد 2000 حرف).'}, 400);
    }

    final item = await news.create(
      text: text,
      enabled: body['enabled'] as bool? ?? true,
      scheduleType: body['scheduleType']?.toString() ?? 'daily',
      date: body['date']?.toString(),
      displayDurationSeconds: body['displayDurationSeconds'] as int? ?? 86400,
    );
    return _json(item.toJson(), 201);
  }

  Future<Response> _handleUpdateNews(Request req) async {
    final id = req.params['id'] ?? '';
    final body = await _readBody(req);
    if (body == null) return _json({'error': 'طلب غير صالح.'}, 400);

    final text = body['text']?.toString().trim();
    if (text != null && text.length > 2000) {
      return _json({'error': 'النص طويل جداً.'}, 400);
    }

    final updated = await news.update(id, body);
    if (updated == null) return _json({'error': 'الرسالة غير موجودة.'}, 404);
    return _json(updated.toJson());
  }

  Future<Response> _handleDeleteNews(Request req) async {
    final id = req.params['id'] ?? '';
    final deleted = await news.delete(id);
    if (!deleted) return _json({'error': 'الرسالة غير موجودة.'}, 404);
    return _json({'message': 'تم الحذف.'});
  }

  Future<Response> _handleReorder(Request req) async {
    final body = await _readBody(req);
    if (body == null || body['orderedIds'] == null) {
      return _json({'error': 'orderedIds مطلوب.'}, 400);
    }
    final ids = (body['orderedIds'] as List).map((e) => e.toString()).toList();
    await news.reorder(ids);
    return _json({'message': 'تم الترتيب.'});
  }

  Future<Response> _handleGetDevices(Request req) async {
    final devices = auth.getDevices().map((d) => d.toJson()).toList();
    return _json({'devices': devices});
  }

  Future<Response> _handleRevokeDevice(Request req) async {
    final id = req.params['id'] ?? '';
    final ok = auth.revokeDevice(id);
    if (!ok) return _json({'error': 'الجهاز غير موجود.'}, 404);
    return _json({'message': 'تم إلغاء الجهاز.'});
  }

  Future<Response> _handleGetSettings(Request req) async {
    return _json(loadSettings());
  }

  Future<Response> _handleUpdateSettings(Request req) async {
    final body = await _readBody(req);
    if (body == null) return _json({'error': 'طلب غير صالح.'}, 400);

    try {
      final updatedSettings = await saveSettings(body);
      sse.broadcastSettingsUpdate(updatedSettings);
      return _json({'status': 'success', 'settings': updatedSettings});
    } catch (e) {
      return _json(
          {'error': 'فشل تحديث الإعدادات.', 'details': e.toString()}, 400);
    }
  }

  Future<Response> _handleFactoryReset(Request req) async {
    try {
      final updatedSettings = await saveSettings({'RESET_TO_DEFAULT': true});
      sse.broadcastSettingsUpdate(updatedSettings);
      return _json({'status': 'success', 'message': 'تم إعادة ضبط المصنع.'});
    } catch (e) {
      return _json(
          {'error': 'فشل إعادة ضبط المصنع.', 'details': e.toString()}, 500);
    }
  }

  Future<Response> _handleSSE(Request req) async {
    final token = req.url.queryParameters['token'] ?? '';
    final device = auth.validate(token);
    if (device == null) {
      return _json({'error': 'غير مصرح.'}, 401);
    }

    final clientId = _uuid.v4();
    final controller = StreamController<String>();

    sse.addClient(clientId, controller);

    final items = news.getAll().map((e) => e.toJson()).toList();
    sse.broadcastNewsUpdate(items);
    sse.broadcastSettingsUpdate(loadSettings());

    return Response.ok(
      controller.stream,
      headers: {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        'connection': 'keep-alive',
        'x-accel-buffering': 'no',
      },
    );
  }

  Future<Response> _handle404(Request req) async {
    return _json({'error': 'المسار غير موجود: ${req.url.path}'}, 404);
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  Response _json(Object data, [int status = 200]) {
    return Response(
      status,
      body: jsonEncode(data),
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }

  Future<Map<String, dynamic>?> _readBody(Request req) async {
    try {
      final raw = await req.readAsString();
      if (raw.isEmpty) return {};
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<Response> _handleUpload(Request req) async {
    try {
      final contentType = req.headers['content-type'] ?? '';
      if (!contentType.contains('multipart/form-data')) {
        // We might also support raw binary if needed, but multipart is standard
      }

      // Simple multipart parser for shelf is hard without extra libs,
      // but we can use 'shelf_multipart' if available or just read raw if it's a single file.
      // Let's assume the web sends the file as raw bytes with a custom header for name.

      final fileName = Uri.decodeComponent(req.headers['x-file-name'] ??
          'upload_${DateTime.now().millisecondsSinceEpoch}.jpg');

      final bytes = await req.read().expand((b) => b).toList();

      final dir = Directory(slidesDirPath);
      if (!await dir.exists()) await dir.create(recursive: true);

      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes);

      return _json({
        'status': 'success',
        'fileName': fileName,
        'url': '/slides/$fileName'
      });
    } catch (e) {
      return _json({'error': 'فشل الرفع: $e'}, 500);
    }
  }

  Future<Response> _handleServeSlide(Request req) async {
    final filename = req.params['filename'] ?? '';
    final file = File('$slidesDirPath/$filename');
    if (await file.exists()) {
      final bytes = await file.readAsBytes();
      // Infer content type
      String type = 'image/jpeg';
      if (filename.endsWith('.png')) type = 'image/png';
      if (filename.endsWith('.gif')) type = 'image/gif';
      if (filename.endsWith('.webp')) type = 'image/webp';

      return Response.ok(bytes, headers: {'content-type': type});
    }
    return Response.notFound('File not found');
  }

  String _clientIp(Request req) {
    final xForwardedFor = req.headers['x-forwarded-for'];
    if (xForwardedFor != null) {
      return xForwardedFor.split(',').first.trim();
    }
    final info = req.context['shelf.io.connection_info'];
    if (info is HttpConnectionInfo) {
      return info.remoteAddress.address;
    }
    return '0.0.0.0';
  }

  Future<String?> _loadWebAsset(String fileName) async {
    if (webAssetsDirPath != null) {
      final file = File('$webAssetsDirPath/$fileName');
      if (await file.exists()) {
        return file.readAsString();
      }
    }
    try {
      return await rootBundle.loadString('assets/web/$fileName');
    } catch (_) {
      return null;
    }
  }

  Map<String, String> _webAssetHeaders(String contentType) {
    return {
      'content-type': contentType,
      'cache-control': 'no-store, no-cache, must-revalidate, max-age=0',
      'pragma': 'no-cache',
      'expires': '0',
    };
  }
  // ─── Background & Adhan Handlers ────────────────────────────────────────────

  String get _backgroundsDirPath =>
      '${slidesDirPath.replaceAll('/slides', '')}/custom_backgrounds';
  String get _adhanDirPath =>
      '${slidesDirPath.replaceAll('/slides', '')}/adhan';

  Future<Response> _handleBackgroundUpload(Request req) async {
    try {
      final requestedName =
          Uri.decodeComponent(req.headers['x-file-name'] ?? '');
      final safeName = _sanitizeFileName(requestedName);
      final fileName = safeName.isNotEmpty
          ? safeName
          : 'bg_${DateTime.now().millisecondsSinceEpoch}.jpg';

      final bytes = await req.read().expand((b) => b).toList();

      final dir = Directory(_backgroundsDirPath);
      if (!await dir.exists()) await dir.create(recursive: true);

      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes);

      // Broadcast update via SSE
      sse.broadcast('background_uploaded',
          {'fileName': fileName, 'url': '/backgrounds/$fileName'});

      await onBackgroundUploaded?.call(fileName, file.path);

      return _json({
        'status': 'success',
        'fileName': fileName,
        'url': '/backgrounds/$fileName'
      });
    } catch (e) {
      return _json({'error': 'فشل رفع الخلفية: $e'}, 500);
    }
  }

  Future<Response> _handleListBackgrounds(Request req) async {
    try {
      final dir = Directory(_backgroundsDirPath);
      if (!await dir.exists()) return _json({'backgrounds': []});

      final files = await dir.list().where((f) => f is File).toList();
      final list = files.map((f) {
        final name = f.path.split(Platform.pathSeparator).last;
        return {'fileName': name, 'url': '/backgrounds/$name'};
      }).toList();

      return _json({'backgrounds': list});
    } catch (e) {
      return _json({'backgrounds': []});
    }
  }

  Future<Response> _handleSelectBackground(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return _json({'error': 'اسم الملف غير صالح.'}, 400);

    final file = File('$_backgroundsDirPath/$filename');
    if (!await file.exists()) return _json({'error': 'الملف غير موجود.'}, 404);

    try {
      final updatedSettings = await saveSettings({
        'bgMode': 'MANUAL',
        'selectedBackgroundId': -1,
        'selectedCustomBgPath': file.path,
      });
      sse.broadcastSettingsUpdate(updatedSettings);
      sse.broadcast(
          'backgrounds_updated', {'fileName': filename, 'selected': true});

      return _json({
        'status': 'success',
        'fileName': filename,
        'settings': updatedSettings,
      });
    } catch (e) {
      return _json(
          {'error': 'فشل تفعيل الخلفية.', 'details': e.toString()}, 500);
    }
  }

  Future<Response> _handleServeBackground(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return Response.notFound('File not found');
    final file = File('$_backgroundsDirPath/$filename');
    if (await file.exists()) {
      final bytes = await file.readAsBytes();
      String type = 'image/jpeg';
      if (filename.endsWith('.png')) type = 'image/png';
      if (filename.endsWith('.webp')) type = 'image/webp';
      return Response.ok(bytes, headers: {'content-type': type});
    }
    return Response.notFound('File not found');
  }

  Future<Response> _handleAdhanUpload(Request req) async {
    try {
      final requestedName =
          Uri.decodeComponent(req.headers['x-file-name'] ?? '');
      final safeName = _sanitizeFileName(requestedName);
      final fileName = safeName.isNotEmpty
          ? safeName
          : 'adhan_${DateTime.now().millisecondsSinceEpoch}.mp3';

      final bytes = await req.read().expand((b) => b).toList();

      final dir = Directory(_adhanDirPath);
      if (!await dir.exists()) await dir.create(recursive: true);

      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes);

      await onAdhanUploaded?.call(fileName, file.path);

      // Broadcast update via SSE
      sse.broadcast(
          'adhan_uploaded', {'fileName': fileName, 'url': '/adhan/$fileName'});

      return _json({
        'status': 'success',
        'fileName': fileName,
        'url': '/adhan/$fileName'
      });
    } catch (e) {
      return _json({'error': 'فشل رفع صوت الأذان: $e'}, 500);
    }
  }

  Future<Response> _handleListAdhan(Request req) async {
    try {
      final dir = Directory(_adhanDirPath);
      if (!await dir.exists()) return _json({'adhan': []});

      final files = await dir.list().where((f) => f is File).toList();
      final list = files.map((f) {
        final name = f.path.split(Platform.pathSeparator).last;
        return {'fileName': name, 'url': '/adhan/$name'};
      }).toList();

      return _json({'adhan': list});
    } catch (e) {
      return _json({'adhan': []});
    }
  }

  Future<Response> _handleServeAdhan(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return Response.notFound('File not found');
    final file = File('$_adhanDirPath/$filename');
    if (await file.exists()) {
      final bytes = await file.readAsBytes();
      String type = 'audio/mpeg';
      if (filename.endsWith('.ogg')) type = 'audio/ogg';
      if (filename.endsWith('.wav')) type = 'audio/wav';
      return Response.ok(bytes, headers: {'content-type': type});
    }
    return Response.notFound('File not found');
  }

  Future<Response> _handleDeleteBackground(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return _json({'error': 'اسم الملف غير صالح.'}, 400);

    final file = File('$_backgroundsDirPath/$filename');
    if (!await file.exists()) return _json({'error': 'الملف غير موجود.'}, 404);

    await file.delete();
    sse.broadcast('backgrounds_updated', {'fileName': filename});
    return _json({'status': 'success', 'fileName': filename});
  }

  Future<Response> _handleDeleteAdhan(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return _json({'error': 'اسم الملف غير صالح.'}, 400);

    final file = File('$_adhanDirPath/$filename');
    if (!await file.exists()) return _json({'error': 'الملف غير موجود.'}, 404);

    await file.delete();
    sse.broadcast('adhan_updated', {'fileName': filename});
    return _json({'status': 'success', 'fileName': filename});
  }

  // ── Mosque Icon Handlers ──
  String get _mosqueIconDirPath =>
      '${slidesDirPath.replaceAll('/slides', '')}/mosque_icons';
  String get _countryFlagDirPath =>
      '${slidesDirPath.replaceAll('/slides', '')}/country_flags';

  Future<Response> _handleMosqueIconUpload(Request req) async {
    try {
      final requestedName =
          Uri.decodeComponent(req.headers['x-file-name'] ?? '');
      final safeName = _sanitizeFileName(requestedName);
      final fileName = safeName.isNotEmpty
          ? safeName
          : 'mosque_${DateTime.now().millisecondsSinceEpoch}.jpg';

      final bytes = await req.read().expand((b) => b).toList();
      final dir = Directory(_mosqueIconDirPath);
      if (!await dir.exists()) await dir.create(recursive: true);

      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes);

      await onBackgroundUploaded?.call(fileName, file.path);
      sse.broadcastSettingsUpdate(loadSettings());

      return _json({
        'status': 'success',
        'fileName': fileName,
        'url': '/mosque-icon/$fileName'
      });
    } catch (e) {
      return _json({'error': 'فشل رفع أيقونة المسجد: $e'}, 500);
    }
  }

  Future<Response> _handleServeMosqueIcon(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return Response.notFound('File not found');

    final file = File('$_mosqueIconDirPath/$filename');
    if (await file.exists()) {
      final bytes = await file.readAsBytes();
      String type = 'image/jpeg';
      if (filename.endsWith('.png')) type = 'image/png';
      if (filename.endsWith('.webp')) type = 'image/webp';
      if (filename.endsWith('.gif')) type = 'image/gif';
      return Response.ok(bytes, headers: {'content-type': type});
    }
    return Response.notFound('File not found');
  }

  Future<Response> _handleCountryFlagUpload(Request req) async {
    try {
      final requestedName =
          Uri.decodeComponent(req.headers['x-file-name'] ?? '');
      final safeName = _sanitizeFileName(requestedName);
      final fileName = safeName.isNotEmpty
          ? safeName
          : 'flag_${DateTime.now().millisecondsSinceEpoch}.jpg';

      final bytes = await req.read().expand((b) => b).toList();
      final dir = Directory(_countryFlagDirPath);
      if (!await dir.exists()) await dir.create(recursive: true);

      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes);

      await onCountryFlagUploaded?.call(fileName, file.path);
      sse.broadcastSettingsUpdate(loadSettings());

      return _json({
        'status': 'success',
        'fileName': fileName,
        'url': '/country-flag/$fileName'
      });
    } catch (e) {
      return _json({'error': 'فشل رفع علم الدولة: $e'}, 500);
    }
  }

  Future<Response> _handleServeCountryFlag(Request req) async {
    final filename = _sanitizeFileName(req.params['filename'] ?? '');
    if (filename.isEmpty) return Response.notFound('File not found');

    final file = File('$_countryFlagDirPath/$filename');
    if (await file.exists()) {
      final bytes = await file.readAsBytes();
      String type = 'image/jpeg';
      if (filename.endsWith('.png')) type = 'image/png';
      if (filename.endsWith('.webp')) type = 'image/webp';
      if (filename.endsWith('.gif')) type = 'image/gif';
      return Response.ok(bytes, headers: {'content-type': type});
    }
    return Response.notFound('File not found');
  }

  // ── Locations & Excel Handlers ──

  Future<Response> _handleGetLocations(Request req) async {
    if (getLocations == null) return _json({'error': 'Not supported'}, 501);
    try {
      final locs = await getLocations!();
      return _json(locs);
    } catch (e) {
      return _json({'error': 'فشل تحميل المواقع: $e'}, 500);
    }
  }

  Future<Response> _handleExcelPreview(Request req) async {
    if (onExcelPreview == null) return _json({'error': 'Not supported'}, 501);
    try {
      final duration = req.headers['x-duration-key'] ?? 'AUTO';
      final country = req.headers['x-country'] ?? '';
      final city = req.headers['x-city'] ?? '';

      final fileName =
          Uri.decodeComponent(req.headers['x-file-name'] ?? 'import.xlsx');
      final bytes = await req.read().expand((b) => b).toList();

      // Save to temp file for the service to read
      final tempDir = Directory.systemTemp;
      final tempFile = File(
          '${tempDir.path}/web_import_${DateTime.now().millisecondsSinceEpoch}_$fileName');
      await tempFile.writeAsBytes(bytes);

      final preview =
          await onExcelPreview!(tempFile.path, duration, country, city);

      // Clean up temp file
      if (await tempFile.exists()) await tempFile.delete();

      return _json(preview);
    } catch (e) {
      return _json({'error': 'فشل معالجة الملف: $e'}, 500);
    }
  }

  Future<Response> _handleExcelImport(Request req) async {
    if (onExcelImport == null) return _json({'error': 'Not supported'}, 501);
    try {
      final body = await _readBody(req);
      if (body == null) return _json({'error': 'طلب غير صالح'}, 400);
      await onExcelImport!(body);
      return _json({'status': 'success'});
    } catch (e) {
      return _json({'error': 'فشل الاستيراد: $e'}, 500);
    }
  }

  Future<Response> _handleExcelDelete(Request req) async {
    if (onExcelDelete == null) return _json({'error': 'Not supported'}, 501);
    try {
      final country = req.url.queryParameters['country'] ?? '';
      final city = req.url.queryParameters['city'] ?? '';
      if (country.isEmpty || city.isEmpty) {
        return _json({'error': 'الدولة والمدينة مطلوبان'}, 400);
      }
      await onExcelDelete!(country, city);
      return _json({'status': 'success'});
    } catch (e) {
      return _json({'error': 'فشل حذف البيانات: $e'}, 500);
    }
  }

  Future<Response> _handleExcelExists(Request req) async {
    if (onExcelExists == null) return _json({'exists': false});
    try {
      final country = req.url.queryParameters['country'] ?? '';
      final city = req.url.queryParameters['city'] ?? '';
      if (country.isEmpty || city.isEmpty) {
        return _json({'error': 'الدولة والمدينة مطلوبان'}, 400);
      }
      final exists = await onExcelExists!(country, city);
      return _json({
        'exists': exists,
        'country': country,
        'city': city,
      });
    } catch (e) {
      return _json({'error': 'فشل التحقق من الملف المخصص: $e'}, 500);
    }
  }

  String _sanitizeFileName(String input) {
    if (input.isEmpty) return '';
    return input
        .replaceAll('\\', '')
        .replaceAll('/', '')
        .replaceAll('..', '')
        .trim();
  }
}
