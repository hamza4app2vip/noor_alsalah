import 'package:flutter/material.dart';
import 'app_colors.dart';
import '../../features/settings/domain/entities/app_settings.dart';

class AppStyles {
  static const String cairo = 'Cairo';
  static const String amiri = 'Amiri';
  
  static AppSettings? currentSettings;

  static String _getFontName(String? family, String defaultFont) {
    if (family == null || family.isEmpty) return defaultFont;
    return family;
  }

  static TextStyle get heading => TextStyle(
        fontFamily: _getFontName(currentSettings?.textFontFamily, amiri),
        color: AppColors.primaryGold,
        fontWeight: FontWeight.bold,
        fontSize: 24, // adjust based on usage
      );

  static TextStyle get body => TextStyle(
        fontFamily: _getFontName(currentSettings?.textFontFamily, cairo),
        color: AppColors.foreground,
        fontSize: 14,
      );

  static TextStyle get bodyMuted => TextStyle(
        fontFamily: _getFontName(currentSettings?.textFontFamily, cairo),
        color: AppColors.mutedForeground,
        fontSize: 14,
      );

  static TextStyle get timeLarge => TextStyle(
        fontFamily: _getFontName(currentSettings?.clockFontFamily, cairo),
        fontWeight: FontWeight.bold,
        color: AppColors.foreground,
        fontFeatures: const [FontFeature.tabularFigures()],
      );

  static TextStyle get timeMedium => TextStyle(
        fontFamily: _getFontName(currentSettings?.timesFontFamily, cairo),
        fontWeight: FontWeight.bold,
        color: AppColors.foreground,
        fontFeatures: const [FontFeature.tabularFigures()],
      );
}
