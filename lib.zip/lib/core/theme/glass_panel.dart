import 'package:flutter/material.dart';
import 'package:noor_prayer_tv/core/widgets/luxury_glass_container.dart';

class GlassPanel extends StatelessWidget {
  final Widget child;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry padding;
  final bool isHighlighted;
  final String theme; // "emerald" | "sapphire"

  const GlassPanel({
    super.key,
    required this.child,
    this.width,
    this.height,
    this.padding = const EdgeInsets.all(16.0),
    this.isHighlighted = false,
    this.theme = 'emerald',
  });

  @override
  Widget build(BuildContext context) {
    return LuxuryGlassContainer(
      isHighlighted: isHighlighted,
      width: width,
      height: height,
      padding: padding,
      child: child,
    );
  }
}
