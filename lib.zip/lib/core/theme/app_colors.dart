import 'package:flutter/material.dart';

class AppColors {
  // Common Colors
  static final Color foreground = HSLColor.fromAHSL(1.0, 220, 0.60, 0.97).toColor();
  
  // Update Brand Color to official User color #08452F (This is actually Green)
  static const Color primaryBrandPath = Color(0xFF08452F);
  
  // Official Gold Accent #DCB881
  static const Color goldAccent = Color(0xFFDCB881);
  
  // Maintain backward compatibility but point to Gold for the "Official" look in the new theme
  static const Color primaryGold = Color(0xFFDCB881); 
  static final Color goldLight = const Color(0xFFDCB881).withValues(alpha: 0.8);
  static final Color goldDark = const Color(0xFFDCB881).withValues(alpha: 1.0);
  
  static final Color mutedForeground = HSLColor.fromAHSL(1.0, 160, 0.15, 0.55).toColor();
  
  static final Color neonEmerald = HSLColor.fromAHSL(1.0, 160, 1.00, 0.44).toColor();
  static final Color neonSapphire = HSLColor.fromAHSL(1.0, 220, 0.80, 0.60).toColor();

  static final Color glassBorder = Colors.white.withValues(alpha: 0.12);
  static final Color glassHighlight = Colors.white.withValues(alpha: 0.08);
  
  // Semantic Colors
  static final Color info = neonSapphire;
  static final Color success = neonEmerald;

  // Emerald Theme
  static final Color emeraldBg = HSLColor.fromAHSL(1.0, 150, 0.60, 0.04).toColor();
  static final Color emeraldGlassBg = HSLColor.fromAHSL(0.45, 155, 0.50, 0.08).toColor();
  static final Color emeraldMuted = HSLColor.fromAHSL(1.0, 155, 0.30, 0.14).toColor();

  // Sapphire Theme
  static final Color sapphireBg = HSLColor.fromAHSL(1.0, 225, 0.60, 0.08).toColor();
  static final Color sapphireGlassBg = HSLColor.fromAHSL(0.45, 225, 0.50, 0.12).toColor();
  static final Color sapphireMuted = HSLColor.fromAHSL(1.0, 225, 0.30, 0.18).toColor();

  // Gradients
  static final LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      HSLColor.fromAHSL(1.0, 43, 0.50, 0.38).toColor(),
      HSLColor.fromAHSL(1.0, 43, 0.56, 0.52).toColor(),
      HSLColor.fromAHSL(1.0, 43, 0.65, 0.72).toColor(),
      HSLColor.fromAHSL(1.0, 43, 0.56, 0.52).toColor(),
      HSLColor.fromAHSL(1.0, 43, 0.50, 0.38).toColor(),
    ],
    stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
  );

  static final LinearGradient goldTextGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      HSLColor.fromAHSL(1.0, 43, 0.50, 0.42).toColor(),
      HSLColor.fromAHSL(1.0, 43, 0.60, 0.65).toColor(),
      HSLColor.fromAHSL(1.0, 43, 0.50, 0.42).toColor(),
    ],
  );
}
