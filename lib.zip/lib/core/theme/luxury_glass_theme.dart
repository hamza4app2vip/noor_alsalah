import 'package:flutter/material.dart';
import '../../features/settings/domain/entities/app_settings.dart';
import '../theme/app_colors.dart';

class LuxuryGlassTheme {
  static const Color backgroundColor = Color(0xFF121212);
  static const Color primaryOrange = Color(0xFFFF7B00);
  static const Color backgroundBlue = Color(0xFF2B5876);
  static const Color glassBorderColor = Colors.white; // Used with opacity globally
  
  static ThemeData getTheme(AppSettings settings, BuildContext context) {
    final String defaultFont = settings.textFontFamily.isNotEmpty ? settings.textFontFamily : 'Cairo';
    
    // Determine the brightness based on themeMode
    Brightness brightness;
    if (settings.themeMode == 'LIGHT') {
      brightness = Brightness.light;
    } else if (settings.themeMode == 'DARK') {
      brightness = Brightness.dark;
    } else {
      // SYSTEM mode
      brightness = MediaQuery.platformBrightnessOf(context);
    }

    final isDark = brightness == Brightness.dark;

    // --- Color Palettes ---
    const goldenColor = AppColors.goldAccent;
    
    // Dark Palette: Deep Navy / Night Sky
    const darkBgBottom = Color(0xFF020617); // Almost black
    
    // Light Palette: Off-White / Fine Paper
    const lightBg = Color(0xFFF8F9FA);
    const lightTextPrimary = Color(0xFF1E293B); // Dark slate
    
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      fontFamily: defaultFont,
      scaffoldBackgroundColor: isDark ? darkBgBottom : lightBg,
      primaryColor: goldenColor,
      colorScheme: isDark 
        ? const ColorScheme.dark(
            primary: goldenColor,
            surface: Colors.transparent,
            onSurface: Colors.white,
          )
        : const ColorScheme.light(
            primary: goldenColor,
            surface: Colors.transparent,
            onSurface: lightTextPrimary,
          ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: isDark ? Colors.white : lightTextPrimary,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          fontFamily: defaultFont,
        ),
      ),
      iconTheme: IconThemeData(color: isDark ? Colors.white : lightTextPrimary),
      textTheme: TextTheme(
        bodyLarge: TextStyle(color: isDark ? Colors.white : lightTextPrimary, fontFamily: defaultFont),
        bodyMedium: TextStyle(color: (isDark ? Colors.white : lightTextPrimary).withValues(alpha: 0.7), fontFamily: defaultFont),
      ),
      dividerTheme: DividerThemeData(
        color: (isDark ? Colors.white : lightTextPrimary).withValues(alpha: 0.1),
        thickness: 0.5,
      ),
    );
  }

  // Helper for background decoration
  static BoxDecoration getPageDecoration(bool isDark) {
    if (isDark) {
      return const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0F172A),
            Color(0xFF020617),
          ],
        ),
      );
    } else {
      return const BoxDecoration(
        color: Color(0xFFF8F9FA),
      );
    }
  }
}
