import 'package:flutter/material.dart';
import 'package:noor_prayer_tv/core/widgets/luxury_glass_container.dart';

class GlassTokens {
  static const double blurX = 7.0;
  static const double blurY = 7.0;
  static const double borderRadius = 30.0;
  
  static BoxDecoration glassDecoration(BuildContext context, {bool isHighlighted = false}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final glassTop = isDark ? const Color(0xFF0F172A).withValues(alpha: 0.26) : Colors.white.withValues(alpha: 0.12);
    final glassBottom = isDark ? const Color(0xFF17233F).withValues(alpha: 0.14) : Colors.white.withValues(alpha: 0.04);
    final borderColor = isDark ? Colors.white.withValues(alpha: 0.10) : Colors.white.withValues(alpha: 0.12);
    final shadowColor = isDark ? Colors.black.withValues(alpha: 0.18) : Colors.black.withValues(alpha: 0.08);
    final highlightColor = isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white.withValues(alpha: 0.06);
    
    final highlightTintColor = isHighlighted ? Theme.of(context).primaryColor.withValues(alpha: 0.4) : Colors.transparent;
    
    return BoxDecoration(
      borderRadius: BorderRadius.circular(borderRadius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          isHighlighted ? highlightTintColor : glassTop, 
          glassBottom
        ],
      ),
      border: Border.all(
        color: isHighlighted ? Theme.of(context).primaryColor : borderColor,
        width: 1.4,
      ),
      boxShadow: [
        BoxShadow(
          color: shadowColor,
          blurRadius: 30,
          offset: const Offset(0, 18),
        ),
        BoxShadow(
          color: highlightColor,
          spreadRadius: 1,
        ),
      ],
    );
  }
}

class PremiumGlassCard extends StatelessWidget {
  final Widget child;
  final bool isHighlighted;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;

  const PremiumGlassCard({
    super.key,
    required this.child,
    this.isHighlighted = false,
    this.width,
    this.height,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return LuxuryGlassContainer(
      isHighlighted: isHighlighted,
      width: width,
      height: height,
      padding: padding ?? const EdgeInsets.all(20.0),
      child: child,
    );
  }
}
