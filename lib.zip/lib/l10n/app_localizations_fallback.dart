import 'app_localizations.dart';

/// Temporary compatibility extension for settings labels that may not exist
/// in older generated localization classes.
extension AppLocalizationsFallback on AppLocalizations {
  bool get _isEn => localeName == 'en';

  String get menuGeneralReportsSubtitle => _isEn ? 'General Settings & Reports' : 'الإعدادات العامة والتقارير';
  String get menuAnnouncements => _isEn ? 'Announcements' : 'الإعلانات';
  String get menuAnnouncementsSubtitle => _isEn ? 'Manage Mosque Announcements' : 'إدارة إعلانات المسجد';
  String get menuContact => _isEn ? 'Contact Us' : 'تواصل معنا';
  String get menuContactSubtitle => _isEn ? 'Contact Messages' : 'رسائل التواصل';

  String get analogClockStyle => _isEn ? 'Analog Clock Style' : 'نمط الساعة التناظرية';
  String get iqamaScreenLabel => _isEn ? 'Iqama Screen' : 'شاشة الإقامة';

  String get adhanIqamaAlerts => _isEn ? 'Adhan & Iqama Alerts' : 'تنبيهات الأذان والإقامة';
  String get alertBeforeAdhan => _isEn ? 'Alert before Adhan' : 'تنبيه قبل الأذان';
  String get alertBeforeAdhanDesc => _isEn ? 'Play an alert before Adhan time' : 'تشغيل تنبيه قبل وقت الأذان';
  String get fajrFirstAdhan => _isEn ? 'First Fajr Alert' : 'تنبيه الفجر الأول';
  String get fajrFirstAdhanDesc => _isEn ? 'Enable additional alert before Fajr Adhan' : 'تفعيل تنبيه إضافي قبل أذان الفجر';
  String get alertIqamaTime => _isEn ? 'Iqama Time Alert' : 'تنبيه وقت الإقامة';
  String get alertIqamaTimeDesc => _isEn ? 'Play an alert at Iqama time' : 'تشغيل تنبيه عند وقت الإقامة';
  String get prayerDhikr => _isEn ? 'Prayer Time Dhikr' : 'ذكر وقت الصلاة';
  String get prayerDhikrDesc => _isEn ? 'Show/Play Dhikr during prayer time' : 'إظهار/تشغيل الذكر أثناء وقت الصلاة';
  String get tasbihAfterAdhan => _isEn ? 'Tasbeeh After Adhan' : 'تسبيح بعد الأذان';
  String get tasbihAfterAdhanDesc => _isEn ? 'Show Tasbeeh after Adhan' : 'إظهار التسبيح بعد الأذان';

  String get morningEveningAzkar => _isEn ? 'Morning & Evening Adhkar' : 'أذكار الصباح والمساء';
  String get morningAzkar => _isEn ? 'Morning Adhkar' : 'أذكار الصباح';
  String get morningAzkarDesc => _isEn ? 'Enable Morning Adhkar' : 'تفعيل أذكار الصباح';
  String get eveningAzkar => _isEn ? 'Evening Adhkar' : 'أذكار المساء';
  String get eveningAzkarDesc => _isEn ? 'Enable Evening Adhkar' : 'تفعيل أذكار المساء';
  String get azkarOnlyScreen => _isEn ? 'Adhkar Only Screen' : 'شاشة أذكار فقط';
  String get azkarOnlyScreenDesc => _isEn ? 'Display Adhkar only screen' : 'عرض شاشة الأذكار فقط';
  String get azkarGlassBg => _isEn ? 'Glass Background for Adhkar' : 'خلفية زجاجية للأذكار';
  String get azkarGlassBgDesc => _isEn ? 'Use a glass background in the Adhkar screen' : 'استخدام خلفية زجاجية في شاشة الأذكار';
  String get customAzkarBg => _isEn ? 'Custom Adhkar Background' : 'خلفية مخصصة للأذكار';
  String get removeAzkarBg => _isEn ? 'Remove Adhkar Background' : 'إزالة خلفية الأذكار';
  String get postPrayerAzkarAdv => _isEn ? 'Post-Prayer Adhkar (Advanced)' : 'أذكار بعد الصلاة (متقدم)';
  String get postPrayerAzkarAdvDesc => _isEn ? 'Advanced options for post-prayer Adhkar' : 'خيارات متقدمة لأذكار ما بعد الصلاة';

  String get defaultSoundName => _isEn ? 'Default Sound' : 'الصوت الافتراضي';
  String get customAdhanSoundsGroup => _isEn ? 'Custom Adhan Sounds' : 'الأصوات المخصصة للأذان';
  String get selectDefaultSound => _isEn ? 'Select Default Sound' : 'اختر الصوت الافتراضي';
  String get customizePerPrayer => _isEn ? 'Customize per prayer' : 'تخصيص لكل صلاة';
  String get adhanTypeSpeedGroup => _isEn ? 'Adhan Type & Speed' : 'نوع وسرعة الأذان';
  String get mp3Adhan => _isEn ? 'MP3 Adhan' : 'أذان MP3';
  String get mp3AdhanDesc => _isEn ? 'Use an MP3 audio file for Adhan' : 'استخدام ملف صوتي MP3 للأذان';
  String get builtInSound => _isEn ? 'Built-in Sound' : 'الصوت المدمج';

  String get azkarFont => _isEn ? 'Adhkar Font' : 'خط الأذكار';
  String get clockFont => _isEn ? 'Clock Font' : 'خط الساعة';
  String get prayerTimesFont => _isEn ? 'Prayer Times Font' : 'خط أوقات الصلاة';
  String get generalTextFont => _isEn ? 'General Text Font' : 'خط النص العام';

  String get importantNotice => _isEn ? 'Important Notice' : 'تنبيه مهم';
  String get addNewLocationMandatoryExcelDesc => _isEn ? 'Before adding a new location, make sure to import the correct prayer times file.' : 'قبل إضافة موقع جديد، تأكد من استيراد ملف الأوقات المناسب.';
  String get countryNameHint => _isEn ? 'Country Name' : 'اسم الدولة';
  String get countryCodeHint => _isEn ? 'Country Code' : 'رمز الدولة';
  String get pleaseCompleteDataCorrectly => _isEn ? 'Please complete the data correctly' : 'يرجى إكمال البيانات بشكل صحيح';
  String get pleaseEnterCityName => _isEn ? 'Please enter the city name' : 'يرجى إدخال اسم المدينة';

  String get themeEmeraldClassic => _isEn ? 'Emerald Classic' : 'الزمرد الكلاسيكي';
  String get themeEmeraldClassicDesc => _isEn ? 'A comforting classic green theme' : 'ثيم كلاسيكي أخضر مريح';
  String get themePureGlass => _isEn ? 'Pure Glass' : 'الزجاج النقي';
  String get themePureGlassDesc => _isEn ? 'A modern, transparent glass theme' : 'ثيم زجاجي شفاف وحديث';

  String get addNewLocation => _isEn ? 'Add New Location' : 'إضافة موقع جديد';
  String get addNewLocationDesc => _isEn ? 'Add a new country and city to prayer times data' : 'أضف دولة ومدينة جديدة لبيانات الأوقات';
  String get excelDataExistsDesc => _isEn ? 'Previously imported data exists. Do you want to activate the new data?' : 'توجد بيانات مستوردة مسبقًا. هل تريد تفعيل البيانات الجديدة؟';
  String get noUseOriginal => _isEn ? 'No, use current' : 'لا، استخدم الحالي';
  String get yesActivateData => _isEn ? 'Yes, activate data' : 'نعم، فعّل البيانات';
  String get applyExcelDataDesc => _isEn ? 'The file data will be applied to the selected city.' : 'سيتم تطبيق بيانات الملف على المدينة المختارة.';

  String errorPickingImage(String error) => _isEn ? 'Error picking image: $error' : 'تعذر اختيار الصورة: $error';

  // --- Newly added fallback keys for azkar settings screen ---
  String get postPrayerAzkarTitle => _isEn ? 'Adhkar After Prayer' : 'الأذكار بعد الصلاة';
  String get generalSettingsLabel => _isEn ? 'General Settings' : 'إعدادات عامة';
  String get enablePostPrayerAzkarSubtitle => _isEn ? 'Enable/disable Adhkar after prayer finishes' : 'تشغيل/إيقاف الأذكار عند انتهاء الصلاة';
  String get repeatAzkarOnce => _isEn ? 'Repeat Adhkar once after finishing' : 'إعادة الأذكار مرة واحدة بعد الانتهاء';
  String get showOneAzkarImage5Min => _isEn ? 'Show one image only for 5 minutes' : 'عرض صورة واحدة فقط لمدة 5 دقائق';
  String get showOneAzkarImage5MinSubtitle => _isEn ? 'Instead of auto-scrolling between Adhkar' : 'بدلاً من التمرير التلقائي بين الأذكار';
  String get mainScreenAzkar => _isEn ? 'Main Screen Adhkar' : 'أذكار الشاشة الرئيسية';
  String get enableSabahAzkarOnMain => _isEn ? 'Enable Morning Adhkar' : 'تفعيل أذكار الصباح';
  String get appearsInMarquee => _isEn ? 'Appears in the scrolling ticker' : 'تظهر في الشريط المتحرك';
  String get enableMasaaAzkarOnMain => _isEn ? 'Enable Evening Adhkar' : 'تفعيل أذكار المساء';
  String get standaloneAzkarScreenSettings => _isEn ? 'Standalone Adhkar Screen Settings' : 'إعدادات الشاشة المستقلة للأذكار';
  String get appearByDesignatedTime => _isEn ? 'Appear based on designated time' : 'الظهور حسب الوقت المحدد';
  String get automaticallyMorningEvening => _isEn ? 'Automatically (morning for morning, evening for evening)' : 'تلقائياً (صباحاً للصباح، ومساءً للمساء)';
  String get specificAzkarForManualPlayback => _isEn ? 'Specific Adhkar for manual playback' : 'الأذكار المحددة للتشغيل اليدوي';
  String get whenAutoTimeOptionDisabled => _isEn ? 'When auto-time option is disabled' : 'عند عدم تفعيل خيار الوقت التلقائي';
  String get sabahAzkarOnly => _isEn ? 'Morning Adhkar only' : 'أذكار الصباح فقط';
  String get masaaAzkarOnly => _isEn ? 'Evening Adhkar only' : 'أذكار المساء فقط';
  String get bothSabahAndMasaa => _isEn ? 'Both (Morning & Evening)' : 'الكل (صباح ومساء)';
  String get azkarTiming => _isEn ? 'Adhkar Timing' : 'توقيت الأذكار';
  String get sabahAzkarStartTime => _isEn ? 'Morning Adhkar Start Time' : 'وقت بدء أذكار الصباح';
  String get sabahAzkarEndTime => _isEn ? 'Morning Adhkar End Time' : 'وقت انتهاء أذكار الصباح';
  String get masaaAzkarStartTime => _isEn ? 'Evening Adhkar Start Time' : 'وقت بدء أذكار المساء';
  String get masaaAzkarEndTime => _isEn ? 'Evening Adhkar End Time' : 'وقت انتهاء أذكار المساء';
  String get azkarAfterEveryPrayer => _isEn ? 'Adhkar After Every Prayer' : 'أذكار بعد كل صلاة';
  String get postPrayerAzkarHint => _isEn ? 'Post-prayer Adhkar appear automatically on the full screen after Iqama time ends and before the black screen.' : 'الأذكار البعدية تظهر تلقائياً على الشاشة الكاملة بعد انتهاء وقت الإقامة وقبل الشاشة السوداء.';
  String get selectTime => _isEn ? 'Select Time' : 'اختر الوقت';
  String get savedSuccessfully => _isEn ? 'Saved successfully' : 'تم الحفظ';
}

