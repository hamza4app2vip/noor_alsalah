import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
      : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @dohaTime.
  ///
  /// In en, this message translates to:
  /// **'Start of Duha'**
  String get dohaTime;

  /// No description provided for @minutesToIqama.
  ///
  /// In en, this message translates to:
  /// **'Iqama...'**
  String get minutesToIqama;

  /// No description provided for @minutesToDoha.
  ///
  /// In en, this message translates to:
  /// **'Duha...'**
  String get minutesToDoha;

  /// No description provided for @azanCalling.
  ///
  /// In en, this message translates to:
  /// **'Adhan'**
  String get azanCalling;

  /// No description provided for @azanName.
  ///
  /// In en, this message translates to:
  /// **'Adhan'**
  String get azanName;

  /// No description provided for @nextPrayTime.
  ///
  /// In en, this message translates to:
  /// **'Next Prayer'**
  String get nextPrayTime;

  /// No description provided for @namesOfPrayings.
  ///
  /// In en, this message translates to:
  /// **'Fajr,Sunrise,Dhuhr,Asr,Maghrib,Isha'**
  String get namesOfPrayings;

  /// No description provided for @namesWeekDays.
  ///
  /// In en, this message translates to:
  /// **'Sunday,Monday,Tuesday,Wednesday,Thursday,Jummoa,Saturday'**
  String get namesWeekDays;

  /// No description provided for @menuMonthsHijri.
  ///
  /// In en, this message translates to:
  /// **'Muharram,Safar,Rabi I,Rabi II,Jumada I,Jumada II,Rajab,Shaban,Ramadan,Shawwal,Dhul\'Qidah,Dhul\'Hijjah'**
  String get menuMonthsHijri;

  /// No description provided for @menuFullScreen.
  ///
  /// In en, this message translates to:
  /// **'Fullscreen mode'**
  String get menuFullScreen;

  /// No description provided for @menuMosqueName.
  ///
  /// In en, this message translates to:
  /// **'Edit Mosque name'**
  String get menuMosqueName;

  /// No description provided for @menuMosqueMessage.
  ///
  /// In en, this message translates to:
  /// **'Edit Mosque announcements'**
  String get menuMosqueMessage;

  /// No description provided for @menuLocation.
  ///
  /// In en, this message translates to:
  /// **'Mosque location'**
  String get menuLocation;

  /// No description provided for @menuHijriClick.
  ///
  /// In en, this message translates to:
  /// **'Adjust Hijri date'**
  String get menuHijriClick;

  /// No description provided for @menuThemes.
  ///
  /// In en, this message translates to:
  /// **'Change screen background'**
  String get menuThemes;

  /// No description provided for @menuOptions.
  ///
  /// In en, this message translates to:
  /// **'Options'**
  String get menuOptions;

  /// No description provided for @menuAzkar.
  ///
  /// In en, this message translates to:
  /// **'Display Adhkar'**
  String get menuAzkar;

  /// No description provided for @menuSliders.
  ///
  /// In en, this message translates to:
  /// **'Display slides'**
  String get menuSliders;

  /// No description provided for @menuAdjustments.
  ///
  /// In en, this message translates to:
  /// **'Adjust Adhan and Iqama times'**
  String get menuAdjustments;

  /// No description provided for @menuBlackscreen.
  ///
  /// In en, this message translates to:
  /// **'Adjust screen blackout'**
  String get menuBlackscreen;

  /// No description provided for @menuRestartApp.
  ///
  /// In en, this message translates to:
  /// **'Reload application'**
  String get menuRestartApp;

  /// No description provided for @option9.
  ///
  /// In en, this message translates to:
  /// **'About application'**
  String get option9;

  /// No description provided for @fastingMonday.
  ///
  /// In en, this message translates to:
  /// **'Reminder of the Sunnah fast for tomorrow, Monday'**
  String get fastingMonday;

  /// No description provided for @fastingThursday.
  ///
  /// In en, this message translates to:
  /// **'Reminder of the Sunnah fast for tomorrow, Thursday'**
  String get fastingThursday;

  /// No description provided for @option0.
  ///
  /// In en, this message translates to:
  /// **'Enable 24-hour display'**
  String get option0;

  /// No description provided for @option1.
  ///
  /// In en, this message translates to:
  /// **'Enable full clock display'**
  String get option1;

  /// No description provided for @option2.
  ///
  /// In en, this message translates to:
  /// **'Dim past prayers'**
  String get option2;

  /// No description provided for @adjust1.
  ///
  /// In en, this message translates to:
  /// **'Enlarge countdown on screen'**
  String get adjust1;

  /// No description provided for @adjust2.
  ///
  /// In en, this message translates to:
  /// **'Use sound for Adhan (MP3)'**
  String get adjust2;

  /// No description provided for @adjust3.
  ///
  /// In en, this message translates to:
  /// **'Add 30 minutes to Isha prayer during Ramadan'**
  String get adjust3;

  /// No description provided for @prayer.
  ///
  /// In en, this message translates to:
  /// **'Prayer'**
  String get prayer;

  /// No description provided for @iqama.
  ///
  /// In en, this message translates to:
  /// **'Iqama'**
  String get iqama;

  /// No description provided for @doha.
  ///
  /// In en, this message translates to:
  /// **'Duha'**
  String get doha;

  /// No description provided for @dimmer0.
  ///
  /// In en, this message translates to:
  /// **'Enable screen blackout during prayer'**
  String get dimmer0;

  /// No description provided for @dimmer1.
  ///
  /// In en, this message translates to:
  /// **'Blackout screen 30 minutes after sunrise'**
  String get dimmer1;

  /// No description provided for @dimmer2.
  ///
  /// In en, this message translates to:
  /// **'Blackout screen 60 minutes after Isha'**
  String get dimmer2;

  /// No description provided for @dimmer3.
  ///
  /// In en, this message translates to:
  /// **'Blackout screen before Dhuhr'**
  String get dimmer3;

  /// No description provided for @dimmer4.
  ///
  /// In en, this message translates to:
  /// **'Show screen after Dhuhr'**
  String get dimmer4;

  /// No description provided for @dimmer5.
  ///
  /// In en, this message translates to:
  /// **'Prayer duration for screen blackout'**
  String get dimmer5;

  /// No description provided for @azkar4.
  ///
  /// In en, this message translates to:
  /// **'Display one image only for a fixed duration of 5 minutes'**
  String get azkar4;

  /// No description provided for @times2.
  ///
  /// In en, this message translates to:
  /// **'Select Mosque country and city'**
  String get times2;

  /// No description provided for @times3.
  ///
  /// In en, this message translates to:
  /// **'To modify or add annual prayer times'**
  String get times3;

  /// No description provided for @times4.
  ///
  /// In en, this message translates to:
  /// **'1- Export settings.<br>2- Edit yearly prayer time data.<br>3- Import settings into the application'**
  String get times4;

  /// No description provided for @box0.
  ///
  /// In en, this message translates to:
  /// **'Click on the Hijri date to adjust it ±3 days'**
  String get box0;

  /// No description provided for @misc0.
  ///
  /// In en, this message translates to:
  /// **'Reload the page after modifications'**
  String get misc0;

  /// No description provided for @misc1.
  ///
  /// In en, this message translates to:
  /// **'Click on the name or Fajr time to change backgrounds'**
  String get misc1;

  /// No description provided for @noSell.
  ///
  /// In en, this message translates to:
  /// **'Free application, selling is prohibited'**
  String get noSell;

  /// No description provided for @jomoa.
  ///
  /// In en, this message translates to:
  /// **'Jummoa'**
  String get jomoa;

  /// No description provided for @iqamaAsHour.
  ///
  /// In en, this message translates to:
  /// **'Display Iqama as time'**
  String get iqamaAsHour;

  /// No description provided for @summertime.
  ///
  /// In en, this message translates to:
  /// **'Add one hour to prayer times during summer'**
  String get summertime;

  /// No description provided for @useArabicDigits.
  ///
  /// In en, this message translates to:
  /// **'Enable Arabic numerals (or numerals of the language in use)'**
  String get useArabicDigits;

  /// No description provided for @wcsvMessage.
  ///
  /// In en, this message translates to:
  /// **'Enable prayer and Iqama times file.<br>Edit the file (wcsv.js) in the application folder (JAMAAT TIMES).'**
  String get wcsvMessage;

  /// No description provided for @eCountdownOnOff.
  ///
  /// In en, this message translates to:
  /// **'Show countdown'**
  String get eCountdownOnOff;

  /// No description provided for @n1MoreHour.
  ///
  /// In en, this message translates to:
  /// **'Manually add one hour to all times'**
  String get n1MoreHour;

  /// No description provided for @n1LessHour.
  ///
  /// In en, this message translates to:
  /// **'Manually remove one hour from all times'**
  String get n1LessHour;

  /// No description provided for @eShortAzan.
  ///
  /// In en, this message translates to:
  /// **'Use short Adhan sound'**
  String get eShortAzan;

  /// No description provided for @eShortIqama.
  ///
  /// In en, this message translates to:
  /// **'Use short Iqama sound'**
  String get eShortIqama;

  /// No description provided for @meteo.
  ///
  /// In en, this message translates to:
  /// **'Enable weather status'**
  String get meteo;

  /// No description provided for @appFonts.
  ///
  /// In en, this message translates to:
  /// **'Adjust application fonts'**
  String get appFonts;

  /// No description provided for @forcedVertical.
  ///
  /// In en, this message translates to:
  /// **'Vertical display'**
  String get forcedVertical;

  /// No description provided for @scrollableMsg.
  ///
  /// In en, this message translates to:
  /// **'Enable scrolling text bar'**
  String get scrollableMsg;

  /// No description provided for @hideIqamat.
  ///
  /// In en, this message translates to:
  /// **'Home clock - hide Iqama times'**
  String get hideIqamat;

  /// No description provided for @zerosAmPm.
  ///
  /// In en, this message translates to:
  /// **'Add leading zero for AM/PM times (04:35 AM)'**
  String get zerosAmPm;

  /// No description provided for @meteoPryrs.
  ///
  /// In en, this message translates to:
  /// **'Enable weather display next to prayer times'**
  String get meteoPryrs;

  /// No description provided for @meteoA.
  ///
  /// In en, this message translates to:
  /// **'Weather forecast'**
  String get meteoA;

  /// No description provided for @time2Shrq.
  ///
  /// In en, this message translates to:
  /// **'Time remaining until sunrise'**
  String get time2Shrq;

  /// No description provided for @wqtShrq.
  ///
  /// In en, this message translates to:
  /// **'Sunrise'**
  String get wqtShrq;

  /// No description provided for @n5BoxesOnly.
  ///
  /// In en, this message translates to:
  /// **'Enlarge prayer and Iqama times in horizontal view'**
  String get n5BoxesOnly;

  /// No description provided for @iqamatSalat.
  ///
  /// In en, this message translates to:
  /// **'Iqama of prayer'**
  String get iqamatSalat;

  /// No description provided for @jomoaOnOff.
  ///
  /// In en, this message translates to:
  /// **'Jummoa : Khutbah start time'**
  String get jomoaOnOff;

  /// No description provided for @adminmsgs0.
  ///
  /// In en, this message translates to:
  /// **'Mosque announcements at the bottom of the screen'**
  String get adminmsgs0;

  /// No description provided for @adminmsgsTexter.
  ///
  /// In en, this message translates to:
  /// **'Here you can add scrolling messages to be displayed at the bottom of the screen'**
  String get adminmsgsTexter;

  /// No description provided for @adminmsgsHelp.
  ///
  /// In en, this message translates to:
  /// **'Info: Double-click the message to edit.<br>Double-click (DAILY) to change the day or date of the message'**
  String get adminmsgsHelp;

  /// No description provided for @addMsg.
  ///
  /// In en, this message translates to:
  /// **'Add message'**
  String get addMsg;

  /// No description provided for @dohrXminAsr.
  ///
  /// In en, this message translates to:
  /// **'Dhuhr = Asr - x minutes (click to change): '**
  String get dohrXminAsr;

  /// No description provided for @jomoaInlogo.
  ///
  /// In en, this message translates to:
  /// **'Jummoa time in place of the logo in horizontal view'**
  String get jomoaInlogo;

  /// No description provided for @azkar0.
  ///
  /// In en, this message translates to:
  /// **'Enable Adhkar after obligatory prayers'**
  String get azkar0;

  /// No description provided for @sliders0.
  ///
  /// In en, this message translates to:
  /// **'Enable slides'**
  String get sliders0;

  /// No description provided for @jomoaShow.
  ///
  /// In en, this message translates to:
  /// **'Show Jummoa in horizontal display'**
  String get jomoaShow;

  /// No description provided for @vrMiddleNames.
  ///
  /// In en, this message translates to:
  /// **'Center prayer names (in vertical view)'**
  String get vrMiddleNames;

  /// No description provided for @middleSalats.
  ///
  /// In en, this message translates to:
  /// **'Center prayer names (in horizontal view)'**
  String get middleSalats;

  /// No description provided for @azkarSabah.
  ///
  /// In en, this message translates to:
  /// **'Enable morning Adhkar after Fajr prayer'**
  String get azkarSabah;

  /// No description provided for @azkarAsr.
  ///
  /// In en, this message translates to:
  /// **'Enable evening Adhkar after Asr prayer'**
  String get azkarAsr;

  /// No description provided for @azkarMagrib.
  ///
  /// In en, this message translates to:
  /// **'Enable evening Adhkar after Maghrib prayer'**
  String get azkarMagrib;

  /// No description provided for @azkarIsha.
  ///
  /// In en, this message translates to:
  /// **'Enable evening Adhkar after Isha prayer'**
  String get azkarIsha;

  /// No description provided for @n1MinCounter.
  ///
  /// In en, this message translates to:
  /// **'Enlarge counter on black screen during the last minute'**
  String get n1MinCounter;

  /// No description provided for @iqamaScreen.
  ///
  /// In en, this message translates to:
  /// **'Show Iqama screen before black screen'**
  String get iqamaScreen;

  /// No description provided for @hrDateRight.
  ///
  /// In en, this message translates to:
  /// **'Date on the right and Mosque name on the left in horizontal view'**
  String get hrDateRight;

  /// No description provided for @verifNet.
  ///
  /// In en, this message translates to:
  /// **'Check internet connection (star at the bottom of the screen)'**
  String get verifNet;

  /// No description provided for @timesBgShadows.
  ///
  /// In en, this message translates to:
  /// **'Shade background behind prayer times'**
  String get timesBgShadows;

  /// No description provided for @mobileAlert.
  ///
  /// In en, this message translates to:
  /// **'Audio alert message during the last minute before Iqama (click to change message)'**
  String get mobileAlert;

  /// No description provided for @shortCuts.
  ///
  /// In en, this message translates to:
  /// **'Screen shortcuts'**
  String get shortCuts;

  /// No description provided for @shortCutsText.
  ///
  /// In en, this message translates to:
  /// **'Direct quick taps on the screen for options'**
  String get shortCutsText;

  /// No description provided for @clockInBlkScr.
  ///
  /// In en, this message translates to:
  /// **'Display clock on black screen'**
  String get clockInBlkScr;

  /// No description provided for @dateInBlkScr.
  ///
  /// In en, this message translates to:
  /// **'Display date on black screen'**
  String get dateInBlkScr;

  /// No description provided for @semiTransparent.
  ///
  /// In en, this message translates to:
  /// **'Semi-transparent screens for Adhan, Iqama, and Duha windows'**
  String get semiTransparent;

  /// No description provided for @iqamaHadith.
  ///
  /// In en, this message translates to:
  /// **'Display a Hadith of Prophet ﷺ (33 seconds before Iqama)'**
  String get iqamaHadith;

  /// No description provided for @primaryAzan.
  ///
  /// In en, this message translates to:
  /// **'Adjust first Adhan time | x minutes before actual Fajr Adhan. Audio alert. Click to change:'**
  String get primaryAzan;

  /// No description provided for @counterColorAlert.
  ///
  /// In en, this message translates to:
  /// **'Change counter color to red during the last 90 seconds'**
  String get counterColorAlert;

  /// No description provided for @showAzanScreen.
  ///
  /// In en, this message translates to:
  /// **'Show Adhan screen'**
  String get showAzanScreen;

  /// No description provided for @biggerNextPray.
  ///
  /// In en, this message translates to:
  /// **'Enlarge remaining time counter for the next prayer'**
  String get biggerNextPray;

  /// No description provided for @themesNoChange.
  ///
  /// In en, this message translates to:
  /// **'Change background manually'**
  String get themesNoChange;

  /// No description provided for @themesEverySalat.
  ///
  /// In en, this message translates to:
  /// **'Change background at every prayer'**
  String get themesEverySalat;

  /// No description provided for @themesEveryDay.
  ///
  /// In en, this message translates to:
  /// **'Change background daily'**
  String get themesEveryDay;

  /// No description provided for @themesRandomDaily.
  ///
  /// In en, this message translates to:
  /// **'Change background daily randomly from this list:'**
  String get themesRandomDaily;

  /// No description provided for @randomSlides.
  ///
  /// In en, this message translates to:
  /// **'Display slides randomly'**
  String get randomSlides;

  /// No description provided for @eidFitrTime.
  ///
  /// In en, this message translates to:
  /// **'Show Eid al-Fitr prayer time:'**
  String get eidFitrTime;

  /// No description provided for @eidAdhaTime.
  ///
  /// In en, this message translates to:
  /// **'Show Eid al-Adha prayer time:'**
  String get eidAdhaTime;

  /// No description provided for @salatEidFitr.
  ///
  /// In en, this message translates to:
  /// **'Eid al-Fitr prayer'**
  String get salatEidFitr;

  /// No description provided for @salatEidAdha.
  ///
  /// In en, this message translates to:
  /// **'Eid al-Adha prayer'**
  String get salatEidAdha;

  /// No description provided for @jomoaAzanOnOff.
  ///
  /// In en, this message translates to:
  /// **'Enable Jummoa Adhan sound'**
  String get jomoaAzanOnOff;

  /// No description provided for @fixedTimeForIqamat.
  ///
  /// In en, this message translates to:
  /// **'Fixed time for Iqama:'**
  String get fixedTimeForIqamat;

  /// No description provided for @fixedTimeForJomoa.
  ///
  /// In en, this message translates to:
  /// **'Fixed time for Jomoa Adhan'**
  String get fixedTimeForJomoa;

  /// No description provided for @slidesViewTime.
  ///
  /// In en, this message translates to:
  /// **'Duration of each slide'**
  String get slidesViewTime;

  /// No description provided for @tawkitViewTime.
  ///
  /// In en, this message translates to:
  /// **'Main screen display duration'**
  String get tawkitViewTime;

  /// No description provided for @slidesScreenMaxMin.
  ///
  /// In en, this message translates to:
  /// **'Display duration: maximum 60 seconds, minimum 10 seconds'**
  String get slidesScreenMaxMin;

  /// No description provided for @menuSynchronize.
  ///
  /// In en, this message translates to:
  /// **'Export/Import settings'**
  String get menuSynchronize;

  /// No description provided for @dlSettingsFile.
  ///
  /// In en, this message translates to:
  /// **'Download settings file'**
  String get dlSettingsFile;

  /// No description provided for @enterImportId.
  ///
  /// In en, this message translates to:
  /// **'(Import ID) - Enter import number'**
  String get enterImportId;

  /// No description provided for @useImportedTimes.
  ///
  /// In en, this message translates to:
  /// **'Use prayer times from imported file'**
  String get useImportedTimes;

  /// No description provided for @clockAdjust.
  ///
  /// In en, this message translates to:
  /// **'Adjust main clock, add or remove hours'**
  String get clockAdjust;

  /// No description provided for @azkarBgWhite.
  ///
  /// In en, this message translates to:
  /// **'Use white background'**
  String get azkarBgWhite;

  /// No description provided for @selectAyatsLang.
  ///
  /// In en, this message translates to:
  /// **'Select language for Quranic verses on screen'**
  String get selectAyatsLang;

  /// No description provided for @persoFiles.
  ///
  /// In en, this message translates to:
  /// **'Manage personal files'**
  String get persoFiles;

  /// No description provided for @persoFilesMessage.
  ///
  /// In en, this message translates to:
  /// **'Customize the app with personal images for background and adhkar.'**
  String get persoFilesMessage;

  /// No description provided for @slowDeviceAlert.
  ///
  /// In en, this message translates to:
  /// **'(This option may cause slowness on low-end devices.)'**
  String get slowDeviceAlert;

  /// No description provided for @enablePersoFiles.
  ///
  /// In en, this message translates to:
  /// **'Enable personal files'**
  String get enablePersoFiles;

  /// No description provided for @showNightPrayers.
  ///
  /// In en, this message translates to:
  /// **'Show night prayer times: midnight, last third of the night, Fajr'**
  String get showNightPrayers;

  /// No description provided for @soundAlertsReminders.
  ///
  /// In en, this message translates to:
  /// **'Sound alerts'**
  String get soundAlertsReminders;

  /// No description provided for @ramadanDaysLeftInfo.
  ///
  /// In en, this message translates to:
  /// **'Include days left until Ramadan with messages (two months before Ramadan).'**
  String get ramadanDaysLeftInfo;

  /// No description provided for @ramadanLeftDays.
  ///
  /// In en, this message translates to:
  /// **'Days left until Ramadan:'**
  String get ramadanLeftDays;

  /// No description provided for @changelog.
  ///
  /// In en, this message translates to:
  /// **'Changelog'**
  String get changelog;

  /// No description provided for @languages.
  ///
  /// In en, this message translates to:
  /// **'Languages'**
  String get languages;

  /// No description provided for @selectLanguage.
  ///
  /// In en, this message translates to:
  /// **'Select Language'**
  String get selectLanguage;

  /// No description provided for @arabic.
  ///
  /// In en, this message translates to:
  /// **'Arabic'**
  String get arabic;

  /// No description provided for @english.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get english;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @preview.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get preview;

  /// No description provided for @fajr.
  ///
  /// In en, this message translates to:
  /// **'Fajr'**
  String get fajr;

  /// No description provided for @sunrise.
  ///
  /// In en, this message translates to:
  /// **'Sunrise'**
  String get sunrise;

  /// No description provided for @dhuhr.
  ///
  /// In en, this message translates to:
  /// **'Dhuhr'**
  String get dhuhr;

  /// No description provided for @asr.
  ///
  /// In en, this message translates to:
  /// **'Asr'**
  String get asr;

  /// No description provided for @maghrib.
  ///
  /// In en, this message translates to:
  /// **'Maghrib'**
  String get maghrib;

  /// No description provided for @isha.
  ///
  /// In en, this message translates to:
  /// **'Isha'**
  String get isha;

  /// No description provided for @midnight.
  ///
  /// In en, this message translates to:
  /// **'Midnight'**
  String get midnight;

  /// No description provided for @lastThird.
  ///
  /// In en, this message translates to:
  /// **'Last Third'**
  String get lastThird;

  /// No description provided for @stopBlackClockWithHour.
  ///
  /// In en, this message translates to:
  /// **'Stop Black Clock with Hour'**
  String get stopBlackClockWithHour;

  /// No description provided for @exitKhushooMode.
  ///
  /// In en, this message translates to:
  /// **'Exit Khushoo Mode'**
  String get exitKhushooMode;

  /// No description provided for @hour.
  ///
  /// In en, this message translates to:
  /// **'Hour'**
  String get hour;

  /// No description provided for @minute.
  ///
  /// In en, this message translates to:
  /// **'Minute'**
  String get minute;

  /// No description provided for @second.
  ///
  /// In en, this message translates to:
  /// **'Second'**
  String get second;

  /// No description provided for @and.
  ///
  /// In en, this message translates to:
  /// **'and'**
  String get and;

  /// No description provided for @adhanTimeHasCome.
  ///
  /// In en, this message translates to:
  /// **'Adhan time has come for'**
  String get adhanTimeHasCome;

  /// No description provided for @prayerNameWithPrefix.
  ///
  /// In en, this message translates to:
  /// **'{name} Prayer'**
  String prayerNameWithPrefix(Object name);

  /// No description provided for @internetConnected.
  ///
  /// In en, this message translates to:
  /// **'Internet Connected'**
  String get internetConnected;

  /// No description provided for @iqamaTimeHasCome.
  ///
  /// In en, this message translates to:
  /// **'Iqama time has come for'**
  String get iqamaTimeHasCome;

  /// No description provided for @minutesUntilIqama.
  ///
  /// In en, this message translates to:
  /// **'minutes until iqama'**
  String get minutesUntilIqama;

  /// No description provided for @seconds.
  ///
  /// In en, this message translates to:
  /// **'seconds'**
  String get seconds;

  /// No description provided for @currentFontLabel.
  ///
  /// In en, this message translates to:
  /// **'Current Font: {font}'**
  String currentFontLabel(Object font);

  /// No description provided for @chooseFontFor.
  ///
  /// In en, this message translates to:
  /// **'Choose {label}'**
  String chooseFontFor(Object label);

  /// No description provided for @changeFontHint.
  ///
  /// In en, this message translates to:
  /// **'Tap \'Change\' to choose the appropriate font for each section'**
  String get changeFontHint;

  /// No description provided for @addFirstCity.
  ///
  /// In en, this message translates to:
  /// **'Add First City'**
  String get addFirstCity;

  /// No description provided for @addFirstCityDesc.
  ///
  /// In en, this message translates to:
  /// **'It is recommended to add at least one city for this country now.'**
  String get addFirstCityDesc;

  /// No description provided for @cityNameHint.
  ///
  /// In en, this message translates to:
  /// **'City Name (e.g., Taiz)'**
  String get cityNameHint;

  /// No description provided for @addAndSave.
  ///
  /// In en, this message translates to:
  /// **'Add & Save'**
  String get addAndSave;

  /// No description provided for @settingsLocationTime.
  ///
  /// In en, this message translates to:
  /// **'Location & Time Settings'**
  String get settingsLocationTime;

  /// No description provided for @settingsAppearanceSlides.
  ///
  /// In en, this message translates to:
  /// **'Appearance & Slides'**
  String get settingsAppearanceSlides;

  /// No description provided for @settingsAdhanFiles.
  ///
  /// In en, this message translates to:
  /// **'Adhan & Custom Files'**
  String get settingsAdhanFiles;

  /// No description provided for @settingsAdvanced.
  ///
  /// In en, this message translates to:
  /// **'Advanced Add-ons'**
  String get settingsAdvanced;

  /// No description provided for @menuGeneralReports.
  ///
  /// In en, this message translates to:
  /// **'General & Reports'**
  String get menuGeneralReports;

  /// No description provided for @menuLocationWeather.
  ///
  /// In en, this message translates to:
  /// **'Location & Weather'**
  String get menuLocationWeather;

  /// No description provided for @menuPrayerAdjustments.
  ///
  /// In en, this message translates to:
  /// **'Prayer & Friday Adjustments'**
  String get menuPrayerAdjustments;

  /// No description provided for @menuIdentityLayout.
  ///
  /// In en, this message translates to:
  /// **'Identity & Formatting'**
  String get menuIdentityLayout;

  /// No description provided for @menuThemesBackgrounds.
  ///
  /// In en, this message translates to:
  /// **'Background Screens'**
  String get menuThemesBackgrounds;

  /// No description provided for @menuModelsLayout.
  ///
  /// In en, this message translates to:
  /// **'Models & Layout'**
  String get menuModelsLayout;

  /// No description provided for @menuMessagesSlides.
  ///
  /// In en, this message translates to:
  /// **'Messages & Slides'**
  String get menuMessagesSlides;

  /// No description provided for @menuAdhanAlerts.
  ///
  /// In en, this message translates to:
  /// **'Adhan & Iqama Alerts'**
  String get menuAdhanAlerts;

  /// No description provided for @menuAudioAlarms.
  ///
  /// In en, this message translates to:
  /// **'Audio & Alarms'**
  String get menuAudioAlarms;

  /// No description provided for @menuExcelImport.
  ///
  /// In en, this message translates to:
  /// **'Import from Excel'**
  String get menuExcelImport;

  /// No description provided for @general.
  ///
  /// In en, this message translates to:
  /// **'General'**
  String get general;

  /// No description provided for @location.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get location;

  /// No description provided for @display.
  ///
  /// In en, this message translates to:
  /// **'Display'**
  String get display;

  /// No description provided for @prayers.
  ///
  /// In en, this message translates to:
  /// **'Prayers'**
  String get prayers;

  /// No description provided for @adhanIqama.
  ///
  /// In en, this message translates to:
  /// **'Adhan & Iqama'**
  String get adhanIqama;

  /// No description provided for @alerts.
  ///
  /// In en, this message translates to:
  /// **'Alerts'**
  String get alerts;

  /// No description provided for @audio.
  ///
  /// In en, this message translates to:
  /// **'Audio'**
  String get audio;

  /// No description provided for @helpAndRestore.
  ///
  /// In en, this message translates to:
  /// **'Help & Restore'**
  String get helpAndRestore;

  /// No description provided for @mosqueName.
  ///
  /// In en, this message translates to:
  /// **'Mosque Name'**
  String get mosqueName;

  /// No description provided for @mosqueIcon.
  ///
  /// In en, this message translates to:
  /// **'Mosque Icon'**
  String get mosqueIcon;

  /// No description provided for @chooseFromGallery.
  ///
  /// In en, this message translates to:
  /// **'Choose image from gallery'**
  String get chooseFromGallery;

  /// No description provided for @mainClockOffset.
  ///
  /// In en, this message translates to:
  /// **'Main Clock Offset'**
  String get mainClockOffset;

  /// No description provided for @unitMinute.
  ///
  /// In en, this message translates to:
  /// **'min'**
  String get unitMinute;

  /// No description provided for @showHijriDate.
  ///
  /// In en, this message translates to:
  /// **'Show Hijri Date'**
  String get showHijriDate;

  /// No description provided for @appTimeCustomization.
  ///
  /// In en, this message translates to:
  /// **'App Time Customization'**
  String get appTimeCustomization;

  /// No description provided for @manualTimeEntry.
  ///
  /// In en, this message translates to:
  /// **'Manual Time Entry'**
  String get manualTimeEntry;

  /// No description provided for @manualTimeAdjustment.
  ///
  /// In en, this message translates to:
  /// **'Manual Time Adjustment'**
  String get manualTimeAdjustment;

  /// No description provided for @notSet.
  ///
  /// In en, this message translates to:
  /// **'Not set'**
  String get notSet;

  /// No description provided for @weatherLocationSettings.
  ///
  /// In en, this message translates to:
  /// **'Weather & Location Settings'**
  String get weatherLocationSettings;

  /// No description provided for @gpsWeatherStatus.
  ///
  /// In en, this message translates to:
  /// **'GPS and weather status'**
  String get gpsWeatherStatus;

  /// No description provided for @countryWithName.
  ///
  /// In en, this message translates to:
  /// **'Country: {name}'**
  String countryWithName(Object name);

  /// No description provided for @tapToChangeCountry.
  ///
  /// In en, this message translates to:
  /// **'Tap to change country'**
  String get tapToChangeCountry;

  /// No description provided for @cityWithName.
  ///
  /// In en, this message translates to:
  /// **'City: {name}'**
  String cityWithName(Object name);

  /// No description provided for @tapToChangeCity.
  ///
  /// In en, this message translates to:
  /// **'Tap to change city'**
  String get tapToChangeCity;

  /// No description provided for @factoryReset.
  ///
  /// In en, this message translates to:
  /// **'Factory Reset'**
  String get factoryReset;

  /// No description provided for @resetSettingsToDefault.
  ///
  /// In en, this message translates to:
  /// **'Reset all settings to default'**
  String get resetSettingsToDefault;

  /// No description provided for @confirmFactoryReset1.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete settings? All settings will be reset to their initial defaults.'**
  String get confirmFactoryReset1;

  /// No description provided for @confirmFactoryReset2.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to completely delete settings? This action cannot be undone.'**
  String get confirmFactoryReset2;

  /// No description provided for @yesSure.
  ///
  /// In en, this message translates to:
  /// **'Yes, I\'m sure'**
  String get yesSure;

  /// No description provided for @settingsResetSuccess.
  ///
  /// In en, this message translates to:
  /// **'Settings have been reset to default'**
  String get settingsResetSuccess;

  /// No description provided for @appTheme.
  ///
  /// In en, this message translates to:
  /// **'App Theme'**
  String get appTheme;

  /// No description provided for @prayerScreenTheme.
  ///
  /// In en, this message translates to:
  /// **'Prayer Screen Theme'**
  String get prayerScreenTheme;

  /// No description provided for @visualIdentity.
  ///
  /// In en, this message translates to:
  /// **'Visual Identity'**
  String get visualIdentity;

  /// No description provided for @countryFlag.
  ///
  /// In en, this message translates to:
  /// **'Country Flag'**
  String get countryFlag;

  /// No description provided for @showCountryFlagDesc.
  ///
  /// In en, this message translates to:
  /// **'Show country flag on screen'**
  String get showCountryFlagDesc;

  /// No description provided for @format24h.
  ///
  /// In en, this message translates to:
  /// **'24-Hour Format'**
  String get format24h;

  /// No description provided for @format24hDesc.
  ///
  /// In en, this message translates to:
  /// **'Display time in 24-hour format'**
  String get format24hDesc;

  /// No description provided for @padWithZero.
  ///
  /// In en, this message translates to:
  /// **'Pad times with zero'**
  String get padWithZero;

  /// No description provided for @padWithZeroDesc.
  ///
  /// In en, this message translates to:
  /// **'Example: 04:35 instead of 4:35'**
  String get padWithZeroDesc;

  /// No description provided for @fullClock.
  ///
  /// In en, this message translates to:
  /// **'Full Clock'**
  String get fullClock;

  /// No description provided for @fullClockDesc.
  ///
  /// In en, this message translates to:
  /// **'Show seconds (00:00:00)'**
  String get fullClockDesc;

  /// No description provided for @analogClock.
  ///
  /// In en, this message translates to:
  /// **'Analog Clock'**
  String get analogClock;

  /// No description provided for @analogClockDesc.
  ///
  /// In en, this message translates to:
  /// **'Show analog glass clock in all themes in landscape mode'**
  String get analogClockDesc;

  /// No description provided for @classicGlass.
  ///
  /// In en, this message translates to:
  /// **'Classic Glass'**
  String get classicGlass;

  /// No description provided for @luxuryGold.
  ///
  /// In en, this message translates to:
  /// **'Luxury Gold'**
  String get luxuryGold;

  /// No description provided for @royalIslamic.
  ///
  /// In en, this message translates to:
  /// **'Royal Islamic'**
  String get royalIslamic;

  /// No description provided for @analogClockDateFrame.
  ///
  /// In en, this message translates to:
  /// **'Analog Clock Date Frame'**
  String get analogClockDateFrame;

  /// No description provided for @analogClockDateFrameDesc.
  ///
  /// In en, this message translates to:
  /// **'Show date and day frame next to/below the clock'**
  String get analogClockDateFrameDesc;

  /// No description provided for @analogClockNumbers.
  ///
  /// In en, this message translates to:
  /// **'Analog Clock Numbers'**
  String get analogClockNumbers;

  /// No description provided for @analogClockNumbersDesc.
  ///
  /// In en, this message translates to:
  /// **'Show numbers on all analog clocks'**
  String get analogClockNumbersDesc;

  /// No description provided for @glassShine.
  ///
  /// In en, this message translates to:
  /// **'Glass Shine'**
  String get glassShine;

  /// No description provided for @glassShineDesc.
  ///
  /// In en, this message translates to:
  /// **'Enable/Disable glass shine in clock, frames, and floating messages'**
  String get glassShineDesc;

  /// No description provided for @nightPrayerTimes.
  ///
  /// In en, this message translates to:
  /// **'Night Prayer Times'**
  String get nightPrayerTimes;

  /// No description provided for @nightPrayerTimesDesc.
  ///
  /// In en, this message translates to:
  /// **'Midnight & Last Third of Night'**
  String get nightPrayerTimesDesc;

  /// No description provided for @marqueeTicker.
  ///
  /// In en, this message translates to:
  /// **'Verses & Athkar Ticker'**
  String get marqueeTicker;

  /// No description provided for @marqueeTickerDesc.
  ///
  /// In en, this message translates to:
  /// **'Moving ticker at the bottom of the screen'**
  String get marqueeTickerDesc;

  /// No description provided for @navbarPositionLandscape.
  ///
  /// In en, this message translates to:
  /// **'Navbar Position (Landscape)'**
  String get navbarPositionLandscape;

  /// No description provided for @fullScreenWidth.
  ///
  /// In en, this message translates to:
  /// **'Full Screen Width'**
  String get fullScreenWidth;

  /// No description provided for @centered.
  ///
  /// In en, this message translates to:
  /// **'Centered'**
  String get centered;

  /// No description provided for @sideMode.
  ///
  /// In en, this message translates to:
  /// **'On the side'**
  String get sideMode;

  /// No description provided for @pureGlassCustomization.
  ///
  /// In en, this message translates to:
  /// **'Pure Glass Theme Customization'**
  String get pureGlassCustomization;

  /// No description provided for @fontColor.
  ///
  /// In en, this message translates to:
  /// **'Font Color (Text)'**
  String get fontColor;

  /// No description provided for @fontColorDesc.
  ///
  /// In en, this message translates to:
  /// **'Change color of all texts in theme'**
  String get fontColorDesc;

  /// No description provided for @chooseFontColor.
  ///
  /// In en, this message translates to:
  /// **'Choose Font Color'**
  String get chooseFontColor;

  /// No description provided for @bgColor1.
  ///
  /// In en, this message translates to:
  /// **'Background Color 1 (Main)'**
  String get bgColor1;

  /// No description provided for @bgColor2.
  ///
  /// In en, this message translates to:
  /// **'Background Color 2'**
  String get bgColor2;

  /// No description provided for @bgColor3.
  ///
  /// In en, this message translates to:
  /// **'Background Color 3'**
  String get bgColor3;

  /// No description provided for @bgColor1Desc.
  ///
  /// In en, this message translates to:
  /// **'Change color of top circle and accents'**
  String get bgColor1Desc;

  /// No description provided for @bgColor2Desc.
  ///
  /// In en, this message translates to:
  /// **'Change color of bottom circle'**
  String get bgColor2Desc;

  /// No description provided for @bgColor3Desc.
  ///
  /// In en, this message translates to:
  /// **'Change color of side circle'**
  String get bgColor3Desc;

  /// No description provided for @screenOrientation.
  ///
  /// In en, this message translates to:
  /// **'Screen Orientation'**
  String get screenOrientation;

  /// No description provided for @auto.
  ///
  /// In en, this message translates to:
  /// **'Auto'**
  String get auto;

  /// No description provided for @portrait.
  ///
  /// In en, this message translates to:
  /// **'Portrait'**
  String get portrait;

  /// No description provided for @landscape.
  ///
  /// In en, this message translates to:
  /// **'Landscape'**
  String get landscape;

  /// No description provided for @announcementsSlides.
  ///
  /// In en, this message translates to:
  /// **'Announcements & Slides'**
  String get announcementsSlides;

  /// No description provided for @changeWallpaper.
  ///
  /// In en, this message translates to:
  /// **'Change Wallpaper'**
  String get changeWallpaper;

  /// No description provided for @changeWallpaperDesc.
  ///
  /// In en, this message translates to:
  /// **'Customize wallpapers for each prayer'**
  String get changeWallpaperDesc;

  /// No description provided for @advertisingSlides.
  ///
  /// In en, this message translates to:
  /// **'Advertising Slides'**
  String get advertisingSlides;

  /// No description provided for @manageSlidesDesc.
  ///
  /// In en, this message translates to:
  /// **'Manage images and texts as slides'**
  String get manageSlidesDesc;

  /// No description provided for @newsTickerVerses.
  ///
  /// In en, this message translates to:
  /// **'News Ticker & Verses'**
  String get newsTickerVerses;

  /// No description provided for @displayOptions.
  ///
  /// In en, this message translates to:
  /// **'Display Options'**
  String get displayOptions;

  /// No description provided for @dimPastPrayersDesc.
  ///
  /// In en, this message translates to:
  /// **'Dim prayers that have passed'**
  String get dimPastPrayersDesc;

  /// No description provided for @centerNamesLandscape.
  ///
  /// In en, this message translates to:
  /// **'Center Prayer Names (Landscape)'**
  String get centerNamesLandscape;

  /// No description provided for @centerNamesLandscapeDesc.
  ///
  /// In en, this message translates to:
  /// **'Center names in landscape mode'**
  String get centerNamesLandscapeDesc;

  /// No description provided for @centerNamesPortrait.
  ///
  /// In en, this message translates to:
  /// **'Center Prayer Names (Portrait)'**
  String get centerNamesPortrait;

  /// No description provided for @centerNamesPortraitDesc.
  ///
  /// In en, this message translates to:
  /// **'Center names in portrait mode'**
  String get centerNamesPortraitDesc;

  /// No description provided for @centerPrayerNameMixed.
  ///
  /// In en, this message translates to:
  /// **'Center Prayer Name (Adhan Right, Iqama Left)'**
  String get centerPrayerNameMixed;

  /// No description provided for @classicThemeOnly.
  ///
  /// In en, this message translates to:
  /// **'Specifically for Classic Theme'**
  String get classicThemeOnly;

  /// No description provided for @enlargeNamesLandscape.
  ///
  /// In en, this message translates to:
  /// **'Enlarge Prayer Names (Landscape)'**
  String get enlargeNamesLandscape;

  /// No description provided for @enlargeNamesLandscapeDesc.
  ///
  /// In en, this message translates to:
  /// **'Enlarge font in landscape mode'**
  String get enlargeNamesLandscapeDesc;

  /// No description provided for @showIqamaWithClock.
  ///
  /// In en, this message translates to:
  /// **'Show Iqama with Clock'**
  String get showIqamaWithClock;

  /// No description provided for @hideIqamaTimeDesc.
  ///
  /// In en, this message translates to:
  /// **'Hide Iqama column from screen'**
  String get hideIqamaTimeDesc;

  /// No description provided for @blackClockMode.
  ///
  /// In en, this message translates to:
  /// **'Black Screen with Center Clock'**
  String get blackClockMode;

  /// No description provided for @blackClockModeDesc.
  ///
  /// In en, this message translates to:
  /// **'Transform prayer screen to black background with center clock'**
  String get blackClockModeDesc;

  /// No description provided for @blackClockUseGlass.
  ///
  /// In en, this message translates to:
  /// **'Glass Background for Clock Screen'**
  String get blackClockUseGlass;

  /// No description provided for @blackClockUseGlassDesc.
  ///
  /// In en, this message translates to:
  /// **'When disabled, background becomes full black'**
  String get blackClockUseGlassDesc;

  /// No description provided for @customClockBg.
  ///
  /// In en, this message translates to:
  /// **'Custom Image for Clock Screen'**
  String get customClockBg;

  /// No description provided for @noCustomImage.
  ///
  /// In en, this message translates to:
  /// **'No custom image'**
  String get noCustomImage;

  /// No description provided for @customImageSet.
  ///
  /// In en, this message translates to:
  /// **'Custom image set'**
  String get customImageSet;

  /// No description provided for @removeClockBg.
  ///
  /// In en, this message translates to:
  /// **'Remove Clock Screen Image'**
  String get removeClockBg;

  /// No description provided for @returnToGlassOrBlack.
  ///
  /// In en, this message translates to:
  /// **'Return to glass or black background'**
  String get returnToGlassOrBlack;

  /// No description provided for @prayerListFontSizes.
  ///
  /// In en, this message translates to:
  /// **'Prayer List Font Sizes'**
  String get prayerListFontSizes;

  /// No description provided for @prayerNameFontSize.
  ///
  /// In en, this message translates to:
  /// **'Prayer Name Font Size'**
  String get prayerNameFontSize;

  /// No description provided for @adhanTimeFontSize.
  ///
  /// In en, this message translates to:
  /// **'Adhan Time Font Size'**
  String get adhanTimeFontSize;

  /// No description provided for @iqamaTimeFontSize.
  ///
  /// In en, this message translates to:
  /// **'Iqama Time Font Size'**
  String get iqamaTimeFontSize;

  /// No description provided for @countdown.
  ///
  /// In en, this message translates to:
  /// **'Countdown'**
  String get countdown;

  /// No description provided for @nextPrayerTimeDesc.
  ///
  /// In en, this message translates to:
  /// **'Next prayer time'**
  String get nextPrayerTimeDesc;

  /// No description provided for @enlargeCountdown.
  ///
  /// In en, this message translates to:
  /// **'Enlarge Countdown'**
  String get enlargeCountdown;

  /// No description provided for @largeCountdownLastMin.
  ///
  /// In en, this message translates to:
  /// **'Large countdown in last minute'**
  String get largeCountdownLastMin;

  /// No description provided for @opensSeparateBlackScreen.
  ///
  /// In en, this message translates to:
  /// **'Opens a separate black screen'**
  String get opensSeparateBlackScreen;

  /// No description provided for @enlargeNextPrayerCountdown.
  ///
  /// In en, this message translates to:
  /// **'Enlarge Next Prayer Countdown'**
  String get enlargeNextPrayerCountdown;

  /// No description provided for @largeCountdownNextPrayer.
  ///
  /// In en, this message translates to:
  /// **'Large countdown for following prayer'**
  String get largeCountdownNextPrayer;

  /// No description provided for @colorGreenLast90s.
  ///
  /// In en, this message translates to:
  /// **'Color Green in last 90s'**
  String get colorGreenLast90s;

  /// No description provided for @changeCountdownColorGreen.
  ///
  /// In en, this message translates to:
  /// **'Change countdown color to green'**
  String get changeCountdownColorGreen;

  /// No description provided for @showCountdown.
  ///
  /// In en, this message translates to:
  /// **'Show Countdown'**
  String get showCountdown;

  /// No description provided for @useArabicIndicDigits.
  ///
  /// In en, this message translates to:
  /// **'Arabic digits (1, 2, 3)'**
  String get useArabicIndicDigits;

  /// No description provided for @otherOptions.
  ///
  /// In en, this message translates to:
  /// **'Other Options'**
  String get otherOptions;

  /// No description provided for @useArabicIndicDigitsDesc.
  ///
  /// In en, this message translates to:
  /// **'Use Arabic-Indic digits'**
  String get useArabicIndicDigitsDesc;

  /// No description provided for @previewIqamaScreen.
  ///
  /// In en, this message translates to:
  /// **'Preview Iqama Screen'**
  String get previewIqamaScreen;

  /// No description provided for @previewAdhanScreen.
  ///
  /// In en, this message translates to:
  /// **'Preview Adhan Screen'**
  String get previewAdhanScreen;

  /// No description provided for @adhanIqamaScreens.
  ///
  /// In en, this message translates to:
  /// **'Adhan & Iqama Screens'**
  String get adhanIqamaScreens;

  /// No description provided for @showAdhanScreen.
  ///
  /// In en, this message translates to:
  /// **'Show Adhan Screen'**
  String get showAdhanScreen;

  /// No description provided for @showBeforeBlackScreen.
  ///
  /// In en, this message translates to:
  /// **'Show it before the black screen'**
  String get showBeforeBlackScreen;

  /// No description provided for @translucentScreens.
  ///
  /// In en, this message translates to:
  /// **'Glass/Translucent Screens'**
  String get translucentScreens;

  /// No description provided for @enableTranslucencyDesc.
  ///
  /// In en, this message translates to:
  /// **'Enable transparency for Adhan/Iqama screens'**
  String get enableTranslucencyDesc;

  /// No description provided for @shadingBehindTimes.
  ///
  /// In en, this message translates to:
  /// **'Shading behind prayer times'**
  String get shadingBehindTimes;

  /// No description provided for @shadingBehindTimesDesc.
  ///
  /// In en, this message translates to:
  /// **'Shadow behind times column'**
  String get shadingBehindTimesDesc;

  /// No description provided for @swapDateMosqueLandscape.
  ///
  /// In en, this message translates to:
  /// **'Swap Date and Mosque Position (Landscape)'**
  String get swapDateMosqueLandscape;

  /// No description provided for @internetStatusIndicator.
  ///
  /// In en, this message translates to:
  /// **'Internet Connection Indicator'**
  String get internetStatusIndicator;

  /// No description provided for @voiceAlerts.
  ///
  /// In en, this message translates to:
  /// **'Voice Alerts'**
  String get voiceAlerts;

  /// No description provided for @voiceAlertBeforeIqama.
  ///
  /// In en, this message translates to:
  /// **'Voice alert before Iqama'**
  String get voiceAlertBeforeIqama;

  /// No description provided for @voiceAlertBeforeIqamaDesc.
  ///
  /// In en, this message translates to:
  /// **'Voice message one minute before Iqama'**
  String get voiceAlertBeforeIqamaDesc;

  /// No description provided for @hadithBeforeText.
  ///
  /// In en, this message translates to:
  /// **'Text / Hadith before Iqama'**
  String get hadithBeforeText;

  /// No description provided for @hadithBeforeTextDesc.
  ///
  /// In en, this message translates to:
  /// **'Appears 33 seconds before Iqama'**
  String get hadithBeforeTextDesc;

  /// No description provided for @preAdhanAlarm.
  ///
  /// In en, this message translates to:
  /// **'Alarm before Adhan'**
  String get preAdhanAlarm;

  /// No description provided for @preAdhanAlarmDesc.
  ///
  /// In en, this message translates to:
  /// **'Alert sound one minute before Adhan'**
  String get preAdhanAlarmDesc;

  /// No description provided for @alertMessageText.
  ///
  /// In en, this message translates to:
  /// **'Alert message text'**
  String get alertMessageText;

  /// No description provided for @khushooProgram.
  ///
  /// In en, this message translates to:
  /// **'Khushoo Program'**
  String get khushooProgram;

  /// No description provided for @muteGlobalAudio.
  ///
  /// In en, this message translates to:
  /// **'Mute Global Audio'**
  String get muteGlobalAudio;

  /// No description provided for @muteGlobalAudioDesc.
  ///
  /// In en, this message translates to:
  /// **'Stop all sounds in the app'**
  String get muteGlobalAudioDesc;

  /// No description provided for @muteAdhanOnly.
  ///
  /// In en, this message translates to:
  /// **'Mute Adhan notifications only'**
  String get muteAdhanOnly;

  /// No description provided for @muteAdhanOnlyDesc.
  ///
  /// In en, this message translates to:
  /// **'Stop Adhan sound separately'**
  String get muteAdhanOnlyDesc;

  /// No description provided for @enableKhushooMode.
  ///
  /// In en, this message translates to:
  /// **'Enable Black Screen (After Adhan)'**
  String get enableKhushooMode;

  /// No description provided for @khushooModeDesc.
  ///
  /// In en, this message translates to:
  /// **'Block screen to avoid distraction'**
  String get khushooModeDesc;

  /// No description provided for @khushooDuration.
  ///
  /// In en, this message translates to:
  /// **'Black Screen Duration'**
  String get khushooDuration;

  /// No description provided for @unitMinuteFull.
  ///
  /// In en, this message translates to:
  /// **'minute'**
  String get unitMinuteFull;

  /// No description provided for @manualKhushooTrigger.
  ///
  /// In en, this message translates to:
  /// **'Manual Black Screen Trigger'**
  String get manualKhushooTrigger;

  /// No description provided for @manualKhushooTriggerDesc.
  ///
  /// In en, this message translates to:
  /// **'Test or immediately activate black screen'**
  String get manualKhushooTriggerDesc;

  /// No description provided for @dayNightAthkar.
  ///
  /// In en, this message translates to:
  /// **'Day & Night Athkar'**
  String get dayNightAthkar;

  /// No description provided for @sabahAthkar.
  ///
  /// In en, this message translates to:
  /// **'Sabah Athkar'**
  String get sabahAthkar;

  /// No description provided for @sabahAthkarDesc.
  ///
  /// In en, this message translates to:
  /// **'Play Sabah Athkar after Fajr prayer'**
  String get sabahAthkarDesc;

  /// No description provided for @masaaAthkar.
  ///
  /// In en, this message translates to:
  /// **'Masaa Athkar'**
  String get masaaAthkar;

  /// No description provided for @masaaAthkarDesc.
  ///
  /// In en, this message translates to:
  /// **'Play Masaa Athkar after Asr prayer'**
  String get masaaAthkarDesc;

  /// No description provided for @athkarOnlyScreen.
  ///
  /// In en, this message translates to:
  /// **'Athkar-Only Screen'**
  String get athkarOnlyScreen;

  /// No description provided for @athkarOnlyScreenDesc.
  ///
  /// In en, this message translates to:
  /// **'Display morning and evening athkar with continuous upward motion'**
  String get athkarOnlyScreenDesc;

  /// No description provided for @athkarScreenGlassBg.
  ///
  /// In en, this message translates to:
  /// **'Glass Background for Athkar Screen'**
  String get athkarScreenGlassBg;

  /// No description provided for @athkarScreenCustomBg.
  ///
  /// In en, this message translates to:
  /// **'Custom Image for Athkar Screen'**
  String get athkarScreenCustomBg;

  /// No description provided for @removeAthkarScreenBg.
  ///
  /// In en, this message translates to:
  /// **'Remove Athkar Screen Image'**
  String get removeAthkarScreenBg;

  /// No description provided for @afterPrayerAthkarAdvanced.
  ///
  /// In en, this message translates to:
  /// **'After Prayer Athkar (Advanced)'**
  String get afterPrayerAthkarAdvanced;

  /// No description provided for @afterPrayerAthkarAdvancedDesc.
  ///
  /// In en, this message translates to:
  /// **'Display mode, colors, and repetition'**
  String get afterPrayerAthkarAdvancedDesc;

  /// No description provided for @customAdhanSounds.
  ///
  /// In en, this message translates to:
  /// **'Custom Adhan Sounds'**
  String get customAdhanSounds;

  /// No description provided for @manageAdhanSounds.
  ///
  /// In en, this message translates to:
  /// **'Manage Adhan Sounds'**
  String get manageAdhanSounds;

  /// No description provided for @manageAdhanSoundsDesc.
  ///
  /// In en, this message translates to:
  /// **'Add, delete, and listen to Adhan sounds'**
  String get manageAdhanSoundsDesc;

  /// No description provided for @defaultAdhanSound.
  ///
  /// In en, this message translates to:
  /// **'Default Adhan sound for all prayers'**
  String get defaultAdhanSound;

  /// No description provided for @defaultSoundMp3.
  ///
  /// In en, this message translates to:
  /// **'Default Sound (MP3/Built-in)'**
  String get defaultSoundMp3;

  /// No description provided for @unknown.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get unknown;

  /// No description provided for @change.
  ///
  /// In en, this message translates to:
  /// **'Change'**
  String get change;

  /// No description provided for @chooseDefaultSound.
  ///
  /// In en, this message translates to:
  /// **'Choose Default Sound'**
  String get chooseDefaultSound;

  /// No description provided for @customizeSoundsPerPrayer.
  ///
  /// In en, this message translates to:
  /// **'Customize sounds for each prayer'**
  String get customizeSoundsPerPrayer;

  /// No description provided for @followsDefault.
  ///
  /// In en, this message translates to:
  /// **'Follows Default'**
  String get followsDefault;

  /// No description provided for @select.
  ///
  /// In en, this message translates to:
  /// **'Select'**
  String get select;

  /// No description provided for @adhanSoundFor.
  ///
  /// In en, this message translates to:
  /// **'Adhan sound for {name}'**
  String adhanSoundFor(Object name);

  /// No description provided for @adhanTypeSpeed.
  ///
  /// In en, this message translates to:
  /// **'Adhan Type & Speed'**
  String get adhanTypeSpeed;

  /// No description provided for @mp3AdhanSound.
  ///
  /// In en, this message translates to:
  /// **'MP3 Sound for Adhan'**
  String get mp3AdhanSound;

  /// No description provided for @useMp3PlayerDesc.
  ///
  /// In en, this message translates to:
  /// **'Use default MP3 player'**
  String get useMp3PlayerDesc;

  /// No description provided for @shortAdhan.
  ///
  /// In en, this message translates to:
  /// **'Short Adhan'**
  String get shortAdhan;

  /// No description provided for @shortAdhanDesc.
  ///
  /// In en, this message translates to:
  /// **'Use short Adhan sound (if custom is missing)'**
  String get shortAdhanDesc;

  /// No description provided for @shortIqama.
  ///
  /// In en, this message translates to:
  /// **'Short Iqama'**
  String get shortIqama;

  /// No description provided for @shortIqamaDesc.
  ///
  /// In en, this message translates to:
  /// **'Use short Iqama sound'**
  String get shortIqamaDesc;

  /// No description provided for @upToDate.
  ///
  /// In en, this message translates to:
  /// **'You are use the latest version'**
  String get upToDate;

  /// No description provided for @newUpdateAvailable.
  ///
  /// In en, this message translates to:
  /// **'New update available: {version}'**
  String newUpdateAvailable(Object version);

  /// No description provided for @selectAdhanSoundTitle.
  ///
  /// In en, this message translates to:
  /// **'Select Adhan Sound'**
  String get selectAdhanSoundTitle;

  /// No description provided for @silent.
  ///
  /// In en, this message translates to:
  /// **'Silent'**
  String get silent;

  /// No description provided for @defaultSound.
  ///
  /// In en, this message translates to:
  /// **'Default Sound'**
  String get defaultSound;

  /// No description provided for @prayerSoundSelectorTitle.
  ///
  /// In en, this message translates to:
  /// **'Adhan sound for {prayerName}'**
  String prayerSoundSelectorTitle(Object prayerName);

  /// No description provided for @verifyingLocation.
  ///
  /// In en, this message translates to:
  /// **'Verifying location...'**
  String get verifyingLocation;

  /// No description provided for @locationAddFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to add location'**
  String get locationAddFailed;

  /// No description provided for @manualTimeNotSet.
  ///
  /// In en, this message translates to:
  /// **'Not set'**
  String get manualTimeNotSet;

  /// No description provided for @straightenRowsHadith.
  ///
  /// In en, this message translates to:
  /// **'Straighten your rows, for straightening the rows is part of the perfection of prayer'**
  String get straightenRowsHadith;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'App Settings'**
  String get settingsTitle;

  /// No description provided for @changeFlag.
  ///
  /// In en, this message translates to:
  /// **'Change Flag'**
  String get changeFlag;

  /// No description provided for @mosqueImage.
  ///
  /// In en, this message translates to:
  /// **'Mosque Image'**
  String get mosqueImage;

  /// No description provided for @isUpToDate.
  ///
  /// In en, this message translates to:
  /// **'You are using the latest version'**
  String get isUpToDate;

  /// No description provided for @updateAvailable.
  ///
  /// In en, this message translates to:
  /// **'New update available: {version}'**
  String updateAvailable(Object version);

  /// No description provided for @appFullyUpdated.
  ///
  /// In en, this message translates to:
  /// **'Your app is fully updated (Version {version})'**
  String appFullyUpdated(Object version);

  /// No description provided for @clickToDownload.
  ///
  /// In en, this message translates to:
  /// **'Tap to download and see what\'s new in this version'**
  String get clickToDownload;

  /// No description provided for @locationTimeGroup.
  ///
  /// In en, this message translates to:
  /// **'Location & Time Settings'**
  String get locationTimeGroup;

  /// No description provided for @menuLocationSubtitle.
  ///
  /// In en, this message translates to:
  /// **'GPS, weather status and location update'**
  String get menuLocationSubtitle;

  /// No description provided for @menuPrayerAdjustSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manual adjustment, Friday and Eid prayer'**
  String get menuPrayerAdjustSubtitle;

  /// No description provided for @menuIdentitySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Colors, orientation, night vision'**
  String get menuIdentitySubtitle;

  /// No description provided for @menuThemesSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Change smart and manual backgrounds'**
  String get menuThemesSubtitle;

  /// No description provided for @menuModelsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manage prayer list and iqama'**
  String get menuModelsSubtitle;

  /// No description provided for @menuMessagesSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manage images and animated ads'**
  String get menuMessagesSubtitle;

  /// No description provided for @menuAdhanSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Adhan screen, shading, and staying'**
  String get menuAdhanSubtitle;

  /// No description provided for @menuAudioSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Sounds, Adhkar, and alerts'**
  String get menuAudioSubtitle;

  /// No description provided for @menuExcelSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Fetch prayer times from external file'**
  String get menuExcelSubtitle;

  /// No description provided for @menuMarqueeTitle.
  ///
  /// In en, this message translates to:
  /// **'News Ticker & Verses'**
  String get menuMarqueeTitle;

  /// No description provided for @menuMarqueeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Control moving ticker and priorities'**
  String get menuMarqueeSubtitle;

  /// No description provided for @menuRemoteTitle.
  ///
  /// In en, this message translates to:
  /// **'Remote Control Panel'**
  String get menuRemoteTitle;

  /// No description provided for @menuRemoteSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manage app from phone'**
  String get menuRemoteSubtitle;

  /// No description provided for @appFontsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Customize fonts for all interfaces'**
  String get appFontsSubtitle;

  /// No description provided for @menuAnnouncementsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manage Mosque Announcements'**
  String get menuAnnouncementsSubtitle;

  /// No description provided for @menuContactSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Contact Messages'**
  String get menuContactSubtitle;

  /// No description provided for @menuChangelogSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Track main operations and changes in the app'**
  String get menuChangelogSubtitle;

  /// No description provided for @menuLanguagesSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose interface language (Arabic / English)'**
  String get menuLanguagesSubtitle;

  /// No description provided for @menuUpdateTitle.
  ///
  /// In en, this message translates to:
  /// **'Update Application'**
  String get menuUpdateTitle;

  /// No description provided for @menuUpdateSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Check for a new update'**
  String get menuUpdateSubtitle;

  /// No description provided for @appVersion.
  ///
  /// In en, this message translates to:
  /// **'App Version: {version}'**
  String appVersion(Object version);

  /// No description provided for @developmentBy.
  ///
  /// In en, this message translates to:
  /// **'Developed by: {team}'**
  String developmentBy(Object team);

  /// No description provided for @editTitle.
  ///
  /// In en, this message translates to:
  /// **'Edit {title}'**
  String editTitle(Object title);

  /// No description provided for @enterTitle.
  ///
  /// In en, this message translates to:
  /// **'Enter {title}...'**
  String enterTitle(Object title);

  /// No description provided for @currentFont.
  ///
  /// In en, this message translates to:
  /// **'Current Font: {font}'**
  String currentFont(Object font);

  /// No description provided for @bismillah.
  ///
  /// In en, this message translates to:
  /// **'In the name of Allah, the Most Gracious, the Most Merciful'**
  String get bismillah;

  /// No description provided for @fontSettings.
  ///
  /// In en, this message translates to:
  /// **'App Font Settings'**
  String get fontSettings;

  /// No description provided for @fontChangeHint.
  ///
  /// In en, this message translates to:
  /// **'Tap \'Change\' to pick the appropriate font for each section'**
  String get fontChangeHint;

  /// No description provided for @chooseCountry.
  ///
  /// In en, this message translates to:
  /// **'Choose Country'**
  String get chooseCountry;

  /// No description provided for @addYourCountry.
  ///
  /// In en, this message translates to:
  /// **'Add Your Country'**
  String get addYourCountry;

  /// No description provided for @addCountryDesc.
  ///
  /// In en, this message translates to:
  /// **'Add a new country and city'**
  String get addCountryDesc;

  /// No description provided for @chooseCity.
  ///
  /// In en, this message translates to:
  /// **'Choose City'**
  String get chooseCity;

  /// No description provided for @excelDataExists.
  ///
  /// In en, this message translates to:
  /// **'Excel Data Exists'**
  String get excelDataExists;

  /// No description provided for @existingExcelFound.
  ///
  /// In en, this message translates to:
  /// **'Previous Excel data found for the new city. Do you want to enable it?'**
  String get existingExcelFound;

  /// No description provided for @useOriginalData.
  ///
  /// In en, this message translates to:
  /// **'No, use original data'**
  String get useOriginalData;

  /// No description provided for @yesEnableData.
  ///
  /// In en, this message translates to:
  /// **'Yes, enable data'**
  String get yesEnableData;

  /// No description provided for @applyExcelData.
  ///
  /// In en, this message translates to:
  /// **'Apply Excel Data'**
  String get applyExcelData;

  /// No description provided for @confirmApplyExcel.
  ///
  /// In en, this message translates to:
  /// **'Do you want to apply current Excel file data to the new location?'**
  String get confirmApplyExcel;

  /// No description provided for @yesApplyData.
  ///
  /// In en, this message translates to:
  /// **'Yes, apply data'**
  String get yesApplyData;

  /// No description provided for @importantNote.
  ///
  /// In en, this message translates to:
  /// **'Important Note'**
  String get importantNote;

  /// No description provided for @addLocationExcelRequirement.
  ///
  /// In en, this message translates to:
  /// **'Adding a new country and city requires an Excel file containing prayer times for this area.\n\nDo you want to continue adding the location now?'**
  String get addLocationExcelRequirement;

  /// No description provided for @yesContinue.
  ///
  /// In en, this message translates to:
  /// **'Yes, continue'**
  String get yesContinue;

  /// No description provided for @newCountryData.
  ///
  /// In en, this message translates to:
  /// **'New Country Data'**
  String get newCountryData;

  /// No description provided for @countryNameLabel.
  ///
  /// In en, this message translates to:
  /// **'Country Name (e.g., Yemen)'**
  String get countryNameLabel;

  /// No description provided for @countryCodeLabel.
  ///
  /// In en, this message translates to:
  /// **'Country Code (2 letters, e.g., YE)'**
  String get countryCodeLabel;

  /// No description provided for @errorIncompleteData.
  ///
  /// In en, this message translates to:
  /// **'Please complete the data correctly'**
  String get errorIncompleteData;

  /// No description provided for @next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get next;

  /// No description provided for @addCityHint.
  ///
  /// In en, this message translates to:
  /// **'It is recommended to add at least one city for this country now.'**
  String get addCityHint;

  /// No description provided for @cityNameLabel.
  ///
  /// In en, this message translates to:
  /// **'City Name (e.g., Taiz)'**
  String get cityNameLabel;

  /// No description provided for @errorEnterCityName.
  ///
  /// In en, this message translates to:
  /// **'Please enter city name'**
  String get errorEnterCityName;

  /// No description provided for @emeraldClassic.
  ///
  /// In en, this message translates to:
  /// **'Emerald (Classic)'**
  String get emeraldClassic;

  /// No description provided for @emeraldDesc.
  ///
  /// In en, this message translates to:
  /// **'Traditional luxury design'**
  String get emeraldDesc;

  /// No description provided for @pureGlassTheme.
  ///
  /// In en, this message translates to:
  /// **'Pure Glass'**
  String get pureGlassTheme;

  /// No description provided for @pureGlassDesc.
  ///
  /// In en, this message translates to:
  /// **'Modern & professional transparency'**
  String get pureGlassDesc;

  /// No description provided for @background1.
  ///
  /// In en, this message translates to:
  /// **'Background 1 (Main)'**
  String get background1;

  /// No description provided for @back.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get back;

  /// No description provided for @mandatoryUpdateAvailable.
  ///
  /// In en, this message translates to:
  /// **'Mandatory Update Available'**
  String get mandatoryUpdateAvailable;

  /// No description provided for @mandatoryUpdateDesc.
  ///
  /// In en, this message translates to:
  /// **'We apologize, but you must update the app to the latest version to continue and enjoy all features and security improvements.'**
  String get mandatoryUpdateDesc;

  /// No description provided for @updateNow.
  ///
  /// In en, this message translates to:
  /// **'Update App Now'**
  String get updateNow;

  /// No description provided for @updateLater.
  ///
  /// In en, this message translates to:
  /// **'Update Later'**
  String get updateLater;

  /// No description provided for @prayerFajr.
  ///
  /// In en, this message translates to:
  /// **'Fajr'**
  String get prayerFajr;

  /// No description provided for @prayerDhuhr.
  ///
  /// In en, this message translates to:
  /// **'Dhuhr'**
  String get prayerDhuhr;

  /// No description provided for @prayerAsr.
  ///
  /// In en, this message translates to:
  /// **'Asr'**
  String get prayerAsr;

  /// No description provided for @prayerMaghrib.
  ///
  /// In en, this message translates to:
  /// **'Maghrib'**
  String get prayerMaghrib;

  /// No description provided for @prayerIsha.
  ///
  /// In en, this message translates to:
  /// **'Isha'**
  String get prayerIsha;

  /// No description provided for @prayerJumuah.
  ///
  /// In en, this message translates to:
  /// **'Friday'**
  String get prayerJumuah;

  /// No description provided for @allahuAkbar.
  ///
  /// In en, this message translates to:
  /// **'Allahu Akbar  •  Allahu Akbar'**
  String get allahuAkbar;

  /// No description provided for @noItemsAvailable.
  ///
  /// In en, this message translates to:
  /// **'No items available at the moment'**
  String get noItemsAvailable;

  /// No description provided for @errorLoadingAzkar.
  ///
  /// In en, this message translates to:
  /// **'Error loading Adhkar'**
  String get errorLoadingAzkar;

  /// No description provided for @sabahAzkarTitle.
  ///
  /// In en, this message translates to:
  /// **'Morning Adhkar'**
  String get sabahAzkarTitle;

  /// No description provided for @masaaAzkarTitle.
  ///
  /// In en, this message translates to:
  /// **'Evening Adhkar'**
  String get masaaAzkarTitle;

  /// No description provided for @noAzkarAtThisTime.
  ///
  /// In en, this message translates to:
  /// **'No specific Adhkar at this time'**
  String get noAzkarAtThisTime;

  /// No description provided for @enableAzkarInSettings.
  ///
  /// In en, this message translates to:
  /// **'Please enable Morning or Evening Adhkar in settings'**
  String get enableAzkarInSettings;

  /// No description provided for @azkarOnlyScreenTitle.
  ///
  /// In en, this message translates to:
  /// **'Adhkar-Only Screen'**
  String get azkarOnlyScreenTitle;

  /// No description provided for @stopAzkarOnlyScreen.
  ///
  /// In en, this message translates to:
  /// **'Stop Adhkar-Only Screen'**
  String get stopAzkarOnlyScreen;

  /// No description provided for @remoteControlPanelTitle.
  ///
  /// In en, this message translates to:
  /// **'Remote Control Panel'**
  String get remoteControlPanelTitle;

  /// No description provided for @passwordTooShort.
  ///
  /// In en, this message translates to:
  /// **'Password too short (min 4 characters)'**
  String get passwordTooShort;

  /// No description provided for @urlCopied.
  ///
  /// In en, this message translates to:
  /// **'URL Copied'**
  String get urlCopied;

  /// No description provided for @errorLabel.
  ///
  /// In en, this message translates to:
  /// **'Error: {error}'**
  String errorLabel(Object error);

  /// No description provided for @serverRunning.
  ///
  /// In en, this message translates to:
  /// **'🟢 Running — {ip}:{port}'**
  String serverRunning(Object ip, Object port);

  /// No description provided for @serverStopped.
  ///
  /// In en, this message translates to:
  /// **'⚪ Stopped — Manage bar from phone'**
  String get serverStopped;

  /// No description provided for @stopServer.
  ///
  /// In en, this message translates to:
  /// **'Stop Server'**
  String get stopServer;

  /// No description provided for @adminUsername.
  ///
  /// In en, this message translates to:
  /// **'Admin Username'**
  String get adminUsername;

  /// No description provided for @adminPassword.
  ///
  /// In en, this message translates to:
  /// **'Control Panel Password'**
  String get adminPassword;

  /// No description provided for @saveUsernameAlways.
  ///
  /// In en, this message translates to:
  /// **'Always save username'**
  String get saveUsernameAlways;

  /// No description provided for @startServer.
  ///
  /// In en, this message translates to:
  /// **'Start Server'**
  String get startServer;

  /// No description provided for @serverSecurityInfo.
  ///
  /// In en, this message translates to:
  /// **'• Login is secure via authorization from this screen\n• Server only runs while app is open and on the same network'**
  String get serverSecurityInfo;

  /// No description provided for @ipAddressChanged.
  ///
  /// In en, this message translates to:
  /// **'IP Address Changed'**
  String get ipAddressChanged;

  /// No description provided for @newIpInfo.
  ///
  /// In en, this message translates to:
  /// **'New link: {url}\nPlease re-scan QR on connected devices.'**
  String newIpInfo(Object url);

  /// No description provided for @pairingCode.
  ///
  /// In en, this message translates to:
  /// **'Pairing Code'**
  String get pairingCode;

  /// No description provided for @remoteControlPermissionRequest.
  ///
  /// In en, this message translates to:
  /// **'Remote Control Permission Request'**
  String get remoteControlPermissionRequest;

  /// No description provided for @devicePermissionRequest.
  ///
  /// In en, this message translates to:
  /// **'Device \"{deviceName}\" is requesting screen control.'**
  String devicePermissionRequest(Object deviceName);

  /// No description provided for @deny.
  ///
  /// In en, this message translates to:
  /// **'Deny'**
  String get deny;

  /// No description provided for @allow.
  ///
  /// In en, this message translates to:
  /// **'Allow'**
  String get allow;

  /// No description provided for @hijri.
  ///
  /// In en, this message translates to:
  /// **'Hijri'**
  String get hijri;

  /// No description provided for @gregorian.
  ///
  /// In en, this message translates to:
  /// **'Gregorian'**
  String get gregorian;

  /// No description provided for @mosqueNameLabel.
  ///
  /// In en, this message translates to:
  /// **'Mosque Name'**
  String get mosqueNameLabel;

  /// No description provided for @fonts.
  ///
  /// In en, this message translates to:
  /// **'Fonts'**
  String get fonts;

  /// No description provided for @fontsCustomizationDesc.
  ///
  /// In en, this message translates to:
  /// **'Customize fonts for all app interfaces'**
  String get fontsCustomizationDesc;

  /// No description provided for @prayerNamesFont.
  ///
  /// In en, this message translates to:
  /// **'Prayer Names Font'**
  String get prayerNamesFont;

  /// No description provided for @adhanTimeFont.
  ///
  /// In en, this message translates to:
  /// **'Adhan Time Font'**
  String get adhanTimeFont;

  /// No description provided for @iqamaTimeFont.
  ///
  /// In en, this message translates to:
  /// **'Iqama Time Font'**
  String get iqamaTimeFont;

  /// No description provided for @dateHijriFont.
  ///
  /// In en, this message translates to:
  /// **'Date & Hijri Font'**
  String get dateHijriFont;

  /// No description provided for @noMessagesYet.
  ///
  /// In en, this message translates to:
  /// **'No messages yet'**
  String get noMessagesYet;

  /// No description provided for @addMessagesDesc.
  ///
  /// In en, this message translates to:
  /// **'Add advertising messages that will appear as a scrolling bar at the bottom of the screen'**
  String get addMessagesDesc;

  /// No description provided for @secondsShort.
  ///
  /// In en, this message translates to:
  /// **'{seconds}s'**
  String secondsShort(Object seconds);

  /// No description provided for @fontCairo.
  ///
  /// In en, this message translates to:
  /// **'Cairo'**
  String get fontCairo;

  /// No description provided for @fontAmiri.
  ///
  /// In en, this message translates to:
  /// **'Amiri'**
  String get fontAmiri;

  /// No description provided for @fontTajawal.
  ///
  /// In en, this message translates to:
  /// **'Tajawal'**
  String get fontTajawal;

  /// No description provided for @fontAlmarai.
  ///
  /// In en, this message translates to:
  /// **'Almarai'**
  String get fontAlmarai;

  /// No description provided for @fontChanga.
  ///
  /// In en, this message translates to:
  /// **'Changa'**
  String get fontChanga;

  /// No description provided for @fontRoboto.
  ///
  /// In en, this message translates to:
  /// **'Roboto'**
  String get fontRoboto;

  /// No description provided for @fontInter.
  ///
  /// In en, this message translates to:
  /// **'Inter'**
  String get fontInter;

  /// No description provided for @fontOutfit.
  ///
  /// In en, this message translates to:
  /// **'Outfit'**
  String get fontOutfit;

  /// No description provided for @errorPickingImage.
  ///
  /// In en, this message translates to:
  /// **'⚠️ Error picking image: {error}'**
  String errorPickingImage(Object error);

  /// No description provided for @previewSample.
  ///
  /// In en, this message translates to:
  /// **'In the name of Allah, the Most Gracious, the Most Merciful'**
  String get previewSample;

  /// No description provided for @menuGeneralReportsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'General Settings & Reports'**
  String get menuGeneralReportsSubtitle;

  /// No description provided for @menuAnnouncements.
  ///
  /// In en, this message translates to:
  /// **'Announcements'**
  String get menuAnnouncements;

  /// No description provided for @menuContact.
  ///
  /// In en, this message translates to:
  /// **'Contact Us'**
  String get menuContact;

  /// No description provided for @analogClockStyle.
  ///
  /// In en, this message translates to:
  /// **'Analog Clock Style'**
  String get analogClockStyle;

  /// No description provided for @iqamaScreenLabel.
  ///
  /// In en, this message translates to:
  /// **'Iqama Screen'**
  String get iqamaScreenLabel;

  /// No description provided for @adhanIqamaAlerts.
  ///
  /// In en, this message translates to:
  /// **'Adhan & Iqama Alerts'**
  String get adhanIqamaAlerts;

  /// No description provided for @alertBeforeAdhan.
  ///
  /// In en, this message translates to:
  /// **'Alert before Adhan'**
  String get alertBeforeAdhan;

  /// No description provided for @alertBeforeAdhanDesc.
  ///
  /// In en, this message translates to:
  /// **'Play an alert before Adhan time'**
  String get alertBeforeAdhanDesc;

  /// No description provided for @fajrFirstAdhan.
  ///
  /// In en, this message translates to:
  /// **'First Fajr Alert'**
  String get fajrFirstAdhan;

  /// No description provided for @fajrFirstAdhanDesc.
  ///
  /// In en, this message translates to:
  /// **'Enable additional alert before Fajr Adhan'**
  String get fajrFirstAdhanDesc;

  /// No description provided for @alertIqamaTime.
  ///
  /// In en, this message translates to:
  /// **'Iqama Time Alert'**
  String get alertIqamaTime;

  /// No description provided for @alertIqamaTimeDesc.
  ///
  /// In en, this message translates to:
  /// **'Play an alert at Iqama time'**
  String get alertIqamaTimeDesc;

  /// No description provided for @prayerDhikr.
  ///
  /// In en, this message translates to:
  /// **'Prayer Time Dhikr'**
  String get prayerDhikr;

  /// No description provided for @prayerDhikrDesc.
  ///
  /// In en, this message translates to:
  /// **'Show/Play Dhikr during prayer time'**
  String get prayerDhikrDesc;

  /// No description provided for @tasbihAfterAdhan.
  ///
  /// In en, this message translates to:
  /// **'Tasbeeh After Adhan'**
  String get tasbihAfterAdhan;

  /// No description provided for @tasbihAfterAdhanDesc.
  ///
  /// In en, this message translates to:
  /// **'Show Tasbeeh after Adhan'**
  String get tasbihAfterAdhanDesc;

  /// No description provided for @morningEveningAzkar.
  ///
  /// In en, this message translates to:
  /// **'Morning & Evening Adhkar'**
  String get morningEveningAzkar;

  /// No description provided for @morningAzkar.
  ///
  /// In en, this message translates to:
  /// **'Morning Adhkar'**
  String get morningAzkar;

  /// No description provided for @morningAzkarDesc.
  ///
  /// In en, this message translates to:
  /// **'Enable Morning Adhkar'**
  String get morningAzkarDesc;

  /// No description provided for @eveningAzkar.
  ///
  /// In en, this message translates to:
  /// **'Evening Adhkar'**
  String get eveningAzkar;

  /// No description provided for @eveningAzkarDesc.
  ///
  /// In en, this message translates to:
  /// **'Enable Evening Adhkar'**
  String get eveningAzkarDesc;

  /// No description provided for @azkarOnlyScreen.
  ///
  /// In en, this message translates to:
  /// **'Adhkar Only Screen'**
  String get azkarOnlyScreen;

  /// No description provided for @azkarOnlyScreenDesc.
  ///
  /// In en, this message translates to:
  /// **'Display Adhkar only screen'**
  String get azkarOnlyScreenDesc;

  /// No description provided for @azkarGlassBg.
  ///
  /// In en, this message translates to:
  /// **'Glass Background for Adhkar'**
  String get azkarGlassBg;

  /// No description provided for @azkarGlassBgDesc.
  ///
  /// In en, this message translates to:
  /// **'Use a glass background in the Adhkar screen'**
  String get azkarGlassBgDesc;

  /// No description provided for @customAzkarBg.
  ///
  /// In en, this message translates to:
  /// **'Custom Adhkar Background'**
  String get customAzkarBg;

  /// No description provided for @removeAzkarBg.
  ///
  /// In en, this message translates to:
  /// **'Remove Adhkar Background'**
  String get removeAzkarBg;

  /// No description provided for @postPrayerAzkarAdv.
  ///
  /// In en, this message translates to:
  /// **'Post-Prayer Adhkar (Advanced)'**
  String get postPrayerAzkarAdv;

  /// No description provided for @postPrayerAzkarAdvDesc.
  ///
  /// In en, this message translates to:
  /// **'Advanced options for post-prayer Adhkar'**
  String get postPrayerAzkarAdvDesc;

  /// No description provided for @defaultSoundName.
  ///
  /// In en, this message translates to:
  /// **'Default Sound'**
  String get defaultSoundName;

  /// No description provided for @customAdhanSoundsGroup.
  ///
  /// In en, this message translates to:
  /// **'Custom Adhan Sounds'**
  String get customAdhanSoundsGroup;

  /// No description provided for @selectDefaultSound.
  ///
  /// In en, this message translates to:
  /// **'Select Default Sound'**
  String get selectDefaultSound;

  /// No description provided for @customizePerPrayer.
  ///
  /// In en, this message translates to:
  /// **'Customize per prayer'**
  String get customizePerPrayer;

  /// No description provided for @adhanTypeSpeedGroup.
  ///
  /// In en, this message translates to:
  /// **'Adhan Type & Speed'**
  String get adhanTypeSpeedGroup;

  /// No description provided for @mp3Adhan.
  ///
  /// In en, this message translates to:
  /// **'MP3 Adhan'**
  String get mp3Adhan;

  /// No description provided for @mp3AdhanDesc.
  ///
  /// In en, this message translates to:
  /// **'Use an MP3 audio file for Adhan'**
  String get mp3AdhanDesc;

  /// No description provided for @builtInSound.
  ///
  /// In en, this message translates to:
  /// **'Built-in Sound'**
  String get builtInSound;

  /// No description provided for @azkarFont.
  ///
  /// In en, this message translates to:
  /// **'Adhkar Font'**
  String get azkarFont;

  /// No description provided for @clockFont.
  ///
  /// In en, this message translates to:
  /// **'Clock Font'**
  String get clockFont;

  /// No description provided for @prayerTimesFont.
  ///
  /// In en, this message translates to:
  /// **'Prayer Times Font'**
  String get prayerTimesFont;

  /// No description provided for @generalTextFont.
  ///
  /// In en, this message translates to:
  /// **'General Text Font'**
  String get generalTextFont;

  /// No description provided for @importantNotice.
  ///
  /// In en, this message translates to:
  /// **'Important Notice'**
  String get importantNotice;

  /// No description provided for @addNewLocationMandatoryExcelDesc.
  ///
  /// In en, this message translates to:
  /// **'Before adding a new location, make sure to import the correct prayer times file.'**
  String get addNewLocationMandatoryExcelDesc;

  /// No description provided for @countryNameHint.
  ///
  /// In en, this message translates to:
  /// **'Country Name'**
  String get countryNameHint;

  /// No description provided for @countryCodeHint.
  ///
  /// In en, this message translates to:
  /// **'Country Code'**
  String get countryCodeHint;

  /// No description provided for @pleaseCompleteDataCorrectly.
  ///
  /// In en, this message translates to:
  /// **'Please complete the data correctly'**
  String get pleaseCompleteDataCorrectly;

  /// No description provided for @pleaseEnterCityName.
  ///
  /// In en, this message translates to:
  /// **'Please enter the city name'**
  String get pleaseEnterCityName;

  /// No description provided for @themeEmeraldClassic.
  ///
  /// In en, this message translates to:
  /// **'Emerald Classic'**
  String get themeEmeraldClassic;

  /// No description provided for @themeEmeraldClassicDesc.
  ///
  /// In en, this message translates to:
  /// **'A comforting classic green theme'**
  String get themeEmeraldClassicDesc;

  /// No description provided for @themePureGlass.
  ///
  /// In en, this message translates to:
  /// **'Pure Glass'**
  String get themePureGlass;

  /// No description provided for @themePureGlassDesc.
  ///
  /// In en, this message translates to:
  /// **'A modern, transparent glass theme'**
  String get themePureGlassDesc;

  /// No description provided for @addNewLocation.
  ///
  /// In en, this message translates to:
  /// **'Add New Location'**
  String get addNewLocation;

  /// No description provided for @addNewLocationDesc.
  ///
  /// In en, this message translates to:
  /// **'Add a new country and city to prayer times data'**
  String get addNewLocationDesc;

  /// No description provided for @excelDataExistsDesc.
  ///
  /// In en, this message translates to:
  /// **'Previously imported data exists. Do you want to activate the new data?'**
  String get excelDataExistsDesc;

  /// No description provided for @noUseOriginal.
  ///
  /// In en, this message translates to:
  /// **'No, use current'**
  String get noUseOriginal;

  /// No description provided for @yesActivateData.
  ///
  /// In en, this message translates to:
  /// **'Yes, activate data'**
  String get yesActivateData;

  /// No description provided for @applyExcelDataDesc.
  ///
  /// In en, this message translates to:
  /// **'The file data will be applied to the selected city.'**
  String get applyExcelDataDesc;

  /// No description provided for @postPrayerAzkarTitle.
  ///
  /// In en, this message translates to:
  /// **'Adhkar After Prayer'**
  String get postPrayerAzkarTitle;

  /// No description provided for @generalSettingsLabel.
  ///
  /// In en, this message translates to:
  /// **'General Settings'**
  String get generalSettingsLabel;

  /// No description provided for @enablePostPrayerAzkarSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enable/disable Adhkar after prayer finishes'**
  String get enablePostPrayerAzkarSubtitle;

  /// No description provided for @repeatAzkarOnce.
  ///
  /// In en, this message translates to:
  /// **'Repeat Adhkar once after finishing'**
  String get repeatAzkarOnce;

  /// No description provided for @showOneAzkarImage5Min.
  ///
  /// In en, this message translates to:
  /// **'Show one image only for 5 minutes'**
  String get showOneAzkarImage5Min;

  /// No description provided for @showOneAzkarImage5MinSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Instead of auto-scrolling between Adhkar'**
  String get showOneAzkarImage5MinSubtitle;

  /// No description provided for @mainScreenAzkar.
  ///
  /// In en, this message translates to:
  /// **'Main Screen Adhkar'**
  String get mainScreenAzkar;

  /// No description provided for @enableSabahAzkarOnMain.
  ///
  /// In en, this message translates to:
  /// **'Enable Morning Adhkar'**
  String get enableSabahAzkarOnMain;

  /// No description provided for @appearsInMarquee.
  ///
  /// In en, this message translates to:
  /// **'Appears in the scrolling ticker'**
  String get appearsInMarquee;

  /// No description provided for @enableMasaaAzkarOnMain.
  ///
  /// In en, this message translates to:
  /// **'Enable Evening Adhkar'**
  String get enableMasaaAzkarOnMain;

  /// No description provided for @standaloneAzkarScreenSettings.
  ///
  /// In en, this message translates to:
  /// **'Standalone Adhkar Screen Settings'**
  String get standaloneAzkarScreenSettings;

  /// No description provided for @appearByDesignatedTime.
  ///
  /// In en, this message translates to:
  /// **'Appear based on designated time'**
  String get appearByDesignatedTime;

  /// No description provided for @automaticallyMorningEvening.
  ///
  /// In en, this message translates to:
  /// **'Automatically (morning for morning, evening for evening)'**
  String get automaticallyMorningEvening;

  /// No description provided for @specificAzkarForManualPlayback.
  ///
  /// In en, this message translates to:
  /// **'Specific Adhkar for manual playback'**
  String get specificAzkarForManualPlayback;

  /// No description provided for @whenAutoTimeOptionDisabled.
  ///
  /// In en, this message translates to:
  /// **'When auto-time option is disabled'**
  String get whenAutoTimeOptionDisabled;

  /// No description provided for @sabahAzkarOnly.
  ///
  /// In en, this message translates to:
  /// **'Morning Adhkar only'**
  String get sabahAzkarOnly;

  /// No description provided for @masaaAzkarOnly.
  ///
  /// In en, this message translates to:
  /// **'Evening Adhkar only'**
  String get masaaAzkarOnly;

  /// No description provided for @bothSabahAndMasaa.
  ///
  /// In en, this message translates to:
  /// **'Both (Morning & Evening)'**
  String get bothSabahAndMasaa;

  /// No description provided for @azkarTiming.
  ///
  /// In en, this message translates to:
  /// **'Adhkar Timing'**
  String get azkarTiming;

  /// No description provided for @sabahAzkarStartTime.
  ///
  /// In en, this message translates to:
  /// **'Morning Adhkar Start Time'**
  String get sabahAzkarStartTime;

  /// No description provided for @sabahAzkarEndTime.
  ///
  /// In en, this message translates to:
  /// **'Morning Adhkar End Time'**
  String get sabahAzkarEndTime;

  /// No description provided for @masaaAzkarStartTime.
  ///
  /// In en, this message translates to:
  /// **'Evening Adhkar Start Time'**
  String get masaaAzkarStartTime;

  /// No description provided for @masaaAzkarEndTime.
  ///
  /// In en, this message translates to:
  /// **'Evening Adhkar End Time'**
  String get masaaAzkarEndTime;

  /// No description provided for @azkarAfterEveryPrayer.
  ///
  /// In en, this message translates to:
  /// **'Adhkar After Every Prayer'**
  String get azkarAfterEveryPrayer;

  /// No description provided for @postPrayerAzkarHint.
  ///
  /// In en, this message translates to:
  /// **'Post-prayer Adhkar appear automatically on the full screen after Iqama time ends and before the black screen.'**
  String get postPrayerAzkarHint;

  /// No description provided for @selectTime.
  ///
  /// In en, this message translates to:
  /// **'Select Time'**
  String get selectTime;

  /// No description provided for @savedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Saved successfully'**
  String get savedSuccessfully;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return AppLocalizationsAr();
    case 'en':
      return AppLocalizationsEn();
  }

  throw FlutterError(
      'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
      'an issue with the localizations generation tool. Please file an issue '
      'on GitHub with a reproducible sample app and the gen-l10n configuration '
      'that was used.');
}
