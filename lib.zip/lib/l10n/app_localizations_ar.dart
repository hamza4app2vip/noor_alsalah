// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get dohaTime => 'دخول وقت الضحى';

  @override
  String get minutesToIqama => 'المتبقي للإقامة';

  @override
  String get minutesToDoha => 'المتبقي للضحى';

  @override
  String get azanCalling => 'أذان';

  @override
  String get azanName => 'الأذان';

  @override
  String get nextPrayTime => 'المتبقي ل';

  @override
  String get namesOfPrayings => 'الفجر,الشروق,الظهر,العصر,المغرب,العشاء';

  @override
  String get namesWeekDays =>
      'الأحد,الإثنين,الثلاثاء,الأربعاء,الخميس,الجمعة,السبت';

  @override
  String get menuMonthsHijri =>
      'محرم,صفر,ربيع الأول,ربيع الآخر,جمادى الأولى,جمادى الآخرة,رجب,شعبان,رمضان,شوال,ذو القعدة,ذو الحجة';

  @override
  String get menuFullScreen => 'توسيع الشاشه';

  @override
  String get menuMosqueName => 'تحرير إسم المسجد';

  @override
  String get menuMosqueMessage => 'تحرير إعلانات المسجد';

  @override
  String get menuLocation => 'موقع المسجد';

  @override
  String get menuHijriClick => 'ضبط التاريخ الهجري';

  @override
  String get menuThemes => 'تغيير خلفية الشاشة';

  @override
  String get menuOptions => 'خيارات';

  @override
  String get menuAzkar => 'عرض الأذكار';

  @override
  String get menuSliders => 'عرض الشرائح';

  @override
  String get menuAdjustments => 'ضبط أوقات الأذان والإقامة';

  @override
  String get menuBlackscreen => 'ضبط إخفاء الشاشة';

  @override
  String get menuRestartApp => 'إعادة تحميل التطبيق';

  @override
  String get option9 => ' عن البرنامج ...';

  @override
  String get fastingMonday => 'تذكير بسنة صيام غدا الإثنين';

  @override
  String get fastingThursday => 'تذكير بسنة صيام غدا الخميس';

  @override
  String get option0 => 'تفعيل عرض 24 ساعة';

  @override
  String get option1 => 'تفعيل عرض الساعة الكاملة';

  @override
  String get option2 => 'تخفيت الصلوات الماضية';

  @override
  String get adjust1 => 'تكبير العد التنازلي على الشاشة';

  @override
  String get adjust2 => ' (MP3) استخدم الصوت للأذان ';

  @override
  String get adjust3 => 'إضافة 30 دقيقة لصلاة العشاء في رمضان';

  @override
  String get prayer => 'الصلاة';

  @override
  String get iqama => 'الإقامة';

  @override
  String get doha => 'الضحى';

  @override
  String get dimmer0 => 'تفعيل إخفاء الشاشة أثناء الصلاة';

  @override
  String get dimmer1 => 'إخفاء الشاشة بعد 30 دقيقة من الشروق';

  @override
  String get dimmer2 => 'إخفاء الشاشة بعد 60 دقيقة من العشاء';

  @override
  String get dimmer3 => 'إخفاء الشاشة بعد أذان الجمعة';

  @override
  String get dimmer4 => 'إظهار الشاشة بعد أذان الجمعة';

  @override
  String get dimmer5 => 'مدة الصلاة لإخفاء الشاشة';

  @override
  String get azkar4 => 'عرض صورة واحدة فقط لمدة 5 دقائق ثابتة';

  @override
  String get times2 => 'اختر بلد و مدينة المسجد';

  @override
  String get times3 => 'لتعديل أو إضافة أوقات الصلاة السنوية';

  @override
  String get times4 =>
      '1- تصدير الإعدادات.<br>2- تعديل بيانات أوقات السنة.<br>3- استيراد الإعدادات في التطبيق';

  @override
  String get box0 => 'اضغط على التاريخ الهجري لتعديله ±3 أيام';

  @override
  String get misc0 => 'أعد تحميل الصفحة بعد التعديلات';

  @override
  String get misc1 => 'انقر فوق إسم أوساعة الفجر لتغيير الخلفيات';

  @override
  String get noSell => 'تطبيق مجاني، ممنوع بيعه';

  @override
  String get jomoa => 'الجمعة';

  @override
  String get iqamaAsHour => 'عرض الإقامة مع الساعة';

  @override
  String get summertime => 'إضافة ساعة واحدة لأوقات الصلاة في الصيف';

  @override
  String get useArabicDigits =>
      'تفعيل الأرقام العربية (أو أرقام اللغة المستعملة)';

  @override
  String get wcsvMessage =>
      'تفعيل ملف أوقات الصلاة والإقامة.<br>قم بتعديل الملف (wcsv.js) في مجلد التطبيق (JAMAAT TIMES).';

  @override
  String get eCountdownOnOff => 'إظهار العد التنازلي';

  @override
  String get n1MoreHour => 'إضافة ساعة واحدة يدويًا لجميع الأوقات';

  @override
  String get n1LessHour => 'إزالة ساعة واحدة يدويًا من جميع الأوقات';

  @override
  String get eShortAzan => 'استخدام صوت أذان قصير';

  @override
  String get eShortIqama => 'استخدام صوت إقامة قصير';

  @override
  String get meteo => 'تفعيل حالة الطقس';

  @override
  String get appFonts => 'ضبط خطوط التطبيق';

  @override
  String get forcedVertical => 'العرض العمودي';

  @override
  String get scrollableMsg => 'تفعيل شريط النص المتحرك';

  @override
  String get hideIqamat => 'ساعة المنزل - إخفاء أوقات الإقامة';

  @override
  String get zerosAmPm => 'إضافة صفر للأوقات AM/PM (04:35 AM)';

  @override
  String get meteoPryrs => 'تفعيل حالة الطقس بجانب أوقات الصلاة';

  @override
  String get meteoA => 'حالة الطقس';

  @override
  String get time2Shrq => 'المتبقي للشروق';

  @override
  String get wqtShrq => 'الشروق';

  @override
  String get n5BoxesOnly => 'تكبير أوقات الصلاة والإقامة في العرض الأفقي';

  @override
  String get iqamatSalat => 'إقامة الصلاة';

  @override
  String get jomoaOnOff => 'الجمعة: وقت بداية الخطبة';

  @override
  String get adminmsgs0 => 'إعلانات المسجد أسفل الشاشة';

  @override
  String get adminmsgsTexter =>
      'هنا يمكن إضافة رسائل على شريط متحرك للعرض أسفل الشاشة';

  @override
  String get adminmsgsHelp =>
      'معلومة: انقر نقرًا مزدوجًا على الرسالة للتحرير.<br>انقر نقرًا مزدوجًا على (DAILY) لتغيير يوم أو تاريخ الرسالة';

  @override
  String get addMsg => 'إضافة رسالة';

  @override
  String get dohrXminAsr => 'الظهر = العصر - x دقيقة (انقر للتغيير): ';

  @override
  String get jomoaInlogo => 'وقت الجمعة مكان الشعار في العرض الأفقي';

  @override
  String get azkar0 => 'تفعيل الأذكار بعد الصلاة المفروضة';

  @override
  String get sliders0 => 'تفعيل الشرائح';

  @override
  String get jomoaShow => 'إظهار الجمعة على الشاشة الأفقية';

  @override
  String get vrMiddleNames => 'وضع أسماء الصلوات في المنتصف (في العرض العمودي)';

  @override
  String get middleSalats => 'وضع أسماء الصلوات في المنتصف (في العرض الأفقي)';

  @override
  String get azkarSabah => 'تفعيل أذكار الصباح بعد صلاة الفجر';

  @override
  String get azkarAsr => 'تفعيل أذكار المساء بعد صلاة العصر';

  @override
  String get azkarMagrib => 'تفعيل أذكار المساء بعد صلاة المغرب';

  @override
  String get azkarIsha => 'تفعيل أذكار المساء بعد صلاة العشاء';

  @override
  String get n1MinCounter => 'تكبير العداد على شاشة سوداء عند آخر دقيقة';

  @override
  String get iqamaScreen => 'عرض شاشة الإقامة قبل الشاشة السوداء';

  @override
  String get hrDateRight =>
      'التاريخ على اليمين واسم المسجد على اليسار في العرض الأفقي';

  @override
  String get verifNet => 'تحقق من اتصال الإنترنت (نجمة أسفل الشاشة)';

  @override
  String get timesBgShadows => 'تظليل خلف أوقات الصلاة';

  @override
  String get mobileAlert =>
      'رسالة تنبيه صوتية عند آخر دقيقة قبل الإقامة (انقر لتغيير الرسالة)';

  @override
  String get shortCuts => 'اختصارات على الشاشة';

  @override
  String get shortCutsText => 'نقرات مختصرة مباشرة على الشاشة للخيارات';

  @override
  String get clockInBlkScr => 'عرض الساعة على الشاشة السوداء';

  @override
  String get dateInBlkScr => 'عرض التاريخ على الشاشة السوداء';

  @override
  String get semiTransparent => 'شاشات شبه شفافة لنوافذ الأذان والإقامة والضحى';

  @override
  String get iqamaHadith => 'إظهار حديث الرسول ﷺ قبل الإقامة بـ ٣٣ ثانية';

  @override
  String get primaryAzan =>
      'تعديل وقت الأذان الأول | x دقيقة قبل الأذان الفعلي للفجر. تنبيه صوتي. انقر للتغيير:';

  @override
  String get counterColorAlert => 'تغيير لون العداد إلى الأحمر في آخر 90 ثانية';

  @override
  String get showAzanScreen => 'إظهار شاشة الأذان';

  @override
  String get biggerNextPray => 'تكبير عداد الوقت المتبقي للصلاة القادمة';

  @override
  String get themesNoChange => 'تغيير الخلفية يدويًا';

  @override
  String get themesEverySalat => 'تغيير الخلفية عند كل صلاة';

  @override
  String get themesEveryDay => 'تغيير الخلفية يوميًا';

  @override
  String get themesRandomDaily =>
      'تغيير الخلفية يوميًا بشكل عشوائي من هذه القائمة:';

  @override
  String get randomSlides => 'عرض الشرائح بشكل عشوائي';

  @override
  String get eidFitrTime => 'إظهار وقت صلاة عيد الفطر:';

  @override
  String get eidAdhaTime => 'إظهار وقت صلاة عيد الأضحى:';

  @override
  String get salatEidFitr => 'صلاة عيد الفطر';

  @override
  String get salatEidAdha => 'صلاة عيد الأضحى';

  @override
  String get jomoaAzanOnOff => 'تفعيل صوت أذان الجمعة';

  @override
  String get fixedTimeForIqamat => 'الوقت الثابت لإقامة الصلاة:';

  @override
  String get fixedTimeForJomoa => 'الوقت الثابت لأذان الجمعة';

  @override
  String get slidesViewTime => 'مدة عرض كل شريحة';

  @override
  String get tawkitViewTime => 'وقت عرض الشاشة الرئيسية';

  @override
  String get slidesScreenMaxMin =>
      'مدة العرض: 60 ثانية كحد أقصى، 10 ثوانٍ كحد أدنى';

  @override
  String get menuSynchronize => 'تصدير واستيراد الإعدادات';

  @override
  String get dlSettingsFile => 'على حاسوبك، استخدم هذا الرابط لتنزيل إعداداتك';

  @override
  String get enterImportId => '(Import ID) - أدخل رقم الاستيراد';

  @override
  String get useImportedTimes => 'استخدم أوقات الصلاة من الملف المستورد';

  @override
  String get clockAdjust => 'ضبط الساعة الرئيسية، إضافة أو حذف ساعات';

  @override
  String get azkarBgWhite => 'استخدام خلفية بيضاء';

  @override
  String get selectAyatsLang => ' اختيار اللغة للآيات القرآنية على الشاشة';

  @override
  String get persoFiles => 'إدارة الملفات الشخصية';

  @override
  String get persoFilesMessage => 'خصص التطبيق بصور شخصية للخلفية والأذكار.';

  @override
  String get slowDeviceAlert =>
      ' (هذا الخيار قد يسبب بطء على الأجهزة الضعيفة.) ';

  @override
  String get enablePersoFiles => 'تفعيل الملفات الشخصية';

  @override
  String get showNightPrayers =>
      'إظهار أوقات صلوات الليل : منتصف الليل، ثلث الليل، الفجر';

  @override
  String get soundAlertsReminders => 'تنبيهات صوتية';

  @override
  String get ramadanDaysLeftInfo =>
      'إدماج المتبقي لرمضان مع الرسائل . (شهرين قبل رمضان)';

  @override
  String get ramadanLeftDays => 'المتبقي لشهر رمضان :';

  @override
  String get changelog => 'سجل التغييرات';

  @override
  String get languages => 'اللغات';

  @override
  String get selectLanguage => 'اختر اللغة';

  @override
  String get arabic => 'العربية';

  @override
  String get english => 'الإنجليزية';

  @override
  String get save => 'حفظ';

  @override
  String get cancel => 'إلغاء';

  @override
  String get preview => 'معاينة';

  @override
  String get fajr => 'الفجر';

  @override
  String get sunrise => 'الشروق';

  @override
  String get dhuhr => 'الظهر';

  @override
  String get asr => 'العصر';

  @override
  String get maghrib => 'المغرب';

  @override
  String get isha => 'العشاء';

  @override
  String get midnight => 'منتصف الليل';

  @override
  String get lastThird => 'الثلث الأخير';

  @override
  String get stopBlackClockWithHour => 'إيقاف الشاشة السوداء مع الساعة';

  @override
  String get exitKhushooMode => 'خروج من وضع الخشوع';

  @override
  String get hour => 'ساعة';

  @override
  String get minute => 'دقيقة';

  @override
  String get second => 'ثانية';

  @override
  String get and => 'و';

  @override
  String get adhanTimeHasCome => 'حـان الآن مـوعـد أذان';

  @override
  String prayerNameWithPrefix(Object name) {
    return 'صلاة $name';
  }

  @override
  String get internetConnected => 'متصل بالإنترنت';

  @override
  String get iqamaTimeHasCome => 'حـان الآن مـوعـد إقامة';

  @override
  String get minutesUntilIqama => 'دقيقة على إقامة الصلاة';

  @override
  String get seconds => 'ثواني';

  @override
  String currentFontLabel(Object font) {
    return 'الخط الحالي: $font';
  }

  @override
  String chooseFontFor(Object label) {
    return 'اختر $label';
  }

  @override
  String get changeFontHint => 'اضغط على «تغيير» لاختيار الخط المناسب لكل قسم';

  @override
  String get addFirstCity => 'إضافة المدينة الأولى';

  @override
  String get addFirstCityDesc =>
      'يفضل إضافة مدينة واحدة على الأقل لهذه الدولة الآن.';

  @override
  String get cityNameHint => 'اسم المدينة (مثلاً: تعز)';

  @override
  String get addAndSave => 'إضافة وحفظ';

  @override
  String get settingsLocationTime => 'إعدادات الموقع والتوقيت';

  @override
  String get settingsAppearanceSlides => 'المظهر والشرائح';

  @override
  String get settingsAdhanFiles => 'الأذان والملفات المخصصة';

  @override
  String get settingsAdvanced => 'الإضافات المتقدمة';

  @override
  String get menuGeneralReports => 'عامة وتقارير';

  @override
  String get menuLocationWeather => 'الموقع والطقس';

  @override
  String get menuPrayerAdjustments => 'تخصيص الأوقات والجمعة';

  @override
  String get menuIdentityLayout => 'الهوية والتنسيق';

  @override
  String get menuThemesBackgrounds => 'خلفيات الشاشة';

  @override
  String get menuModelsLayout => 'النماذج والتخطيط';

  @override
  String get menuMessagesSlides => 'الرسائل والشرائح (Slides)';

  @override
  String get menuAdhanAlerts => 'تنبيهات الأذان والإقامة';

  @override
  String get menuAudioAlarms => 'الصوتيات والمنبهات';

  @override
  String get menuExcelImport => 'استيراد من Excel';

  @override
  String get general => 'عامة';

  @override
  String get location => 'الموقع';

  @override
  String get display => 'العرض';

  @override
  String get prayers => 'الصلوات';

  @override
  String get adhanIqama => 'الأذان والإقامة';

  @override
  String get alerts => 'التنبيهات';

  @override
  String get audio => 'الصوت';

  @override
  String get helpAndRestore => 'مساعدة واستعادة';

  @override
  String get mosqueName => 'اسم المسجد';

  @override
  String get mosqueIcon => 'أيقونة المسجد';

  @override
  String get chooseFromGallery => 'اختر صورة من المعرض';

  @override
  String get mainClockOffset => 'إزاحة الساعة الرئيسية';

  @override
  String get unitMinute => 'دق';

  @override
  String get showHijriDate => 'إظهار التاريخ الهجري';

  @override
  String get appTimeCustomization => 'تخصيص وقت التطبيق';

  @override
  String get manualTimeEntry => 'إدخال الوقت يدوياً';

  @override
  String get manualTimeAdjustment => 'ضبط الوقت اليدوي';

  @override
  String get notSet => 'لم يتم التحديد';

  @override
  String get weatherLocationSettings => 'إعدادات الموقع والطقس';

  @override
  String get gpsWeatherStatus => 'GPS وحالة الطقس';

  @override
  String countryWithName(Object name) {
    return 'الدولة: $name';
  }

  @override
  String get tapToChangeCountry => 'اضغط لتغيير الدولة';

  @override
  String cityWithName(Object name) {
    return 'المدينة: $name';
  }

  @override
  String get tapToChangeCity => 'اضغط لتغيير المدينة';

  @override
  String get factoryReset => 'إعادة ضبط المصنع';

  @override
  String get resetSettingsToDefault => 'تصفير جميع الإعدادات للوضع الافتراضي';

  @override
  String get confirmFactoryReset1 =>
      'هل تريد حذف الإعدادات حقاً؟ سيتم إعادة تعيين جميع الإعدادات لافتراضياتها الأولى.';

  @override
  String get confirmFactoryReset2 =>
      'هل أنت متأكد من حذف الإعدادات بالكامل؟ لا يمكن التراجع عن هذه الخطوة.';

  @override
  String get yesSure => 'نعم، متأكد';

  @override
  String get settingsResetSuccess => 'تم إعادة تعيين الإعدادات للوضع الافتراضي';

  @override
  String get appTheme => 'سمة التطبيق';

  @override
  String get prayerScreenTheme => 'ثيم شاشة المواقيت';

  @override
  String get visualIdentity => 'الهوية البصرية';

  @override
  String get countryFlag => 'علم الدولة';

  @override
  String get showCountryFlagDesc => 'إظهار علم الدولة في الشاشة';

  @override
  String get format24h => 'صيغة 24 ساعة';

  @override
  String get format24hDesc => 'عرض الوقت بتنسيق ٢٤ ساعة';

  @override
  String get padWithZero => 'إضافة صفر للأوقات';

  @override
  String get padWithZeroDesc => 'مثال: 04:35 بدلاً من 4:35';

  @override
  String get fullClock => 'الساعة الكاملة';

  @override
  String get fullClockDesc => 'عرض الثواني (00:00:00)';

  @override
  String get analogClock => 'الساعة التناظرية';

  @override
  String get analogClockDesc =>
      'إظهار ساعة زجاجية تناظرية في جميع الثيمات بالوضع الأفقي';

  @override
  String get classicGlass => 'زجاجي كلاسيك';

  @override
  String get luxuryGold => 'ذهبي فاخر';

  @override
  String get royalIslamic => 'إسلامي ملكي';

  @override
  String get analogClockDateFrame => 'إطار التاريخ التناظري';

  @override
  String get analogClockDateFrameDesc =>
      'إظهار إطار التاريخ واليوم بجانب/أسفل الساعة';

  @override
  String get analogClockNumbers => 'أرقام الساعة التناظرية';

  @override
  String get analogClockNumbersDesc =>
      'إظهار الأرقام على جميع الساعات التناظرية';

  @override
  String get glassShine => 'البريق الزجاجي';

  @override
  String get glassShineDesc =>
      'تشغيل/إيقاف لمعة الزجاج في الساعة والإطارات والرسائل العائمة';

  @override
  String get nightPrayerTimes => 'أوقات صلوات الليل';

  @override
  String get nightPrayerTimesDesc => 'منتصف الليل وثلث الليل';

  @override
  String get marqueeTicker => 'شريط الآيات والأذكار';

  @override
  String get marqueeTickerDesc => 'الشريط المتحرك أسفل الشاشة';

  @override
  String get navbarPositionLandscape => 'موضع شريط العناوين (الأفقي)';

  @override
  String get fullScreenWidth => 'ممتد بعرض الشاشة';

  @override
  String get centered => 'في المنتصف';

  @override
  String get sideMode => 'على الجانب';

  @override
  String get pureGlassCustomization => 'تخصيص ثيم الزجاج (Pure Glass)';

  @override
  String get fontColor => 'لون الخط (النصوص)';

  @override
  String get fontColorDesc => 'تغيير لون جميع النصوص في الثيم';

  @override
  String get chooseFontColor => 'اختر لون الخط';

  @override
  String get bgColor1 => 'لون الخلفية 1 (الرئيسي)';

  @override
  String get bgColor2 => 'لون الخلفية 2';

  @override
  String get bgColor3 => 'لون الخلفية 3';

  @override
  String get bgColor1Desc => 'تغيير لون الدائرة العلوية واللمسات';

  @override
  String get bgColor2Desc => 'تغيير لون الدائرة السفلية';

  @override
  String get bgColor3Desc => 'تغيير لون الدائرة الجانبية';

  @override
  String get screenOrientation => 'توجيه الشاشة';

  @override
  String get auto => 'تلقائي';

  @override
  String get portrait => 'عمودي';

  @override
  String get landscape => 'أفقي';

  @override
  String get announcementsSlides => 'الإعلانات والشرائح';

  @override
  String get changeWallpaper => 'تغيير خلفية الشاشة';

  @override
  String get changeWallpaperDesc => 'تخصيص الخلفيات لكل صلاة';

  @override
  String get advertisingSlides => 'الشرائح الإعلانية';

  @override
  String get manageSlidesDesc => 'إدارة الصور والنصوص كشرائح';

  @override
  String get newsTickerVerses => 'الشريط الإخباري والآيات';

  @override
  String get displayOptions => 'خيارات العرض';

  @override
  String get dimPastPrayersDesc => 'تعتيم الصلوات التي مضت';

  @override
  String get centerNamesLandscape => 'توسيط أسماء الصلوات (أفقي)';

  @override
  String get centerNamesLandscapeDesc => 'تمركز الأسماء في وضع الشاشة الأفقي';

  @override
  String get centerNamesPortrait => 'توسيط أسماء الصلوات (عمودي)';

  @override
  String get centerNamesPortraitDesc => 'تمركز في وضع الشاشة العمودي';

  @override
  String get centerPrayerNameMixed =>
      'توسيط اسم الصلاة (أذان يمين، إقامة يسار)';

  @override
  String get classicThemeOnly => 'خاص بالثيم الكلاسيكي';

  @override
  String get enlargeNamesLandscape => 'تكبير أوقات الصلاة (أفقي)';

  @override
  String get enlargeNamesLandscapeDesc => 'تكبير الخط في الوضع الأفقي';

  @override
  String get showIqamaWithClock => 'عرض الإقامة مع الساعة';

  @override
  String get hideIqamaTimeDesc => 'إخفاء عمود الإقامة من الشاشة';

  @override
  String get blackClockMode => 'شاشة سوداء مع ساعة الوسط';

  @override
  String get blackClockModeDesc =>
      'تحويل شاشة المواقيت إلى خلفية سوداء مع ساعة في المنتصف';

  @override
  String get blackClockUseGlass => 'خلفية زجاجية لشاشة الساعة';

  @override
  String get blackClockUseGlassDesc => 'عند الإيقاف تصبح خلفية سوداء كاملة';

  @override
  String get customClockBg => 'صورة مخصصة لشاشة الساعة';

  @override
  String get noCustomImage => 'لا توجد صورة مخصصة';

  @override
  String get customImageSet => 'تم تعيين صورة مخصصة';

  @override
  String get removeClockBg => 'إزالة صورة شاشة الساعة';

  @override
  String get returnToGlassOrBlack => 'العودة للخلفية الزجاجية أو السوداء';

  @override
  String get prayerListFontSizes => 'أحجام خطوط قائمة الصلوات';

  @override
  String get prayerNameFontSize => 'حجم خط اسم الصلاة';

  @override
  String get adhanTimeFontSize => 'حجم خط وقت الأذان';

  @override
  String get iqamaTimeFontSize => 'حجم خط وقت الإقامة';

  @override
  String get countdown => 'العد التنازلي';

  @override
  String get nextPrayerTimeDesc => 'وقت الصلاة القادمة';

  @override
  String get enlargeCountdown => 'تكبير العداد التنازلي';

  @override
  String get largeCountdownLastMin => 'عداد كبير عند آخر دقيقة';

  @override
  String get opensSeparateBlackScreen => 'يفتح شاشة سوداء منفصلة';

  @override
  String get enlargeNextPrayerCountdown => 'تكبير عداد الصلاة القادمة';

  @override
  String get largeCountdownNextPrayer => 'عداد كبير للصلاة التالية';

  @override
  String get colorGreenLast90s => 'تلوين أخضر آخر 90 ثانية';

  @override
  String get changeCountdownColorGreen => 'تغيير لون العداد للأخضر';

  @override
  String get showCountdown => 'إظهار العد التنازلي';

  @override
  String get useArabicIndicDigits => 'الأرقام العربية (١، ٢، ٣)';

  @override
  String get otherOptions => 'خيارات أخرى';

  @override
  String get useArabicIndicDigitsDesc => 'Use Arabic-Indic digits';

  @override
  String get previewIqamaScreen => 'معاينة شاشة الإقامة';

  @override
  String get previewAdhanScreen => 'معاينة شاشة الأذان';

  @override
  String get adhanIqamaScreens => 'شاشات الأذان والإقامة';

  @override
  String get showAdhanScreen => 'إظهار شاشة الأذان';

  @override
  String get showBeforeBlackScreen => 'عرضها قبل الشاشة السوداء';

  @override
  String get translucentScreens => 'شاشات زجاجية/شبه شفافة';

  @override
  String get enableTranslucencyDesc => 'تفعيل الشفافية لشاشات الأذان/الإقامة';

  @override
  String get shadingBehindTimes => 'تظليل خلف أوقات الصلاة';

  @override
  String get shadingBehindTimesDesc => 'ظل خلف عمود الأوقات';

  @override
  String get swapDateMosqueLandscape => 'تبديل موضع التاريخ والمسجد (أفقي)';

  @override
  String get internetStatusIndicator => 'مؤشر اتصال الإنترنت';

  @override
  String get voiceAlerts => 'التنبيهات الصوتية';

  @override
  String get voiceAlertBeforeIqama => 'تنبيه صوتي قبل الإقامة';

  @override
  String get voiceAlertBeforeIqamaDesc => 'رسالة صوتية قبل الإقامة بدقيقة';

  @override
  String get hadithBeforeText => 'نص / حديث قبل الإقامة';

  @override
  String get hadithBeforeTextDesc => 'يظهر قبل 33 ثانية من الإقامة';

  @override
  String get preAdhanAlarm => 'منبه قبل الأذان';

  @override
  String get preAdhanAlarmDesc => 'صوت تنبيه قبل دقيقة من الأذان';

  @override
  String get alertMessageText => 'نص رسالة التنبيه';

  @override
  String get khushooProgram => 'برنامج الخشوع';

  @override
  String get muteGlobalAudio => 'كتم الصوت العام';

  @override
  String get muteGlobalAudioDesc => 'إيقاف جميع الأصوات في التطبيق';

  @override
  String get muteAdhanOnly => 'كتم إشعارات الأذان فقط';

  @override
  String get muteAdhanOnlyDesc => 'إيقاف صوت الأذان بشكل منفصل';

  @override
  String get enableKhushooMode => 'تفعيل الشاشة السوداء (بعد الأذان)';

  @override
  String get khushooModeDesc => 'حجب الشاشة لعدم التشتيت';

  @override
  String get khushooDuration => 'مدة الشاشة السوداء';

  @override
  String get unitMinuteFull => 'دقيقة';

  @override
  String get manualKhushooTrigger => 'تشغيل الشاشة السوداء يدوياً';

  @override
  String get manualKhushooTriggerDesc => 'اختبار أو تفعيل فوري للشاشة السوداء';

  @override
  String get dayNightAthkar => 'أذكار اليوم والليلة';

  @override
  String get sabahAthkar => 'أذكار الصباح';

  @override
  String get sabahAthkarDesc => 'تشغيل أذكار الصباح بعد صلاة الفجر';

  @override
  String get masaaAthkar => 'أذكار المساء';

  @override
  String get masaaAthkarDesc => 'تشغيل أذكار المساء بعد صلاة العصر';

  @override
  String get athkarOnlyScreen => 'شاشة الأذكار فقط';

  @override
  String get athkarOnlyScreenDesc =>
      'عرض أذكار الصباح والمساء بحركة صعود مستمرة';

  @override
  String get athkarScreenGlassBg => 'خلفية زجاجية لشاشة الأذكار';

  @override
  String get athkarScreenCustomBg => 'صورة مخصصة لشاشة الأذكار';

  @override
  String get removeAthkarScreenBg => 'إزالة صورة شاشة الأذكار';

  @override
  String get afterPrayerAthkarAdvanced => 'أذكار ما بعد الصلاة (متقدمة)';

  @override
  String get afterPrayerAthkarAdvancedDesc => 'طريقة العرض والألوان والتكرار';

  @override
  String get customAdhanSounds => 'أصوات الأذان المخصصة';

  @override
  String get manageAdhanSounds => 'إدارة أصوات الأذان';

  @override
  String get manageAdhanSoundsDesc => 'إضافة، حذف، واستماع لأصوات الأذان';

  @override
  String get defaultAdhanSound => 'صوت الأذان الافتراضي لجميع الصلوات';

  @override
  String get defaultSoundMp3 => 'الصوت الافتراضي (MP3/مدمج)';

  @override
  String get unknown => 'غير معروف';

  @override
  String get change => 'تغيير';

  @override
  String get chooseDefaultSound => 'اختر الصوت الافتراضي';

  @override
  String get customizeSoundsPerPrayer => 'تخصيص الأصوات لكل صلاة';

  @override
  String get followsDefault => 'يتبع الافتراضي';

  @override
  String get select => 'تحديد';

  @override
  String adhanSoundFor(Object name) {
    return 'صوت صلاة $name';
  }

  @override
  String get adhanTypeSpeed => 'نوع الأذان والسرعة';

  @override
  String get mp3AdhanSound => 'صوت MP3 للأذان';

  @override
  String get useMp3PlayerDesc => 'استخدام مشغل MP3 الافتراضي';

  @override
  String get shortAdhan => 'أذان قصير';

  @override
  String get shortAdhanDesc => 'استخدام صوت أذان مختصر (في حال عدم وجود مخصص)';

  @override
  String get shortIqama => 'إقامة قصيرة';

  @override
  String get shortIqamaDesc => 'استخدام صوت إقامة مختصرة';

  @override
  String get upToDate => 'أنت تستخدم النسخة الأخيرة';

  @override
  String newUpdateAvailable(Object version) {
    return 'تحديث جديد متوفر: $version';
  }

  @override
  String get selectAdhanSoundTitle => 'اختر صوت الأذان';

  @override
  String get silent => 'بدون صوت (صامت)';

  @override
  String get defaultSound => 'الصوت الافتراضي';

  @override
  String prayerSoundSelectorTitle(Object prayerName) {
    return 'صوت الأذان لـ $prayerName';
  }

  @override
  String get verifyingLocation => 'جاري التحقق من الموقع...';

  @override
  String get locationAddFailed => 'فشل إضافة الموقع';

  @override
  String get manualTimeNotSet => 'غير محدد';

  @override
  String get straightenRowsHadith =>
      'استووا صفوفكم فإن تسوية الصفوف من تمام الصلاة';

  @override
  String get settingsTitle => 'إعدادات التطبيق';

  @override
  String get changeFlag => 'تغيير العلم';

  @override
  String get mosqueImage => 'صورة المسجد';

  @override
  String get isUpToDate => 'أنت تستخدم النسخة الأخيرة';

  @override
  String updateAvailable(Object version) {
    return 'تحديث جديد متوفر: $version';
  }

  @override
  String appFullyUpdated(Object version) {
    return 'تطبيقك محدث بالكامل (النسخة $version)';
  }

  @override
  String get clickToDownload => 'اضغط للتحميل ومعرفة الجديد في هذا الإصدار';

  @override
  String get locationTimeGroup => 'إعدادات الموقع والتوقيت';

  @override
  String get menuLocationSubtitle => 'GPS، حالة الجو وتحديث الموقع';

  @override
  String get menuPrayerAdjustSubtitle => 'ضبط يدوي، صلاة الجمعة والعيد';

  @override
  String get menuIdentitySubtitle => 'الألوان، التوجيه، الرؤية الليلية';

  @override
  String get menuThemesSubtitle => 'تغيير الخلفيات الذكية واليدوية';

  @override
  String get menuModelsSubtitle => 'إدارة قائمة الصلوات والإقامة';

  @override
  String get menuMessagesSubtitle => 'إدارة الصور والإعلانات المتحركة';

  @override
  String get menuAdhanSubtitle => 'شاشة الأذان، التظليل، والمكث';

  @override
  String get menuAudioSubtitle => 'الأصوات، الأذكار، والتنبيهات';

  @override
  String get menuExcelSubtitle => 'جلب أوقات الصلاة من ملف خارجي';

  @override
  String get menuMarqueeTitle => 'الشريط الإخباري والآيات';

  @override
  String get menuMarqueeSubtitle => 'التحكم في الشريط المتحرك والأولويات';

  @override
  String get menuRemoteTitle => 'لوحة التحكم عن بُعد';

  @override
  String get menuRemoteSubtitle => 'إدارة التطبيق من الهاتف';

  @override
  String get appFontsSubtitle => 'تخصيص الخطوط لجميع الواجهات';

  @override
  String get menuAnnouncementsSubtitle => 'إدارة إعلانات المسجد';

  @override
  String get menuContactSubtitle => 'رسائل التواصل';

  @override
  String get menuChangelogSubtitle => 'تتبع أهم العمليات والتغييرات في التطبيق';

  @override
  String get menuLanguagesSubtitle => 'اختر لغة الواجهة (العربية / English)';

  @override
  String get menuUpdateTitle => 'تحديث التطبيق';

  @override
  String get menuUpdateSubtitle => 'تحقق من وجود تحديث جديد';

  @override
  String appVersion(Object version) {
    return 'إصدار التطبيق: $version';
  }

  @override
  String developmentBy(Object team) {
    return 'تطوير: $team';
  }

  @override
  String editTitle(Object title) {
    return 'تعديل $title';
  }

  @override
  String enterTitle(Object title) {
    return 'أدخل $title...';
  }

  @override
  String currentFont(Object font) {
    return 'الخط الحالي: $font';
  }

  @override
  String get bismillah => 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ';

  @override
  String get fontSettings => 'ضبط خطوط التطبيق';

  @override
  String get fontChangeHint => 'اضغط على «تغيير» لاختيار الخط المناسب لكل قسم';

  @override
  String get chooseCountry => 'اختر الدولة';

  @override
  String get addYourCountry => 'أضف دولتك';

  @override
  String get addCountryDesc => 'إضافة دولة ومدينة جديدة';

  @override
  String get chooseCity => 'اختر المدينة';

  @override
  String get excelDataExists => 'بيانات إكسل موجودة';

  @override
  String get existingExcelFound =>
      'تم العثور على بيانات إكسل سابقة للمدينة الجديدة. هل تريد تفعيلها؟';

  @override
  String get useOriginalData => 'لا، استخدم البيانات الأصلية';

  @override
  String get yesEnableData => 'نعم، تفعيل البيانات';

  @override
  String get applyExcelData => 'تطبيق بيانات الإكسل';

  @override
  String get confirmApplyExcel =>
      'هل تريد تطبيق بيانات ملف الإكسل الحالي على الموقع الجديد؟';

  @override
  String get yesApplyData => 'نعم، تطبيق البيانات';

  @override
  String get importantNote => 'تنبيه هام';

  @override
  String get addLocationExcelRequirement =>
      'إضافة دولة ومدينة جديدة تتطلب وجود ملف إكسل (Excel) يحتوي على مواقيت الصلاة لهذه المنطقة.\n\nهل تود الاستمرار في إضافة الموقع الآن؟';

  @override
  String get yesContinue => 'نعم، متابعة';

  @override
  String get newCountryData => 'بيانات الدولة الجديدة';

  @override
  String get countryNameLabel => 'اسم الدولة (مثلاً: اليمن)';

  @override
  String get countryCodeLabel => 'رمز الدولة (حرفين، مثلاً: YE)';

  @override
  String get errorIncompleteData => 'يرجى إكمال البيانات بشكل صحيح';

  @override
  String get next => 'التالي';

  @override
  String get addCityHint =>
      'يفضل إضافة مدينة واحدة على الأقل لهذه الدولة الآن.';

  @override
  String get cityNameLabel => 'اسم المدينة (مثلاً: تعز)';

  @override
  String get errorEnterCityName => 'يرجى إدخال اسم المدينة';

  @override
  String get emeraldClassic => 'الزمردي (Classic)';

  @override
  String get emeraldDesc => 'التصميم التقليدي الفاخر';

  @override
  String get pureGlassTheme => 'الزجاجي (Pure Glass)';

  @override
  String get pureGlassDesc => 'شفافية عصرية واحترافية';

  @override
  String get background1 => 'الخلفية 1 (الرئيسية)';

  @override
  String get back => 'رجوع';

  @override
  String get mandatoryUpdateAvailable => 'تحديث إلزامي متوفر';

  @override
  String get mandatoryUpdateDesc =>
      'نعتذر، ولكن يتوجب عليك تحديث التطبيق إلى النسخة الأخيرة للمتابعة والاستمتاع بكافة الميزات والتحسينات الأمنية.';

  @override
  String get updateNow => 'تحديث التطبيق الآن';

  @override
  String get updateLater => 'تحديث لاحقاً';

  @override
  String get prayerFajr => 'الفجر';

  @override
  String get prayerDhuhr => 'الظهر';

  @override
  String get prayerAsr => 'العصر';

  @override
  String get prayerMaghrib => 'المغرب';

  @override
  String get prayerIsha => 'العشاء';

  @override
  String get prayerJumuah => 'الجمعة';

  @override
  String get allahuAkbar => 'اللَّهُ أَكْبَرُ  •  اللَّهُ أَكْبَرُ';

  @override
  String get noItemsAvailable => 'لا توجد عناصر متاحة حالياً';

  @override
  String get errorLoadingAzkar => 'تعذر تحميل الأذكار';

  @override
  String get sabahAzkarTitle => 'أذكار الصباح';

  @override
  String get masaaAzkarTitle => 'أذكار المساء';

  @override
  String get noAzkarAtThisTime => 'لا توجد أذكار مخصصة في هذا الوقت';

  @override
  String get enableAzkarInSettings =>
      'قم بتفعيل أذكار الصباح أو أذكار المساء من الإعدادات';

  @override
  String get azkarOnlyScreenTitle => 'شاشة الأذكار فقط';

  @override
  String get stopAzkarOnlyScreen => 'إيقاف شاشة الأذكار فقط';

  @override
  String get remoteControlPanelTitle => 'Remote Control Panel';

  @override
  String get passwordTooShort => 'Password too short (min 4 characters)';

  @override
  String get urlCopied => 'URL Copied';

  @override
  String errorLabel(Object error) {
    return 'Error: $error';
  }

  @override
  String serverRunning(Object ip, Object port) {
    return '🟢 Running — $ip:$port';
  }

  @override
  String get serverStopped => '⚪ Stopped — Manage bar from phone';

  @override
  String get stopServer => 'Stop Server';

  @override
  String get adminUsername => 'Admin Username';

  @override
  String get adminPassword => 'Control Panel Password';

  @override
  String get saveUsernameAlways => 'Always save username';

  @override
  String get startServer => 'Start Server';

  @override
  String get serverSecurityInfo =>
      '• Login is secure via authorization from this screen\n• Server only runs while app is open and on the same network';

  @override
  String get ipAddressChanged => 'IP Address Changed';

  @override
  String newIpInfo(Object url) {
    return 'New link: $url\nPlease re-scan QR on connected devices.';
  }

  @override
  String get pairingCode => 'Pairing Code';

  @override
  String get remoteControlPermissionRequest =>
      'Remote Control Permission Request';

  @override
  String devicePermissionRequest(Object deviceName) {
    return 'Device \"$deviceName\" is requesting screen control.';
  }

  @override
  String get deny => 'Deny';

  @override
  String get allow => 'Allow';

  @override
  String get hijri => 'Hijri';

  @override
  String get gregorian => 'Gregorian';

  @override
  String get mosqueNameLabel => 'Mosque Name';

  @override
  String get fonts => 'Fonts';

  @override
  String get fontsCustomizationDesc => 'Customize fonts for all app interfaces';

  @override
  String get prayerNamesFont => 'Prayer Names Font';

  @override
  String get adhanTimeFont => 'Adhan Time Font';

  @override
  String get iqamaTimeFont => 'Iqama Time Font';

  @override
  String get dateHijriFont => 'Date & Hijri Font';

  @override
  String get noMessagesYet => 'No messages yet';

  @override
  String get addMessagesDesc =>
      'Add advertising messages that will appear as a scrolling bar at the bottom of the screen';

  @override
  String secondsShort(Object seconds) {
    return '${seconds}s';
  }

  @override
  String get fontCairo => 'Cairo';

  @override
  String get fontAmiri => 'Amiri';

  @override
  String get fontTajawal => 'Tajawal';

  @override
  String get fontAlmarai => 'Almarai';

  @override
  String get fontChanga => 'Changa';

  @override
  String get fontRoboto => 'Roboto';

  @override
  String get fontInter => 'Inter';

  @override
  String get fontOutfit => 'Outfit';

  @override
  String errorPickingImage(Object error) {
    return '⚠️ Error picking image: $error';
  }

  @override
  String get previewSample =>
      'In the name of Allah, the Most Gracious, the Most Merciful';

  @override
  String get menuGeneralReportsSubtitle => 'الإعدادات العامة والتقارير';

  @override
  String get menuAnnouncements => 'الإعلانات';

  @override
  String get menuContact => 'تواصل معنا';

  @override
  String get analogClockStyle => 'نمط الساعة التناظرية';

  @override
  String get iqamaScreenLabel => 'شاشة الإقامة';

  @override
  String get adhanIqamaAlerts => 'تنبيهات الأذان والإقامة';

  @override
  String get alertBeforeAdhan => 'تنبيه قبل الأذان';

  @override
  String get alertBeforeAdhanDesc => 'تشغيل تنبيه قبل وقت الأذان';

  @override
  String get fajrFirstAdhan => 'تنبيه الفجر الأول';

  @override
  String get fajrFirstAdhanDesc => 'تفعيل تنبيه إضافي قبل أذان الفجر';

  @override
  String get alertIqamaTime => 'تنبيه وقت الإقامة';

  @override
  String get alertIqamaTimeDesc => 'تشغيل تنبيه عند وقت الإقامة';

  @override
  String get prayerDhikr => 'ذكر وقت الصلاة';

  @override
  String get prayerDhikrDesc => 'إظهار/تشغيل الذكر أثناء وقت الصلاة';

  @override
  String get tasbihAfterAdhan => 'تسبيح بعد الأذان';

  @override
  String get tasbihAfterAdhanDesc => 'إظهار التسبيح بعد الأذان';

  @override
  String get morningEveningAzkar => 'أذكار الصباح والمساء';

  @override
  String get morningAzkar => 'أذكار الصباح';

  @override
  String get morningAzkarDesc => 'تفعيل أذكار الصباح';

  @override
  String get eveningAzkar => 'أذكار المساء';

  @override
  String get eveningAzkarDesc => 'تفعيل أذكار المساء';

  @override
  String get azkarOnlyScreen => 'شاشة أذكار فقط';

  @override
  String get azkarOnlyScreenDesc => 'عرض شاشة الأذكار فقط';

  @override
  String get azkarGlassBg => 'خلفية زجاجية للأذكار';

  @override
  String get azkarGlassBgDesc => 'استخدام خلفية زجاجية في شاشة الأذكار';

  @override
  String get customAzkarBg => 'خلفية مخصصة للأذكار';

  @override
  String get removeAzkarBg => 'إزالة خلفية الأذكار';

  @override
  String get postPrayerAzkarAdv => 'أذكار بعد الصلاة (متقدم)';

  @override
  String get postPrayerAzkarAdvDesc => 'خيارات متقدمة لأذكار ما بعد الصلاة';

  @override
  String get defaultSoundName => 'الصوت الافتراضي';

  @override
  String get customAdhanSoundsGroup => 'الأصوات المخصصة للأذان';

  @override
  String get selectDefaultSound => 'اختر الصوت الافتراضي';

  @override
  String get customizePerPrayer => 'تخصيص لكل صلاة';

  @override
  String get adhanTypeSpeedGroup => 'نوع وسرعة الأذان';

  @override
  String get mp3Adhan => 'أذان MP3';

  @override
  String get mp3AdhanDesc => 'استخدام ملف صوتي MP3 للأذان';

  @override
  String get builtInSound => 'الصوت المدمج';

  @override
  String get azkarFont => 'خط الأذكار';

  @override
  String get clockFont => 'خط الساعة';

  @override
  String get prayerTimesFont => 'خط أوقات الصلاة';

  @override
  String get generalTextFont => 'خط النص العام';

  @override
  String get importantNotice => 'تنبيه مهم';

  @override
  String get addNewLocationMandatoryExcelDesc =>
      'قبل إضافة موقع جديد، تأكد من استيراد ملف الأوقات المناسب.';

  @override
  String get countryNameHint => 'اسم الدولة';

  @override
  String get countryCodeHint => 'رمز الدولة';

  @override
  String get pleaseCompleteDataCorrectly => 'يرجى إكمال البيانات بشكل صحيح';

  @override
  String get pleaseEnterCityName => 'يرجى إدخال اسم المدينة';

  @override
  String get themeEmeraldClassic => 'الزمرد الكلاسيكي';

  @override
  String get themeEmeraldClassicDesc => 'ثيم كلاسيكي أخضر مريح';

  @override
  String get themePureGlass => 'الزجاج النقي';

  @override
  String get themePureGlassDesc => 'ثيم زجاجي شفاف وحديث';

  @override
  String get addNewLocation => 'إضافة موقع جديد';

  @override
  String get addNewLocationDesc => 'أضف دولة ومدينة جديدة لبيانات الأوقات';

  @override
  String get excelDataExistsDesc =>
      'توجد بيانات مستوردة مسبقًا. هل تريد تفعيل البيانات الجديدة؟';

  @override
  String get noUseOriginal => 'لا، استخدم الحالي';

  @override
  String get yesActivateData => 'نعم، فعّل البيانات';

  @override
  String get applyExcelDataDesc =>
      'سيتم تطبيق بيانات الملف على المدينة المختارة.';

  @override
  String get postPrayerAzkarTitle => 'الأذكار بعد الصلاة';

  @override
  String get generalSettingsLabel => 'إعدادات عامة';

  @override
  String get enablePostPrayerAzkarSubtitle =>
      'تشغيل/إيقاف الأذكار عند انتهاء الصلاة';

  @override
  String get repeatAzkarOnce => 'إعادة الأذكار مرة واحدة بعد الانتهاء';

  @override
  String get showOneAzkarImage5Min => 'عرض صورة واحدة فقط لمدة 5 دقائق';

  @override
  String get showOneAzkarImage5MinSubtitle =>
      'بدلاً من التمرير التلقائي بين الأذكار';

  @override
  String get mainScreenAzkar => 'أذكار الشاشة الرئيسية';

  @override
  String get enableSabahAzkarOnMain => 'تفعيل أذكار الصباح';

  @override
  String get appearsInMarquee => 'تظهر في الشريط المتحرك';

  @override
  String get enableMasaaAzkarOnMain => 'تفعيل أذكار المساء';

  @override
  String get standaloneAzkarScreenSettings => 'إعدادات الشاشة المستقلة للأذكار';

  @override
  String get appearByDesignatedTime => 'الظهور حسب الوقت المحدد';

  @override
  String get automaticallyMorningEvening =>
      'تلقائياً (صباحاً للصباح، ومساءً للمساء)';

  @override
  String get specificAzkarForManualPlayback => 'الأذكار المحددة للتشغيل اليدوي';

  @override
  String get whenAutoTimeOptionDisabled => 'عند عدم تفعيل خيار الوقت التلقائي';

  @override
  String get sabahAzkarOnly => 'أذكار الصباح فقط';

  @override
  String get masaaAzkarOnly => 'أذكار المساء فقط';

  @override
  String get bothSabahAndMasaa => 'الكل (صباح ومساء)';

  @override
  String get azkarTiming => 'توقيت الأذكار';

  @override
  String get sabahAzkarStartTime => 'وقت بدء أذكار الصباح';

  @override
  String get sabahAzkarEndTime => 'وقت انتهاء أذكار الصباح';

  @override
  String get masaaAzkarStartTime => 'وقت بدء أذكار المساء';

  @override
  String get masaaAzkarEndTime => 'وقت انتهاء أذكار المساء';

  @override
  String get azkarAfterEveryPrayer => 'أذكار بعد كل صلاة';

  @override
  String get postPrayerAzkarHint =>
      'الأذكار البعدية تظهر تلقائياً على الشاشة الكاملة بعد انتهاء وقت الإقامة وقبل الشاشة السوداء.';

  @override
  String get selectTime => 'اختر الوقت';

  @override
  String get savedSuccessfully => 'تم الحفظ';
}
