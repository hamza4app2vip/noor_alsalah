// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get dohaTime => 'Start of Duha';

  @override
  String get minutesToIqama => 'Iqama...';

  @override
  String get minutesToDoha => 'Duha...';

  @override
  String get azanCalling => 'Adhan';

  @override
  String get azanName => 'Adhan';

  @override
  String get nextPrayTime => 'Next Prayer';

  @override
  String get namesOfPrayings => 'Fajr,Sunrise,Dhuhr,Asr,Maghrib,Isha';

  @override
  String get namesWeekDays =>
      'Sunday,Monday,Tuesday,Wednesday,Thursday,Jummoa,Saturday';

  @override
  String get menuMonthsHijri =>
      'Muharram,Safar,Rabi I,Rabi II,Jumada I,Jumada II,Rajab,Shaban,Ramadan,Shawwal,Dhul\'Qidah,Dhul\'Hijjah';

  @override
  String get menuFullScreen => 'Fullscreen mode';

  @override
  String get menuMosqueName => 'Edit Mosque name';

  @override
  String get menuMosqueMessage => 'Edit Mosque announcements';

  @override
  String get menuLocation => 'Mosque location';

  @override
  String get menuHijriClick => 'Adjust Hijri date';

  @override
  String get menuThemes => 'Change screen background';

  @override
  String get menuOptions => 'Options';

  @override
  String get menuAzkar => 'Display Adhkar';

  @override
  String get menuSliders => 'Display slides';

  @override
  String get menuAdjustments => 'Adjust Adhan and Iqama times';

  @override
  String get menuBlackscreen => 'Adjust screen blackout';

  @override
  String get menuRestartApp => 'Reload application';

  @override
  String get option9 => 'About application';

  @override
  String get fastingMonday =>
      'Reminder of the Sunnah fast for tomorrow, Monday';

  @override
  String get fastingThursday =>
      'Reminder of the Sunnah fast for tomorrow, Thursday';

  @override
  String get option0 => 'Enable 24-hour display';

  @override
  String get option1 => 'Enable full clock display';

  @override
  String get option2 => 'Dim past prayers';

  @override
  String get adjust1 => 'Enlarge countdown on screen';

  @override
  String get adjust2 => 'Use sound for Adhan (MP3)';

  @override
  String get adjust3 => 'Add 30 minutes to Isha prayer during Ramadan';

  @override
  String get prayer => 'Prayer';

  @override
  String get iqama => 'Iqama';

  @override
  String get doha => 'Duha';

  @override
  String get dimmer0 => 'Enable screen blackout during prayer';

  @override
  String get dimmer1 => 'Blackout screen 30 minutes after sunrise';

  @override
  String get dimmer2 => 'Blackout screen 60 minutes after Isha';

  @override
  String get dimmer3 => 'Blackout screen before Dhuhr';

  @override
  String get dimmer4 => 'Show screen after Dhuhr';

  @override
  String get dimmer5 => 'Prayer duration for screen blackout';

  @override
  String get azkar4 =>
      'Display one image only for a fixed duration of 5 minutes';

  @override
  String get times2 => 'Select Mosque country and city';

  @override
  String get times3 => 'To modify or add annual prayer times';

  @override
  String get times4 =>
      '1- Export settings.<br>2- Edit yearly prayer time data.<br>3- Import settings into the application';

  @override
  String get box0 => 'Click on the Hijri date to adjust it ±3 days';

  @override
  String get misc0 => 'Reload the page after modifications';

  @override
  String get misc1 => 'Click on the name or Fajr time to change backgrounds';

  @override
  String get noSell => 'Free application, selling is prohibited';

  @override
  String get jomoa => 'Jummoa';

  @override
  String get iqamaAsHour => 'Display Iqama as time';

  @override
  String get summertime => 'Add one hour to prayer times during summer';

  @override
  String get useArabicDigits =>
      'Enable Arabic numerals (or numerals of the language in use)';

  @override
  String get wcsvMessage =>
      'Enable prayer and Iqama times file.<br>Edit the file (wcsv.js) in the application folder (JAMAAT TIMES).';

  @override
  String get eCountdownOnOff => 'Show countdown';

  @override
  String get n1MoreHour => 'Manually add one hour to all times';

  @override
  String get n1LessHour => 'Manually remove one hour from all times';

  @override
  String get eShortAzan => 'Use short Adhan sound';

  @override
  String get eShortIqama => 'Use short Iqama sound';

  @override
  String get meteo => 'Enable weather status';

  @override
  String get appFonts => 'Adjust application fonts';

  @override
  String get forcedVertical => 'Vertical display';

  @override
  String get scrollableMsg => 'Enable scrolling text bar';

  @override
  String get hideIqamat => 'Home clock - hide Iqama times';

  @override
  String get zerosAmPm => 'Add leading zero for AM/PM times (04:35 AM)';

  @override
  String get meteoPryrs => 'Enable weather display next to prayer times';

  @override
  String get meteoA => 'Weather forecast';

  @override
  String get time2Shrq => 'Time remaining until sunrise';

  @override
  String get wqtShrq => 'Sunrise';

  @override
  String get n5BoxesOnly => 'Enlarge prayer and Iqama times in horizontal view';

  @override
  String get iqamatSalat => 'Iqama of prayer';

  @override
  String get jomoaOnOff => 'Jummoa : Khutbah start time';

  @override
  String get adminmsgs0 => 'Mosque announcements at the bottom of the screen';

  @override
  String get adminmsgsTexter =>
      'Here you can add scrolling messages to be displayed at the bottom of the screen';

  @override
  String get adminmsgsHelp =>
      'Info: Double-click the message to edit.<br>Double-click (DAILY) to change the day or date of the message';

  @override
  String get addMsg => 'Add message';

  @override
  String get dohrXminAsr => 'Dhuhr = Asr - x minutes (click to change): ';

  @override
  String get jomoaInlogo =>
      'Jummoa time in place of the logo in horizontal view';

  @override
  String get azkar0 => 'Enable Adhkar after obligatory prayers';

  @override
  String get sliders0 => 'Enable slides';

  @override
  String get jomoaShow => 'Show Jummoa in horizontal display';

  @override
  String get vrMiddleNames => 'Center prayer names (in vertical view)';

  @override
  String get middleSalats => 'Center prayer names (in horizontal view)';

  @override
  String get azkarSabah => 'Enable morning Adhkar after Fajr prayer';

  @override
  String get azkarAsr => 'Enable evening Adhkar after Asr prayer';

  @override
  String get azkarMagrib => 'Enable evening Adhkar after Maghrib prayer';

  @override
  String get azkarIsha => 'Enable evening Adhkar after Isha prayer';

  @override
  String get n1MinCounter =>
      'Enlarge counter on black screen during the last minute';

  @override
  String get iqamaScreen => 'Show Iqama screen before black screen';

  @override
  String get hrDateRight =>
      'Date on the right and Mosque name on the left in horizontal view';

  @override
  String get verifNet =>
      'Check internet connection (star at the bottom of the screen)';

  @override
  String get timesBgShadows => 'Shade background behind prayer times';

  @override
  String get mobileAlert =>
      'Audio alert message during the last minute before Iqama (click to change message)';

  @override
  String get shortCuts => 'Screen shortcuts';

  @override
  String get shortCutsText => 'Direct quick taps on the screen for options';

  @override
  String get clockInBlkScr => 'Display clock on black screen';

  @override
  String get dateInBlkScr => 'Display date on black screen';

  @override
  String get semiTransparent =>
      'Semi-transparent screens for Adhan, Iqama, and Duha windows';

  @override
  String get iqamaHadith =>
      'Display a Hadith of Prophet ﷺ (33 seconds before Iqama)';

  @override
  String get primaryAzan =>
      'Adjust first Adhan time | x minutes before actual Fajr Adhan. Audio alert. Click to change:';

  @override
  String get counterColorAlert =>
      'Change counter color to red during the last 90 seconds';

  @override
  String get showAzanScreen => 'Show Adhan screen';

  @override
  String get biggerNextPray =>
      'Enlarge remaining time counter for the next prayer';

  @override
  String get themesNoChange => 'Change background manually';

  @override
  String get themesEverySalat => 'Change background at every prayer';

  @override
  String get themesEveryDay => 'Change background daily';

  @override
  String get themesRandomDaily =>
      'Change background daily randomly from this list:';

  @override
  String get randomSlides => 'Display slides randomly';

  @override
  String get eidFitrTime => 'Show Eid al-Fitr prayer time:';

  @override
  String get eidAdhaTime => 'Show Eid al-Adha prayer time:';

  @override
  String get salatEidFitr => 'Eid al-Fitr prayer';

  @override
  String get salatEidAdha => 'Eid al-Adha prayer';

  @override
  String get jomoaAzanOnOff => 'Enable Jummoa Adhan sound';

  @override
  String get fixedTimeForIqamat => 'Fixed time for Iqama:';

  @override
  String get fixedTimeForJomoa => 'Fixed time for Jomoa Adhan';

  @override
  String get slidesViewTime => 'Duration of each slide';

  @override
  String get tawkitViewTime => 'Main screen display duration';

  @override
  String get slidesScreenMaxMin =>
      'Display duration: maximum 60 seconds, minimum 10 seconds';

  @override
  String get menuSynchronize => 'Export/Import settings';

  @override
  String get dlSettingsFile => 'Download settings file';

  @override
  String get enterImportId => '(Import ID) - Enter import number';

  @override
  String get useImportedTimes => 'Use prayer times from imported file';

  @override
  String get clockAdjust => 'Adjust main clock, add or remove hours';

  @override
  String get azkarBgWhite => 'Use white background';

  @override
  String get selectAyatsLang => 'Select language for Quranic verses on screen';

  @override
  String get persoFiles => 'Manage personal files';

  @override
  String get persoFilesMessage =>
      'Customize the app with personal images for background and adhkar.';

  @override
  String get slowDeviceAlert =>
      '(This option may cause slowness on low-end devices.)';

  @override
  String get enablePersoFiles => 'Enable personal files';

  @override
  String get showNightPrayers =>
      'Show night prayer times: midnight, last third of the night, Fajr';

  @override
  String get soundAlertsReminders => 'Sound alerts';

  @override
  String get ramadanDaysLeftInfo =>
      'Include days left until Ramadan with messages (two months before Ramadan).';

  @override
  String get ramadanLeftDays => 'Days left until Ramadan:';

  @override
  String get changelog => 'Changelog';

  @override
  String get languages => 'Languages';

  @override
  String get selectLanguage => 'Select Language';

  @override
  String get arabic => 'Arabic';

  @override
  String get english => 'English';

  @override
  String get save => 'Save';

  @override
  String get cancel => 'Cancel';

  @override
  String get preview => 'Preview';

  @override
  String get fajr => 'Fajr';

  @override
  String get sunrise => 'Sunrise';

  @override
  String get dhuhr => 'Dhuhr';

  @override
  String get asr => 'Asr';

  @override
  String get maghrib => 'Maghrib';

  @override
  String get isha => 'Isha';

  @override
  String get midnight => 'Midnight';

  @override
  String get lastThird => 'Last Third';

  @override
  String get stopBlackClockWithHour => 'Stop Black Clock with Hour';

  @override
  String get exitKhushooMode => 'Exit Khushoo Mode';

  @override
  String get hour => 'Hour';

  @override
  String get minute => 'Minute';

  @override
  String get second => 'Second';

  @override
  String get and => 'and';

  @override
  String get adhanTimeHasCome => 'Adhan time has come for';

  @override
  String prayerNameWithPrefix(Object name) {
    return '$name Prayer';
  }

  @override
  String get internetConnected => 'Internet Connected';

  @override
  String get iqamaTimeHasCome => 'Iqama time has come for';

  @override
  String get minutesUntilIqama => 'minutes until iqama';

  @override
  String get seconds => 'seconds';

  @override
  String currentFontLabel(Object font) {
    return 'Current Font: $font';
  }

  @override
  String chooseFontFor(Object label) {
    return 'Choose $label';
  }

  @override
  String get changeFontHint =>
      'Tap \'Change\' to choose the appropriate font for each section';

  @override
  String get addFirstCity => 'Add First City';

  @override
  String get addFirstCityDesc =>
      'It is recommended to add at least one city for this country now.';

  @override
  String get cityNameHint => 'City Name (e.g., Taiz)';

  @override
  String get addAndSave => 'Add & Save';

  @override
  String get settingsLocationTime => 'Location & Time Settings';

  @override
  String get settingsAppearanceSlides => 'Appearance & Slides';

  @override
  String get settingsAdhanFiles => 'Adhan & Custom Files';

  @override
  String get settingsAdvanced => 'Advanced Add-ons';

  @override
  String get menuGeneralReports => 'General & Reports';

  @override
  String get menuLocationWeather => 'Location & Weather';

  @override
  String get menuPrayerAdjustments => 'Prayer & Friday Adjustments';

  @override
  String get menuIdentityLayout => 'Identity & Formatting';

  @override
  String get menuThemesBackgrounds => 'Background Screens';

  @override
  String get menuModelsLayout => 'Models & Layout';

  @override
  String get menuMessagesSlides => 'Messages & Slides';

  @override
  String get menuAdhanAlerts => 'Adhan & Iqama Alerts';

  @override
  String get menuAudioAlarms => 'Audio & Alarms';

  @override
  String get menuExcelImport => 'Import from Excel';

  @override
  String get general => 'General';

  @override
  String get location => 'Location';

  @override
  String get display => 'Display';

  @override
  String get prayers => 'Prayers';

  @override
  String get adhanIqama => 'Adhan & Iqama';

  @override
  String get alerts => 'Alerts';

  @override
  String get audio => 'Audio';

  @override
  String get helpAndRestore => 'Help & Restore';

  @override
  String get mosqueName => 'Mosque Name';

  @override
  String get mosqueIcon => 'Mosque Icon';

  @override
  String get chooseFromGallery => 'Choose image from gallery';

  @override
  String get mainClockOffset => 'Main Clock Offset';

  @override
  String get unitMinute => 'min';

  @override
  String get showHijriDate => 'Show Hijri Date';

  @override
  String get appTimeCustomization => 'App Time Customization';

  @override
  String get manualTimeEntry => 'Manual Time Entry';

  @override
  String get manualTimeAdjustment => 'Manual Time Adjustment';

  @override
  String get notSet => 'Not set';

  @override
  String get weatherLocationSettings => 'Weather & Location Settings';

  @override
  String get gpsWeatherStatus => 'GPS and weather status';

  @override
  String countryWithName(Object name) {
    return 'Country: $name';
  }

  @override
  String get tapToChangeCountry => 'Tap to change country';

  @override
  String cityWithName(Object name) {
    return 'City: $name';
  }

  @override
  String get tapToChangeCity => 'Tap to change city';

  @override
  String get factoryReset => 'Factory Reset';

  @override
  String get resetSettingsToDefault => 'Reset all settings to default';

  @override
  String get confirmFactoryReset1 =>
      'Are you sure you want to delete settings? All settings will be reset to their initial defaults.';

  @override
  String get confirmFactoryReset2 =>
      'Are you sure you want to completely delete settings? This action cannot be undone.';

  @override
  String get yesSure => 'Yes, I\'m sure';

  @override
  String get settingsResetSuccess => 'Settings have been reset to default';

  @override
  String get appTheme => 'App Theme';

  @override
  String get prayerScreenTheme => 'Prayer Screen Theme';

  @override
  String get visualIdentity => 'Visual Identity';

  @override
  String get countryFlag => 'Country Flag';

  @override
  String get showCountryFlagDesc => 'Show country flag on screen';

  @override
  String get format24h => '24-Hour Format';

  @override
  String get format24hDesc => 'Display time in 24-hour format';

  @override
  String get padWithZero => 'Pad times with zero';

  @override
  String get padWithZeroDesc => 'Example: 04:35 instead of 4:35';

  @override
  String get fullClock => 'Full Clock';

  @override
  String get fullClockDesc => 'Show seconds (00:00:00)';

  @override
  String get analogClock => 'Analog Clock';

  @override
  String get analogClockDesc =>
      'Show analog glass clock in all themes in landscape mode';

  @override
  String get classicGlass => 'Classic Glass';

  @override
  String get luxuryGold => 'Luxury Gold';

  @override
  String get royalIslamic => 'Royal Islamic';

  @override
  String get analogClockDateFrame => 'Analog Clock Date Frame';

  @override
  String get analogClockDateFrameDesc =>
      'Show date and day frame next to/below the clock';

  @override
  String get analogClockNumbers => 'Analog Clock Numbers';

  @override
  String get analogClockNumbersDesc => 'Show numbers on all analog clocks';

  @override
  String get glassShine => 'Glass Shine';

  @override
  String get glassShineDesc =>
      'Enable/Disable glass shine in clock, frames, and floating messages';

  @override
  String get nightPrayerTimes => 'Night Prayer Times';

  @override
  String get nightPrayerTimesDesc => 'Midnight & Last Third of Night';

  @override
  String get marqueeTicker => 'Verses & Athkar Ticker';

  @override
  String get marqueeTickerDesc => 'Moving ticker at the bottom of the screen';

  @override
  String get navbarPositionLandscape => 'Navbar Position (Landscape)';

  @override
  String get fullScreenWidth => 'Full Screen Width';

  @override
  String get centered => 'Centered';

  @override
  String get sideMode => 'On the side';

  @override
  String get pureGlassCustomization => 'Pure Glass Theme Customization';

  @override
  String get fontColor => 'Font Color (Text)';

  @override
  String get fontColorDesc => 'Change color of all texts in theme';

  @override
  String get chooseFontColor => 'Choose Font Color';

  @override
  String get bgColor1 => 'Background Color 1 (Main)';

  @override
  String get bgColor2 => 'Background Color 2';

  @override
  String get bgColor3 => 'Background Color 3';

  @override
  String get bgColor1Desc => 'Change color of top circle and accents';

  @override
  String get bgColor2Desc => 'Change color of bottom circle';

  @override
  String get bgColor3Desc => 'Change color of side circle';

  @override
  String get screenOrientation => 'Screen Orientation';

  @override
  String get auto => 'Auto';

  @override
  String get portrait => 'Portrait';

  @override
  String get landscape => 'Landscape';

  @override
  String get announcementsSlides => 'Announcements & Slides';

  @override
  String get changeWallpaper => 'Change Wallpaper';

  @override
  String get changeWallpaperDesc => 'Customize wallpapers for each prayer';

  @override
  String get advertisingSlides => 'Advertising Slides';

  @override
  String get manageSlidesDesc => 'Manage images and texts as slides';

  @override
  String get newsTickerVerses => 'News Ticker & Verses';

  @override
  String get displayOptions => 'Display Options';

  @override
  String get dimPastPrayersDesc => 'Dim prayers that have passed';

  @override
  String get centerNamesLandscape => 'Center Prayer Names (Landscape)';

  @override
  String get centerNamesLandscapeDesc => 'Center names in landscape mode';

  @override
  String get centerNamesPortrait => 'Center Prayer Names (Portrait)';

  @override
  String get centerNamesPortraitDesc => 'Center names in portrait mode';

  @override
  String get centerPrayerNameMixed =>
      'Center Prayer Name (Adhan Right, Iqama Left)';

  @override
  String get classicThemeOnly => 'Specifically for Classic Theme';

  @override
  String get enlargeNamesLandscape => 'Enlarge Prayer Names (Landscape)';

  @override
  String get enlargeNamesLandscapeDesc => 'Enlarge font in landscape mode';

  @override
  String get showIqamaWithClock => 'Show Iqama with Clock';

  @override
  String get hideIqamaTimeDesc => 'Hide Iqama column from screen';

  @override
  String get blackClockMode => 'Black Screen with Center Clock';

  @override
  String get blackClockModeDesc =>
      'Transform prayer screen to black background with center clock';

  @override
  String get blackClockUseGlass => 'Glass Background for Clock Screen';

  @override
  String get blackClockUseGlassDesc =>
      'When disabled, background becomes full black';

  @override
  String get customClockBg => 'Custom Image for Clock Screen';

  @override
  String get noCustomImage => 'No custom image';

  @override
  String get customImageSet => 'Custom image set';

  @override
  String get removeClockBg => 'Remove Clock Screen Image';

  @override
  String get returnToGlassOrBlack => 'Return to glass or black background';

  @override
  String get prayerListFontSizes => 'Prayer List Font Sizes';

  @override
  String get prayerNameFontSize => 'Prayer Name Font Size';

  @override
  String get adhanTimeFontSize => 'Adhan Time Font Size';

  @override
  String get iqamaTimeFontSize => 'Iqama Time Font Size';

  @override
  String get countdown => 'Countdown';

  @override
  String get nextPrayerTimeDesc => 'Next prayer time';

  @override
  String get enlargeCountdown => 'Enlarge Countdown';

  @override
  String get largeCountdownLastMin => 'Large countdown in last minute';

  @override
  String get opensSeparateBlackScreen => 'Opens a separate black screen';

  @override
  String get enlargeNextPrayerCountdown => 'Enlarge Next Prayer Countdown';

  @override
  String get largeCountdownNextPrayer => 'Large countdown for following prayer';

  @override
  String get colorGreenLast90s => 'Color Green in last 90s';

  @override
  String get changeCountdownColorGreen => 'Change countdown color to green';

  @override
  String get showCountdown => 'Show Countdown';

  @override
  String get useArabicIndicDigits => 'Arabic digits (1, 2, 3)';

  @override
  String get otherOptions => 'Other Options';

  @override
  String get useArabicIndicDigitsDesc => 'Use Arabic-Indic digits';

  @override
  String get previewIqamaScreen => 'Preview Iqama Screen';

  @override
  String get previewAdhanScreen => 'Preview Adhan Screen';

  @override
  String get adhanIqamaScreens => 'Adhan & Iqama Screens';

  @override
  String get showAdhanScreen => 'Show Adhan Screen';

  @override
  String get showBeforeBlackScreen => 'Show it before the black screen';

  @override
  String get translucentScreens => 'Glass/Translucent Screens';

  @override
  String get enableTranslucencyDesc =>
      'Enable transparency for Adhan/Iqama screens';

  @override
  String get shadingBehindTimes => 'Shading behind prayer times';

  @override
  String get shadingBehindTimesDesc => 'Shadow behind times column';

  @override
  String get swapDateMosqueLandscape =>
      'Swap Date and Mosque Position (Landscape)';

  @override
  String get internetStatusIndicator => 'Internet Connection Indicator';

  @override
  String get voiceAlerts => 'Voice Alerts';

  @override
  String get voiceAlertBeforeIqama => 'Voice alert before Iqama';

  @override
  String get voiceAlertBeforeIqamaDesc =>
      'Voice message one minute before Iqama';

  @override
  String get hadithBeforeText => 'Text / Hadith before Iqama';

  @override
  String get hadithBeforeTextDesc => 'Appears 33 seconds before Iqama';

  @override
  String get preAdhanAlarm => 'Alarm before Adhan';

  @override
  String get preAdhanAlarmDesc => 'Alert sound one minute before Adhan';

  @override
  String get alertMessageText => 'Alert message text';

  @override
  String get khushooProgram => 'Khushoo Program';

  @override
  String get muteGlobalAudio => 'Mute Global Audio';

  @override
  String get muteGlobalAudioDesc => 'Stop all sounds in the app';

  @override
  String get muteAdhanOnly => 'Mute Adhan notifications only';

  @override
  String get muteAdhanOnlyDesc => 'Stop Adhan sound separately';

  @override
  String get enableKhushooMode => 'Enable Black Screen (After Adhan)';

  @override
  String get khushooModeDesc => 'Block screen to avoid distraction';

  @override
  String get khushooDuration => 'Black Screen Duration';

  @override
  String get unitMinuteFull => 'minute';

  @override
  String get manualKhushooTrigger => 'Manual Black Screen Trigger';

  @override
  String get manualKhushooTriggerDesc =>
      'Test or immediately activate black screen';

  @override
  String get dayNightAthkar => 'Day & Night Athkar';

  @override
  String get sabahAthkar => 'Sabah Athkar';

  @override
  String get sabahAthkarDesc => 'Play Sabah Athkar after Fajr prayer';

  @override
  String get masaaAthkar => 'Masaa Athkar';

  @override
  String get masaaAthkarDesc => 'Play Masaa Athkar after Asr prayer';

  @override
  String get athkarOnlyScreen => 'Athkar-Only Screen';

  @override
  String get athkarOnlyScreenDesc =>
      'Display morning and evening athkar with continuous upward motion';

  @override
  String get athkarScreenGlassBg => 'Glass Background for Athkar Screen';

  @override
  String get athkarScreenCustomBg => 'Custom Image for Athkar Screen';

  @override
  String get removeAthkarScreenBg => 'Remove Athkar Screen Image';

  @override
  String get afterPrayerAthkarAdvanced => 'After Prayer Athkar (Advanced)';

  @override
  String get afterPrayerAthkarAdvancedDesc =>
      'Display mode, colors, and repetition';

  @override
  String get customAdhanSounds => 'Custom Adhan Sounds';

  @override
  String get manageAdhanSounds => 'Manage Adhan Sounds';

  @override
  String get manageAdhanSoundsDesc => 'Add, delete, and listen to Adhan sounds';

  @override
  String get defaultAdhanSound => 'Default Adhan sound for all prayers';

  @override
  String get defaultSoundMp3 => 'Default Sound (MP3/Built-in)';

  @override
  String get unknown => 'Unknown';

  @override
  String get change => 'Change';

  @override
  String get chooseDefaultSound => 'Choose Default Sound';

  @override
  String get customizeSoundsPerPrayer => 'Customize sounds for each prayer';

  @override
  String get followsDefault => 'Follows Default';

  @override
  String get select => 'Select';

  @override
  String adhanSoundFor(Object name) {
    return 'Adhan sound for $name';
  }

  @override
  String get adhanTypeSpeed => 'Adhan Type & Speed';

  @override
  String get mp3AdhanSound => 'MP3 Sound for Adhan';

  @override
  String get useMp3PlayerDesc => 'Use default MP3 player';

  @override
  String get shortAdhan => 'Short Adhan';

  @override
  String get shortAdhanDesc => 'Use short Adhan sound (if custom is missing)';

  @override
  String get shortIqama => 'Short Iqama';

  @override
  String get shortIqamaDesc => 'Use short Iqama sound';

  @override
  String get upToDate => 'You are use the latest version';

  @override
  String newUpdateAvailable(Object version) {
    return 'New update available: $version';
  }

  @override
  String get selectAdhanSoundTitle => 'Select Adhan Sound';

  @override
  String get silent => 'Silent';

  @override
  String get defaultSound => 'Default Sound';

  @override
  String prayerSoundSelectorTitle(Object prayerName) {
    return 'Adhan sound for $prayerName';
  }

  @override
  String get verifyingLocation => 'Verifying location...';

  @override
  String get locationAddFailed => 'Failed to add location';

  @override
  String get manualTimeNotSet => 'Not set';

  @override
  String get straightenRowsHadith =>
      'Straighten your rows, for straightening the rows is part of the perfection of prayer';

  @override
  String get settingsTitle => 'App Settings';

  @override
  String get changeFlag => 'Change Flag';

  @override
  String get mosqueImage => 'Mosque Image';

  @override
  String get isUpToDate => 'You are using the latest version';

  @override
  String updateAvailable(Object version) {
    return 'New update available: $version';
  }

  @override
  String appFullyUpdated(Object version) {
    return 'Your app is fully updated (Version $version)';
  }

  @override
  String get clickToDownload =>
      'Tap to download and see what\'s new in this version';

  @override
  String get locationTimeGroup => 'Location & Time Settings';

  @override
  String get menuLocationSubtitle => 'GPS, weather status and location update';

  @override
  String get menuPrayerAdjustSubtitle =>
      'Manual adjustment, Friday and Eid prayer';

  @override
  String get menuIdentitySubtitle => 'Colors, orientation, night vision';

  @override
  String get menuThemesSubtitle => 'Change smart and manual backgrounds';

  @override
  String get menuModelsSubtitle => 'Manage prayer list and iqama';

  @override
  String get menuMessagesSubtitle => 'Manage images and animated ads';

  @override
  String get menuAdhanSubtitle => 'Adhan screen, shading, and staying';

  @override
  String get menuAudioSubtitle => 'Sounds, Adhkar, and alerts';

  @override
  String get menuExcelSubtitle => 'Fetch prayer times from external file';

  @override
  String get menuMarqueeTitle => 'News Ticker & Verses';

  @override
  String get menuMarqueeSubtitle => 'Control moving ticker and priorities';

  @override
  String get menuRemoteTitle => 'Remote Control Panel';

  @override
  String get menuRemoteSubtitle => 'Manage app from phone';

  @override
  String get appFontsSubtitle => 'Customize fonts for all interfaces';

  @override
  String get menuAnnouncementsSubtitle => 'Manage Mosque Announcements';

  @override
  String get menuContactSubtitle => 'Contact Messages';

  @override
  String get menuChangelogSubtitle =>
      'Track main operations and changes in the app';

  @override
  String get menuLanguagesSubtitle =>
      'Choose interface language (Arabic / English)';

  @override
  String get menuUpdateTitle => 'Update Application';

  @override
  String get menuUpdateSubtitle => 'Check for a new update';

  @override
  String appVersion(Object version) {
    return 'App Version: $version';
  }

  @override
  String developmentBy(Object team) {
    return 'Developed by: $team';
  }

  @override
  String editTitle(Object title) {
    return 'Edit $title';
  }

  @override
  String enterTitle(Object title) {
    return 'Enter $title...';
  }

  @override
  String currentFont(Object font) {
    return 'Current Font: $font';
  }

  @override
  String get bismillah =>
      'In the name of Allah, the Most Gracious, the Most Merciful';

  @override
  String get fontSettings => 'App Font Settings';

  @override
  String get fontChangeHint =>
      'Tap \'Change\' to pick the appropriate font for each section';

  @override
  String get chooseCountry => 'Choose Country';

  @override
  String get addYourCountry => 'Add Your Country';

  @override
  String get addCountryDesc => 'Add a new country and city';

  @override
  String get chooseCity => 'Choose City';

  @override
  String get excelDataExists => 'Excel Data Exists';

  @override
  String get existingExcelFound =>
      'Previous Excel data found for the new city. Do you want to enable it?';

  @override
  String get useOriginalData => 'No, use original data';

  @override
  String get yesEnableData => 'Yes, enable data';

  @override
  String get applyExcelData => 'Apply Excel Data';

  @override
  String get confirmApplyExcel =>
      'Do you want to apply current Excel file data to the new location?';

  @override
  String get yesApplyData => 'Yes, apply data';

  @override
  String get importantNote => 'Important Note';

  @override
  String get addLocationExcelRequirement =>
      'Adding a new country and city requires an Excel file containing prayer times for this area.\n\nDo you want to continue adding the location now?';

  @override
  String get yesContinue => 'Yes, continue';

  @override
  String get newCountryData => 'New Country Data';

  @override
  String get countryNameLabel => 'Country Name (e.g., Yemen)';

  @override
  String get countryCodeLabel => 'Country Code (2 letters, e.g., YE)';

  @override
  String get errorIncompleteData => 'Please complete the data correctly';

  @override
  String get next => 'Next';

  @override
  String get addCityHint =>
      'It is recommended to add at least one city for this country now.';

  @override
  String get cityNameLabel => 'City Name (e.g., Taiz)';

  @override
  String get errorEnterCityName => 'Please enter city name';

  @override
  String get emeraldClassic => 'Emerald (Classic)';

  @override
  String get emeraldDesc => 'Traditional luxury design';

  @override
  String get pureGlassTheme => 'Pure Glass';

  @override
  String get pureGlassDesc => 'Modern & professional transparency';

  @override
  String get background1 => 'Background 1 (Main)';

  @override
  String get back => 'Back';

  @override
  String get mandatoryUpdateAvailable => 'Mandatory Update Available';

  @override
  String get mandatoryUpdateDesc =>
      'We apologize, but you must update the app to the latest version to continue and enjoy all features and security improvements.';

  @override
  String get updateNow => 'Update App Now';

  @override
  String get updateLater => 'Update Later';

  @override
  String get prayerFajr => 'Fajr';

  @override
  String get prayerDhuhr => 'Dhuhr';

  @override
  String get prayerAsr => 'Asr';

  @override
  String get prayerMaghrib => 'Maghrib';

  @override
  String get prayerIsha => 'Isha';

  @override
  String get prayerJumuah => 'Friday';

  @override
  String get allahuAkbar => 'Allahu Akbar  •  Allahu Akbar';

  @override
  String get noItemsAvailable => 'No items available at the moment';

  @override
  String get errorLoadingAzkar => 'Error loading Adhkar';

  @override
  String get sabahAzkarTitle => 'Morning Adhkar';

  @override
  String get masaaAzkarTitle => 'Evening Adhkar';

  @override
  String get noAzkarAtThisTime => 'No specific Adhkar at this time';

  @override
  String get enableAzkarInSettings =>
      'Please enable Morning or Evening Adhkar in settings';

  @override
  String get azkarOnlyScreenTitle => 'Adhkar-Only Screen';

  @override
  String get stopAzkarOnlyScreen => 'Stop Adhkar-Only Screen';

  @override
  String get remoteControlPanelTitle => 'Remote Control Panel';

  @override
  String get passwordTooShort => 'Password too short (min 4 characters)';

  @override
  String get urlCopied => 'URL Copied';

  @override
  String errorLabel(Object error) {
    return 'Error: $error';
  }

  @override
  String serverRunning(Object ip, Object port) {
    return '🟢 Running — $ip:$port';
  }

  @override
  String get serverStopped => '⚪ Stopped — Manage bar from phone';

  @override
  String get stopServer => 'Stop Server';

  @override
  String get adminUsername => 'Admin Username';

  @override
  String get adminPassword => 'Control Panel Password';

  @override
  String get saveUsernameAlways => 'Always save username';

  @override
  String get startServer => 'Start Server';

  @override
  String get serverSecurityInfo =>
      '• Login is secure via authorization from this screen\n• Server only runs while app is open and on the same network';

  @override
  String get ipAddressChanged => 'IP Address Changed';

  @override
  String newIpInfo(Object url) {
    return 'New link: $url\nPlease re-scan QR on connected devices.';
  }

  @override
  String get pairingCode => 'Pairing Code';

  @override
  String get remoteControlPermissionRequest =>
      'Remote Control Permission Request';

  @override
  String devicePermissionRequest(Object deviceName) {
    return 'Device \"$deviceName\" is requesting screen control.';
  }

  @override
  String get deny => 'Deny';

  @override
  String get allow => 'Allow';

  @override
  String get hijri => 'Hijri';

  @override
  String get gregorian => 'Gregorian';

  @override
  String get mosqueNameLabel => 'Mosque Name';

  @override
  String get fonts => 'Fonts';

  @override
  String get fontsCustomizationDesc => 'Customize fonts for all app interfaces';

  @override
  String get prayerNamesFont => 'Prayer Names Font';

  @override
  String get adhanTimeFont => 'Adhan Time Font';

  @override
  String get iqamaTimeFont => 'Iqama Time Font';

  @override
  String get dateHijriFont => 'Date & Hijri Font';

  @override
  String get noMessagesYet => 'No messages yet';

  @override
  String get addMessagesDesc =>
      'Add advertising messages that will appear as a scrolling bar at the bottom of the screen';

  @override
  String secondsShort(Object seconds) {
    return '${seconds}s';
  }

  @override
  String get fontCairo => 'Cairo';

  @override
  String get fontAmiri => 'Amiri';

  @override
  String get fontTajawal => 'Tajawal';

  @override
  String get fontAlmarai => 'Almarai';

  @override
  String get fontChanga => 'Changa';

  @override
  String get fontRoboto => 'Roboto';

  @override
  String get fontInter => 'Inter';

  @override
  String get fontOutfit => 'Outfit';

  @override
  String errorPickingImage(Object error) {
    return '⚠️ Error picking image: $error';
  }

  @override
  String get previewSample =>
      'In the name of Allah, the Most Gracious, the Most Merciful';

  @override
  String get menuGeneralReportsSubtitle => 'General Settings & Reports';

  @override
  String get menuAnnouncements => 'Announcements';

  @override
  String get menuContact => 'Contact Us';

  @override
  String get analogClockStyle => 'Analog Clock Style';

  @override
  String get iqamaScreenLabel => 'Iqama Screen';

  @override
  String get adhanIqamaAlerts => 'Adhan & Iqama Alerts';

  @override
  String get alertBeforeAdhan => 'Alert before Adhan';

  @override
  String get alertBeforeAdhanDesc => 'Play an alert before Adhan time';

  @override
  String get fajrFirstAdhan => 'First Fajr Alert';

  @override
  String get fajrFirstAdhanDesc => 'Enable additional alert before Fajr Adhan';

  @override
  String get alertIqamaTime => 'Iqama Time Alert';

  @override
  String get alertIqamaTimeDesc => 'Play an alert at Iqama time';

  @override
  String get prayerDhikr => 'Prayer Time Dhikr';

  @override
  String get prayerDhikrDesc => 'Show/Play Dhikr during prayer time';

  @override
  String get tasbihAfterAdhan => 'Tasbeeh After Adhan';

  @override
  String get tasbihAfterAdhanDesc => 'Show Tasbeeh after Adhan';

  @override
  String get morningEveningAzkar => 'Morning & Evening Adhkar';

  @override
  String get morningAzkar => 'Morning Adhkar';

  @override
  String get morningAzkarDesc => 'Enable Morning Adhkar';

  @override
  String get eveningAzkar => 'Evening Adhkar';

  @override
  String get eveningAzkarDesc => 'Enable Evening Adhkar';

  @override
  String get azkarOnlyScreen => 'Adhkar Only Screen';

  @override
  String get azkarOnlyScreenDesc => 'Display Adhkar only screen';

  @override
  String get azkarGlassBg => 'Glass Background for Adhkar';

  @override
  String get azkarGlassBgDesc => 'Use a glass background in the Adhkar screen';

  @override
  String get customAzkarBg => 'Custom Adhkar Background';

  @override
  String get removeAzkarBg => 'Remove Adhkar Background';

  @override
  String get postPrayerAzkarAdv => 'Post-Prayer Adhkar (Advanced)';

  @override
  String get postPrayerAzkarAdvDesc =>
      'Advanced options for post-prayer Adhkar';

  @override
  String get defaultSoundName => 'Default Sound';

  @override
  String get customAdhanSoundsGroup => 'Custom Adhan Sounds';

  @override
  String get selectDefaultSound => 'Select Default Sound';

  @override
  String get customizePerPrayer => 'Customize per prayer';

  @override
  String get adhanTypeSpeedGroup => 'Adhan Type & Speed';

  @override
  String get mp3Adhan => 'MP3 Adhan';

  @override
  String get mp3AdhanDesc => 'Use an MP3 audio file for Adhan';

  @override
  String get builtInSound => 'Built-in Sound';

  @override
  String get azkarFont => 'Adhkar Font';

  @override
  String get clockFont => 'Clock Font';

  @override
  String get prayerTimesFont => 'Prayer Times Font';

  @override
  String get generalTextFont => 'General Text Font';

  @override
  String get importantNotice => 'Important Notice';

  @override
  String get addNewLocationMandatoryExcelDesc =>
      'Before adding a new location, make sure to import the correct prayer times file.';

  @override
  String get countryNameHint => 'Country Name';

  @override
  String get countryCodeHint => 'Country Code';

  @override
  String get pleaseCompleteDataCorrectly =>
      'Please complete the data correctly';

  @override
  String get pleaseEnterCityName => 'Please enter the city name';

  @override
  String get themeEmeraldClassic => 'Emerald Classic';

  @override
  String get themeEmeraldClassicDesc => 'A comforting classic green theme';

  @override
  String get themePureGlass => 'Pure Glass';

  @override
  String get themePureGlassDesc => 'A modern, transparent glass theme';

  @override
  String get addNewLocation => 'Add New Location';

  @override
  String get addNewLocationDesc =>
      'Add a new country and city to prayer times data';

  @override
  String get excelDataExistsDesc =>
      'Previously imported data exists. Do you want to activate the new data?';

  @override
  String get noUseOriginal => 'No, use current';

  @override
  String get yesActivateData => 'Yes, activate data';

  @override
  String get applyExcelDataDesc =>
      'The file data will be applied to the selected city.';

  @override
  String get postPrayerAzkarTitle => 'Adhkar After Prayer';

  @override
  String get generalSettingsLabel => 'General Settings';

  @override
  String get enablePostPrayerAzkarSubtitle =>
      'Enable/disable Adhkar after prayer finishes';

  @override
  String get repeatAzkarOnce => 'Repeat Adhkar once after finishing';

  @override
  String get showOneAzkarImage5Min => 'Show one image only for 5 minutes';

  @override
  String get showOneAzkarImage5MinSubtitle =>
      'Instead of auto-scrolling between Adhkar';

  @override
  String get mainScreenAzkar => 'Main Screen Adhkar';

  @override
  String get enableSabahAzkarOnMain => 'Enable Morning Adhkar';

  @override
  String get appearsInMarquee => 'Appears in the scrolling ticker';

  @override
  String get enableMasaaAzkarOnMain => 'Enable Evening Adhkar';

  @override
  String get standaloneAzkarScreenSettings =>
      'Standalone Adhkar Screen Settings';

  @override
  String get appearByDesignatedTime => 'Appear based on designated time';

  @override
  String get automaticallyMorningEvening =>
      'Automatically (morning for morning, evening for evening)';

  @override
  String get specificAzkarForManualPlayback =>
      'Specific Adhkar for manual playback';

  @override
  String get whenAutoTimeOptionDisabled => 'When auto-time option is disabled';

  @override
  String get sabahAzkarOnly => 'Morning Adhkar only';

  @override
  String get masaaAzkarOnly => 'Evening Adhkar only';

  @override
  String get bothSabahAndMasaa => 'Both (Morning & Evening)';

  @override
  String get azkarTiming => 'Adhkar Timing';

  @override
  String get sabahAzkarStartTime => 'Morning Adhkar Start Time';

  @override
  String get sabahAzkarEndTime => 'Morning Adhkar End Time';

  @override
  String get masaaAzkarStartTime => 'Evening Adhkar Start Time';

  @override
  String get masaaAzkarEndTime => 'Evening Adhkar End Time';

  @override
  String get azkarAfterEveryPrayer => 'Adhkar After Every Prayer';

  @override
  String get postPrayerAzkarHint =>
      'Post-prayer Adhkar appear automatically on the full screen after Iqama time ends and before the black screen.';

  @override
  String get selectTime => 'Select Time';

  @override
  String get savedSuccessfully => 'Saved successfully';
}
