import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

class GreenGoldClock extends StatefulWidget {
  final DateTime baseTime;
  final double size;
  final String brand;
  final bool showHourNumbers;
  final bool useArabicIndicDigits;

  const GreenGoldClock({
    super.key,
    required this.baseTime,
    this.size = 300,
    this.brand = 'NOOR',
    this.showHourNumbers = false,
    this.useArabicIndicDigits = false,
  });

  @override
  State<GreenGoldClock> createState() => _GreenGoldClockState();
}

class _GreenGoldClockState extends State<GreenGoldClock>
    with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  final ValueNotifier<DateTime> _timeNotifier = ValueNotifier(DateTime.now());

  late DateTime _anchorVirtualNow;
  late DateTime _anchorSystemNow;

  static const Color patternLineColor = Color(0xFF1B4938);
  static const Color dialBase = Color(0xFFE2C46E);
  static const Color dialHighlight = Color(0xFFF7E6A9);
  static const Color dialShadow = Color(0xFFB08933);
  static const Color elementDarkGreen = Color(0xFF103324);
  static const Color medallionGold = Color(0xFFC7A550);

  @override
  void initState() {
    super.initState();
    _anchorVirtualNow = widget.baseTime;
    _anchorSystemNow = DateTime.now();
    _timeNotifier.value = widget.baseTime;
    _ticker = createTicker((_) {
      final elapsed = DateTime.now().difference(_anchorSystemNow);
      _timeNotifier.value = _anchorVirtualNow.add(elapsed);
    });
    _ticker.start();
  }

  @override
  void didUpdateWidget(covariant GreenGoldClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    final drift =
        widget.baseTime.difference(_timeNotifier.value).inMilliseconds.abs();
    if (drift > 1500 || oldWidget.baseTime != widget.baseTime) {
      _anchorVirtualNow = widget.baseTime;
      _anchorSystemNow = DateTime.now();
      _timeNotifier.value = widget.baseTime;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    _timeNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final clockSize = widget.size;

    return Center(
      child: SizedBox.square(
        dimension: clockSize,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.45),
                blurRadius: clockSize * 0.12,
                spreadRadius: clockSize * 0.01,
                offset: Offset(0, clockSize * 0.06),
              ),
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.22),
                blurRadius: clockSize * 0.04,
                offset: Offset(0, clockSize * 0.02),
              ),
            ],
          ),
          child: ClipOval(
            child: Stack(
              fit: StackFit.expand,
              children: [
                _buildBrushedGoldDial(clockSize),
                Opacity(
                  opacity: 0.18,
                  child: CustomPaint(
                    painter: _BackgroundIslamicPatternPainter(
                      lineColor: patternLineColor,
                    ),
                  ),
                ),
                CustomPaint(
                  painter: _MedallionPainter(
                    color: medallionGold.withValues(alpha: 0.85),
                  ),
                ),
                CustomPaint(
                  painter: _TicksPainter(
                    color: elementDarkGreen,
                  ),
                ),
                if (widget.showHourNumbers) ..._buildNumerals(clockSize),
                Positioned(
                  top: clockSize * 0.22,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Text(
                      widget.brand,
                      maxLines: 1,
                      overflow: TextOverflow.fade,
                      style: TextStyle(
                        fontSize: clockSize * 0.052,
                        fontWeight: FontWeight.w700,
                        letterSpacing: clockSize * 0.015,
                        color: elementDarkGreen,
                      ),
                    ),
                  ),
                ),
                ValueListenableBuilder<DateTime>(
                  valueListenable: _timeNotifier,
                  builder: (context, now, child) {
                    final sec = now.second + (now.millisecond / 1000.0);
                    final min = now.minute + (sec / 60.0);
                    final hr = (now.hour % 12) + (min / 60.0);

                    return Stack(
                      fit: StackFit.expand,
                      children: [
                        CustomPaint(
                          painter: _HandPainter(
                            angle: hr * 30 * math.pi / 180,
                            lengthRatio: 0.55,
                            widthRatio: 0.022,
                            color: elementDarkGreen,
                            hasTail: false,
                          ),
                        ),
                        CustomPaint(
                          painter: _HandPainter(
                            angle: min * 6 * math.pi / 180,
                            lengthRatio: 0.75,
                            widthRatio: 0.018,
                            color: elementDarkGreen,
                            hasTail: false,
                          ),
                        ),
                        CustomPaint(
                          painter: _HandPainter(
                            angle: sec * 6 * math.pi / 180,
                            lengthRatio: 0.8,
                            widthRatio: 0.006,
                            color: elementDarkGreen,
                            hasTail: true,
                            tailLengthRatio: 0.2,
                          ),
                        ),
                      ],
                    );
                  },
                ),
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    width: clockSize * 0.04,
                    height: clockSize * 0.04,
                    decoration: BoxDecoration(
                      color: elementDarkGreen,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.4),
                          blurRadius: 4.0,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Center(
                      child: Container(
                        width: clockSize * 0.015,
                        height: clockSize * 0.015,
                        decoration: const BoxDecoration(
                          color: Color(0xFF18422F),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ),
                ),
                CustomPaint(
                  painter: _GlassGlarePainter(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBrushedGoldDial(double size) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: SweepGradient(
          colors: const [
            dialBase,
            dialHighlight,
            dialBase,
            dialShadow,
            dialBase,
            dialHighlight,
            dialBase,
            dialShadow,
            dialBase,
          ],
          stops: const [0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1.0],
          transform: const GradientRotation(math.pi / 4),
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              Colors.white.withValues(alpha: 0.18),
              Colors.transparent,
              Colors.black.withValues(alpha: 0.12),
            ],
            stops: const [0.0, 0.72, 1.0],
          ),
          border: Border.all(
            color: dialHighlight.withValues(alpha: 0.82),
            width: size * 0.005,
          ),
        ),
      ),
    );
  }

  List<Widget> _buildNumerals(double clockSize) {
    final numerals = <Widget>[];
    final radius = clockSize * 0.36;
    final center = clockSize / 2;

    for (var i = 1; i <= 12; i++) {
      final angle = (i * 30 - 90) * math.pi / 180;
      final x = center + radius * math.cos(angle);
      final y = center + radius * math.sin(angle);
      numerals.add(
        Positioned(
          left: x - (clockSize * 0.05),
          top: y - (clockSize * 0.05),
          width: clockSize * 0.1,
          height: clockSize * 0.1,
          child: Center(
            child: Text(
              _formatHour(i),
              style: TextStyle(
                fontSize: clockSize * 0.065,
                fontWeight: FontWeight.w600,
                color: elementDarkGreen,
              ),
            ),
          ),
        ),
      );
    }
    return numerals;
  }

  String _formatHour(int hour) {
    final value = hour.toString();
    if (!widget.useArabicIndicDigits) return value;
    const western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const arabicIndic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    var result = value;
    for (var i = 0; i < western.length; i++) {
      result = result.replaceAll(western[i], arabicIndic[i]);
    }
    return result;
  }
}

class _BackgroundIslamicPatternPainter extends CustomPainter {
  final Color lineColor;

  _BackgroundIslamicPatternPainter({required this.lineColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.003;

    final step = size.width / 4;
    for (double x = -step; x < size.width + step; x += step) {
      for (double y = -step; y < size.height + step; y += step) {
        _drawEightPointStar(canvas, paint, Offset(x, y), step * 0.6);
        _drawEightPointStar(
          canvas,
          paint,
          Offset(x + step / 2, y + step / 2),
          step * 0.4,
        );
      }
    }
  }

  void _drawEightPointStar(
    Canvas canvas,
    Paint paint,
    Offset center,
    double radius,
  ) {
    final path = Path();
    for (var i = 0; i < 8; i++) {
      final outerAngle = i * math.pi / 4;
      final innerAngle = outerAngle + math.pi / 8;
      final outerPoint = Offset(
        center.dx + radius * math.cos(outerAngle),
        center.dy + radius * math.sin(outerAngle),
      );
      final innerPoint = Offset(
        center.dx + radius * 0.4 * math.cos(innerAngle),
        center.dy + radius * 0.4 * math.sin(innerAngle),
      );
      if (i == 0) {
        path.moveTo(outerPoint.dx, outerPoint.dy);
      } else {
        path.lineTo(outerPoint.dx, outerPoint.dy);
      }
      path.lineTo(innerPoint.dx, innerPoint.dy);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _MedallionPainter extends CustomPainter {
  final Color color;

  _MedallionPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.24;
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.003
      ..isAntiAlias = true;

    canvas.saveLayer(Offset.zero & size, Paint());
    canvas.drawCircle(center, radius, paint);
    canvas.drawCircle(center, radius * 0.95, paint);
    canvas.drawCircle(center, radius * 0.65, paint);
    canvas.drawCircle(center, radius * 0.25, paint);

    for (var i = 0; i < 8; i++) {
      final angle = i * math.pi / 4;
      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas.rotate(angle);
      final petal = Path()
        ..moveTo(0, -radius * 0.25)
        ..lineTo(radius * 0.15, -radius * 0.5)
        ..lineTo(0, -radius * 0.95)
        ..lineTo(-radius * 0.15, -radius * 0.5)
        ..close();
      canvas.drawPath(petal, paint);
      canvas.drawLine(
        Offset(0, -radius * 0.25),
        Offset(radius * 0.2, -radius * 0.65),
        paint,
      );
      canvas.drawLine(
        Offset(0, -radius * 0.25),
        Offset(-radius * 0.2, -radius * 0.65),
        paint,
      );
      canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _TicksPainter extends CustomPainter {
  final Color color;

  _TicksPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final radius = size.width / 2;

    final minutePaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.004
      ..strokeCap = StrokeCap.round;

    final hourPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.009
      ..strokeCap = StrokeCap.square;

    for (var i = 0; i < 60; i++) {
      final angle = i * 6 * math.pi / 180;
      final isHour = i % 5 == 0;
      final innerRadius = radius * (isHour ? 0.88 : 0.92);
      final outerRadius = radius * 0.96;
      final p1 = Offset(
        cx + innerRadius * math.cos(angle),
        cy + innerRadius * math.sin(angle),
      );
      final p2 = Offset(
        cx + outerRadius * math.cos(angle),
        cy + outerRadius * math.sin(angle),
      );
      canvas.drawLine(p1, p2, isHour ? hourPaint : minutePaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _HandPainter extends CustomPainter {
  final double angle;
  final double lengthRatio;
  final double widthRatio;
  final Color color;
  final bool hasTail;
  final double tailLengthRatio;

  _HandPainter({
    required this.angle,
    required this.lengthRatio,
    required this.widthRatio,
    required this.color,
    required this.hasTail,
    this.tailLengthRatio = 0.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final length = (size.width / 2) * lengthRatio;
    final width = size.width * widthRatio;
    final tailLength = (size.width / 2) * tailLengthRatio;

    canvas.save();
    canvas.translate(cx, cy);
    canvas.rotate(angle);

    final handPath = Path();
    if (!hasTail) {
      handPath.moveTo(0, -length);
      handPath.lineTo(width / 2, 0);
      handPath.lineTo(0, width);
      handPath.lineTo(-width / 2, 0);
      handPath.close();
    } else {
      handPath.moveTo(-width / 2, tailLength);
      handPath.lineTo(width / 2, tailLength);
      handPath.lineTo(width / 2, -length);
      handPath.lineTo(-width / 2, -length);
      handPath.close();
    }

    canvas.drawShadow(
        handPath, Colors.black.withValues(alpha: 0.6), 4.0, false);
    final fillPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    canvas.drawPath(handPath, fillPaint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class _GlassGlarePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bounds = Offset.zero & size;
    final paint = Paint()
      ..shader = ui.Gradient.linear(
        bounds.topLeft,
        bounds.bottomRight,
        [
          Colors.white.withValues(alpha: 0.15),
          Colors.white.withValues(alpha: 0.0),
          Colors.transparent,
          Colors.black.withValues(alpha: 0.05),
        ],
        [0.0, 0.4, 0.5, 1.0],
      )
      ..blendMode = BlendMode.screen;

    canvas.drawOval(bounds, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
