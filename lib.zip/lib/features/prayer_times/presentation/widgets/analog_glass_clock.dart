import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'green_gold_clock.dart';
import 'luxury_gold_clock.dart';
import 'luxury_royal_islamic_clock.dart';

class AnalogGlassClock extends StatelessWidget {
  final DateTime baseTime;
  final double size;
  final String brand;
  final bool showHourNumbers;
  final bool useArabicIndicDigits;
  final String style;
  final bool enableShine;

  const AnalogGlassClock({
    super.key,
    required this.baseTime,
    this.size = 150,
    this.brand = 'NOOR',
    this.showHourNumbers = false,
    this.useArabicIndicDigits = true,
    this.style = 'GLASS',
    this.enableShine = true,
  });

  @override
  Widget build(BuildContext context) {
    if (style == 'GOLDEN') {
      return LuxuryGoldClock(
        baseTime: baseTime,
        size: size,
        brand: brand,
        showHourNumbers: showHourNumbers,
        useArabicIndicDigits: useArabicIndicDigits,
      );
    }

    if (style == 'GREEN_GOLD') {
      return GreenGoldClock(
        baseTime: baseTime,
        size: size,
        brand: brand,
        showHourNumbers: showHourNumbers,
        useArabicIndicDigits: useArabicIndicDigits,
      );
    }

    if (style == 'ROYAL') {
      return LuxuryRoyalIslamicClock(
        baseTime: baseTime,
        size: size,
        brand: 'نُور',
        showHourNumbers: showHourNumbers,
        useArabicIndicDigits: useArabicIndicDigits,
      );
    }

    return StandardGlassClock(
      baseTime: baseTime,
      size: size,
      brand: brand,
      showHourNumbers: showHourNumbers,
      useArabicIndicDigits: useArabicIndicDigits,
      enableShine: enableShine,
    );
  }
}

class StandardGlassClock extends StatefulWidget {
  final DateTime baseTime;
  final double size;
  final String brand;

  final bool showHourNumbers;
  final bool useArabicIndicDigits;
  final String Function(int hour)? hourNumberBuilder;
  final bool enableShine; // التحكم في طبقة البريق
  final TextStyle? hourNumberStyle;

  const StandardGlassClock({
    super.key,
    required this.baseTime,
    this.size = 150,
    this.brand = 'NOOR',
    this.showHourNumbers = false,
    this.useArabicIndicDigits = true,
    this.hourNumberBuilder,
    this.hourNumberStyle,
    this.enableShine = true,
  });

  @override
  State<StandardGlassClock> createState() => _StandardGlassClockState();
}

class _StandardGlassClockState extends State<StandardGlassClock>
    with TickerProviderStateMixin {
  // Entrance Animation
  late AnimationController _entranceController;
  late Animation<double> _opacityAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _translateAnimation;

  // Shine Animation
  late AnimationController _shineController;
  late Animation<double> _shineAnimation;

  // Real-time Clock Engine (Sweeping motion)
  late Ticker _clockTicker;
  final ValueNotifier<DateTime> _timeNotifier = ValueNotifier(DateTime.now());

  late DateTime _anchorVirtualNow;
  late DateTime _anchorSystemNow;

  @override
  void initState() {
    super.initState();

    _anchorVirtualNow = widget.baseTime;
    _anchorSystemNow = DateTime.now();
    _timeNotifier.value = widget.baseTime;

    // 1. Setup Entrance Animation (1.2s cubic-bezier(0.16, 1, 0.3, 1))
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    final CurvedAnimation entranceCurve = CurvedAnimation(
      parent: _entranceController,
      curve: const Cubic(0.16, 1.0, 0.3, 1.0),
    );

    _opacityAnimation =
        Tween<double>(begin: 0.0, end: 1.0).animate(entranceCurve);
    _scaleAnimation =
        Tween<double>(begin: 0.9, end: 1.0).animate(entranceCurve);

    _translateAnimation = Tween<Offset>(
      begin: const Offset(0.0, 30.0),
      end: Offset.zero,
    ).animate(entranceCurve);

    _entranceController.forward();

    // 2. Setup Shine Animation (6s infinite, moving -1.5 to 1.5 in the first 50%)
    _shineController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    );

    _shineAnimation = Tween<double>(begin: -1.5, end: 1.5).animate(
      CurvedAnimation(
        parent: _shineController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeInOut),
      ),
    );

    _syncShineState();
    // 3. Setup Clock Ticker for high-fidelity sweeping motion
    _clockTicker = createTicker((_) {
      final elapsed = DateTime.now().difference(_anchorSystemNow);
      _timeNotifier.value = _anchorVirtualNow.add(elapsed);
    });
    _clockTicker.start();
  }

  @override
  void didUpdateWidget(covariant StandardGlassClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    final drift =
        widget.baseTime.difference(_timeNotifier.value).inMilliseconds.abs();
    if (drift > 1500 || oldWidget.baseTime != widget.baseTime) {
      _anchorVirtualNow = widget.baseTime;
      _anchorSystemNow = DateTime.now();
      _timeNotifier.value = widget.baseTime;
    }
    if (oldWidget.enableShine != widget.enableShine) {
      _syncShineState();
    }
  }

  void _syncShineState() {
    if (widget.enableShine) {
      _shineController.repeat();
    } else {
      _shineController
        ..stop()
        ..value = 0;
    }
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _shineController.dispose();
    _clockTicker.dispose();
    _timeNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double clockSize = widget.size;

    return Center(
      child: AnimatedBuilder(
        animation: _entranceController,
        builder: (context, child) {
          return Opacity(
            opacity: _opacityAnimation.value,
            child: Transform.translate(
              offset: _translateAnimation.value,
              child: Transform.scale(
                scale: _scaleAnimation.value,
                child: child,
              ),
            ),
          );
        },
        child: Container(
          width: clockSize,
          height: clockSize,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              // Outer drop shadow for depth
              BoxShadow(
                color: Color.fromRGBO(0, 0, 0, 0.4),
                offset: Offset(0, 25),
                blurRadius: 50.0,
              ),
            ],
          ),
          child: ClipOval(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
              child: Stack(
                children: [
                  // --- Base Glass Background & Border Highlighting ---
                  Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color.fromRGBO(255, 255, 255, 0.3),
                          Color.fromRGBO(255, 255, 255, 0.06),
                        ],
                        stops: [0.0, 0.2],
                      ),
                    ),
                    padding: const EdgeInsets.all(1.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color.fromRGBO(255, 255, 255, 0.02),
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.center,
                          colors: [
                            Color.fromRGBO(255, 255, 255, 0.25),
                            Colors.transparent,
                          ],
                          stops: [0.0, 0.15],
                        ),
                      ),
                    ),
                  ),

                  // --- Shine Animation Layer ---
                  if (widget.enableShine)
                    AnimatedBuilder(
                      animation: _shineController,
                      builder: (context, child) {
                        return FractionalTranslation(
                          translation: Offset(_shineAnimation.value, 0),
                          child: child,
                        );
                      },
                      child: Transform(
                        transform: Matrix4.skewX(-25 * math.pi / 180),
                        alignment: Alignment.center,
                        child: FractionallySizedBox(
                          widthFactor: 1.5,
                          heightFactor: 1.0,
                          child: Container(
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0.05),
                                  Color.fromRGBO(255, 255, 255, 0.25),
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0.1),
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0),
                                ],
                                stops: [
                                  0.0,
                                  0.20,
                                  0.25,
                                  0.30,
                                  0.50,
                                  0.55,
                                  0.60,
                                  1.0
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                  // --- Markers Container ---
                  ..._buildMarkers(clockSize),

                  // --- Numbers Layer (Optional) ---
                  if (widget.showHourNumbers) ..._buildHourNumbers(clockSize),

                  // --- Branding Text ---
                  Positioned(
                    top: clockSize * 0.25,
                    left: 0,
                    right: 0,
                    child: Text(
                      widget.brand,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: clockSize * 0.04,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 4.0,
                        color: const Color.fromRGBO(255, 255, 255, 0.7),
                        shadows: const [
                          Shadow(
                            color: Color.fromRGBO(0, 0, 0, 0.3),
                            blurRadius: 4.0,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // --- Real-time Sweeping Hands ---
                  ValueListenableBuilder<DateTime>(
                    valueListenable: _timeNotifier,
                    builder: (context, now, child) {
                      final ms = now.millisecond;
                      final seconds = now.second + (ms / 1000.0);
                      final minutes = now.minute + (seconds / 60.0);
                      final hours = (now.hour % 12) + (minutes / 60.0);

                      final secondAngle = seconds * 6 * math.pi / 180;
                      final minuteAngle = minutes * 6 * math.pi / 180;
                      final hourAngle = hours * 30 * math.pi / 180;

                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          Transform.rotate(
                            angle: hourAngle,
                            child: _buildHourHand(clockSize),
                          ),
                          Transform.rotate(
                            angle: minuteAngle,
                            child: _buildMinuteHand(clockSize),
                          ),
                          Transform.rotate(
                            angle: secondAngle,
                            child: _buildSecondHand(clockSize),
                          ),
                        ],
                      );
                    },
                  ),

                  // --- Center Pin ---
                  Center(
                    child: _buildCenterPin(clockSize),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // --- Widget Builders ---

  List<Widget> _buildMarkers(double clockSize) {
    return List.generate(60, (i) {
      final isMain = i % 5 == 0;
      final width = isMain ? 3.0 : 1.0;
      final height = isMain ? clockSize * 0.06 : clockSize * 0.025;

      return Transform.rotate(
        angle: i * 6 * math.pi / 180,
        child: Align(
          alignment: Alignment.topCenter,
          child: Padding(
            padding: EdgeInsets.only(top: clockSize * 0.03),
            child: Container(
              width: width,
              height: height,
              decoration: BoxDecoration(
                color: isMain
                    ? const Color.fromRGBO(255, 255, 255, 0.8)
                    : const Color.fromRGBO(255, 255, 255, 0.25),
                borderRadius: BorderRadius.circular(4.0),
                boxShadow: isMain
                    ? const [
                        BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.3),
                            blurRadius: 3,
                            offset: Offset(0, 1)),
                      ]
                    : const [
                        BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.2),
                            blurRadius: 2,
                            offset: Offset(0, 1)),
                      ],
              ),
              child: isMain
                  ? Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4.0),
                        border: const Border(
                          top: BorderSide(
                              color: Color.fromRGBO(255, 255, 255, 0.8),
                              width: 1.0),
                        ),
                      ),
                    )
                  : null,
            ),
          ),
        ),
      );
    });
  }

  List<Widget> _buildHourNumbers(double clockSize) {
    final style = widget.hourNumberStyle ??
        TextStyle(
          fontFamily: 'Cairo',
          fontSize: clockSize * 0.08,
          fontWeight: FontWeight.w800,
          color: const Color.fromRGBO(255, 255, 255, 0.8),
          shadows: const [
            Shadow(
                color: Color.fromRGBO(0, 0, 0, 0.5),
                blurRadius: 4,
                offset: Offset(0, 2)),
          ],
        );

    final radius = clockSize * 0.36;

    return List.generate(12, (index) {
      final hour = index == 0 ? 12 : index;
      final angle = ((hour * 30) - 90) * math.pi / 180;
      final dx = math.cos(angle) * radius;
      final dy = math.sin(angle) * radius;

      return Positioned.fill(
        child: Align(
          alignment: Alignment.center,
          child: Transform.translate(
            offset: Offset(dx, dy),
            child: Text(
              _formatHourNumber(hour),
              style: style,
            ),
          ),
        ),
      );
    });
  }

  String _formatHourNumber(int hour) {
    if (widget.hourNumberBuilder != null) {
      return widget.hourNumberBuilder!(hour);
    }

    final value = '$hour';
    if (!widget.useArabicIndicDigits) {
      return value;
    }

    const western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const arabicIndic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

    var output = value;
    for (var i = 0; i < western.length; i++) {
      output = output.replaceAll(western[i], arabicIndic[i]);
    }
    return output;
  }

  Widget _buildHourHand(double clockSize) {
    return SizedBox(
      width: clockSize,
      height: clockSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: (clockSize / 2) - (clockSize * 0.25),
            child: Container(
              width: clockSize * 0.018,
              height: clockSize * 0.25,
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 255, 255, 0.85),
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(
                  color: const Color.fromRGBO(255, 255, 255, 0.5),
                  width: 1.0,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.3),
                    blurRadius: 10.0,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9.0),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromRGBO(255, 255, 255, 0.9),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.2],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMinuteHand(double clockSize) {
    return SizedBox(
      width: clockSize,
      height: clockSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: (clockSize / 2) - (clockSize * 0.38),
            child: Container(
              width: clockSize * 0.012,
              height: clockSize * 0.38,
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 255, 255, 0.7),
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(
                  color: const Color.fromRGBO(255, 255, 255, 0.5),
                  width: 1.0,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.3),
                    blurRadius: 10.0,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9.0),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromRGBO(255, 255, 255, 0.9),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.15],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSecondHand(double clockSize) {
    final double handHeight = clockSize * 0.44;
    final double handWidth = clockSize * 0.005;
    final double tailHeight = math.max(clockSize * 0.08, 12.0);

    return SizedBox(
      width: clockSize,
      height: clockSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Main Body of Second Hand
          Positioned(
            top: (clockSize / 2) - handHeight,
            child: Container(
              width: handWidth,
              height: handHeight,
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 255, 255, 0.9),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(10.0),
                  topRight: Radius.circular(10.0),
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.4),
                    blurRadius: 6.0,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
            ),
          ),
          // Counterweight tail
          Positioned(
            top: clockSize / 2,
            child: Container(
              width: handWidth,
              height: tailHeight,
              decoration: const BoxDecoration(
                color: Color.fromRGBO(255, 255, 255, 0.5),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(4.0),
                  bottomRight: Radius.circular(4.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCenterPin(double clockSize) {
    final double pinSize = clockSize * 0.035;

    return Container(
      width: pinSize,
      height: pinSize,
      decoration: BoxDecoration(
        color: const Color.fromRGBO(255, 255, 255, 0.95),
        shape: BoxShape.circle,
        border: Border.all(
          color: const Color.fromRGBO(255, 255, 255, 0.6),
          width: 1.0,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(0, 0, 0, 0.4),
            blurRadius: 8.0,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Container(
          width: pinSize * 0.35,
          height: pinSize * 0.35,
          decoration: BoxDecoration(
            color: const Color(0xFF0F172A).withValues(alpha: 0.8),
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }
}
