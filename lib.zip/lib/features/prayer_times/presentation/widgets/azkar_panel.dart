import 'package:flutter/material.dart';
import 'package:noor_prayer_tv/core/theme/app_colors.dart';
import 'package:noor_prayer_tv/core/theme/app_styles.dart';
import 'package:noor_prayer_tv/core/theme/glass_panel.dart';
import 'package:noor_prayer_tv/core/tv/tv_remote_support.dart';

class AdhkarCategory {
  final String category;
  final List<String> items;

  AdhkarCategory({required this.category, required this.items});
}

class AdhkarPanel extends StatefulWidget {
  final List<AdhkarCategory> adhkarList;
  final String theme;

  const AdhkarPanel({
    super.key,
    required this.adhkarList,
    this.theme = 'emerald',
  });

  @override
  State<AdhkarPanel> createState() => _AdhkarPanelState();
}

class _AdhkarPanelState extends State<AdhkarPanel> {
  int _activeTab = 0;
  int _currentIndex = 0;

  void _next() {
    setState(() {
      _currentIndex =
          (_currentIndex + 1) % widget.adhkarList[_activeTab].items.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.adhkarList.isEmpty) return const SizedBox.shrink();

    final activeCategory = widget.adhkarList[_activeTab];
    final currentText = activeCategory.items[_currentIndex];

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Tabs
        Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: List.generate(widget.adhkarList.length, (i) {
            final isActive = i == _activeTab;
            return TvFocusable(
              onPressed: () {
                setState(() {
                  _activeTab = i;
                  _currentIndex = 0;
                });
              },
              borderRadius: BorderRadius.circular(12),
              focusColor: AppColors.neonEmerald,
              child: GlassPanel(
                theme: widget.theme,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                isHighlighted: isActive,
                child: isActive
                    ? ShaderMask(
                        shaderCallback: (bounds) =>
                            AppColors.goldTextGradient.createShader(bounds),
                        child: Text(
                          widget.adhkarList[i].category,
                          style: AppStyles.body.copyWith(
                              fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      )
                    : Text(
                        widget.adhkarList[i].category,
                        style: AppStyles.bodyMuted
                            .copyWith(fontWeight: FontWeight.bold),
                      ),
              ),
            );
          }),
        ),
        const SizedBox(height: 12),
        // Content card
        TvFocusable(
          onPressed: _next,
          borderRadius: BorderRadius.circular(16),
          focusColor: AppColors.primaryGold,
          child: GlassPanel(
            theme: widget.theme,
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 120),
              child: Center(
                child: Text(
                  currentText,
                  style: AppStyles.heading
                      .copyWith(fontSize: 20, color: AppColors.foreground),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "اضغط للتالي • ${_currentIndex + 1}/${activeCategory.items.length}",
          style: AppStyles.bodyMuted.copyWith(fontSize: 12),
        ),
      ],
    );
  }
}
