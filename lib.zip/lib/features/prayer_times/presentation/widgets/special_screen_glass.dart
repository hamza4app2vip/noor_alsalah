import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

import '../../../settings/domain/entities/app_settings.dart';

class SpecialScreenGlassBackground extends StatelessWidget {
  final AppSettings settings;
  final bool enabled;
  final String? customImagePath;

  const SpecialScreenGlassBackground({
    super.key,
    required this.settings,
    required this.enabled,
    this.customImagePath,
  });

  @override
  Widget build(BuildContext context) {
    final hasCustomImage =
        customImagePath != null && File(customImagePath!).existsSync();

    if (!enabled && !hasCustomImage) {
      return const ColoredBox(color: Colors.black);
    }

    return Stack(
      children: [
        if (hasCustomImage)
          Positioned.fill(
            child: Image.file(
              File(customImagePath!),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  const ColoredBox(color: Colors.black),
            ),
          )
        else if (enabled)
          Positioned.fill(child: _BackgroundShapes(settings: settings))
        else
          const Positioned.fill(child: ColoredBox(color: Colors.black)),
        Positioned.fill(
          child: Container(
            color: Colors.black.withValues(alpha: enabled ? 0.45 : 0.55),
          ),
        ),
      ],
    );
  }
}

class PureGlassPrayerFrame extends StatelessWidget {
  final Widget child;
  final AppSettings settings;
  final EdgeInsets padding;
  final double borderRadius;
  final bool highlighted;
  final bool useBackdropBlur;

  const PureGlassPrayerFrame({
    super.key,
    required this.child,
    required this.settings,
    this.padding = EdgeInsets.zero,
    this.borderRadius = 20.0,
    this.highlighted = false,
    this.useBackdropBlur = true,
  });

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    final accentColor =
        _parseHex(settings.pureGlassColor1, fallback: const Color(0xFF38BDF8));
    final baseText =
        _parseHex(settings.pureGlassTextColor, fallback: Colors.white);

    final glassBody = Container(
      decoration: BoxDecoration(
        color: highlighted
            ? baseText.withValues(alpha: 0.12)
            : baseText.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
          color: baseText.withValues(alpha: highlighted ? 0.28 : 0.14),
          width: 1.0,
        ),
      ),
      child: Stack(
        children: [
          if (highlighted)
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 4,
                decoration: BoxDecoration(
                  color: accentColor.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(borderRadius),
                    bottomLeft: Radius.circular(borderRadius),
                  ),
                ),
              ),
            ),
          Padding(
            padding: padding,
            child: Align(alignment: Alignment.center, child: child),
          ),
        ],
      ),
    );

    final canUseBlur = useBackdropBlur &&
        MediaQuery.of(context).orientation != Orientation.landscape;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        boxShadow: [
          BoxShadow(
            color: highlighted
                ? accentColor.withValues(alpha: 0.15)
                : const Color.fromRGBO(0, 0, 0, 0.25),
            offset: const Offset(0, 10),
            blurRadius: 20.0,
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: canUseBlur
            ? BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 12.0, sigmaY: 12.0),
                child: glassBody,
              )
            : glassBody,
      ),
    );
  }
}

class GlassToastSurface extends StatefulWidget {
  final Widget child;
  final double? width;
  final double height;
  final BorderRadius borderRadius;
  final EdgeInsets padding;
  final bool enableShine;

  const GlassToastSurface({
    super.key,
    required this.child,
    this.width,
    this.height = 48.0,
    this.borderRadius = const BorderRadius.all(Radius.circular(16.0)),
    this.padding = const EdgeInsets.symmetric(horizontal: 16.0),
    this.enableShine = true,
  });

  @override
  State<GlassToastSurface> createState() => _GlassToastSurfaceState();
}

class _GlassToastSurfaceState extends State<GlassToastSurface>
    with SingleTickerProviderStateMixin {
  late AnimationController _shineController;
  late Animation<double> _shineAnimation;

  @override
  void initState() {
    super.initState();
    _shineController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _shineAnimation = Tween<double>(begin: -1.5, end: 1.5).animate(
      CurvedAnimation(
        parent: _shineController,
        curve: const Interval(0.0, 0.40, curve: Curves.easeInOut),
      ),
    );
    _syncShineState();
  }

  @override
  void didUpdateWidget(covariant GlassToastSurface oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.enableShine != widget.enableShine) {
      _syncShineState();
    }
  }

  void _syncShineState() {
    if (widget.enableShine) {
      _shineController.repeat();
    } else {
      _shineController
        ..stop()
        ..value = 0;
    }
  }

  @override
  void dispose() {
    _shineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double frameWidth = widget.width ?? math.min(screenWidth - 80, 320.0);

    return Container(
      width: frameWidth,
      height: widget.height,
      decoration: BoxDecoration(
        borderRadius: widget.borderRadius,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            offset: const Offset(0, 15),
            blurRadius: 30.0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: widget.borderRadius,
        clipBehavior: Clip.antiAlias,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.02),
              borderRadius: widget.borderRadius,
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 0.5,
              ),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: widget.borderRadius,
                      border: Border(
                        top: BorderSide(
                          color: Colors.white.withValues(alpha: 0.3),
                          width: 1.5,
                        ),
                        left: BorderSide(
                          color: Colors.white.withValues(alpha: 0.2),
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                ),
                if (widget.enableShine)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15.0),
                      child: AnimatedBuilder(
                        animation: _shineController,
                        builder: (context, child) {
                          return FractionalTranslation(
                            translation: Offset(_shineAnimation.value, 0),
                            child: child,
                          );
                        },
                        child: Transform(
                          transform: Matrix4.skewX(-25 * math.pi / 180),
                          alignment: Alignment.center,
                          child: Container(
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0.1),
                                  Color.fromRGBO(255, 255, 255, 0.4),
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0.15),
                                  Color.fromRGBO(255, 255, 255, 0),
                                  Color.fromRGBO(255, 255, 255, 0),
                                ],
                                stops: [
                                  0.0,
                                  0.20,
                                  0.25,
                                  0.30,
                                  0.50,
                                  0.55,
                                  0.60,
                                  1.0
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                Padding(
                  padding: widget.padding,
                  child: Center(child: widget.child),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BackgroundShapes extends StatelessWidget {
  final AppSettings settings;
  const _BackgroundShapes({required this.settings});

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Stack(
      children: [
        _Shape(
          top: -size.height * 0.1,
          right: -size.width * 0.1,
          color: _parseHex(settings.pureGlassColor1,
              fallback: const Color(0xFF38BDF8)),
          size: size.width * 0.6,
        ),
        _Shape(
          bottom: -size.height * 0.1,
          left: -size.width * 0.1,
          color: _parseHex(settings.pureGlassColor2,
              fallback: const Color(0xFF818CF8)),
          size: size.width * 0.7,
        ),
        _Shape(
          top: size.height * 0.4,
          left: size.width * 0.6,
          color: _parseHex(settings.pureGlassColor3,
              fallback: const Color(0xFFE879F9)),
          size: size.width * 0.5,
          opacity: 0.2,
        ),
      ],
    );
  }
}

class _Shape extends StatelessWidget {
  final double? top;
  final double? bottom;
  final double? left;
  final double? right;
  final Color color;
  final double size;
  final double opacity;

  const _Shape({
    this.top,
    this.bottom,
    this.left,
    this.right,
    required this.color,
    required this.size,
    this.opacity = 0.4,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top,
      bottom: bottom,
      left: left,
      right: right,
      child: ImageFiltered(
        imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
        child: Opacity(
          opacity: opacity,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color),
          ),
        ),
      ),
    );
  }
}
