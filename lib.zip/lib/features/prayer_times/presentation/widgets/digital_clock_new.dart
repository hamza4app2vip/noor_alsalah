import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/utils/number_helper.dart';
import '../providers/timer_engine_provider.dart';

class DigitalClock extends ConsumerWidget {
  final bool showSeconds;
  final bool use24h;
  final bool useArabicIndicDigits;
  final bool showFullClock;
  final bool padTimesWithZero;
  final int offsetMinutes;
  final double? fontSize;
  final Color? color;
  final String? fontFamily;

  const DigitalClock({
    super.key,
    this.showSeconds = true,
    this.use24h = true,
    this.useArabicIndicDigits = true,
    this.showFullClock = false,
    this.padTimesWithZero = true,
    this.offsetMinutes = 0,
    this.fontFamily,
    this.fontSize,
    this.color,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // timerEngine.now is the single source of truth for both real and manual time.
    // It already applies the app's clock rules, so we do not re-apply local offset.
    final displayTime = ref.watch(timerEngineProvider.select((s) => s.now));

    int h = displayTime.hour;
    final m = displayTime.minute;
    final s = displayTime.second;
    String period = '';

    if (!use24h) {
      period = h >= 12 ? ' م' : ' ص';
      h = h % 12;
      if (h == 0) h = 12;
    }

    String hStr =
        padTimesWithZero ? h.toString().padLeft(2, '0') : h.toString();
    String mStr = m.toString().padLeft(2, '0');
    String sStr = s.toString().padLeft(2, '0');

    if (useArabicIndicDigits) {
      hStr = NumberHelper.format(hStr, true);
      mStr = NumberHelper.format(mStr, true);
      sStr = NumberHelper.format(sStr, true);
    }

    final hourMinSize = fontSize ?? 80.0;
    final secSize = showFullClock
        ? hourMinSize
        : (fontSize != null ? fontSize! * 0.35 : 28.0);
    final displayColor = color ?? Colors.white;

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      textDirection: TextDirection.ltr,
      children: [
        Text(
          hStr,
          style: TextStyle(
            fontSize: hourMinSize,
            fontWeight: FontWeight.w800,
            height: 1,
            letterSpacing: -2,
            fontFamily: fontFamily,
            color: displayColor,
            shadows: const [
              Shadow(
                  color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))
            ],
          ),
        ),
        const SizedBox(width: 5),
        Text(
          useArabicIndicDigits ? ' :' : ':',
          style: TextStyle(
            fontSize: hourMinSize * 0.8,
            fontWeight: FontWeight.w800,
            height: 1,
            fontFamily: fontFamily,
            color: displayColor,
            shadows: const [
              Shadow(
                  color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))
            ],
          ),
        ),
        const SizedBox(width: 5),
        Text(
          mStr,
          style: TextStyle(
            fontSize: hourMinSize,
            fontWeight: FontWeight.w800,
            height: 1,
            letterSpacing: -2,
            fontFamily: fontFamily,
            color: displayColor,
            shadows: const [
              Shadow(
                  color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))
            ],
          ),
        ),
        if (showSeconds || showFullClock) ...[
          const SizedBox(width: 5),
          if (showFullClock)
            Text(
              useArabicIndicDigits ? ' :' : ':',
              style: TextStyle(
                fontSize: hourMinSize * 0.8,
                fontWeight: FontWeight.w800,
                height: 1,
                fontFamily: fontFamily,
                color: displayColor,
                shadows: const [
                  Shadow(
                      color: Colors.black54,
                      blurRadius: 15,
                      offset: Offset(0, 4))
                ],
              ),
            ),
          if (showFullClock) const SizedBox(width: 5),
          Text(
            sStr,
            style: TextStyle(
              fontSize: secSize,
              fontWeight: FontWeight.w700,
              height: 1,
              fontFamily: fontFamily,
              color: showFullClock
                  ? displayColor
                  : displayColor.withValues(alpha: 0.7),
              shadows: const [
                Shadow(
                    color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))
              ],
            ),
          ),
        ],
        if (period.isNotEmpty) ...[
          const SizedBox(width: 12),
          Text(
            period,
            style: TextStyle(
              fontSize: hourMinSize * 0.35,
              fontWeight: FontWeight.w500,
              color: displayColor.withValues(alpha: 0.8),
              shadows: const [
                Shadow(
                    color: Colors.black87, blurRadius: 4, offset: Offset(0, 2))
              ],
            ),
          ),
        ]
      ],
    );
  }
}
