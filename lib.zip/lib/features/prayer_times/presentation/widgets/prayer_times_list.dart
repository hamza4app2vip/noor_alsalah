import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:noor_prayer_tv/core/theme/app_styles.dart';

import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/utils/number_helper.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../widgets/post_prayer_azkar_overlay.dart';

class PrayerTimeDisplay {
  final String id;
  final String nameAr;
  final String nameEn;
  final String time;
  final String? iqama;

  PrayerTimeDisplay({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.time,
    this.iqama,
  });
}

class PrayerTimesList extends StatefulWidget {
  final List<PrayerTimeDisplay> prayers;
  final String nextPrayerId;
  final String theme;
  final AppSettings? settings;

  const PrayerTimesList({
    super.key,
    required this.prayers,
    required this.nextPrayerId,
    this.theme = 'emerald',
    this.settings,
  });

  @override
  State<PrayerTimesList> createState() => _PrayerTimesListState();
}

class _PrayerTimesListState extends State<PrayerTimesList>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  int _testTapCount = 0;
  DateTime _lastTestTap = DateTime.now();

  static const Color _gold = Color(0xFFE2C473);
  static const Color _goldMuted = Color(0xFFB89B57);
  static const Color _cardBase = Color(0xFF0D3224);
  static const Color _cardGradientEnd = Color(0xFF144633);
  static const Color _activeTeal = Color(0xFF5CD8C4);
  static const Color _activeCardBase = Color(0xFF124F44);
  static const Color _activeCardEnd = Color(0xFF18685A);

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1250),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Widget _buildClassicPrayerCard({
    required bool isNext,
    required Widget child,
    required double cornerRadius,
  }) {
    final radius = BorderRadius.circular(cornerRadius);
    return ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: radius,
            gradient: LinearGradient(
              begin: Alignment.centerRight,
              end: Alignment.centerLeft,
              colors: isNext
                  ? [
                      _activeCardEnd.withValues(alpha: 0.92),
                      _activeCardBase.withValues(alpha: 0.88),
                    ]
                  : [
                      _cardGradientEnd.withValues(alpha: 0.88),
                      _cardBase.withValues(alpha: 0.84),
                    ],
            ),
            border: Border.all(
              color: isNext
                  ? _activeTeal.withValues(alpha: 0.78)
                  : _gold.withValues(alpha: 0.24),
              width: isNext ? 1.4 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.40),
                blurRadius: 18,
                spreadRadius: -5,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: (isNext ? _activeTeal : _goldMuted)
                    .withValues(alpha: isNext ? 0.20 : 0.08),
                blurRadius: isNext ? 24 : 14,
                spreadRadius: isNext ? 1 : 0,
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withValues(alpha: 0.08),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              if (isNext)
                PositionedDirectional(
                  start: 0,
                  top: 14,
                  bottom: 14,
                  child: Container(
                    width: 6,
                    decoration: BoxDecoration(
                      color: _activeTeal,
                      borderRadius: BorderRadius.circular(cornerRadius * 0.36),
                      boxShadow: [
                        BoxShadow(
                          color: _activeTeal.withValues(alpha: 0.36),
                          blurRadius: 18,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                ),
              child,
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIqamaBadge(
    String value, {
    required bool isNext,
    required double fontSize,
    required bool shouldDim,
  }) {
    return Container(
      constraints: const BoxConstraints(minWidth: 68),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isNext
              ? [
                  _gold.withValues(alpha: 0.96),
                  _goldMuted.withValues(alpha: 0.92),
                ]
              : [
                  Colors.white.withValues(alpha: 0.13),
                  Colors.white.withValues(alpha: 0.05),
                ],
        ),
        border: Border.all(
          color: isNext
              ? _gold.withValues(alpha: 0.30)
              : Colors.white.withValues(alpha: 0.12),
        ),
      ),
      child: Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
          fontFamily: widget.settings?.timesFontFamily,
          color: isNext
              ? const Color(0xFF09241A)
              : Colors.white.withValues(alpha: shouldDim ? 0.54 : 0.78),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = widget.settings;
    final mediaQuery = MediaQuery.of(context);
    final isLandscape = mediaQuery.orientation == Orientation.landscape;
    final compactPortrait = !isLandscape &&
        (widget.prayers.length > 6 || mediaQuery.size.height < 860);

    bool shouldCenter = false;
    if (settings != null) {
      if (isLandscape && settings.centerPrayerNamesLandscape) {
        shouldCenter = true;
      }
      if (!isLandscape && settings.centerPrayerNamesPortrait) {
        shouldCenter = true;
      }
    }

    final shouldEnlarge =
        isLandscape && (settings?.enlargePrayerNamesLandscape ?? false);
    final showOtherLanguage = settings?.showPrayerNameInOtherLanguage ?? false;

    final baseNameSize = settings?.prayerNameFontSize ?? 22.0;
    final baseTimeSize = settings?.prayerTimeFontSize ?? 24.0;
    final baseIqamaSize = settings?.iqamaTimeFontSize ?? 18.0;

    final portraitNameScale = compactPortrait ? 0.92 : 0.97;
    final portraitTimeScale = compactPortrait ? 0.90 : 0.95;
    final portraitIqamaScale = compactPortrait ? 0.88 : 0.93;

    final nameSize = (shouldEnlarge ? baseNameSize * 1.24 : baseNameSize) *
        (isLandscape ? 1.0 : portraitNameScale);
    final timeSize = (shouldEnlarge ? baseTimeSize * 1.18 : baseTimeSize) *
        (isLandscape ? 1.0 : portraitTimeScale);
    final iqamaSize = (shouldEnlarge ? baseIqamaSize * 1.10 : baseIqamaSize) *
        (isLandscape ? 1.0 : portraitIqamaScale);

    var hasReachedNextPrayer = false;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: widget.prayers.map((prayer) {
        final isNext = prayer.id == widget.nextPrayerId;
        if (isNext) hasReachedNextPrayer = true;

        final isPast = !hasReachedNextPrayer && !isNext;
        final shouldDim = isPast && (settings?.dimPastPrayers ?? false);

        var displayTime = prayer.time;
        if (settings?.padTimesWithZero == true) {
          if (displayTime.isNotEmpty &&
              displayTime[0] != '0' &&
              displayTime.contains(':') &&
              displayTime.indexOf(':') == 1) {
            displayTime = '0$displayTime';
          }
        }

        String? displayIqama = prayer.iqama;
        if (settings?.useArabicIndicDigits == true) {
          displayTime = NumberHelper.format(displayTime, true);
          if (displayIqama != null) {
            displayIqama = NumberHelper.format(displayIqama, true);
          }
        }

        if (settings?.showIqamaWithClock == true &&
            displayIqama != null &&
            displayIqama.isNotEmpty) {
          displayTime = '$displayTime | $displayIqama';
        }

        final enlargeNext =
            isNext && (settings?.enlargeNextPrayerCountdown ?? false);
        final cardCornerRadius =
            isLandscape ? 28.0 : (compactPortrait ? 30.0 : 34.0);
        final verticalMargin =
            isLandscape ? (enlargeNext ? 8.0 : 5.0) : (enlargeNext ? 6.0 : 4.0);
        final panelScale = enlargeNext ? (isLandscape ? 1.04 : 1.02) : 1.0;

        final primaryName =
            settings?.languageCode == 'ar' ? prayer.nameAr : prayer.nameEn;
        final secondaryName =
            settings?.languageCode == 'ar' ? prayer.nameEn : prayer.nameAr;
        final primaryNameText = isNext
            ? ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [_gold, _activeTeal],
                ).createShader(bounds),
                child: Text(
                  primaryName,
                  style: AppStyles.heading.copyWith(
                    fontSize: nameSize * (enlargeNext ? 1.05 : 1.0),
                    color: Colors.white,
                    fontFamily: settings?.timesFontFamily,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              )
            : Text(
                primaryName,
                style: AppStyles.heading.copyWith(
                  fontSize: nameSize,
                  fontFamily: settings?.timesFontFamily,
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              );

        final prayerNameWidget = Expanded(
          child: Row(
            mainAxisAlignment: shouldCenter
                ? MainAxisAlignment.center
                : (settings?.centerNameWithTimesOnSides == true
                    ? MainAxisAlignment.center
                    : MainAxisAlignment.end),
            textDirection: settings?.languageCode == 'ar'
                ? TextDirection.rtl
                : TextDirection.ltr,
            children: [
              primaryNameText,
              if (showOtherLanguage && secondaryName.isNotEmpty) ...[
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    secondaryName,
                    overflow: TextOverflow.ellipsis,
                    style: AppStyles.bodyMuted.copyWith(
                      fontSize: nameSize * 0.50,
                      fontFamily: settings?.timesFontFamily,
                      color: isNext
                          ? _activeTeal.withValues(alpha: 0.90)
                          : Colors.white70,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ],
          ),
        );

        final adhanTimeWidget = Expanded(
          child: Center(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                displayTime,
                textDirection: TextDirection.ltr,
                style: AppStyles.timeMedium.copyWith(
                  fontSize: timeSize * (enlargeNext ? 1.08 : 1.0),
                  fontFamily: settings?.timesFontFamily,
                  color: isNext ? _activeTeal : _gold,
                  fontWeight: FontWeight.w900,
                  shadows: [
                    Shadow(
                      color: (isNext ? _activeTeal : _gold)
                          .withValues(alpha: 0.18),
                      blurRadius: 14,
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        );

        final iqamaTimeWidget = (settings?.hideIqamaTime != true)
            ? Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: _buildIqamaBadge(
                    displayIqama ?? '—',
                    isNext: isNext,
                    fontSize: iqamaSize * (enlargeNext ? 1.02 : 1.0),
                    shouldDim: shouldDim,
                  ),
                ),
              )
            : const SizedBox.shrink();

        List<Widget> rowChildren;
        if (settings?.centerNameWithTimesOnSides == true) {
          rowChildren = [
            adhanTimeWidget,
            prayerNameWidget,
            if (settings?.hideIqamaTime != true) iqamaTimeWidget,
          ];
        } else {
          rowChildren = [
            prayerNameWidget,
            adhanTimeWidget,
            if (settings?.hideIqamaTime != true) iqamaTimeWidget,
          ];
        }

        Widget panel = Transform.scale(
          scale: panelScale,
          child: _buildClassicPrayerCard(
            isNext: isNext,
            cornerRadius: cardCornerRadius,
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: isLandscape ? 16 : (compactPortrait ? 18 : 20),
                vertical: isLandscape
                    ? (enlargeNext ? 16 : 13)
                    : (enlargeNext ? 13 : (compactPortrait ? 10.5 : 11.5)),
              ),
              child: Opacity(
                opacity: shouldDim ? 0.45 : 1.0,
                child: Row(
                  mainAxisAlignment: shouldCenter
                      ? MainAxisAlignment.center
                      : MainAxisAlignment.spaceBetween,
                  children: rowChildren,
                ),
              ),
            ),
          ),
        );

        if (prayer.id == 'dhuhr' || prayer.id == 'asr') {
          panel = TvFocusable(
            onPressed: () {
              final now = DateTime.now();
              if (now.difference(_lastTestTap).inMilliseconds > 500) {
                _testTapCount = 1;
              } else {
                _testTapCount++;
              }
              _lastTestTap = now;

              if (_testTapCount >= 3) {
                _testTapCount = 0;
                PostPrayerAzkarOverlay.of(context)?.showAzkarForTesting();
              }
            },
            borderRadius: BorderRadius.circular(cardCornerRadius),
            focusColor: _gold,
            child: panel,
          );
        }

        if (isNext) {
          panel = AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: verticalMargin),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(cardCornerRadius),
                  boxShadow: [
                    BoxShadow(
                      color: _activeTeal.withValues(
                          alpha: 0.14 * _pulseAnimation.value),
                      blurRadius: 18 * (enlargeNext ? 1.15 : 1.0),
                      spreadRadius:
                          4 * _pulseAnimation.value * (enlargeNext ? 1.4 : 1.0),
                    ),
                  ],
                ),
                child: child,
              );
            },
            child: panel,
          );
        } else {
          panel = Padding(
            padding: EdgeInsets.symmetric(vertical: verticalMargin),
            child: panel,
          );
        }

        return panel;
      }).toList(),
    );
  }
}
