import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:noor_prayer_tv/core/services/weather_provider.dart';
import 'package:noor_prayer_tv/core/theme/app_colors.dart';
import 'package:noor_prayer_tv/core/theme/app_styles.dart';
import 'package:noor_prayer_tv/core/widgets/premium_glass_navbar.dart';

class AppHeader extends ConsumerWidget {
  final String theme;
  final String? mosqueIconPath;
  final VoidCallback onSettingsTap;
  final String locationText;
  final bool showPalestineFlag;
  final String mosqueName;

  const AppHeader({
    super.key,
    required this.theme,
    required this.onSettingsTap,
    required this.mosqueName,
    required this.locationText,
    this.mosqueIconPath,
    this.showPalestineFlag = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weatherAsync = ref.watch(weatherForecastProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black;
    final shadowColor =
        isDark ? const Color.fromRGBO(0, 0, 0, 0.3) : Colors.transparent;

    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 920),
      child: PremiumGlassSurface(
        borderRadius: 30.0,
        shadowColor: shadowColor,
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
        child: Row(
          children: [
            _HeaderButton(
              icon: Icons.settings,
              onTap: onSettingsTap,
              iconColor: AppColors.mutedForeground,
              shadowColor: shadowColor,
            ),
            const SizedBox(width: 12),
            weatherAsync.when(
              data: (forecasts) {
                if (forecasts == null || forecasts.isEmpty) {
                  return const SizedBox.shrink();
                }
                final today = forecasts.first;
                return PremiumGlassSurface(
                  borderRadius: 22.0,
                  shadowColor: shadowColor.withValues(alpha: 0.7),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.cloud_queue_rounded,
                        color: AppColors.primaryGold,
                        size: 22,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${today.maxTemp.round()}° / ${today.minTemp.round()}°',
                        style: TextStyle(
                          color: textColor,
                          fontFamily: 'Cairo',
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                );
              },
              loading: () => PremiumGlassSurface(
                borderRadius: 22.0,
                shadowColor: shadowColor.withValues(alpha: 0.7),
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.primaryGold,
                  ),
                ),
              ),
              error: (e, st) => const SizedBox.shrink(),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) =>
                              AppColors.goldTextGradient.createShader(bounds),
                          child: Text(
                            mosqueName,
                            textAlign: TextAlign.end,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppStyles.heading.copyWith(
                              fontSize: 18,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (showPalestineFlag)
                              const Padding(
                                padding: EdgeInsets.only(left: 4.0),
                                child: Text('🇵🇸',
                                    style: TextStyle(fontSize: 16)),
                              ),
                            Flexible(
                              child: Text(
                                locationText,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: AppStyles.bodyMuted.copyWith(
                                  fontSize: 12,
                                  color: textColor.withValues(alpha: 0.82),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  _MosqueIconCard(
                    mosqueIconPath: mosqueIconPath,
                    shadowColor: shadowColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color iconColor;
  final Color shadowColor;

  const _HeaderButton({
    required this.icon,
    required this.onTap,
    required this.iconColor,
    required this.shadowColor,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: PremiumGlassSurface(
        width: 52,
        height: 52,
        borderRadius: 22.0,
        shadowColor: shadowColor,
        child: Icon(icon, color: iconColor, size: 26),
      ),
    );
  }
}

class _MosqueIconCard extends StatelessWidget {
  final String? mosqueIconPath;
  final Color shadowColor;

  const _MosqueIconCard(
      {required this.mosqueIconPath, required this.shadowColor});

  @override
  Widget build(BuildContext context) {
    return PremiumGlassSurface(
      width: 54,
      height: 54,
      borderRadius: 18.0,
      shadowColor: shadowColor,
      padding: const EdgeInsets.all(4),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: mosqueIconPath != null
            ? Image.file(
                File(mosqueIconPath!),
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Container(color: AppColors.primaryGold),
              )
            : Image.asset(
                'assets/images/logo.jpg',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Container(color: AppColors.primaryGold),
              ),
      ),
    );
  }
}
