
import 'package:flutter/material.dart';
import 'package:marquee/marquee.dart';

class MarqueeBanner extends StatelessWidget {
  final List<String> texts;
  final String theme;

  const MarqueeBanner({
    super.key,
    required this.texts,
    this.theme = 'emerald',
  });

  @override
  Widget build(BuildContext context) {
    if (texts.isEmpty) return const SizedBox.shrink();

    final fullText = "${texts.join("   ✦   ")}   ✦   ";

    return SizedBox(
      height: 30,
      child: Marquee(
        text: fullText,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Color(0xFFE5E7EB),
          shadows: [Shadow(color: Colors.black87, blurRadius: 4, offset: Offset(0, 2))],
        ),
        scrollAxis: Axis.horizontal,
        crossAxisAlignment: CrossAxisAlignment.center,
        blankSpace: 20.0,
        velocity: 30.0,
        pauseAfterRound: const Duration(seconds: 0),
        startPadding: 10.0,
        accelerationDuration: const Duration(seconds: 0),
        accelerationCurve: Curves.linear,
        decelerationDuration: const Duration(seconds: 0),
        decelerationCurve: Curves.linear,
        textDirection: TextDirection.rtl,
      ),
    );
  }
}
