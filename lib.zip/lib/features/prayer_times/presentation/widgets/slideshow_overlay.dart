import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:noor_prayer_tv/core/local_server/marquee_trigger_provider.dart';
import 'package:noor_prayer_tv/core/theme/app_colors.dart';
import 'package:noor_prayer_tv/core/tv/tv_remote_support.dart';
import 'package:noor_prayer_tv/features/prayer_times/presentation/providers/timer_engine_provider.dart';
import 'package:noor_prayer_tv/features/settings/domain/entities/app_settings.dart';
import 'package:noor_prayer_tv/features/settings/domain/entities/slide_item.dart';
import 'package:noor_prayer_tv/features/settings/presentation/providers/settings_provider.dart';
import 'package:path_provider/path_provider.dart';

class SlideshowOverlay extends ConsumerStatefulWidget {
  final Widget child;
  const SlideshowOverlay({super.key, required this.child});

  @override
  ConsumerState<SlideshowOverlay> createState() => _SlideshowOverlayState();
}

class _SlideshowOverlayState extends ConsumerState<SlideshowOverlay>
    with SingleTickerProviderStateMixin {
  Timer? _slideTimer;
  bool _isShowingSlides = false;
  int _currentSlideIndex = 0;
  List<SlideItem> _activeSlides = [];
  String _appDirPath = '';
  late AnimationController _progressController;
  DateTime? _currentSlideEndsAt;
  bool _didInitialManualKickoff = false;

  @override
  void initState() {
    super.initState();
    _initPath();
    _progressController = AnimationController(vsync: this);
  }

  Future<void> _initPath() async {
    final dir = await getApplicationDocumentsDirectory();
    setState(() {
      _appDirPath = '${dir.path}/slides';
    });
  }

  @override
  void dispose() {
    _slideTimer?.cancel();
    _progressController.dispose();
    super.dispose();
  }

  int _normalizedDuration(int value) => value < 1 ? 1 : value;

  void _finishSlidesSession() {
    _slideTimer?.cancel();
    _slideTimer = null;
    _currentSlideEndsAt = null;
    _progressController.stop();
    _progressController.value = 0.0;
    if (_isShowingSlides && mounted) {
      setState(() => _isShowingSlides = false);
    }
  }

  void _refreshActiveSlides(AppSettings settings, {bool reshuffle = false}) {
    _activeSlides = settings.slidesList
        .map((e) => SlideItem.fromJson(e))
        .where((s) => s.enabled)
        .toList();

    if (settings.slidesShuffle && reshuffle) {
      _activeSlides.shuffle();
    }

    if (_activeSlides.isNotEmpty &&
        _currentSlideIndex >= _activeSlides.length) {
      _currentSlideIndex = 0;
    }
  }

  void _startSlidesSession() {
    final settings = ref.read(settingsNotifierProvider);
    if (settings.slidesShowMode == 'OFF') {
      _finishSlidesSession();
      return;
    }

    _refreshActiveSlides(settings, reshuffle: true);
    if (_activeSlides.isEmpty) {
      _finishSlidesSession();
      return;
    }

    _currentSlideIndex = 0;
    _showCurrentSlide(settings);
  }

  void _showCurrentSlide(AppSettings settings) {
    if (_activeSlides.isEmpty || _currentSlideIndex >= _activeSlides.length) {
      _finishSlidesSession();
      return;
    }

    final currentSlide = _activeSlides[_currentSlideIndex];
    final durationSeconds = _normalizedDuration(
        currentSlide.durationSeconds ?? settings.slideDurationSeconds);

    _slideTimer?.cancel();
    _currentSlideEndsAt =
        DateTime.now().add(Duration(seconds: durationSeconds));
    _progressController
      ..duration = Duration(seconds: durationSeconds)
      ..forward(from: 0.0);

    if (mounted) {
      setState(() => _isShowingSlides = true);
    }

    _slideTimer =
        Timer(Duration(seconds: durationSeconds), _onCurrentSlideFinished);
  }

  void _onCurrentSlideFinished() {
    if (!mounted) return;

    // Core logic fix:
    // If current slide is the last (or the only slide), we end the slideshow session
    // and return to main prayer times view with no running timer.
    final isLastSlide = _currentSlideIndex >= (_activeSlides.length - 1);
    if (isLastSlide) {
      _finishSlidesSession();
      return;
    }

    _currentSlideIndex++;
    final settings = ref.read(settingsNotifierProvider);
    _showCurrentSlide(settings);
  }

  void _setupTimer({bool forceRestart = false, bool startWithSlides = false}) {
    final settings = ref.read(settingsNotifierProvider);
    if (settings.slidesShowMode == 'OFF') {
      _finishSlidesSession();
      return;
    }

    if (forceRestart) {
      _finishSlidesSession();
    }

    if (settings.slidesShowMode == 'AFTER_PRAYER') {
      if (startWithSlides) {
        _startSlidesSession();
      }
      return;
    }

    if (_slideTimer == null || !_slideTimer!.isActive || forceRestart) {
      _startSlidesSession();
    }
  }

  Widget _cleanText(String text, TextStyle style, {TextAlign? align}) {
    return Text(
      text,
      style: style.copyWith(
        decoration: TextDecoration.none,
        decorationColor: Colors.transparent,
      ),
      textAlign: align,
      textDirection: TextDirection.rtl,
    );
  }

  Widget _buildSlideContent(SlideItem slide, AppSettings settings) {
    switch (slide.type) {
      case 'FILE':
        final normalizedContent = slide.content
            .replaceFirst(RegExp(r'^/slides/'), '')
            .replaceFirst(RegExp(r'^/+'), '');
        final path = '$_appDirPath/$normalizedContent';
        return Image.file(
          File(path),
          fit: BoxFit.cover,
          width: double.infinity,
          height: double.infinity,
          errorBuilder: (ctx, err, stack) => const Center(
            child: Icon(Icons.broken_image, color: Colors.white54, size: 100),
          ),
        );
      case 'LINK':
        return Image.network(
          slide.content,
          fit: BoxFit.cover,
          width: double.infinity,
          height: double.infinity,
          errorBuilder: (ctx, err, stack) => const Center(
            child: Icon(Icons.broken_image, color: Colors.white54, size: 100),
          ),
        );
      case 'TEXT':
      default:
        return Stack(
          children: [
            Positioned.fill(
              child: ClipRRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10.8, sigmaY: 10.8),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withValues(alpha: 0.05),
                          Colors.transparent,
                          Colors.black.withValues(alpha: 0.05),
                        ],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Center(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 60),
                constraints: const BoxConstraints(maxWidth: 1000),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _cleanText(
                      slide.content.replaceAll('|', '\n'),
                      TextStyle(
                        fontSize: 64,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        fontFamily: settings.textFontFamily,
                        height: 1.4,
                        letterSpacing: -0.5,
                        shadows: [
                          Shadow(
                            color: Colors.black.withValues(alpha: 0.8),
                            offset: const Offset(0, 8),
                            blurRadius: 20,
                          ),
                          Shadow(
                            color: Colors.white.withValues(alpha: 0.1),
                            offset: const Offset(0, 0),
                            blurRadius: 30,
                          ),
                        ],
                      ),
                      align: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);

    ref.listen<String?>(marqueeTriggerProvider, (prev, next) {
      if (next != null && _isShowingSlides) {
        _finishSlidesSession();
      }
    });

    ref.listen(settingsNotifierProvider, (prev, next) {
      bool listChanged = false;
      if (prev != null) {
        final prevJson = prev.slidesList.map((e) => jsonEncode(e)).toList();
        final nextJson = next.slidesList.map((e) => jsonEncode(e)).toList();
        if (prevJson.join() != nextJson.join()) {
          listChanged = true;
        }
      }

      if (listChanged ||
          prev?.slidesShuffle != next.slidesShuffle ||
          prev?.slidesShowMode != next.slidesShowMode ||
          prev?.slideDurationSeconds != next.slideDurationSeconds) {
        _setupTimer(forceRestart: true);
      }
    });

    ref.listen<TimerState>(timerEngineProvider, (prev, next) {
      final mode = ref.read(settingsNotifierProvider).slidesShowMode;
      if (mode == 'AFTER_PRAYER') {
        if ((prev?.phase == PrayerPhase.blackScreen ||
                prev?.phase == PrayerPhase.iqama ||
                prev?.phase == PrayerPhase.adhan) &&
            next.phase == PrayerPhase.countdown) {
          _setupTimer(forceRestart: true, startWithSlides: true);
        } else if (next.phase != PrayerPhase.countdown) {
          _finishSlidesSession();
        }
      }
    });

    if (!_didInitialManualKickoff &&
        _slideTimer == null &&
        !_isShowingSlides &&
        settings.slidesShowMode == 'MANUAL') {
      _didInitialManualKickoff = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _setupTimer();
      });
    }

    return Stack(
      children: [
        widget.child,
        if (_isShowingSlides && _activeSlides.isNotEmpty)
          Positioned.fill(
            child: TvFocusable(
              onPressed: _finishSlidesSession,
              borderRadius: BorderRadius.zero,
              focusColor: AppColors.primaryGold,
              child: Container(
                decoration: const BoxDecoration(color: Colors.transparent),
                child: DefaultTextStyle.merge(
                  style: const TextStyle(
                    decoration: TextDecoration.none,
                    decorationColor: Colors.transparent,
                  ),
                  child: Material(
                    type: MaterialType.transparency,
                    child: AnimatedSwitcher(
                      duration: Duration.zero,
                      child: KeyedSubtree(
                        key: ValueKey(_currentSlideIndex),
                        child: _buildSlideContent(
                          _activeSlides[_currentSlideIndex],
                          settings,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        if (_isShowingSlides && _activeSlides.isNotEmpty)
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Center(
              child: AnimatedBuilder(
                animation: _progressController,
                builder: (context, child) {
                  final remainingMs = _currentSlideEndsAt == null
                      ? 0
                      : _currentSlideEndsAt!
                          .difference(DateTime.now())
                          .inMilliseconds;
                  final roundedRemaining =
                      remainingMs <= 0 ? 0 : ((remainingMs + 999) ~/ 1000);

                  return ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.2),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.2),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                SizedBox(
                                  width: 44,
                                  height: 44,
                                  child: CircularProgressIndicator(
                                    value: 1.0 - _progressController.value,
                                    strokeWidth: 3,
                                    color: AppColors.goldAccent,
                                    backgroundColor:
                                        Colors.white.withValues(alpha: 0.1),
                                  ),
                                ),
                                _cleanText(
                                  '$roundedRemaining',
                                  const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Cairo',
                                    height: 1,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(width: 16),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _cleanText(
                                  'ثانية متبقية',
                                  const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Cairo',
                                    height: 1,
                                  ),
                                ),
                                _cleanText(
                                  'عرض الشريحة',
                                  TextStyle(
                                    color: Colors.white.withValues(alpha: 0.6),
                                    fontSize: 11,
                                    fontFamily: 'Cairo',
                                    height: 1.2,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}
