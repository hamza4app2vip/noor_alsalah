import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

class LuxuryRoyalIslamicClock extends StatefulWidget {
  final DateTime baseTime;
  final double size;
  final String brand;
  final bool showHourNumbers;
  final bool useArabicIndicDigits;

  const LuxuryRoyalIslamicClock({
    super.key,
    required this.baseTime,
    this.size = 300,
    this.brand = 'نُور',
    this.showHourNumbers = true,
    this.useArabicIndicDigits = true,
  });

  @override
  State<LuxuryRoyalIslamicClock> createState() => _LuxuryRoyalIslamicClockState();
}

class _LuxuryRoyalIslamicClockState extends State<LuxuryRoyalIslamicClock>
    with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  final ValueNotifier<DateTime> _timeNotifier = ValueNotifier(DateTime.now());
  late DateTime _anchorVirtualNow;
  late DateTime _anchorSystemNow;

  // --- Royal Light Palette Constants ---
  static const Color ivoryLight = Color(0xFFFDFBF7);
  static const Color ivoryMid = Color(0xFFF2EDE4);
  static const Color ivoryDark = Color(0xFFE3D9C8);
  
  static const Color champagneLight = Color(0xFFF2E3C6);
  static const Color champagneMid = Color(0xFFCBAA7B);
  static const Color champagneDark = Color(0xFF9A7B4F);
  
  static const Color bronzeText = Color(0xFF6B5B4B);
  
  static const Color shadowSoft = Color(0x268A7967); // 0.15 opacity
  static const Color shadowDeep = Color(0x406B553E); // 0.25 opacity

  @override
  void initState() {
    super.initState();
    _anchorVirtualNow = widget.baseTime;
    _anchorSystemNow = DateTime.now();
    _timeNotifier.value = widget.baseTime;

    _ticker = createTicker((_) {
      final elapsed = DateTime.now().difference(_anchorSystemNow);
      _timeNotifier.value = _anchorVirtualNow.add(elapsed);
    });
    _ticker.start();
  }

  @override
  void didUpdateWidget(covariant LuxuryRoyalIslamicClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    final drift = widget.baseTime.difference(_timeNotifier.value).inMilliseconds.abs();
    if (drift > 1500 || oldWidget.baseTime != widget.baseTime) {
      _anchorVirtualNow = widget.baseTime;
      _anchorSystemNow = DateTime.now();
      _timeNotifier.value = widget.baseTime;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    _timeNotifier.dispose();
    super.dispose();
  }

  String _getArabicDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    const englishToArabic = {'0': '٠', '1': '١', '2': '٢', '3': '٣', '4': '٤', '5': '٥', '6': '٦', '7': '٧', '8': '٨', '9': '٩'};
    return day.split('').map((e) => englishToArabic[e] ?? e).join('');
  }

  @override
  Widget build(BuildContext context) {
    final double clockSize = widget.size;
    final double paddingSize = clockSize * 0.025;
    final double dialSize = clockSize - (paddingSize * 2);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Center(
        child: Container(
          width: clockSize,
          height: clockSize,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(color: shadowDeep, offset: Offset(0, 25), blurRadius: 50.0, spreadRadius: -10.0),
              BoxShadow(color: shadowSoft, offset: Offset(0, 10), blurRadius: 20.0, spreadRadius: -5.0),
            ],
            gradient: SweepGradient(
              colors: [
                champagneMid, champagneLight, ivoryLight, champagneLight,
                champagneMid, champagneDark, champagneMid, champagneLight,
                ivoryLight, champagneLight, champagneMid,
              ],
              stops: [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
            ),
          ),
          child: Stack(
            children: [
              CustomPaint(painter: _CaseInsetShadowPainter(), size: Size.infinite),
              Center(
                child: Container(
                  width: dialSize,
                  height: dialSize,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      center: Alignment(0.0, -0.2),
                      radius: 0.8,
                      colors: [ivoryLight, ivoryMid, ivoryDark],
                      stops: [0.0, 0.7, 1.0],
                    ),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CustomPaint(painter: _DialInsetShadowPainter(), size: Size.infinite),
                      Opacity(
                        opacity: 0.15,
                        child: SizedBox(
                          width: dialSize * 0.75,
                          height: dialSize * 0.75,
                          child: CustomPaint(painter: _IslamicPatternPainter()),
                        ),
                      ),
                      _buildRing(dialSize * 0.96, const Color.fromRGBO(203, 170, 123, 0.3), innerWhiteShadow: true),
                      _buildRing(dialSize * 0.64, const Color.fromRGBO(203, 170, 123, 0.15)),
                      Positioned(
                        top: dialSize * 0.26,
                        child: Column(
                          children: [
                            Text(
                              widget.brand,
                              style: TextStyle(
                                fontFamily: 'Amiri',
                                fontSize: clockSize * 0.08,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 4.0,
                                color: champagneDark,
                                shadows: const [Shadow(color: Color.fromRGBO(255, 255, 255, 0.8), offset: Offset(1, 1), blurRadius: 0)],
                              ),
                            ),
                            const SizedBox(height: 3.0),
                            Text(
                              'ROYAL TIMEPIECE',
                              style: TextStyle(
                                fontSize: clockSize * 0.03,
                                letterSpacing: 2.0,
                                color: Colors.white.withValues(alpha: 0.1),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        bottom: dialSize * 0.20,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            vertical: clockSize * 0.005,
                            horizontal: clockSize * 0.018,
                          ),
                          decoration: BoxDecoration(
                            color: ivoryLight,
                            borderRadius: BorderRadius.circular(4.0),
                            border: Border.all(color: champagneMid, width: 1.0),
                            boxShadow: const [
                              BoxShadow(color: Color.fromRGBO(255, 255, 255, 0.9), offset: Offset(0, 1), blurRadius: 2.0),
                            ],
                          ),
                          child: ValueListenableBuilder<DateTime>(
                            valueListenable: _timeNotifier,
                            builder: (context, now, __) {
                              return Text(
                                _getArabicDate(now),
                                style: TextStyle(
                                  fontSize: clockSize * 0.06,
                                  fontWeight: FontWeight.bold,
                                  color: bronzeText,
                                  height: 1.1,
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      ..._buildTicks(clockSize, dialSize),
                      if (widget.showHourNumbers) ..._buildNumerals(clockSize, dialSize),
                      ValueListenableBuilder<DateTime>(
                        valueListenable: _timeNotifier,
                        builder: (context, now, child) {
                          final ms = now.millisecond;
                          final sec = now.second + (ms / 1000.0);
                          final min = now.minute + (sec / 60.0);
                          final hr = (now.hour % 12) + (min / 60.0);

                          final secAngle = sec * 6 * math.pi / 180;
                          final minAngle = min * 6 * math.pi / 180;
                          final hrAngle = hr * 30 * math.pi / 180;

                          return Stack(
                            alignment: Alignment.center,
                            children: [
                              Transform.rotate(
                                angle: hrAngle,
                                child: _buildLuxuryHand(
                                  clockSize: clockSize,
                                  dialSize: dialSize,
                                  widthRatio: 0.035,
                                  heightRatio: 0.24,
                                  pathBuilder: _getHourHandPath,
                                ),
                              ),
                              Transform.rotate(
                                angle: minAngle,
                                child: _buildLuxuryHand(
                                  clockSize: clockSize,
                                  dialSize: dialSize,
                                  widthRatio: 0.025,
                                  heightRatio: 0.38,
                                  pathBuilder: _getMinuteHandPath,
                                ),
                              ),
                              Transform.rotate(
                                angle: secAngle,
                                child: _buildSecondHand(clockSize, dialSize),
                              ),
                            ],
                          );
                        },
                      ),
                      _buildCenterPin(clockSize),
                      CustomPaint(painter: _GlassGlarePainter(), size: Size.infinite),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRing(double size, Color borderColor, {bool innerWhiteShadow = false}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: borderColor, width: 1.0),
        boxShadow: innerWhiteShadow ? const [BoxShadow(color: Color.fromRGBO(255, 255, 255, 0.5), blurRadius: 10.0, spreadRadius: -5.0)] : null,
      ),
    );
  }

  List<Widget> _buildTicks(double clockSize, double dialSize) {
    List<Widget> ticks = [];
    for (int i = 0; i < 60; i++) {
      final isHour = i % 5 == 0;
      final width = isHour ? clockSize * 0.015 : clockSize * 0.006;
      final height = isHour ? clockSize * 0.035 : clockSize * 0.020;
      final color = isHour ? champagneDark : champagneMid.withOpacity(0.6);
      
      ticks.add(
        Transform.rotate(
          angle: i * 6 * math.pi / 180,
          child: Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: EdgeInsets.only(top: dialSize * 0.02),
              child: Container(
                width: width,
                height: height,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(2.0),
                  boxShadow: const [BoxShadow(color: Color.fromRGBO(255, 255, 255, 0.8), offset: Offset(0, 1), blurRadius: 1.0)],
                ),
              ),
            ),
          ),
        ),
      );
    }
    return ticks;
  }

  List<Widget> _buildNumerals(double clockSize, double dialSize) {
    final westernNumerals = ['12', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'];
    final arabicNumerals = ['١٢', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '١٠', '١١'];
    
    final numeralsToUse = widget.useArabicIndicDigits ? arabicNumerals : westernNumerals;
    
    List<Widget> numerals = [];
    final double radius = dialSize * 0.355;

    for (int i = 0; i < 12; i++) {
      final String numStr = numeralsToUse[i];
      final bool isHighlight = (i == 0 || i == 3 || i == 6 || i == 9);
      
      final angleDeg = i * 30.0;
      final angleRad = (angleDeg - 90) * math.pi / 180;
      final dx = math.cos(angleRad) * radius;
      final dy = math.sin(angleRad) * radius;

      numerals.add(
        Transform.translate(
          offset: Offset(dx, dy),
          child: Text(
            numStr,
            style: TextStyle(
              fontSize: isHighlight ? clockSize * 0.12 : clockSize * 0.10,
              fontWeight: isHighlight ? FontWeight.bold : FontWeight.w500,
              color: isHighlight ? champagneDark : bronzeText,
              fontFamily: 'Amiri',
              shadows: const [
                Shadow(color: Color.fromRGBO(255, 255, 255, 0.9), offset: Offset(-1, -1), blurRadius: 1.0),
                Shadow(color: shadowSoft, offset: Offset(1, 1), blurRadius: 2.0),
              ],
            ),
          ),
        ),
      );
    }
    return numerals;
  }

  Widget _buildLuxuryHand({
    required double clockSize,
    required double dialSize,
    required double widthRatio,
    required double heightRatio,
    required Path Function(Size) pathBuilder,
  }) {
    final double width = clockSize * widthRatio;
    final double height = dialSize * heightRatio;
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned(
          bottom: dialSize * 0.5,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: CustomPaint(
              size: Size(width, height),
              painter: _FacetedHandPainter(
                pathBuilder: pathBuilder,
                colorLight: champagneLight,
                colorDark: champagneDark,
                shadowColor: shadowSoft,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSecondHand(double clockSize, double dialSize) {
    final double handWidth = clockSize * 0.008;
    final double handHeight = dialSize * 0.45;
    final double counterWeightSize = clockSize * 0.05;

    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned(
          bottom: dialSize * 0.5,
          child: Container(
            width: handWidth,
            height: handHeight,
            decoration: const BoxDecoration(
              color: champagneMid,
              borderRadius: BorderRadius.vertical(top: Radius.circular(2.0)),
              boxShadow: [BoxShadow(color: shadowSoft, offset: Offset(0, 4), blurRadius: 4.0)],
            ),
          ),
        ),
        Positioned(
          top: dialSize * 0.5 + (clockSize * 0.05),
          child: Container(
            width: counterWeightSize,
            height: counterWeightSize,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: champagneMid,
              boxShadow: [
                BoxShadow(color: shadowSoft, offset: Offset(0, 4), blurRadius: 4.0),
                BoxShadow(color: Colors.white24, offset: Offset(0, -2), blurRadius: 2.0, spreadRadius: -2, blurStyle: BlurStyle.inner),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCenterPin(double clockSize) {
    final double pinSize = clockSize * 0.06;
    return Container(
      width: pinSize,
      height: pinSize,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
          center: Alignment(-0.4, -0.4),
          radius: 0.8,
          colors: [Color(0xFFFFFFFF), ivoryMid, champagneMid],
          stops: [0.0, 0.5, 1.0],
        ),
        border: Border.all(color: ivoryLight, width: 1.0),
        boxShadow: const [
          BoxShadow(color: shadowDeep, offset: Offset(0, 4), blurRadius: 8.0),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(painter: _PinInsetShadowPainter(), size: Size.infinite),
          Container(
            width: pinSize * 0.3,
            height: pinSize * 0.3,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: champagneDark,
              boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0, 0.5), blurRadius: 1.0, blurStyle: BlurStyle.inner)],
            ),
          ),
        ],
      ),
    );
  }
  
  Path _getHourHandPath(Size size) {
    final w = size.width;
    final h = size.height;
    return Path()
      ..moveTo(w * 0.50, 0)
      ..lineTo(w, h * 0.20)
      ..lineTo(w * 0.80, h)
      ..lineTo(w * 0.20, h)
      ..lineTo(0, h * 0.20)
      ..close();
  }

  Path _getMinuteHandPath(Size size) {
    final w = size.width;
    final h = size.height;
    return Path()
      ..moveTo(w * 0.50, 0)
      ..lineTo(w, h * 0.15)
      ..lineTo(w * 0.80, h)
      ..lineTo(w * 0.20, h)
      ..lineTo(0, h * 0.15)
      ..close();
  }
}

class _CaseInsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path circle = Path()..addOval(Offset.zero & size);
    canvas.clipPath(circle);

    Paint highlight = Paint()
      ..color = const Color.fromRGBO(255, 255, 255, 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
    canvas.drawOval(Rect.fromLTRB(0, -2, size.width, size.height - 2), highlight);

    Paint shadow = Paint()
      ..color = const Color.fromRGBO(154, 123, 79, 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6.0);
    canvas.drawOval(Rect.fromLTRB(0, 2, size.width, size.height + 2), shadow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _DialInsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path circle = Path()..addOval(Offset.zero & size);
    canvas.clipPath(circle);

    Paint shadowSoft = Paint()
      ..color = const Color(0x268A7967)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 20
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20.0);
    canvas.drawOval(Rect.fromLTRB(0, -8, size.width, size.height - 8), shadowSoft);

    Paint highlight = Paint()
      ..color = const Color.fromRGBO(255, 255, 255, 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10.0);
    canvas.drawOval(Rect.fromLTRB(0, 4, size.width, size.height + 4), highlight);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _IslamicPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Paint borderPaint = Paint()
      ..color = const Color(0xFF9A7B4F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    final Paint glowPaint = Paint()
      ..color = const Color(0xFFCBAA7B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10.0
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15.0);

    void drawSquareWithGlow(Canvas canvas, Rect r) {
      canvas.drawRect(r, glowPaint);
      canvas.save();
      canvas.clipRect(r);
      canvas.drawRect(r.inflate(10), glowPaint);
      canvas.restore();
      canvas.drawRect(r, borderPaint);
    }

    drawSquareWithGlow(canvas, rect);

    canvas.save();
    canvas.translate(size.width / 2, size.height / 2);
    canvas.rotate(45 * math.pi / 180);
    canvas.translate(-size.width / 2, -size.height / 2);
    drawSquareWithGlow(canvas, rect);
    canvas.restore();

    final double innerRadius = (size.width * 0.70) / 2;
    final Path circlePath = Path()..addOval(Rect.fromCircle(center: rect.center, radius: innerRadius));
    
    final Paint dashedPaint = Paint()
      ..color = const Color(0xFF9A7B4F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    const double dashWidth = 8.0;
    const double dashSpace = 8.0;
    for (PathMetric measure in circlePath.computeMetrics()) {
      double distance = 0.0;
      while (distance < measure.length) {
        final Path extractPath = measure.extractPath(distance, distance + dashWidth);
        canvas.drawPath(extractPath, dashedPaint);
        distance += dashWidth + dashSpace;
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _GlassGlarePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Rect bounds = Offset.zero & size;
    final Paint paint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color.fromRGBO(255, 255, 255, 0.4),
          Color.fromRGBO(255, 255, 255, 0.05),
          Color.fromRGBO(255, 255, 255, 0),
          Color.fromRGBO(138, 121, 103, 0.05),
        ],
        stops: [0.0, 0.3, 0.5, 1.0],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(bounds);
      
    canvas.drawOval(bounds, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _PinInsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path circle = Path()..addOval(Offset.zero & size);
    canvas.clipPath(circle);

    Paint shadow = Paint()
      ..color = const Color.fromRGBO(0, 0, 0, 0.2)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0);
    canvas.drawOval(Rect.fromLTRB(0, 1, size.width, size.height - 1), shadow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FacetedHandPainter extends CustomPainter {
  final Path Function(Size) pathBuilder;
  final Color colorLight;
  final Color colorDark;
  final Color shadowColor;

  _FacetedHandPainter({
    required this.pathBuilder,
    required this.colorLight,
    required this.colorDark,
    required this.shadowColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    Path path = pathBuilder(size);
    canvas.drawShadow(path, shadowColor, 6.0, false);
    canvas.save();
    canvas.translate(0, 6);
    canvas.drawShadow(path, shadowColor.withOpacity(0.5), 6.0, false);
    canvas.restore();

    final Rect bounds = Offset.zero & size;
    final Paint paint = Paint()
      ..shader = LinearGradient(
        colors: [colorLight, colorLight, colorDark, colorDark],
        stops: const [0.0, 0.5, 0.5, 1.0],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ).createShader(bounds);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
