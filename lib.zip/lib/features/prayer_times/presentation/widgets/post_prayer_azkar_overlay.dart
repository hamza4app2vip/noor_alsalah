import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:noor_prayer_tv/core/theme/app_colors.dart';
import 'package:noor_prayer_tv/features/settings/presentation/providers/settings_provider.dart';
import 'package:noor_prayer_tv/features/prayer_times/presentation/providers/timer_engine_provider.dart';
import 'package:noor_prayer_tv/features/azkar_quran/presentation/providers/azkar_provider.dart';
import 'package:noor_prayer_tv/core/local_server/marquee_trigger_provider.dart';

class PostPrayerAzkarOverlay extends ConsumerStatefulWidget {
  final Widget child;
  const PostPrayerAzkarOverlay({super.key, required this.child});

  static _PostPrayerAzkarOverlayState? of(BuildContext context) {
    return context.findAncestorStateOfType<_PostPrayerAzkarOverlayState>();
  }

  @override
  ConsumerState<PostPrayerAzkarOverlay> createState() => _PostPrayerAzkarOverlayState();
}

class _PostPrayerAzkarOverlayState extends ConsumerState<PostPrayerAzkarOverlay> {
  bool _isShowingAzkar = false;
  Timer? _azkarTimer;
  PrayerName _lastPrayer = PrayerName.fajr;

  @override
  void dispose() {
    _azkarTimer?.cancel();
    super.dispose();
  }

  // Callable for testing
  void showAzkarForTesting() {
    _triggerAzkar(PrayerName.dhuhr);
  }

  void _triggerAzkar(PrayerName finishedPrayer) {
    final settings = ref.read(settingsNotifierProvider);
    if (!settings.postPrayerAzkarEnabled) return;

    setState(() {
      _lastPrayer = finishedPrayer;
      _isShowingAzkar = true;
    });

    if (settings.postPrayerShowSingleSlide5Min) {
      _azkarTimer?.cancel();
      _azkarTimer = Timer(const Duration(minutes: 5), () {
        if (mounted) setState(() => _isShowingAzkar = false);
      });
    } else {
      // Normal reading duration or until tapped
      // For now, let's keep it visible until tapped or a timeout
      _azkarTimer?.cancel();
      _azkarTimer = Timer(const Duration(minutes: 5), () {
         if (mounted) setState(() => _isShowingAzkar = false);
      });
    }
  }

  List<ZikrItem> _getAzkarList() {
    final settings = ref.read(settingsNotifierProvider);
    final isSabah = (_lastPrayer == PrayerName.fajr && settings.enableSabahAfterFajr);
    final isMasaa = (_lastPrayer == PrayerName.asr && settings.enableMasaaAfterAsr) ||
                   (_lastPrayer == PrayerName.maghrib && settings.enableMasaaAfterMaghrib) ||
                   (_lastPrayer == PrayerName.isha && settings.enableMasaaAfterIsha);

    if (isSabah) {
      return ref.read(sabahAzkarProvider).valueOrNull ?? [];
    } else if (isMasaa) {
      return ref.read(masaaAzkarProvider).valueOrNull ?? [];
    }
    return ref.read(generalAzkarProvider).valueOrNull ?? [];
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);

    // التحقق من وجود رسالة فورية لإخفاء الأذكار فوراً
    ref.listen<String?>(marqueeTriggerProvider, (prev, next) {
      if (next != null && _isShowingAzkar) {
        setState(() => _isShowingAzkar = false);
        _azkarTimer?.cancel();
      }
    });

    // We can auto-trigger when timer state changes from blackScreen to countdown, 
    // implying a prayer just finished.
    ref.listen<TimerState>(timerEngineProvider, (prev, next) {
      if (prev?.phase == PrayerPhase.blackScreen && next.phase == PrayerPhase.countdown) {
        // Find which prayer just ended
        // next.currentOrNextPrayer is the NEXT prayer, so previous was the finished one.
        _triggerAzkar(next.currentOrNextPrayer); 
      }
    });

    final currentList = _getAzkarList();

    return Stack(
      children: [
        widget.child,

        if (_isShowingAzkar)
          Positioned.fill(
            child: Material(
              color: settings.postPrayerWhiteBackground ? Colors.white : Colors.black87,
              child: Stack(
                children: [
                   if (currentList.isEmpty)
                      const Center(child: CircularProgressIndicator(color: Colors.amber))
                   else
                      ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 80),
                        itemCount: currentList.length,
                        itemBuilder: (context, index) {
                          final item = currentList[index];
                          return Container(
                            margin: const EdgeInsets.only(bottom: 32),
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                               color: settings.postPrayerWhiteBackground ? Colors.grey.shade100 : Colors.white12,
                               borderRadius: BorderRadius.circular(16),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  item.text,
                                  style: TextStyle(
                                    fontFamily: settings.azkarFontFamily,
                                    fontSize: 42,
                                    fontWeight: FontWeight.bold,
                                    color: settings.postPrayerWhiteBackground ? Colors.black87 : Colors.white,
                                    height: 1.6,
                                  ),
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.rtl,
                                ),
                                if (item.repeatInfo != null) ...[
                                  const SizedBox(height: 16),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryGold.withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: AppColors.primaryGold.withValues(alpha: 0.5)),
                                    ),
                                    child: Text(
                                      item.repeatInfo!,
                                      style: TextStyle(
                                        fontFamily: settings.azkarFontFamily,
                                        fontSize: 24,
                                        color: AppColors.primaryGold,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          );
                        },
                      ),

                  // Close Button
                  Positioned(
                    top: 24,
                    left: 24,
                    child: IconButton(
                      icon: Icon(Icons.close, size: 40, color: settings.postPrayerWhiteBackground ? Colors.black : Colors.white),
                      onPressed: () {
                         setState(() => _isShowingAzkar = false);
                         _azkarTimer?.cancel();
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
