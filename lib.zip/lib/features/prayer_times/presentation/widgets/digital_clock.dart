import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:noor_prayer_tv/core/theme/app_colors.dart';
import 'package:noor_prayer_tv/core/theme/app_styles.dart';
import 'package:noor_prayer_tv/features/settings/presentation/providers/settings_provider.dart';

class DigitalClock extends ConsumerStatefulWidget {
  final bool showSeconds;
  final bool use24h;
  final bool useArabicIndicDigits;
  final bool showFullClock;
  final int offsetMinutes;

  const DigitalClock({
    super.key,
    this.showSeconds = true,
    this.use24h = true,
    this.useArabicIndicDigits = true,
    this.showFullClock = false,
    this.offsetMinutes = 0,
  });

  @override
  ConsumerState<DigitalClock> createState() => _DigitalClockState();
}

class _DigitalClockState extends ConsumerState<DigitalClock> {
  late Timer _timer;
  late DateTime _time;

  @override
  void initState() {
    super.initState();
    _time = DateTime.now();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _time = DateTime.now();
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _toArabicNumerals(String input) {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    String result = input;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], arabic[i]);
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    // Apply offset
    final displayTime = _time.add(Duration(minutes: widget.offsetMinutes));
    
    int h = displayTime.hour;
    int m = displayTime.minute;
    int s = displayTime.second;
    String period = '';

    if (!widget.use24h) {
      period = h >= 12 ? ' م' : ' ص';
      h = h % 12;
      if (h == 0) h = 12;
    }

    String hStr = h.toString().padLeft(2, '0');
    String mStr = m.toString().padLeft(2, '0');
    String sStr = s.toString().padLeft(2, '0');
    
    if (widget.useArabicIndicDigits) {
      hStr = _toArabicNumerals(hStr);
      mStr = _toArabicNumerals(mStr);
      sStr = _toArabicNumerals(sStr);
    }

    final screenWidth = MediaQuery.of(context).size.width;
    final isCompact = screenWidth < 600;
    
    // If showFullClock is true, make it identical in size to hours/mins
    final hourMinSize = isCompact ? 60.0 : 84.0;
    final secSize = widget.showFullClock ? hourMinSize : (isCompact ? 32.0 : 48.0);

    return Center(
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: isCompact ? 24 : 48,
          vertical: isCompact ? 16 : 24,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(40),
          color: Colors.white.withValues(alpha: 0.03),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.15),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.emeraldMuted.withValues(alpha: 0.2),
              blurRadius: 40,
              spreadRadius: -10,
            ),
            BoxShadow(
              color: AppColors.primaryGold.withValues(alpha: 0.05),
              blurRadius: 60,
              offset: const Offset(0, 20),
            )
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(hStr, style: AppStyles.timeLarge.copyWith(fontSize: hourMinSize, height: 1.0, color: Colors.white, fontFamily: settings.clockFontFamily)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: ShaderMask(
                shaderCallback: (bounds) => AppColors.goldTextGradient.createShader(bounds),
                child: Text(':', style: AppStyles.timeLarge.copyWith(fontSize: hourMinSize * 0.8, color: Colors.white, height: 1.0, fontFamily: settings.clockFontFamily)),
              ),
            ),
            Text(mStr, style: AppStyles.timeLarge.copyWith(fontSize: hourMinSize, height: 1.0, color: Colors.white, fontFamily: settings.clockFontFamily)),
            if (widget.showSeconds) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: ShaderMask(
                  shaderCallback: (bounds) => AppColors.goldTextGradient.createShader(bounds),
                  child: Text(':', style: AppStyles.timeLarge.copyWith(fontSize: secSize * 0.8, color: Colors.white, height: 1.0, fontFamily: settings.clockFontFamily)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 12.0),
                child: Text(sStr, style: AppStyles.timeLarge.copyWith(fontSize: secSize, color: AppColors.mutedForeground, height: 1.0, fontFamily: settings.clockFontFamily)),
              ),
            ],
            if (period.isNotEmpty) ...[
              const SizedBox(width: 12),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: Text(period, style: AppStyles.bodyMuted.copyWith(fontSize: isCompact ? 20.0 : 28.0, height: 1.0, fontFamily: settings.clockFontFamily)),
              ),
            ]
          ],
        ),
      ),
    );
  }
}
