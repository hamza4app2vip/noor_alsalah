import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

class LuxuryGoldClock extends StatefulWidget {
  final DateTime baseTime;
  final double size;
  final String brand;
  final bool showHourNumbers;
  final bool useArabicIndicDigits;

  const LuxuryGoldClock({
    super.key,
    required this.baseTime,
    this.size = 300,
    this.brand = 'NOOR',
    this.showHourNumbers = false,
    this.useArabicIndicDigits = false,
  });

  @override
  State<LuxuryGoldClock> createState() => _LuxuryGoldClockState();
}

class _LuxuryGoldClockState extends State<LuxuryGoldClock>
    with SingleTickerProviderStateMixin {
  // High-fidelity real-time sweeping clock engine
  late Ticker _ticker;
  final ValueNotifier<DateTime> _timeNotifier = ValueNotifier(DateTime.now());

  late DateTime _anchorVirtualNow;
  late DateTime _anchorSystemNow;

  // Gold Color Palette
  static const Color goldLight = Color(0xFFFBECA9);
  static const Color goldMid = Color(0xFFD4AF37);
  static const Color goldDark = Color(0xFF8A6311);
  static const Color goldDeep = Color(0xFF4A3300);
  static const Color dialCenter = Color(0xFF2B2C30);
  static const Color dialEdge = Color(0xFF090A0C);

  @override
  void initState() {
    super.initState();
    _anchorVirtualNow = widget.baseTime;
    _anchorSystemNow = DateTime.now();
    _timeNotifier.value = widget.baseTime;

    // 60fps Ticker for flawlessly smooth sweeping second hand
    _ticker = createTicker((_) {
      final elapsed = DateTime.now().difference(_anchorSystemNow);
      _timeNotifier.value = _anchorVirtualNow.add(elapsed);
    });
    _ticker.start();
  }

  @override
  void didUpdateWidget(covariant LuxuryGoldClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    final drift =
        widget.baseTime.difference(_timeNotifier.value).inMilliseconds.abs();
    if (drift > 1500 || oldWidget.baseTime != widget.baseTime) {
      _anchorVirtualNow = widget.baseTime;
      _anchorSystemNow = DateTime.now();
      _timeNotifier.value = widget.baseTime;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    _timeNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double clockSize = widget.size;
    final double casePadding = clockSize * 0.035;
    final double dialSize = clockSize - (casePadding * 2);

    return Center(
      child: SizedBox.square(
        dimension: clockSize,
        child: Container(
          width: clockSize,
          height: clockSize,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: const [
              // Outer drop shadow
              BoxShadow(
                color: Color.fromRGBO(0, 0, 0, 0.9),
                offset: Offset(0, 30),
                blurRadius: 60.0,
                spreadRadius: -15.0,
              ),
            ],
            // Conic Gradient Bezel
            gradient: const SweepGradient(
              colors: [
                goldMid,
                goldLight,
                goldMid,
                goldDark,
                goldMid,
                goldLight,
                goldMid,
                goldDark,
                goldMid,
              ],
              stops: [0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1.0],
            ),
          ),
          child: Stack(
            children: [
              // Case Inset Shadow replication
              CustomPaint(
                  painter: _CaseInsetShadowPainter(), size: Size.infinite),

              // Dial Area
              Padding(
                padding: EdgeInsets.all(casePadding),
                child: Container(
                  width: dialSize,
                  height: dialSize,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    // Base dial radial gradient
                    gradient: RadialGradient(
                      colors: [dialCenter, dialEdge],
                      stops: [0.0, 1.0],
                    ),
                  ),
                  child: Stack(
                    children: [
                      // Dial Sunburst Layer
                      CustomPaint(
                          painter: _SunburstPainter(), size: Size.infinite),

                      // Dial Inset Shadow
                      CustomPaint(
                          painter: _DialInsetShadowPainter(),
                          size: Size.infinite),

                      // Chapter Ring
                      Positioned.fill(
                        child: Padding(
                          padding: EdgeInsets.all(dialSize * 0.02),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: const Color.fromRGBO(212, 175, 55, 0.15),
                                width: 1.0,
                              ),
                            ),
                          ),
                        ),
                      ),

                      // Brand Name "NOOR"
                      Positioned(
                        top: dialSize * 0.22,
                        left: 0,
                        right: 0,
                        child: Column(
                          children: [
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                // Text Drop Shadow
                                Text(
                                  widget.brand,
                                  style: TextStyle(
                                    fontSize: clockSize * 0.06,
                                    letterSpacing: clockSize * 0.015,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.transparent,
                                    shadows: const [
                                      Shadow(
                                          color: Color.fromRGBO(0, 0, 0, 0.8),
                                          offset: Offset(0, 2),
                                          blurRadius: 4),
                                    ],
                                  ),
                                ),
                                // Gradient Text
                                ShaderMask(
                                  shaderCallback: (bounds) =>
                                      const LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [goldLight, goldMid],
                                  ).createShader(bounds),
                                  child: Text(
                                    widget.brand,
                                    style: TextStyle(
                                      fontSize: clockSize * 0.06,
                                      letterSpacing: clockSize * 0.015,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: clockSize * 0.01),
                            Text(
                              'CHRONOMETER\nAUTOMATIC',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: 'sans-serif',
                                fontSize: clockSize * 0.02,
                                letterSpacing: clockSize * 0.008,
                                color: const Color(0xFFA48C47),
                                height: 1.2,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Bottom Text
                      Positioned(
                        bottom: dialSize * 0.06,
                        left: 0,
                        right: 0,
                        child: Text(
                          'PREMIUM TIME',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: 'sans-serif',
                            fontSize: clockSize * 0.015,
                            letterSpacing: 2.0,
                            color: goldDark,
                          ),
                        ),
                      ),

                      // Date Window
                      Positioned(
                        bottom: dialSize * 0.18,
                        left: (dialSize / 2) - ((clockSize * 0.08) / 2),
                        child: ValueListenableBuilder<DateTime>(
                          valueListenable: _timeNotifier,
                          builder: (context, now, child) {
                            return _buildDateWindow(clockSize, now);
                          },
                        ),
                      ),

                      // Numbers (if enabled)
                      if (widget.showHourNumbers)
                        ..._buildHourNumbers(clockSize, dialSize),

                      // Markers
                      ..._buildMarkers(clockSize, dialSize),

                      // Sweeping Hands
                      ValueListenableBuilder<DateTime>(
                        valueListenable: _timeNotifier,
                        builder: (context, now, child) {
                          final ms = now.millisecond;
                          final seconds = now.second + (ms / 1000.0);
                          final minutes = now.minute + (seconds / 60.0);
                          final hours = (now.hour % 12) + (minutes / 60.0);

                          final secAngle = seconds * 6 * math.pi / 180;
                          final minAngle = minutes * 6 * math.pi / 180;
                          final hrAngle = hours * 30 * math.pi / 180;

                          return Stack(
                            children: [
                              // Hour Hand
                              Transform.rotate(
                                angle: hrAngle,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      bottom: dialSize * 0.5,
                                      left: 0,
                                      right: 0,
                                      child: Align(
                                        alignment: Alignment.bottomCenter,
                                        child: CustomPaint(
                                          size: Size(clockSize * 0.025,
                                              dialSize * 0.28),
                                          painter: _FacetedShapePainter(
                                            pathBuilder: _getHandPath,
                                            shadowBlur: 6.0,
                                            shadowOffsetY: 4.0,
                                            shadowColor: const Color.fromRGBO(
                                                0, 0, 0, 0.6),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // Minute Hand
                              Transform.rotate(
                                angle: minAngle,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      bottom: dialSize * 0.5,
                                      left: 0,
                                      right: 0,
                                      child: Align(
                                        alignment: Alignment.bottomCenter,
                                        child: CustomPaint(
                                          size: Size(clockSize * 0.018,
                                              dialSize * 0.42),
                                          painter: _FacetedShapePainter(
                                            pathBuilder: _getHandPath,
                                            shadowBlur: 6.0,
                                            shadowOffsetY: 4.0,
                                            shadowColor: const Color.fromRGBO(
                                                0, 0, 0, 0.6),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // Second Hand
                              Transform.rotate(
                                angle: secAngle,
                                child: _buildSecondHand(clockSize, dialSize),
                              ),
                            ],
                          );
                        },
                      ),

                      // Center Pin
                      Align(
                        alignment: Alignment.center,
                        child: _buildCenterPin(clockSize),
                      ),

                      // Sapphire Glass Glare
                      CustomPaint(
                          painter: _GlassGlarePainter(), size: Size.infinite),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Widget Builders ---

  List<Widget> _buildMarkers(double clockSize, double dialSize) {
    List<Widget> markers = [];
    for (int i = 0; i < 60; i++) {
      Widget marker;
      double topPadding;

      if (i == 0) {
        // Double Baton (12 o'clock)
        marker = SizedBox(
          width: clockSize * 0.03,
          height: clockSize * 0.08,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomPaint(
                size: Size(clockSize * 0.03 * 0.38, clockSize * 0.08),
                painter: _FacetedShapePainter(pathBuilder: _getBatonPath),
              ),
              CustomPaint(
                size: Size(clockSize * 0.03 * 0.38, clockSize * 0.08),
                painter: _FacetedShapePainter(pathBuilder: _getBatonPath),
              ),
            ],
          ),
        );
        topPadding = dialSize * 0.035;
      } else if (i % 5 == 0) {
        // Single Baton
        marker = CustomPaint(
          size: Size(clockSize * 0.012, clockSize * 0.08),
          painter: _FacetedShapePainter(pathBuilder: _getBatonPath),
        );
        topPadding = dialSize * 0.035;
      } else {
        // Dot
        marker = Container(
          width: clockSize * 0.006,
          height: clockSize * 0.006,
          decoration: const BoxDecoration(
            color: goldMid,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.5),
                  blurRadius: 2,
                  offset: Offset(0, 1))
            ],
          ),
        );
        topPadding = dialSize * 0.04;
      }

      markers.add(
        Transform.rotate(
          angle: i * 6 * math.pi / 180,
          child: Stack(
            children: [
              Positioned(
                top: topPadding,
                left: 0,
                right: 0,
                child: Center(child: marker),
              ),
            ],
          ),
        ),
      );
    }
    return markers;
  }

  List<Widget> _buildHourNumbers(double clockSize, double dialSize) {
    List<Widget> numbers = [];
    final double radius = dialSize * 0.38;

    for (int i = 1; i <= 12; i++) {
      final angle = (i * 30 - 90) * math.pi / 180;
      final dx = math.cos(angle) * radius;
      final dy = math.sin(angle) * radius;

      String numStr = i.toString();
      if (widget.useArabicIndicDigits) {
        const western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        const arabicIndic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        for (int j = 0; j < western.length; j++) {
          numStr = numStr.replaceAll(western[j], arabicIndic[j]);
        }
      }

      numbers.add(
        Positioned.fill(
          child: Align(
            alignment: Alignment.center,
            child: Transform.translate(
              offset: Offset(dx, dy),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Text(
                    numStr,
                    style: TextStyle(
                      fontSize: clockSize * 0.08,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'serif',
                      color: Colors.black.withValues(alpha: 0.5),
                      shadows: [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.8),
                          offset: const Offset(0, 2),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                  ),
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [goldLight, goldMid, goldDark],
                    ).createShader(bounds),
                    child: Text(
                      numStr,
                      style: TextStyle(
                        fontSize: clockSize * 0.08,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'serif',
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    return numbers;
  }

  Widget _buildSecondHand(double clockSize, double dialSize) {
    return Stack(
      children: [
        Positioned(
          bottom: dialSize * 0.5,
          left: 0,
          right: 0,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: clockSize * 0.005,
              height: dialSize * 0.46,
              decoration: const BoxDecoration(
                color: goldMid,
                borderRadius: BorderRadius.vertical(top: Radius.circular(2.0)),
                boxShadow: [
                  BoxShadow(
                      color: Color.fromRGBO(0, 0, 0, 0.4),
                      blurRadius: 4,
                      offset: Offset(0, 4))
                ],
              ),
            ),
          ),
        ),
        Positioned(
          top: dialSize * 0.5,
          left: 0,
          right: 0,
          child: Align(
            alignment: Alignment.topCenter,
            child: Container(
              width: clockSize * 0.015,
              height: dialSize * 0.12,
              decoration: BoxDecoration(
                color: goldMid,
                borderRadius: BorderRadius.circular(50.0),
                boxShadow: const [
                  BoxShadow(
                      color: Color.fromRGBO(0, 0, 0, 0.4),
                      blurRadius: 4,
                      offset: Offset(0, 4))
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCenterPin(double clockSize) {
    final double pinSize = clockSize * 0.035;
    return Container(
      width: pinSize,
      height: pinSize,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
            color: const Color.fromRGBO(255, 255, 255, 0.6), width: 1.0),
        gradient: const RadialGradient(colors: [goldLight, goldDark]),
        boxShadow: const [
          BoxShadow(
              color: Color.fromRGBO(0, 0, 0, 0.6),
              blurRadius: 10,
              offset: Offset(0, 4))
        ],
      ),
      child: Center(
        child: Container(
          width: pinSize * 0.3,
          height: pinSize * 0.3,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: goldDeep,
          ),
        ),
      ),
    );
  }

  Widget _buildDateWindow(double clockSize, DateTime now) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: clockSize * 0.015, vertical: clockSize * 0.005),
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        border: Border.all(color: goldDark, width: 1.0),
        borderRadius: BorderRadius.circular(2.0),
        boxShadow: const [
          BoxShadow(
              color: Color.fromRGBO(255, 255, 255, 0.1),
              blurRadius: 2,
              offset: Offset(0, 1)),
        ],
      ),
      child: CustomPaint(
        painter: _DateInsetShadowPainter(),
        child: Text(
          now.day.toString().padLeft(2, '0'),
          style: TextStyle(
            fontFamily: 'sans-serif',
            fontSize: clockSize * 0.035,
            fontWeight: FontWeight.bold,
            color: goldLight,
          ),
        ),
      ),
    );
  }

  Path _getBatonPath(Size size) {
    final double w = size.width;
    final double h = size.height;
    return Path()
      ..moveTo(w * 0.15, 0)
      ..lineTo(w * 0.85, 0)
      ..lineTo(w, h)
      ..lineTo(0, h)
      ..close();
  }

  Path _getHandPath(Size size) {
    final double w = size.width;
    final double h = size.height;
    return Path()
      ..moveTo(w * 0.50, 0)
      ..lineTo(w, h * 0.90)
      ..lineTo(w * 0.80, h)
      ..lineTo(w * 0.20, h)
      ..lineTo(0, h * 0.90)
      ..close();
  }
}

class _CaseInsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path circle = Path()..addOval(Offset.zero & size);
    canvas.clipPath(circle);

    Paint topHighlight = Paint()
      ..color = const Color.fromRGBO(255, 255, 255, 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5.0);
    canvas.drawOval(
        Rect.fromLTRB(0, -4, size.width, size.height - 4), topHighlight);

    Paint bottomShadow = Paint()
      ..color = const Color.fromRGBO(0, 0, 0, 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5.0);
    canvas.drawOval(
        Rect.fromLTRB(0, 4, size.width, size.height + 4), bottomShadow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _DialInsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path circle = Path()..addOval(Offset.zero & size);
    canvas.clipPath(circle);

    Paint shadow = Paint()
      ..color = const Color.fromRGBO(0, 0, 0, 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 30
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15.0);
    canvas.drawOval(
        Rect.fromLTRB(0, -12, size.width, size.height - 12), shadow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _DateInsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path rect = Path()..addRect(Offset.zero & size);
    canvas.clipPath(rect);

    Paint shadow = Paint()
      ..color = const Color.fromRGBO(0, 0, 0, 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5);
    canvas.drawRect(Rect.fromLTRB(0, -2, size.width, size.height + 2), shadow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SunburstPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Rect bounds = Offset.zero & size;
    List<Color> colors = [];
    List<double> stops = [];

    for (int i = 0; i < 24; i++) {
      colors.add(const Color.fromRGBO(255, 255, 255, 0.02));
      stops.add((i * 15) / 360.0);
      colors.add(const Color.fromRGBO(255, 255, 255, 0));
      stops.add(((i + 1) * 15) / 360.0);
    }

    final Paint paint = Paint()
      ..shader =
          SweepGradient(colors: colors, stops: stops).createShader(bounds);

    canvas.drawOval(bounds, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _GlassGlarePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Rect bounds = Offset.zero & size;
    final Paint paint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color.fromRGBO(255, 255, 255, 0.12),
          Color.fromRGBO(255, 255, 255, 0),
          Color.fromRGBO(0, 0, 0, 0.1),
        ],
        stops: [0.0, 0.45, 1.0],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(bounds);

    canvas.drawOval(bounds, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FacetedShapePainter extends CustomPainter {
  final Path Function(Size) pathBuilder;
  final double shadowBlur;
  final double shadowOffsetY;
  final Color shadowColor;

  _FacetedShapePainter({
    required this.pathBuilder,
    this.shadowBlur = 4.0,
    this.shadowOffsetY = 2.0,
    this.shadowColor = const Color.fromRGBO(0, 0, 0, 0.5),
  });

  @override
  void paint(Canvas canvas, Size size) {
    Path path = pathBuilder(size);
    canvas.drawShadow(path, shadowColor, shadowBlur, false);

    final Rect bounds = Offset.zero & size;
    final Paint paint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color(0xFFFBECA9),
          Color(0xFFFBECA9),
          Color(0xFF8A6311),
          Color(0xFF8A6311),
        ],
        stops: [0.0, 0.5, 0.5, 1.0],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ).createShader(bounds);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
