import 'package:flutter/material.dart';
import 'package:marquee/marquee.dart';
import 'package:noor_prayer_tv/core/theme/app_styles.dart';
import 'package:noor_prayer_tv/core/theme/glass_panel.dart';

class MarqueeBanner extends StatelessWidget {
  final List<String> texts;
  final String theme;

  const MarqueeBanner({
    super.key,
    required this.texts,
    this.theme = 'emerald',
  });

  @override
  Widget build(BuildContext context) {
    if (texts.isEmpty) return const SizedBox.shrink();
    
    final fullText = "${texts.join("   ✦   ")}   ✦   ";

    return GlassPanel(
      theme: theme,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      child: SizedBox(
        height: 30, // appropriate height for marquee text
        child: Marquee(
          text: fullText,
          style: AppStyles.heading.copyWith(fontSize: 18),
          scrollAxis: Axis.horizontal,
          crossAxisAlignment: CrossAxisAlignment.center,
          blankSpace: 20.0,
          velocity: 30.0,
          pauseAfterRound: const Duration(seconds: 0),
          startPadding: 10.0,
          accelerationDuration: const Duration(seconds: 0),
          accelerationCurve: Curves.linear,
          decelerationDuration: const Duration(seconds: 0),
          decelerationCurve: Curves.linear,
          textDirection: TextDirection.rtl,
        ),
      ),
    );
  }
}
