import 'package:hijri/hijri_calendar.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../settings/domain/entities/app_settings.dart';
import '../../../settings/presentation/providers/settings_provider.dart';
import '../../data/datasources/local_data_source.dart';
import '../../data/repositories/prayer_times_repository_impl.dart';
import '../../domain/entities/prayer_day.dart';
import '../../domain/usecases/get_today_prayer_times.dart';

part 'prayer_times_provider.g.dart';

@riverpod
PrayerTimesLocalDataSource localDataSource(LocalDataSourceRef ref) {
  return PrayerTimesLocalDataSourceImpl();
}

@riverpod
GetTodayPrayerTimes getTodayPrayerTimes(GetTodayPrayerTimesRef ref) {
  final dataSource = ref.watch(localDataSourceProvider);
  final repository = PrayerTimesRepositoryImpl(dataSource);
  return GetTodayPrayerTimes(repository);
}

@riverpod
Future<PrayerDay> todayPrayerTimes(TodayPrayerTimesRef ref) async {
  final useCase = ref.watch(getTodayPrayerTimesProvider);
  final settings = ref.watch(settingsNotifierProvider);

  final systemNow = DateTime.now();
  DateTime now;

  if (settings.isManualTimeEnabled && settings.manualTimeValue != null) {
    final parts = settings.manualTimeValue!.split(':');
    if (parts.length == 2) {
      final h = int.tryParse(parts[0]) ?? systemNow.hour;
      final m = int.tryParse(parts[1]) ?? systemNow.minute;
      final hour = h.clamp(0, 23).toInt();
      final minute = m.clamp(0, 59).toInt();
      now = DateTime(
        systemNow.year,
        systemNow.month,
        systemNow.day,
        hour,
        minute,
        systemNow.second,
        systemNow.millisecond,
      );
    } else {
      now = systemNow.add(Duration(minutes: settings.clockOffsetMinutes));
    }
  } else {
    now = systemNow.add(Duration(minutes: settings.clockOffsetMinutes));
  }

  final result = await useCase(
    settings.country,
    settings.city,
    now,
    customFilePath:
        settings.useCustomPrayerTimes ? settings.customTimesFilePath : null,
  );

  return result.fold(
    (failure) => throw Exception(failure.message),
    (prayerDay) => _applySettingsOffsets(prayerDay, settings, now),
  );
}

PrayerDay _applySettingsOffsets(
  PrayerDay baseDay,
  AppSettings settings,
  DateTime referenceNow,
) {
  DateTime applyOffset(DateTime time, int minutes) {
    if (minutes == 0) return time;
    return time.add(Duration(minutes: minutes));
  }

  int allOffset = 0;
  if (settings.manualPlus1HourAllEnabled) allOffset += 60;
  if (settings.manualMinus1HourAllEnabled) allOffset -= 60;
  if (settings.summerPlus1HourEnabled) allOffset += 60;

  DateTime fajr =
      applyOffset(baseDay.fajr, allOffset + settings.prayerOffsetFajr);
  DateTime sunrise =
      applyOffset(baseDay.sunrise, allOffset + settings.prayerOffsetSunrise);
  DateTime dhuhr =
      applyOffset(baseDay.dhuhr, allOffset + settings.prayerOffsetDhuhr);
  DateTime asr = applyOffset(baseDay.asr, allOffset + settings.prayerOffsetAsr);
  DateTime maghrib =
      applyOffset(baseDay.maghrib, allOffset + settings.prayerOffsetMaghrib);
  DateTime isha =
      applyOffset(baseDay.isha, allOffset + settings.prayerOffsetIsha);

  if (settings.ramadanIshaPlus30Enabled) {
    final adjustedDate =
        referenceNow.add(Duration(days: settings.hijriOffsetDays));
    final hDate = HijriCalendar.fromDate(adjustedDate);
    if (hDate.hMonth == 9) {
      isha = isha.add(const Duration(minutes: 30));
    }
  }

  if (settings.dhuhrFromAsrMinusMinutesEnabled) {
    dhuhr =
        asr.subtract(Duration(minutes: settings.dhuhrEqualsAsrMinusMinutes));
  }

  return PrayerDay(
    fajr: fajr,
    sunrise: sunrise,
    dhuhr: dhuhr,
    asr: asr,
    maghrib: maghrib,
    isha: isha,
  );
}
