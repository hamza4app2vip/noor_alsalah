import 'dart:async';

import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../settings/domain/entities/app_settings.dart';
import '../../../settings/presentation/providers/settings_provider.dart';
import 'prayer_times_provider.dart';

part 'timer_engine_provider.g.dart';

enum PrayerName { fajr, sunrise, dhuhr, asr, maghrib, isha, none }

enum PrayerPhase { countdown, adhan, iqama, blackScreen }

DateTime _parseTime(String hhmm, DateTime baseDate) {
  final parts = hhmm.split(':');
  if (parts.length != 2) return baseDate;
  final h = int.tryParse(parts[0]) ?? 0;
  final m = int.tryParse(parts[1]) ?? 0;
  return DateTime(baseDate.year, baseDate.month, baseDate.day, h, m);
}

String _getPNameId(PrayerName name) {
  switch (name) {
    case PrayerName.fajr:
      return 'fajr';
    case PrayerName.dhuhr:
      return 'dhuhr';
    case PrayerName.asr:
      return 'asr';
    case PrayerName.maghrib:
      return 'maghrib';
    case PrayerName.isha:
      return 'isha';
    default:
      return '';
  }
}

class TimerState {
  final Duration timeUntilNext;
  final PrayerName currentOrNextPrayer;
  final PrayerPhase phase;
  final DateTime now;

  const TimerState({
    required this.timeUntilNext,
    required this.currentOrNextPrayer,
    required this.phase,
    required this.now,
  });
}

@riverpod
class TimerEngine extends _$TimerEngine {
  Timer? _timer;

  DateTime? _manualAnchorSystemNow;
  DateTime? _manualAnchorVirtualNow;
  String? _manualAnchorManualValue;
  String? _lastPrayerDayKey;

  @override
  TimerState build() {
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    ref.onDispose(() => _timer?.cancel());

    return _calculateState(DateTime.now());
  }

  void _tick() {
    state = _calculateState(DateTime.now());
  }

  void _resetManualAnchors() {
    _manualAnchorSystemNow = null;
    _manualAnchorVirtualNow = null;
    _manualAnchorManualValue = null;
  }

  String _dayKey(DateTime dt) =>
      '${dt.year.toString().padLeft(4, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';

  void _syncPrayerDay(DateTime now) {
    final currentKey = _dayKey(now);
    if (_lastPrayerDayKey == null) {
      _lastPrayerDayKey = currentKey;
      return;
    }
    if (_lastPrayerDayKey != currentKey) {
      _lastPrayerDayKey = currentKey;
      ref.invalidate(todayPrayerTimesProvider);
    }
  }

  DateTime _resolveClockNow(DateTime systemNow, AppSettings settings) {
    final manualValue = settings.manualTimeValue;
    if (!settings.isManualTimeEnabled ||
        manualValue == null ||
        manualValue.isEmpty) {
      _resetManualAnchors();
      return systemNow.add(Duration(minutes: settings.clockOffsetMinutes));
    }

    final parts = manualValue.split(':');
    if (parts.length != 2) {
      _resetManualAnchors();
      return systemNow.add(Duration(minutes: settings.clockOffsetMinutes));
    }

    final parsedHour = int.tryParse(parts[0]);
    final parsedMinute = int.tryParse(parts[1]);
    if (parsedHour == null || parsedMinute == null) {
      _resetManualAnchors();
      return systemNow.add(Duration(minutes: settings.clockOffsetMinutes));
    }

    final h = parsedHour.clamp(0, 23).toInt();
    final m = parsedMinute.clamp(0, 59).toInt();
    final normalizedManual =
        '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}';

    if (_manualAnchorSystemNow == null ||
        _manualAnchorVirtualNow == null ||
        _manualAnchorManualValue != normalizedManual) {
      _manualAnchorSystemNow = systemNow;
      _manualAnchorVirtualNow = DateTime(
        systemNow.year,
        systemNow.month,
        systemNow.day,
        h,
        m,
        systemNow.second,
        systemNow.millisecond,
      );
      _manualAnchorManualValue = normalizedManual;
    }

    final elapsed = systemNow.difference(_manualAnchorSystemNow!);
    return _manualAnchorVirtualNow!.add(elapsed);
  }

  TimerState _calculateState(DateTime systemNow) {
    final settings = ref.read(settingsNotifierProvider);
    final now = _resolveClockNow(systemNow, settings);
    _syncPrayerDay(now);
    final todayTimes = ref.read(todayPrayerTimesProvider).valueOrNull;

    if (todayTimes == null) {
      return TimerState(
        timeUntilNext: Duration.zero,
        currentOrNextPrayer: PrayerName.none,
        phase: PrayerPhase.countdown,
        now: now,
      );
    }

    final isFriday = now.weekday == DateTime.friday;

    final prayers = [
      (PrayerName.fajr, todayTimes.fajr, settings.fajrIqamaTime),
      (PrayerName.sunrise, todayTimes.sunrise, 0),
      (
        PrayerName.dhuhr,
        todayTimes.dhuhr,
        isFriday ? settings.jomoaIqamaTime : settings.dhuhrIqamaTime,
      ),
      (PrayerName.asr, todayTimes.asr, settings.asrIqamaTime),
      (PrayerName.maghrib, todayTimes.maghrib, settings.maghribIqamaTime),
      (PrayerName.isha, todayTimes.isha, settings.ishaIqamaTime),
    ];

    PrayerName targetPrayer = PrayerName.fajr;
    PrayerPhase currentPhase = PrayerPhase.countdown;
    DateTime? targetEventTime;

    const adhanDuration = Duration(minutes: 3);
    final blackScreenDuration =
        Duration(minutes: settings.blackScreenDurationMinutes);
    final khushooDuration = Duration(minutes: settings.khushooModeDuration);

    if (settings.isKhushooManualActive) {
      return TimerState(
        timeUntilNext: Duration.zero,
        currentOrNextPrayer: PrayerName.none,
        phase: PrayerPhase.blackScreen,
        now: now,
      );
    }

    for (int i = prayers.length - 1; i >= 0; i--) {
      final p = prayers[i];
      final pName = p.$1;
      final pTime = p.$2;
      final pIqamaMinutes = p.$3;

      if (now.isAfter(pTime) || now.isAtSameMomentAs(pTime)) {
        if (pName == PrayerName.sunrise) {
          break;
        }

        final adhanEndTime = pTime.add(adhanDuration);

        DateTime iqamaEndTime;
        if (pName == PrayerName.dhuhr && isFriday) {
          if (!settings.jumuaKhutbahAutoMode &&
              settings.jumuaKhutbahManualTime.isNotEmpty) {
            iqamaEndTime = _parseTime(settings.jumuaKhutbahManualTime, pTime);
          } else {
            iqamaEndTime =
                adhanEndTime.add(Duration(minutes: settings.jomoaIqamaTime));
          }
        } else {
          final pId = _getPNameId(pName);
          if (pId.isNotEmpty &&
              settings.iqamaIsFixed[pId] == true &&
              settings.iqamaFixedTimes[pId] != null) {
            iqamaEndTime = _parseTime(settings.iqamaFixedTimes[pId]!, pTime);
            if (iqamaEndTime.isBefore(pTime)) {
              iqamaEndTime = iqamaEndTime.add(const Duration(days: 1));
            }
          } else {
            iqamaEndTime = adhanEndTime.add(Duration(minutes: pIqamaMinutes));
          }
        }

        final blackScreenEndTime = iqamaEndTime.add(blackScreenDuration);
        final khushooDelay = const Duration(seconds: 10);

        if (now.isBefore(adhanEndTime)) {
          currentPhase = PrayerPhase.adhan;
          targetPrayer = pName;
          targetEventTime = adhanEndTime;
          return TimerState(
            timeUntilNext: targetEventTime.difference(now),
            currentOrNextPrayer: targetPrayer,
            phase: currentPhase,
            now: now,
          );
        } else if (now.isAfter(adhanEndTime.add(khushooDelay)) &&
            now.isBefore(adhanEndTime.add(khushooDuration)) &&
            settings.khushooModeEnabled) {
          currentPhase = PrayerPhase.blackScreen;
          targetPrayer = pName;
          targetEventTime = adhanEndTime.add(khushooDuration);
          return TimerState(
            timeUntilNext: targetEventTime.difference(now),
            currentOrNextPrayer: targetPrayer,
            phase: currentPhase,
            now: now,
          );
        } else if (now.isBefore(iqamaEndTime)) {
          currentPhase = PrayerPhase.iqama;
          targetPrayer = pName;
          targetEventTime = iqamaEndTime;
          return TimerState(
            timeUntilNext: targetEventTime.difference(now),
            currentOrNextPrayer: targetPrayer,
            phase: currentPhase,
            now: now,
          );
        } else if (now.isBefore(blackScreenEndTime) &&
            settings.showBlackScreenDuringPrayer) {
          currentPhase = PrayerPhase.blackScreen;
          targetPrayer = pName;
          targetEventTime = blackScreenEndTime;
          return TimerState(
            timeUntilNext: targetEventTime.difference(now),
            currentOrNextPrayer: targetPrayer,
            phase: currentPhase,
            now: now,
          );
        }

        break;
      }
    }

    for (final p in prayers) {
      if (now.isBefore(p.$2)) {
        targetPrayer = p.$1;
        targetEventTime = p.$2;
        break;
      }
    }

    if (targetEventTime == null) {
      targetPrayer = PrayerName.fajr;
      targetEventTime = todayTimes.fajr.add(const Duration(days: 1));
    }

    return TimerState(
      timeUntilNext: targetEventTime.difference(now),
      currentOrNextPrayer: targetPrayer,
      phase: PrayerPhase.countdown,
      now: now,
    );
  }
}
