import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/services/location_service.dart';
import 'prayer_times_provider.dart';

// Provider for LocationService
final locationServiceProvider = Provider<LocationService>((ref) {
  return LocationService(ref);
});

// Provider that reads available locations (Countries and their Cities)
final availableLocationsProvider = FutureProvider<Map<String, List<String>>>((ref) async {
  final dataSource = ref.watch(localDataSourceProvider);
  return await dataSource.loadAvailableLocations();
});

// A localized version of countries based on countries.js
final countriesNameProvider = FutureProvider<Map<String, String>>((ref) async {
  final dataSource = ref.watch(localDataSourceProvider);
  return await dataSource.loadCountriesNames();
});
