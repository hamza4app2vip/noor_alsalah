// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'timer_engine_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$timerEngineHash() => r'b8ca2c8eb46b42a68da9aa77fac1ed0457ea2933';

/// See also [TimerEngine].
@ProviderFor(TimerEngine)
final timerEngineProvider =
    AutoDisposeNotifierProvider<TimerEngine, TimerState>.internal(
  TimerEngine.new,
  name: r'timerEngineProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$timerEngineHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$TimerEngine = AutoDisposeNotifier<TimerState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
