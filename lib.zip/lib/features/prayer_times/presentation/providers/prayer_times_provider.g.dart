// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prayer_times_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localDataSourceHash() => r'e18cfe5dedf9fe4df983f6db64fce44a981a8499';

/// See also [localDataSource].
@ProviderFor(localDataSource)
final localDataSourceProvider =
    AutoDisposeProvider<PrayerTimesLocalDataSource>.internal(
  localDataSource,
  name: r'localDataSourceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$localDataSourceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LocalDataSourceRef = AutoDisposeProviderRef<PrayerTimesLocalDataSource>;
String _$getTodayPrayerTimesHash() =>
    r'a941fed404e86dee2967fa5885a67a10ee6092a0';

/// See also [getTodayPrayerTimes].
@ProviderFor(getTodayPrayerTimes)
final getTodayPrayerTimesProvider =
    AutoDisposeProvider<GetTodayPrayerTimes>.internal(
  getTodayPrayerTimes,
  name: r'getTodayPrayerTimesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getTodayPrayerTimesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GetTodayPrayerTimesRef = AutoDisposeProviderRef<GetTodayPrayerTimes>;
String _$todayPrayerTimesHash() => r'efe474bea78f4b57f8f7a46a9f4dbf7ca43df238';

/// See also [todayPrayerTimes].
@ProviderFor(todayPrayerTimes)
final todayPrayerTimesProvider = AutoDisposeFutureProvider<PrayerDay>.internal(
  todayPrayerTimes,
  name: r'todayPrayerTimesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$todayPrayerTimesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef TodayPrayerTimesRef = AutoDisposeFutureProviderRef<PrayerDay>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
