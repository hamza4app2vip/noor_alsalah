import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../providers/timer_engine_provider.dart';
import '../widgets/marquee_banner_new.dart';
import '../../../../core/utils/number_helper.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../widgets/analog_glass_clock.dart';

class PureGlassThemeLayout extends StatefulWidget {
  final AppSettings settings;
  final String dayName;
  final String gregorianStr;
  final HijriCalendar hijriDate;
  final String nextPrayerId;
  final String nextPrayerStr;
  final String timeUntilStr;
  final List<String> tickerItems;
  final TimerState timerState;
  final Widget Function(AppSettings) buildHeader;
  final String currentTime;
  final String iqamaTimerText;
  final List<Map<String, dynamic>> prayers;
  final ImageProvider? backgroundImage;

  const PureGlassThemeLayout({
    super.key,
    required this.settings,
    required this.dayName,
    required this.gregorianStr,
    required this.hijriDate,
    required this.nextPrayerId,
    required this.nextPrayerStr,
    required this.timeUntilStr,
    required this.tickerItems,
    required this.timerState,
    required this.buildHeader,
    required this.currentTime,
    required this.iqamaTimerText,
    required this.prayers,
    this.backgroundImage,
  });

  @override
  State<PureGlassThemeLayout> createState() => _PureGlassThemeLayoutState();
}

class _PureGlassThemeLayoutState extends State<PureGlassThemeLayout>
    with TickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideUpAnimation;

  late AnimationController _shineController;
  late Animation<double> _shineAnimation;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1100));
    final entryCurve = CurvedAnimation(
        parent: _entryController,
        curve: const Interval(0.0, 0.6, curve: Cubic(0.16, 1.0, 0.3, 1.0)));
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(entryCurve);
    _slideUpAnimation =
        Tween<Offset>(begin: const Offset(0.0, 0.2), end: Offset.zero)
            .animate(entryCurve);
    _entryController.forward();

    _shineController =
        AnimationController(vsync: this, duration: const Duration(seconds: 4));
    _shineAnimation = Tween<double>(begin: -1.5, end: 1.5).animate(
      CurvedAnimation(
          parent: _shineController,
          curve: const Interval(0.0, 0.40, curve: Curves.easeInOut)),
    );
    _syncShineState();
  }

  @override
  void didUpdateWidget(covariant PureGlassThemeLayout oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.settings.glassShineEnabled !=
        widget.settings.glassShineEnabled) {
      _syncShineState();
    }
  }

  void _syncShineState() {
    if (widget.settings.glassShineEnabled) {
      _shineController.repeat();
    } else {
      _shineController
        ..stop()
        ..value = 0;
    }
  }

  @override
  void dispose() {
    _entryController.dispose();
    _shineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenSize = mediaQuery.size;
    final isLandscape = mediaQuery.orientation == Orientation.landscape;

    final isDefaultBg = widget.settings.selectedBackgroundId == 0 &&
        widget.settings.selectedCustomBgPath == null;

    // Determine if we should show the header as a standalone overlay (Portrait or Landscape FULL/CENTER)
    final showOverlayHeader = !isLandscape ||
        (widget.settings.navbarPosition == 'FULL' ||
            widget.settings.navbarPosition == 'CENTER');
    final horizontalPadding = screenSize.width < 380 ? 16.0 : 20.0;
    final topPadding = showOverlayHeader
        ? _overlayHeaderReservedHeight(
            isLandscape: isLandscape, screenSize: screenSize)
        : 15.0;
    final bottomPadding = widget.settings.showMarqueeTicker
        ? _tickerReservedHeight(isLandscape: isLandscape)
        : 14.0;

    return Stack(
      children: [
        if (isDefaultBg)
          _BackgroundShapes(settings: widget.settings)
        else if (widget.backgroundImage != null)
          Positioned.fill(
            child: Image(
              image: widget.backgroundImage!,
              fit: widget.settings.bgFitMode == 'CONTAIN'
                  ? BoxFit.contain
                  : (widget.settings.bgFitMode == 'FILL'
                      ? BoxFit.fill
                      : BoxFit.cover),
            ),
          ),
        if (!isDefaultBg)
          Positioned.fill(
            child: Container(
              color: Colors.black.withValues(alpha: 0.45),
            ),
          ),
        if (showOverlayHeader)
          Positioned(
            top: isLandscape ? 8.0 : 10.0,
            left: horizontalPadding,
            right: horizontalPadding,
            child: widget.settings.navbarPosition == 'CENTER' && isLandscape
                ? Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 800),
                      child: widget.buildHeader(widget.settings),
                    ),
                  )
                : widget.buildHeader(widget.settings),
          ),
        Padding(
          padding: EdgeInsets.only(
            top: topPadding,
            bottom: bottomPadding,
            left: horizontalPadding,
            right: horizontalPadding,
          ),
          child: isLandscape ? _buildLandscapeLayout() : _buildPortraitLayout(),
        ),
        if (widget.settings.showMarqueeTicker)
          Positioned(
            bottom: isLandscape ? 4.0 : 8.0,
            left: horizontalPadding,
            right: horizontalPadding,
            child: _buildNewsTicker(isLandscape),
          ),
      ],
    );
  }

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  double _overlayHeaderReservedHeight({
    required bool isLandscape,
    required Size screenSize,
  }) {
    if (isLandscape) {
      return (screenSize.height * 0.11).clamp(84.0, 104.0).toDouble();
    }
    return (screenSize.height * 0.13).clamp(96.0, 118.0).toDouble();
  }

  double _tickerReservedHeight({required bool isLandscape}) {
    return isLandscape ? 44.0 : 64.0;
  }

  Widget _buildPortraitLayout() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final prayerCount = widget.prayers.length;
        final hasNightPrayers = prayerCount > 6;
        final veryCompact = prayerCount > 7 || constraints.maxHeight < 760;
        final heroFlex = widget.settings.enableAnalogGlassClock
            ? (veryCompact ? 44 : (hasNightPrayers ? 46 : 48))
            : (veryCompact ? 30 : (hasNightPrayers ? 32 : 34));
        final sectionGap = veryCompact ? 4.0 : 6.0;

        return Column(
          children: [
            Flexible(
              flex: heroFlex,
              child: SizedBox.expand(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    width: constraints.maxWidth,
                    child: _buildHeroCard(false),
                  ),
                ),
              ),
            ),
            SizedBox(height: sectionGap),
            Expanded(
              flex: 100 - heroFlex,
              child: _buildPrayersList(false),
            ),
          ],
        );
      },
    );
  }

  Widget _buildLandscapeLayout() {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Keep everything in one screen in landscape with no page scrolling.
        return SizedBox(
          width: constraints.maxWidth,
          height: constraints.maxHeight,
          child: _buildLandscapeMainContent(),
        );
      },
    );
  }

  Widget _buildLandscapeMainContent() {
    final cards = _buildLandscapePrayerCardsData();
    Map<String, dynamic>? featured;

    if (cards.isNotEmpty) {
      for (final card in cards) {
        if (card['isNext'] == true) {
          featured = card;
          break;
        }
      }
      featured ??= cards.first;
    }

    return Row(
      textDirection: TextDirection.ltr,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          flex: 58,
          child: _buildLandscapePrayerColumn(cards),
        ),
        const SizedBox(width: 14),
        Expanded(
          flex: 42,
          child: _buildLandscapeInfoRail(featuredCard: featured),
        ),
      ],
    );
  }

  List<Map<String, dynamic>> _buildLandscapePrayerCardsData() {
    var hasReachedNextPrayer = false;

    return widget.prayers.map((item) {
      final isNext = item['id'] == widget.nextPrayerId;
      if (isNext) hasReachedNextPrayer = true;

      final isPast = !hasReachedNextPrayer && !isNext;
      var displayTime = '${item['time'] ?? '--:--'}';
      var displayIqama = '${item['iqama'] ?? ''}';

      if (displayIqama == 'null') {
        displayIqama = '';
      }

      if (widget.settings.useArabicIndicDigits) {
        displayTime = NumberHelper.format(displayTime, true);
        if (displayIqama.isNotEmpty) {
          displayIqama = NumberHelper.format(displayIqama, true);
        }
      }

      return {
        'item': item,
        'isNext': isNext,
        'isPast': isPast,
        'displayTime': displayTime,
        'displayIqama': displayIqama,
      };
    }).toList();
  }

  Widget _buildLandscapePrayerColumn(List<Map<String, dynamic>> cards) {
    if (cards.isEmpty) {
      return const SizedBox.shrink();
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final count = cards.length;
        final labelHeight = (constraints.maxHeight * (count > 6 ? 0.054 : 0.06))
            .clamp(34.0, 44.0)
            .toDouble();
        final labelGap = (labelHeight * 0.10).clamp(3.0, 5.0).toDouble();
        final spacing = count > 6 ? 10.0 : 12.0;
        final availableListHeight = math.max(
          0.0,
          constraints.maxHeight - labelHeight - labelGap,
        );
        final totalSpacing = spacing * math.max(0, count - 1);
        final usableHeight = math.max(0.0, availableListHeight - totalSpacing);
        final rawCardHeight = usableHeight / math.max(1, count);
        final cardHeight = rawCardHeight.clamp(70.0, 108.0).toDouble();
        final usedHeight = cardHeight * count + totalSpacing;
        final remainingHeight = math.max(0.0, availableListHeight - usedHeight);
        final topInset = remainingHeight <= 0
            ? 0.0
            : math.min(remainingHeight, (cardHeight * 0.16).clamp(8.0, 16.0));
        final bottomInset = math.max(0.0, remainingHeight - topInset);

        return Column(
          children: [
            SizedBox(
              height: labelHeight,
              child: _buildLandscapePrayerHeaderRow(cardHeight),
            ),
            SizedBox(height: labelGap),
            Expanded(
              child: Column(
                children: [
                  if (topInset > 0) SizedBox(height: topInset),
                  for (var i = 0; i < count; i++) ...[
                    SizedBox(
                      height: cardHeight,
                      child: _buildLandscapePrayerCard(cards[i], i, cardHeight),
                    ),
                    if (i != count - 1) SizedBox(height: spacing),
                  ],
                  if (bottomInset > 0) SizedBox(height: bottomInset),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildLandscapePrayerHeaderRow(double cardHeight) {
    final useCenteredLandscapeLayout =
        widget.settings.centerPrayerNamesLandscape ||
            widget.settings.centerNameWithTimesOnSides;
    final sidePadding = cardHeight * 0.24;
    final badgeWidth = math.max(cardHeight * 1.0, 86.0);
    final timeWidth = cardHeight * (useCenteredLandscapeLayout ? 2.12 : 1.76);
    final innerGap = cardHeight * 0.18;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: sidePadding),
      child: Row(
        textDirection: TextDirection.ltr,
        children: [
          SizedBox(
            width: badgeWidth,
            child: Align(
              alignment: Alignment.centerLeft,
              child: _buildLandscapeColumnTitle('الإقامة', cardHeight),
            ),
          ),
          SizedBox(width: innerGap),
          if (useCenteredLandscapeLayout) ...[
            Expanded(
              child: Center(
                child: _buildLandscapeColumnTitle('اسم الصلاة', cardHeight),
              ),
            ),
            SizedBox(width: cardHeight * 0.14),
            SizedBox(
              width: timeWidth,
              child: Align(
                alignment: Alignment.centerRight,
                child: _buildLandscapeColumnTitle('وقت الصلاة', cardHeight),
              ),
            ),
          ] else ...[
            SizedBox(
              width: timeWidth,
              child: Center(
                child: _buildLandscapeColumnTitle('وقت الصلاة', cardHeight),
              ),
            ),
            SizedBox(width: cardHeight * 0.14),
            Expanded(
              child: Align(
                alignment: Alignment.centerRight,
                child: _buildLandscapeColumnTitle('اسم الصلاة', cardHeight),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildLandscapeColumnTitle(String text, double cardHeight) {
    final textColor = _parseHex(widget.settings.pureGlassTextColor);
    final accentColor = _parseHex(
      widget.settings.pureGlassColor1,
      fallback: const Color(0xFF38BDF8),
    );
    final isEmerald = widget.settings.appTheme == 'EMERALD';
    final fontSize = (cardHeight * 0.18).clamp(14.0, 18.0).toDouble();
    final horizontalPadding = (cardHeight * 0.16).clamp(12.0, 18.0).toDouble();
    final verticalPadding = (cardHeight * 0.07).clamp(6.0, 8.0).toDouble();

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: horizontalPadding,
        vertical: verticalPadding,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: Colors.black.withValues(alpha: isEmerald ? 0.18 : 0.24),
        border: Border.all(
          color: (isEmerald ? textColor : accentColor).withValues(alpha: 0.24),
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: 'Cairo',
          fontSize: fontSize,
          fontWeight: FontWeight.w800,
          color: isEmerald
              ? textColor.withValues(alpha: 0.92)
              : Colors.white.withValues(alpha: 0.86),
        ),
      ),
    );
  }

  Widget _buildLandscapePrayerCard(
      Map<String, dynamic> card, int index, double cardHeight) {
    final textColor = _parseHex(widget.settings.pureGlassTextColor);
    final accentColor = _parseHex(widget.settings.pureGlassColor1,
        fallback: const Color(0xFF38BDF8));
    final goldColor = widget.settings.appTheme == 'EMERALD'
        ? textColor
        : const Color(0xFFE2C473);
    final rawItem = card['item'];
    final item = rawItem is Map ? rawItem : const <String, dynamic>{};
    final isNext = card['isNext'] == true;
    final isPast = card['isPast'] == true;
    final shouldDim = isPast && widget.settings.dimPastPrayers;
    final displayTime = card['displayTime'] as String;
    final displayIqama = card['displayIqama'] as String;
    final badgeText = displayIqama.isNotEmpty && !widget.settings.hideIqamaTime
        ? displayIqama
        : '—';
    final primaryName = widget.settings.languageCode == 'ar'
        ? '${item['nameAr'] ?? item['nameEn'] ?? ''}'
        : '${item['nameEn'] ?? item['nameAr'] ?? ''}';
    final secondaryName = widget.settings.languageCode == 'ar'
        ? '${item['nameEn'] ?? ''}'
        : '${item['nameAr'] ?? ''}';
    final showSecondary = widget.settings.showPrayerNameInOtherLanguage &&
        secondaryName.trim().isNotEmpty;
    final useCenteredLandscapeLayout =
        widget.settings.centerPrayerNamesLandscape ||
            widget.settings.centerNameWithTimesOnSides;
    final timeWidth = cardHeight * (useCenteredLandscapeLayout ? 2.12 : 1.76);
    final badgeGap = cardHeight * 0.18;
    final contentGap = cardHeight * 0.14;

    final double delayStart = 0.07 * (index + 1);
    final double normalizedStart = math.min(delayStart / 1.0, 0.9);
    final slideAnim = Tween<double>(begin: 24.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: Interval(normalizedStart, 1.0, curve: Curves.easeOut),
      ),
    );
    final fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: Interval(normalizedStart, 1.0, curve: Curves.easeOut),
      ),
    );

    final timeColor = isNext ? accentColor : goldColor;
    final primaryColor = isNext
        ? accentColor
        : (widget.settings.appTheme == 'EMERALD' ? Colors.white : textColor);
    final secondaryColor = widget.settings.appTheme == 'EMERALD'
        ? Colors.white.withValues(alpha: 0.58)
        : textColor.withValues(alpha: 0.48);

    final prayerNameLabel = FittedBox(
      fit: BoxFit.scaleDown,
      alignment:
          useCenteredLandscapeLayout ? Alignment.center : Alignment.centerRight,
      child: Text.rich(
        TextSpan(
          style: TextStyle(
            fontFamily: widget.settings.timesFontFamily,
            fontSize: cardHeight * 0.35,
            fontWeight: FontWeight.w800,
            color: primaryColor,
          ),
          children: [
            TextSpan(text: primaryName),
            if (showSecondary) const TextSpan(text: '  '),
            if (showSecondary)
              TextSpan(
                text: secondaryName,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: cardHeight * 0.18,
                  fontWeight: FontWeight.w700,
                  color: secondaryColor,
                ),
              ),
          ],
        ),
        textAlign:
            useCenteredLandscapeLayout ? TextAlign.center : TextAlign.right,
        textDirection: TextDirection.ltr,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );

    final timeLabel = FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(
        displayTime,
        textDirection: TextDirection.ltr,
        style: TextStyle(
          fontFamily: widget.settings.clockFontFamily,
          fontSize: cardHeight * (useCenteredLandscapeLayout ? 0.43 : 0.41),
          fontWeight: FontWeight.w900,
          color: timeColor,
          letterSpacing: -0.4,
        ),
      ),
    );

    return AnimatedBuilder(
      animation: _entryController,
      builder: (context, child) => Transform.translate(
        offset: Offset(0, slideAnim.value),
        child: Opacity(
          opacity: fadeAnim.value * (shouldDim ? 0.45 : 1.0),
          child: child,
        ),
      ),
      child: _PureGlassContainer(
        settings: widget.settings,
        hasShine: isNext,
        shineController: _shineController,
        shineAnimation: _shineAnimation,
        isActive: isNext,
        borderRadius: 34.0,
        padding: EdgeInsets.symmetric(
          horizontal: cardHeight * 0.24,
          vertical: cardHeight * 0.16,
        ),
        child: Row(
          textDirection: TextDirection.ltr,
          children: [
            _buildLandscapeIqamaBadge(
              badgeText: badgeText,
              isActive: isNext,
              height: cardHeight,
              accentColor: accentColor,
              goldColor: goldColor,
            ),
            SizedBox(width: badgeGap),
            if (useCenteredLandscapeLayout) ...[
              Expanded(
                child: Center(child: prayerNameLabel),
              ),
              SizedBox(width: contentGap),
              SizedBox(
                width: timeWidth,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: timeLabel,
                ),
              ),
            ] else ...[
              SizedBox(
                width: timeWidth,
                child: Center(child: timeLabel),
              ),
              SizedBox(width: contentGap),
              Expanded(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: prayerNameLabel,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildLandscapeIqamaBadge({
    required String badgeText,
    required bool isActive,
    required double height,
    required Color accentColor,
    required Color goldColor,
  }) {
    final isEmerald = widget.settings.appTheme == 'EMERALD';
    final badgeHeight = height * 0.58;
    final badgeWidth = math.max(height * 0.96, 82.0);

    return Container(
      width: badgeWidth,
      height: badgeHeight,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(badgeHeight / 2),
        gradient: isEmerald && isActive
            ? const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFD4A95B), Color(0xFFA67C33)],
              )
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white.withValues(alpha: isActive ? 0.18 : 0.10),
                  Colors.white.withValues(alpha: isActive ? 0.08 : 0.03),
                ],
              ),
        border: Border.all(
          color: isEmerald && isActive
              ? goldColor.withValues(alpha: 0.54)
              : Colors.white.withValues(alpha: 0.10),
        ),
        boxShadow: [
          BoxShadow(
            color: (isActive ? accentColor : Colors.black)
                .withValues(alpha: isActive ? 0.24 : 0.22),
            offset: const Offset(0, 2),
            blurRadius: 6,
          ),
        ],
      ),
      child: Center(
        child: Text(
          badgeText,
          textDirection: TextDirection.ltr,
          style: TextStyle(
            fontFamily: widget.settings.clockFontFamily,
            fontSize: badgeHeight * 0.38,
            fontWeight: FontWeight.w800,
            color: isEmerald && isActive
                ? const Color(0xFF111111)
                : Colors.white.withValues(alpha: 0.92),
          ),
        ),
      ),
    );
  }

  Widget _buildLandscapeInfoRail(
      {required Map<String, dynamic>? featuredCard}) {
    final textColor = _parseHex(widget.settings.pureGlassTextColor);
    final accentColor = _parseHex(widget.settings.pureGlassColor1,
        fallback: const Color(0xFF38BDF8));

    final isIqamaPhase = widget.timerState.phase == PrayerPhase.iqama;
    final hasValidIqamaTime = widget.iqamaTimerText.isNotEmpty &&
        widget.iqamaTimerText != '--:--' &&
        widget.iqamaTimerText != '00:00';
    final isShowingIqama = isIqamaPhase && hasValidIqamaTime;

    final bool isGreen = widget.settings.countdownGreenLast90s &&
        widget.timerState.timeUntilNext.inSeconds <= 90;
    final Color timerColor = isGreen ? const Color(0xFF4ADE80) : accentColor;

    final countdownTitle = isShowingIqama
        ? 'نهاية وقت الإقامة وتكبيرة الإحرام'
        : 'الوقت المتبقي لـ ${widget.nextPrayerStr}';
    final countdownTimeStr =
        isShowingIqama ? widget.iqamaTimerText : widget.timeUntilStr;
    final displayTimeUntil = NumberHelper.format(
        countdownTimeStr, widget.settings.useArabicIndicDigits);

    final hijriMonthsAr = [
      '',
      'محرم',
      'صفر',
      'ربيع الأول',
      'ربيع الثاني',
      'جمادى الأولى',
      'جمادى الآخرة',
      'رجب',
      'شعبان',
      'رمضان',
      'شوال',
      'ذو القعدة',
      'ذو الحجة'
    ];
    final hijriMonthName = hijriMonthsAr[widget.hijriDate.hMonth];
    final hijriDay = NumberHelper.format(
        widget.hijriDate.hDay, widget.settings.useArabicIndicDigits);
    final hijriYear = NumberHelper.format(
        widget.hijriDate.hYear, widget.settings.useArabicIndicDigits);

    final displayGregorian = NumberHelper.format(
        widget.gregorianStr, widget.settings.useArabicIndicDigits);
    final displayClock = NumberHelper.format(
        widget.currentTime, widget.settings.useArabicIndicDigits);
    final featuredRawItem = featuredCard?['item'];
    final featuredName = featuredRawItem is Map
        ? '${featuredRawItem['nameAr'] ?? 'Prayer Time'}'
        : 'Prayer Time';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.settings.navbarPosition == 'SIDE') ...[
          widget.buildHeader(widget.settings),
          const SizedBox(height: 10),
        ],
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final count = widget.prayers.length;
              final spacing = count > 6 ? 12.0 : 14.0;
              final totalSpacing = spacing * math.max(0, count - 1);
              final usableHeight =
                  math.max(0.0, constraints.maxHeight - totalSpacing);
              final rawPrayerHeight = usableHeight / math.max(1, count);
              final frameHeight = rawPrayerHeight.clamp(68.0, 96.0).toDouble();
              const frameGap = 12.0;
              final showDateFrame = widget.settings.showAnalogClockDateFrame;

              if (widget.settings.enableAnalogGlassClock) {
                final reservedHeight = frameHeight +
                    frameGap +
                    (showDateFrame ? frameHeight + frameGap : 0);
                final clockHeight = math.max(
                    frameHeight * 2.85, constraints.maxHeight - reservedHeight);

                return Column(
                  children: [
                    SizedBox(
                      height: clockHeight,
                      child: Center(
                        child: LayoutBuilder(
                          builder: (context, box) {
                            final size = math.min(
                              box.maxWidth * 0.92,
                              box.maxHeight * 0.96,
                            );
                            return AnalogGlassClock(
                              baseTime: widget.timerState.now,
                              size: size,
                              brand: 'NOOR',
                              showHourNumbers:
                                  widget.settings.showAnalogClockNumbers,
                              useArabicIndicDigits:
                                  widget.settings.useArabicIndicDigits,
                              style: widget.settings.analogClockStyle,
                              enableShine: widget.settings.glassShineEnabled,
                            );
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: frameGap),
                    if (showDateFrame) ...[
                      SizedBox(
                        height: frameHeight,
                        child: _buildLandscapeDateFrame(
                          displayGregorian: displayGregorian,
                          dayName: widget.dayName,
                          hijriDay: hijriDay,
                          hijriMonthName: hijriMonthName,
                          hijriYear: hijriYear,
                          textColor: textColor,
                          accentColor: accentColor,
                        ),
                      ),
                      SizedBox(height: frameGap),
                    ],
                    SizedBox(
                      height: frameHeight,
                      child: _buildLandscapeCountdownFrame(
                        displayTimeUntil: displayTimeUntil,
                        countdownTitle: countdownTitle,
                        timerColor: timerColor,
                        textColor: textColor,
                        frameHeight: frameHeight,
                      ),
                    ),
                  ],
                );
              }

              final contentHeight = frameHeight +
                  frameGap +
                  frameHeight +
                  (showDateFrame ? frameGap + frameHeight : 0);
              final remainingHeight =
                  math.max(0.0, constraints.maxHeight - contentHeight);
              final topInset = remainingHeight * 0.56;
              final bottomInset = remainingHeight - topInset;

              return Column(
                children: [
                  if (topInset > 0) SizedBox(height: topInset),
                  SizedBox(
                    height: frameHeight,
                    child: _buildLandscapeDigitalClockFrame(
                      displayClock: displayClock,
                      featuredName: featuredName,
                      textColor: textColor,
                      accentColor: accentColor,
                      frameHeight: frameHeight,
                    ),
                  ),
                  SizedBox(height: frameGap),
                  if (showDateFrame) ...[
                    SizedBox(
                      height: frameHeight,
                      child: _buildLandscapeDateFrame(
                        displayGregorian: displayGregorian,
                        dayName: widget.dayName,
                        hijriDay: hijriDay,
                        hijriMonthName: hijriMonthName,
                        hijriYear: hijriYear,
                        textColor: textColor,
                        accentColor: accentColor,
                      ),
                    ),
                    SizedBox(height: frameGap),
                  ],
                  SizedBox(
                    height: frameHeight,
                    child: _buildLandscapeCountdownFrame(
                      displayTimeUntil: displayTimeUntil,
                      countdownTitle: countdownTitle,
                      timerColor: timerColor,
                      textColor: textColor,
                      frameHeight: frameHeight,
                    ),
                  ),
                  if (bottomInset > 0) SizedBox(height: bottomInset),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLandscapeDigitalClockFrame({
    required String displayClock,
    required String featuredName,
    required Color textColor,
    required Color accentColor,
    required double frameHeight,
  }) {
    return _PureGlassContainer(
      settings: widget.settings,
      borderRadius: 34,
      padding: EdgeInsets.symmetric(
        horizontal: frameHeight * 0.28,
        vertical: frameHeight * 0.14,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              displayClock,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontFamily: widget.settings.clockFontFamily,
                fontSize: frameHeight * 0.52,
                fontWeight: FontWeight.w900,
                color: textColor,
                letterSpacing: -0.6,
              ),
            ),
          ),
          SizedBox(height: frameHeight * 0.04),
          Text(
            featuredName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: widget.settings.timesFontFamily,
              fontSize: frameHeight * 0.20,
              fontWeight: FontWeight.w800,
              color: accentColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLandscapeDateFrame({
    required String displayGregorian,
    required String dayName,
    required String hijriDay,
    required String hijriMonthName,
    required String hijriYear,
    required Color textColor,
    required Color accentColor,
  }) {
    return _PureGlassContainer(
      settings: widget.settings,
      borderRadius: 34,
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
      child: Row(
        textDirection: TextDirection.ltr,
        children: [
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  displayGregorian,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: widget.settings.clockFontFamily,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  dayName,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: textColor.withValues(alpha: 0.78),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 1,
            height: 42,
            color: textColor.withValues(alpha: 0.18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '$hijriDay $hijriMonthName',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: accentColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$hijriYear هـ',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: textColor.withValues(alpha: 0.78),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLandscapeCountdownFrame({
    required String displayTimeUntil,
    required String countdownTitle,
    required Color timerColor,
    required Color textColor,
    required double frameHeight,
  }) {
    return _PureGlassContainer(
      settings: widget.settings,
      borderRadius: 34,
      padding: EdgeInsets.symmetric(
        horizontal: frameHeight * 0.28,
        vertical: frameHeight * 0.14,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  displayTimeUntil,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  style: TextStyle(
                    fontFamily: widget.settings.clockFontFamily,
                    fontSize: frameHeight * 0.48,
                    fontWeight: FontWeight.w900,
                    color: timerColor,
                    letterSpacing: -0.3,
                  ),
                ),
              ),
            ),
          ),
          Text(
            countdownTitle,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: frameHeight * 0.18,
              fontWeight: FontWeight.w700,
              color: textColor.withValues(alpha: 0.75),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard(bool isLandscape) {
    final textColor = _parseHex(widget.settings.pureGlassTextColor);
    final accentColor = _parseHex(widget.settings.pureGlassColor1,
        fallback: const Color(0xFF38BDF8));

    // Smart iqama logic
    final isIqamaPhase = widget.timerState.phase == PrayerPhase.iqama;
    final hasValidIqamaTime = widget.iqamaTimerText.isNotEmpty &&
        widget.iqamaTimerText != '--:--' &&
        widget.iqamaTimerText != '00:00';
    final isShowingIqama = isIqamaPhase && hasValidIqamaTime;

    final bool isGreen = widget.settings.countdownGreenLast90s &&
        widget.timerState.timeUntilNext.inSeconds <= 90;
    final Color timerColor = isGreen ? const Color(0xFF4ADE80) : accentColor;

    final bool enlargeTimer = widget.settings.enlargeCountdown;
    final double countdownFontSize =
        enlargeTimer ? (isShowingIqama ? 32 : 28) : (isShowingIqama ? 22 : 18);

    final countdownTitle = isShowingIqama
        ? 'نهاية وقت الإقامة وتكبيرة الإحرام'
        : 'الوقت المتبقي لـ ${widget.nextPrayerStr}';
    final countdownTimeStr =
        isShowingIqama ? widget.iqamaTimerText : widget.timeUntilStr;
    final displayTimeUntil = NumberHelper.format(
        countdownTimeStr, widget.settings.useArabicIndicDigits);
    final boxColor = isShowingIqama
        ? timerColor.withValues(alpha: 0.1)
        : Colors.white.withValues(alpha: 0.05);
    final borderColor = isShowingIqama
        ? timerColor.withValues(alpha: 0.3)
        : Colors.white.withValues(alpha: 0.1);

    final hijriMonthsAr = [
      '',
      'محرم',
      'صفر',
      'ربيع الأول',
      'ربيع الثاني',
      'جمادى الأولى',
      'جمادى الآخرة',
      'رجب',
      'شعبان',
      'رمضان',
      'شوال',
      'ذو القعدة',
      'ذو الحجة'
    ];
    final hijriMonthName = hijriMonthsAr[widget.hijriDate.hMonth];
    final hijriDay = NumberHelper.format(
        widget.hijriDate.hDay, widget.settings.useArabicIndicDigits);
    final hijriYear = NumberHelper.format(
        widget.hijriDate.hYear, widget.settings.useArabicIndicDigits);
    final hijriStr = '$hijriDay $hijriMonthName $hijriYear هـ';

    final gregorianDigitsOnly = widget.settings.useArabicIndicDigits;
    final displayGregorian =
        NumberHelper.format(widget.gregorianStr, gregorianDigitsOnly);
    final displayClock = NumberHelper.format(
        widget.currentTime, widget.settings.useArabicIndicDigits);

    return AnimatedBuilder(
      animation: _entryController,
      builder: (context, child) => Transform.translate(
          offset: Offset(0, _slideUpAnimation.value.dy * 50),
          child: Opacity(opacity: _fadeAnimation.value, child: child)),
      child: widget.settings.enableAnalogGlassClock
          ? _buildAnalogHeroContent(
              isLandscape: isLandscape,
              textColor: textColor,
              accentColor: accentColor,
              displayGregorian: displayGregorian,
              hijriStr: hijriStr,
              countdownTitle: countdownTitle,
              displayTimeUntil: displayTimeUntil,
              timerColor: timerColor,
              enlargeTimer: enlargeTimer,
              countdownFontSize: countdownFontSize,
              boxColor: boxColor,
              borderColor: borderColor,
              isShowingIqama: isShowingIqama,
            )
          : _buildDefaultHeroContent(
              isLandscape: isLandscape,
              textColor: textColor,
              accentColor: accentColor,
              displayGregorian: displayGregorian,
              hijriStr: hijriStr,
              displayClock: displayClock,
              countdownTitle: countdownTitle,
              displayTimeUntil: displayTimeUntil,
              timerColor: timerColor,
              countdownFontSize: countdownFontSize,
              boxColor: boxColor,
              borderColor: borderColor,
              enlargeTimer: enlargeTimer,
              isShowingIqama: isShowingIqama,
            ),
    );
  }

  Widget _buildAnalogHeroContent({
    required bool isLandscape,
    required Color textColor,
    required Color accentColor,
    required String displayGregorian,
    required String hijriStr,
    required String countdownTitle,
    required String displayTimeUntil,
    required Color timerColor,
    required bool enlargeTimer,
    required double countdownFontSize,
    required Color boxColor,
    required Color borderColor,
    required bool isShowingIqama,
  }) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final compactPortrait =
        !isLandscape && (widget.prayers.length > 7 || screenHeight < 760);
    final clockSize = isLandscape
        ? 210.0
        : math.min(
            screenWidth * (compactPortrait ? 0.69 : 0.75),
            screenHeight * (compactPortrait ? 0.32 : 0.36),
          );
    final frameWidthFactor = compactPortrait ? 0.82 : 0.86;
    final dateFontSize = compactPortrait ? 24.0 : 26.0;
    final countdownTitleSize = compactPortrait ? 14.0 : 15.0;
    final portraitCountdownFontSize = !isLandscape
        ? math.max(countdownFontSize, compactPortrait ? 22.0 : 24.0)
        : countdownFontSize;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: AnalogGlassClock(
            baseTime: widget.timerState.now,
            size: clockSize,
            brand: 'NOOR',
            showHourNumbers: widget.settings.showAnalogClockNumbers,
            useArabicIndicDigits: widget.settings.useArabicIndicDigits,
            style: widget.settings.analogClockStyle,
            enableShine: widget.settings.glassShineEnabled,
          ),
        ),
        SizedBox(height: compactPortrait ? 10 : 12),
        Align(
          child: FractionallySizedBox(
            widthFactor: isLandscape ? 1.0 : frameWidthFactor,
            child: _PureGlassContainer(
              settings: widget.settings,
              borderRadius: compactPortrait ? 18 : 20,
              padding: EdgeInsets.symmetric(
                horizontal: compactPortrait ? 18 : 22,
                vertical: compactPortrait ? 12 : 14,
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  '${widget.dayName}  •  $displayGregorian  •  $hijriStr',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: dateFontSize,
                    fontWeight: FontWeight.w800,
                    color: textColor,
                  ),
                ),
              ),
            ),
          ),
        ),
        if (widget.settings.showCountdown) ...[
          SizedBox(height: compactPortrait ? 10 : 12),
          Align(
            child: FractionallySizedBox(
              widthFactor: isLandscape ? 1.0 : frameWidthFactor,
              child: _PureGlassContainer(
                settings: widget.settings,
                borderRadius: compactPortrait ? 18 : 20,
                padding: EdgeInsets.symmetric(
                  horizontal: compactPortrait ? 18 : 22,
                  vertical: compactPortrait ? 11 : 13,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            countdownTitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: countdownTitleSize,
                              fontWeight: isShowingIqama
                                  ? FontWeight.w700
                                  : FontWeight.w600,
                              color: isShowingIqama
                                  ? textColor
                                  : textColor.withValues(alpha: 0.68),
                            ),
                          ),
                          const SizedBox(height: 4),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: AlignmentDirectional.centerStart,
                            child: Text(
                              displayTimeUntil,
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: portraitCountdownFontSize,
                                fontWeight: FontWeight.w900,
                                color: timerColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      padding: EdgeInsets.all(compactPortrait ? 10 : 12),
                      decoration: BoxDecoration(
                        color: boxColor,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: borderColor),
                      ),
                      child: Icon(Icons.timer_outlined,
                          color: timerColor, size: enlargeTimer ? 32 : 28),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildDefaultHeroContent({
    required bool isLandscape,
    required Color textColor,
    required Color accentColor,
    required String displayGregorian,
    required String hijriStr,
    required String displayClock,
    required String countdownTitle,
    required String displayTimeUntil,
    required Color timerColor,
    required double countdownFontSize,
    required Color boxColor,
    required Color borderColor,
    required bool enlargeTimer,
    required bool isShowingIqama,
  }) {
    final compactPortrait = !isLandscape &&
        (widget.prayers.length > 7 || MediaQuery.of(context).size.height < 760);

    return _PureGlassContainer(
      settings: widget.settings,
      borderRadius: isLandscape ? 20.0 : (compactPortrait ? 15.0 : 16.0),
      padding:
          EdgeInsets.all(isLandscape ? 24.0 : (compactPortrait ? 16.0 : 18.0)),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(
                    '${widget.dayName}  •  $displayGregorian  •  $hijriStr',
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: textColor),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                displayClock,
                style: TextStyle(
                  fontFamily: widget.settings.clockFontFamily,
                  fontSize: isLandscape ? 42 : (compactPortrait ? 44 : 50),
                  fontWeight: FontWeight.bold,
                  color: textColor,
                  shadows: [
                    Shadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    )
                  ],
                ),
              ),
            ],
          ),
          if (widget.settings.showCountdown) ...[
            SizedBox(height: isLandscape ? 20 : 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: boxColor,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: borderColor),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(countdownTitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 13,
                                fontWeight: isShowingIqama
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                color: isShowingIqama
                                    ? textColor
                                    : textColor.withValues(alpha: 0.6))),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: AlignmentDirectional.centerStart,
                          child: Text(displayTimeUntil,
                              style: TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: countdownFontSize,
                                  fontWeight: FontWeight.w900,
                                  color: timerColor)),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.timer_outlined,
                      color: timerColor, size: enlargeTimer ? 34 : 28),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildPrayersList(bool isLandscape) {
    final textColor = _parseHex(widget.settings.pureGlassTextColor);
    final accentColor = _parseHex(widget.settings.pureGlassColor1,
        fallback: const Color(0xFF38BDF8));
    final screenSize = MediaQuery.of(context).size;
    final itemCount = widget.prayers.length;
    final isArabicLayout = widget.settings.languageCode == 'ar';
    final portraitDensity = !isLandscape
        ? ((0.18 +
                    ((itemCount - 6) * 0.24) +
                    (math.max(0.0, 940.0 - screenSize.height) / 170.0))
                .clamp(0.18, 1.95))
            .toDouble()
        : 0.0;
    final portraitSpacing = !isLandscape
        ? ((itemCount >= 8
                    ? 1.25
                    : itemCount >= 7
                        ? 1.8
                        : 2.4) *
                (1.0 - portraitDensity * 0.10).clamp(0.82, 1.0))
            .toDouble()
        : 4.0;

    var hasReachedNextPrayer = false;
    final items = List.generate(widget.prayers.length, (index) {
      final item = widget.prayers[index];
      final bool isNext = item['id'] == widget.nextPrayerId;
      if (isNext) hasReachedNextPrayer = true;

      final bool isPast = !hasReachedNextPrayer && !isNext;
      final bool shouldDim = isPast && widget.settings.dimPastPrayers;
      final bool enlargeNext =
          isNext && widget.settings.enlargeNextPrayerCountdown;
      final bool enlargeLandscape =
          isLandscape && widget.settings.enlargePrayerNamesLandscape;

      final double delayStart = 0.1 * (index + 1);
      final double normalizedStart = math.min(delayStart / 1.1, 0.9);
      final slideAnim = Tween<double>(begin: 20.0, end: 0.0).animate(
          CurvedAnimation(
              parent: _entryController,
              curve: Interval(normalizedStart, 1.0, curve: Curves.easeOut)));
      final fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
          CurvedAnimation(
              parent: _entryController,
              curve: Interval(normalizedStart, 1.0, curve: Curves.easeOut)));

      String displayTime = item['time'];
      String? displayIqama = item['iqama'];

      if (widget.settings.useArabicIndicDigits) {
        displayTime = NumberHelper.format(displayTime, true);
        if (displayIqama != null) {
          displayIqama = NumberHelper.format(displayIqama, true);
        }
      }

      final mergeIqamaIntoTime = widget.settings.showIqamaWithClock &&
          displayIqama != null &&
          displayIqama.isNotEmpty;
      if (mergeIqamaIntoTime) {
        displayTime = '$displayTime | $displayIqama';
      }

      bool shouldCenter = false;
      if (isLandscape && widget.settings.centerPrayerNamesLandscape) {
        shouldCenter = true;
      }
      if (!isLandscape && widget.settings.centerPrayerNamesPortrait) {
        shouldCenter = true;
      }

      final bool hasNightPrayers = itemCount > 6;
      final double verticalPadding = isLandscape
          ? (hasNightPrayers ? 8.0 : 9.0)
          : (((hasNightPrayers ? 3.6 : 4.2) * (1.0 - portraitDensity * 0.38))
                  .clamp(1.8, 3.8))
              .toDouble();

      double baseNameSize = widget.settings.prayerNameFontSize;
      double baseTimeSize = widget.settings.prayerTimeFontSize;
      double baseIqamaSize = widget.settings.iqamaTimeFontSize;

      if (hasNightPrayers) {
        baseNameSize *= 0.88;
        baseTimeSize *= 0.88;
        baseIqamaSize *= 0.88;
      }

      double nameFontSize = baseNameSize;
      double timeFontSize = baseTimeSize;
      double iqamaFontSize = baseIqamaSize;

      if (isLandscape) {
        if (enlargeLandscape) {
          nameFontSize *= 1.35;
          timeFontSize *= 1.35;
          iqamaFontSize *= 1.35;
        } else {
          nameFontSize *= 0.75;
          timeFontSize *= 0.75;
          iqamaFontSize *= 0.75;
        }
      } else {
        final portraitScale =
            (0.90 - portraitDensity * 0.18).clamp(0.62, 0.90).toDouble();
        final portraitNameMin = math.max(10.8, baseNameSize * 0.48);
        final portraitNameMax = math.max(portraitNameMin, baseNameSize * 1.00);
        final portraitTimeMin = math.max(13.0, baseTimeSize * 0.52);
        final portraitTimeMax = math.max(portraitTimeMin, baseTimeSize * 1.00);
        final portraitIqamaMin = math.max(8.0, baseIqamaSize * 0.50);
        final portraitIqamaMax =
            math.max(portraitIqamaMin, baseIqamaSize * 0.96);

        nameFontSize = (nameFontSize * portraitScale)
            .clamp(portraitNameMin, portraitNameMax);
        timeFontSize = (timeFontSize * (portraitScale + 0.01))
            .clamp(portraitTimeMin, portraitTimeMax);
        iqamaFontSize = (iqamaFontSize * (portraitScale - 0.10))
            .clamp(portraitIqamaMin, portraitIqamaMax);
      }

      final double secondaryNameSize =
          nameFontSize * (isLandscape ? 0.62 : 0.48);
      final double secondaryNameEnlarge = nameFontSize * 0.72;
      final String primaryName = isArabicLayout
          ? '${item['nameAr'] ?? item['nameEn'] ?? ''}'
          : '${item['nameEn'] ?? item['nameAr'] ?? ''}';
      final String secondaryName = isArabicLayout
          ? '${item['nameEn'] ?? ''}'
          : '${item['nameAr'] ?? ''}';
      final bool showSecondaryName =
          widget.settings.showPrayerNameInOtherLanguage &&
              secondaryName.trim().isNotEmpty;
      final bool showSeparateIqama =
          !widget.settings.hideIqamaTime && !mergeIqamaIntoTime;
      final bool useMixedCenteredLayout =
          widget.settings.centerNameWithTimesOnSides;
      final bool centerPrayerName = shouldCenter || useMixedCenteredLayout;

      final TextAlign prayerNameTextAlign = centerPrayerName
          ? TextAlign.center
          : (isArabicLayout ? TextAlign.end : TextAlign.start);
      final TextDirection prayerNameDirection =
          isArabicLayout ? TextDirection.rtl : TextDirection.ltr;
      final prayerNameLabel = Text.rich(
        key: ValueKey('pure-glass-prayer-name-${item['id']}'),
        TextSpan(
          style: TextStyle(
            fontFamily: widget.settings.timesFontFamily,
            fontSize: enlargeNext
                ? nameFontSize + (isLandscape ? 1.6 : 0.4)
                : nameFontSize,
            fontWeight: isNext ? FontWeight.w900 : FontWeight.w800,
            color: isNext ? accentColor : textColor,
          ),
          children: [
            TextSpan(text: primaryName),
            if (showSecondaryName) const TextSpan(text: '   '),
            if (showSecondaryName)
              TextSpan(
                text: secondaryName,
                style: TextStyle(
                  fontFamily: widget.settings.timesFontFamily,
                  fontSize: enlargeNext && isLandscape
                      ? secondaryNameEnlarge
                      : secondaryNameSize,
                  fontWeight: FontWeight.w600,
                  color: isNext
                      ? accentColor.withValues(alpha: 0.60)
                      : textColor.withValues(alpha: 0.42),
                ),
              ),
          ],
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        textAlign: prayerNameTextAlign,
        textDirection: prayerNameDirection,
      );

      final prayerNameWidget = Expanded(
        flex: isLandscape ? 2 : (centerPrayerName ? 6 : 5),
        child: Align(
          alignment: centerPrayerName
              ? Alignment.center
              : (isArabicLayout ? Alignment.centerRight : Alignment.centerLeft),
          child: prayerNameLabel,
        ),
      );

      final portraitTimeLabel = Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            displayTime,
            key: ValueKey('pure-glass-prayer-time-${item['id']}'),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: widget.settings.clockFontFamily,
              fontSize: enlargeNext ? timeFontSize + 1.5 : timeFontSize,
              fontWeight: FontWeight.w800,
              color: isNext ? accentColor : textColor.withValues(alpha: 0.84),
            ),
          ),
        ),
      );

      final portraitIqamaLabel = showSeparateIqama
          ? Align(
              alignment:
                  isArabicLayout ? Alignment.centerLeft : Alignment.centerRight,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  displayIqama ?? '—',
                  key: ValueKey('pure-glass-prayer-iqama-${item['id']}'),
                  textAlign: isArabicLayout ? TextAlign.left : TextAlign.right,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: iqamaFontSize,
                    fontWeight: FontWeight.w700,
                    color: isNext
                        ? accentColor.withValues(alpha: 0.82)
                        : textColor.withValues(alpha: 0.50),
                  ),
                ),
              ),
            )
          : const SizedBox.shrink();

      final landscapeTimeLabel = Text(displayTime,
          key: ValueKey('pure-glass-prayer-time-${item['id']}'),
          textAlign: TextAlign.center,
          style: TextStyle(
              fontFamily: widget.settings.clockFontFamily,
              fontSize: enlargeNext ? timeFontSize + 4 : timeFontSize,
              fontWeight: FontWeight.bold,
              color: isNext ? accentColor : textColor.withValues(alpha: 0.7)));

      final adhanTimeLabel =
          isLandscape ? landscapeTimeLabel : portraitTimeLabel;

      final adhanTimeWidget = Expanded(
        flex: isLandscape ? 2 : 3,
        child: adhanTimeLabel,
      );

      final landscapeIqamaLabel = Text(displayIqama ?? '—',
          key: ValueKey('pure-glass-prayer-iqama-${item['id']}'),
          textAlign: centerPrayerName ? TextAlign.center : TextAlign.end,
          style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: iqamaFontSize,
              fontWeight: FontWeight.w800,
              color: isNext
                  ? accentColor.withValues(alpha: 0.8)
                  : textColor.withValues(alpha: 0.4)));

      final iqamaTimeLabel =
          isLandscape ? landscapeIqamaLabel : portraitIqamaLabel;

      final iqamaTimeWidget = showSeparateIqama
          ? Expanded(
              flex: isLandscape ? (useMixedCenteredLayout ? 2 : 1) : 2,
              child: iqamaTimeLabel,
            )
          : const SizedBox.shrink();

      Widget rowContent;
      if (useMixedCenteredLayout) {
        rowContent = Row(
          textDirection: isArabicLayout ? TextDirection.rtl : TextDirection.ltr,
          children: [
            Expanded(
              flex: isLandscape ? 3 : 3,
              child: Center(child: adhanTimeLabel),
            ),
            Expanded(
              flex: isLandscape ? 4 : 4,
              child: Center(child: prayerNameLabel),
            ),
            Expanded(
              flex: isLandscape ? 3 : 3,
              child: showSeparateIqama
                  ? Center(child: iqamaTimeLabel)
                  : const SizedBox.shrink(),
            ),
          ],
        );
      } else if (!isLandscape && shouldCenter) {
        rowContent = LayoutBuilder(
          builder: (context, boxConstraints) {
            final metricsWidth = (showSeparateIqama
                    ? boxConstraints.maxWidth * 0.38
                    : boxConstraints.maxWidth * 0.25)
                .clamp(88.0, boxConstraints.maxWidth * 0.44)
                .toDouble();

            return Stack(
              children: [
                Align(
                  alignment: isArabicLayout
                      ? Alignment.centerLeft
                      : Alignment.centerRight,
                  child: SizedBox(
                    width: metricsWidth,
                    child: Row(
                      textDirection: isArabicLayout
                          ? TextDirection.rtl
                          : TextDirection.ltr,
                      children: [
                        Expanded(child: portraitTimeLabel),
                        if (showSeparateIqama) const SizedBox(width: 6),
                        if (showSeparateIqama)
                          Expanded(child: portraitIqamaLabel),
                      ],
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: metricsWidth * 0.42,
                      ),
                      child: prayerNameLabel,
                    ),
                  ),
                ),
              ],
            );
          },
        );
      } else {
        List<Widget> rowChildren;
        if (useMixedCenteredLayout && isLandscape) {
          rowChildren = [
            adhanTimeWidget,
            prayerNameWidget,
            if (showSeparateIqama) iqamaTimeWidget,
          ];
        } else if (!isLandscape) {
          rowChildren = [
            prayerNameWidget,
            const SizedBox(width: 8),
            adhanTimeWidget,
            if (showSeparateIqama) const SizedBox(width: 8),
            if (showSeparateIqama) iqamaTimeWidget,
          ];
        } else {
          rowChildren = [
            prayerNameWidget,
            adhanTimeWidget,
            if (showSeparateIqama) iqamaTimeWidget,
          ];
        }

        rowContent = Row(
          textDirection: !isLandscape
              ? (isArabicLayout ? TextDirection.rtl : TextDirection.ltr)
              : TextDirection.ltr,
          mainAxisAlignment: !isLandscape
              ? MainAxisAlignment.start
              : shouldCenter
                  ? MainAxisAlignment.center
                  : MainAxisAlignment.spaceBetween,
          children: rowChildren,
        );
      }

      Widget panel = _PureGlassContainer(
        settings: widget.settings,
        hasShine: isNext,
        shineController: _shineController,
        shineAnimation: _shineAnimation,
        isActive: isNext,
        borderRadius: isLandscape ? 20.0 : (itemCount > 6 ? 24.0 : 26.0),
        padding: EdgeInsets.symmetric(
          horizontal: isLandscape ? 16.0 : 12.0,
          vertical: verticalPadding,
        ),
        child: rowContent,
      );

      if (!isLandscape) {
        final widthFactor = itemCount > 6 ? 0.95 : 0.944;
        panel = Align(
          child: FractionallySizedBox(
            widthFactor: widthFactor,
            heightFactor: 1.0,
            child: SizedBox.expand(child: panel),
          ),
        );
      }

      return AnimatedBuilder(
        animation: _entryController,
        builder: (context, child) => Transform.translate(
            offset: Offset(0, slideAnim.value),
            child: Opacity(
                opacity: fadeAnim.value * (shouldDim ? 0.45 : 1.0),
                child: child)),
        child: panel,
      );
    });

    if (isLandscape) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final count = items.length;
          final crossAxisCount = count <= 6 ? 3 : 4;
          final rows = (count / crossAxisCount).ceil();
          const spacing = 10.0;

          final totalHorizontalSpacing = spacing * (crossAxisCount - 1);
          final totalVerticalSpacing = spacing * (rows - 1);

          final itemWidth = math.max(1.0,
              (constraints.maxWidth - totalHorizontalSpacing) / crossAxisCount);
          final itemHeight = math.max(
              1.0, (constraints.maxHeight - totalVerticalSpacing) / rows);

          final aspectRatio =
              (itemWidth / itemHeight).clamp(1.45, 4.0).toDouble();

          return GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: count,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: spacing,
              mainAxisSpacing: spacing,
              childAspectRatio: aspectRatio,
            ),
            itemBuilder: (context, index) => items[index],
          );
        },
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final count = items.length;
        final spacing = portraitSpacing;
        final maxCardHeight = itemCount <= 6
            ? 72.0
            : itemCount == 7
                ? 64.0
                : 58.0;
        final minCardHeight = itemCount >= 8
            ? 42.0
            : itemCount == 7
                ? 46.0
                : 52.0;
        final spacingTotal = spacing * math.max(0, count - 1);
        final usableHeight =
            math.max(0.0, constraints.maxHeight - spacingTotal);
        final rawCardHeight = count == 0 ? 0.0 : usableHeight / count;
        double cardHeight =
            rawCardHeight.clamp(minCardHeight, maxCardHeight).toDouble();
        final usedHeight = cardHeight * count + spacingTotal;

        if (usedHeight > constraints.maxHeight && rawCardHeight > 0) {
          cardHeight = rawCardHeight;
        }

        final remainingHeight = math.max(
          0.0,
          constraints.maxHeight - (cardHeight * count) - spacingTotal,
        );
        final topInset = remainingHeight * 0.06;
        final bottomInset = remainingHeight - topInset;

        return Column(
          children: [
            if (topInset > 0) SizedBox(height: topInset),
            for (var index = 0; index < count; index++) ...[
              SizedBox(height: cardHeight, child: items[index]),
              if (index != count - 1) SizedBox(height: spacing),
            ],
            if (bottomInset > 0) SizedBox(height: bottomInset),
          ],
        );
      },
    );
  }

  Widget _buildNewsTicker(bool isLandscape) {
    return _PureGlassContainer(
      settings: widget.settings,
      hasShine: true,
      shineController: _shineController,
      shineAnimation: _shineAnimation,
      borderRadius: isLandscape ? 34.0 : 36.0,
      padding: EdgeInsets.symmetric(
        horizontal: isLandscape ? 16 : 18,
        vertical: isLandscape ? 6 : 7,
      ),
      child: SizedBox(
        height: isLandscape ? 28 : 33,
        child: MarqueeBanner(texts: widget.tickerItems),
      ),
    );
  }
}

class _PureGlassContainer extends StatelessWidget {
  final Widget child;
  final bool hasShine;
  final AnimationController? shineController;
  final Animation<double>? shineAnimation;
  final EdgeInsets padding;
  final double borderRadius;
  final bool isActive;
  final AppSettings settings;

  const _PureGlassContainer({
    required this.child,
    this.hasShine = false,
    this.shineController,
    this.shineAnimation,
    this.padding = EdgeInsets.zero,
    this.borderRadius = 20.0,
    this.isActive = false,
    required this.settings,
  });

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (settings.appTheme == 'EMERALD') {
      return _buildEmeraldSurface(context);
    }
    return _buildDefaultGlassSurface(context);
  }

  Widget _buildEmeraldSurface(BuildContext context) {
    final accentColor =
        _parseHex(settings.pureGlassColor1, fallback: const Color(0xFF5CD8C4));
    final goldColor = _parseHex(settings.pureGlassTextColor,
        fallback: const Color(0xFFE2C473));
    final canUseBlur =
        MediaQuery.of(context).orientation != Orientation.landscape;
    final gradientColors = isActive
        ? const [Color(0xFF18685A), Color(0xFF124F44)]
        : const [Color(0xFF144633), Color(0xFF0D3224)];
    final borderColor = isActive
        ? accentColor.withValues(alpha: 0.82)
        : goldColor.withValues(alpha: 0.24);
    final shadows = isActive
        ? [
            BoxShadow(
              color: accentColor.withValues(alpha: 0.28),
              blurRadius: 15.0,
              spreadRadius: 1.0,
            ),
            BoxShadow(
              color: accentColor.withValues(alpha: 0.18),
              blurRadius: 30.0,
              spreadRadius: -5.0,
            ),
          ]
        : [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.40),
              offset: const Offset(0, 4),
              blurRadius: 8.0,
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.22),
              offset: const Offset(0, 2),
              blurRadius: 4.0,
            ),
          ];

    final body = Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(color: borderColor, width: isActive ? 1.5 : 1.0),
        gradient: LinearGradient(
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
          colors: gradientColors,
        ),
        boxShadow: shadows,
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(borderRadius - 1),
                border: const Border(
                  top: BorderSide(
                    color: Color.fromRGBO(255, 255, 255, 0.10),
                    width: 1.0,
                  ),
                ),
              ),
            ),
          ),
          if (settings.glassShineEnabled &&
              hasShine &&
              shineController != null &&
              shineAnimation != null)
            Positioned.fill(
              child: AnimatedBuilder(
                animation: shineController!,
                builder: (context, child) => FractionalTranslation(
                  translation: Offset(shineAnimation!.value, 0),
                  child: child,
                ),
                child: Transform(
                  transform: Matrix4.skewX(-25 * math.pi / 180),
                  alignment: Alignment.center,
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Color.fromRGBO(255, 255, 255, 0.04),
                          Color.fromRGBO(255, 255, 255, 0.18),
                          Colors.transparent,
                        ],
                        stops: [0.0, 0.20, 0.25, 0.30],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (isActive)
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 5,
                decoration: BoxDecoration(
                  color: accentColor.withValues(alpha: 0.96),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(borderRadius),
                    bottomLeft: Radius.circular(borderRadius),
                  ),
                ),
              ),
            ),
          Padding(
            padding: padding,
            child: Align(
              alignment: Alignment.center,
              child: child,
            ),
          ),
        ],
      ),
    );

    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: canUseBlur
          ? BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3.5, sigmaY: 3.5),
              child: body,
            )
          : body,
    );
  }

  Widget _buildDefaultGlassSurface(BuildContext context) {
    final accentColor =
        _parseHex(settings.pureGlassColor1, fallback: const Color(0xFF38BDF8));
    final canUseBlur =
        MediaQuery.of(context).orientation != Orientation.landscape;

    return PremiumGlassSurface(
      borderRadius: borderRadius,
      shadowColor: isActive
          ? accentColor.withValues(alpha: 0.16)
          : const Color.fromRGBO(0, 0, 0, 0.30),
      useBackdropBlur: canUseBlur,
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(borderRadius),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withValues(alpha: isActive ? 0.055 : 0.035),
                    Colors.white.withValues(alpha: 0.008),
                  ],
                ),
              ),
            ),
          ),
          if (isActive)
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(borderRadius),
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [
                      accentColor.withValues(alpha: 0.08),
                      Colors.transparent,
                      accentColor.withValues(alpha: 0.04),
                    ],
                  ),
                ),
              ),
            ),
          if (settings.glassShineEnabled &&
              hasShine &&
              shineController != null &&
              shineAnimation != null)
            Positioned.fill(
              child: AnimatedBuilder(
                animation: shineController!,
                builder: (context, child) => FractionalTranslation(
                  translation: Offset(shineAnimation!.value, 0),
                  child: child,
                ),
                child: Transform(
                  transform: Matrix4.skewX(-25 * math.pi / 180),
                  alignment: Alignment.center,
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Color.fromRGBO(255, 255, 255, 0.05),
                          Color.fromRGBO(255, 255, 255, 0.3),
                          Colors.transparent,
                        ],
                        stops: [0.0, 0.20, 0.25, 0.30],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (isActive)
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 5,
                decoration: BoxDecoration(
                  color: accentColor.withValues(alpha: 0.95),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(borderRadius),
                    bottomLeft: Radius.circular(borderRadius),
                  ),
                ),
              ),
            ),
          Padding(
            padding: padding,
            child: Align(
              alignment: Alignment.center,
              child: child,
            ),
          ),
        ],
      ),
    );
  }
}

class _BackgroundShapes extends StatelessWidget {
  final AppSettings settings;
  const _BackgroundShapes({required this.settings});

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Stack(
      children: [
        _Shape(
            top: -size.height * 0.1,
            right: -size.width * 0.1,
            color: _parseHex(settings.pureGlassColor1,
                fallback: const Color(0xFF38BDF8)),
            size: size.width * 0.6),
        _Shape(
            bottom: -size.height * 0.1,
            left: -size.width * 0.1,
            color: _parseHex(settings.pureGlassColor2,
                fallback: const Color(0xFF818CF8)),
            size: size.width * 0.7),
        _Shape(
            top: size.height * 0.4,
            left: size.width * 0.6,
            color: _parseHex(settings.pureGlassColor3,
                fallback: const Color(0xFFE879F9)),
            size: size.width * 0.5,
            opacity: 0.2),
      ],
    );
  }
}

class _Shape extends StatelessWidget {
  final double? top, bottom, left, right;
  final Color color;
  final double size;
  final double opacity;
  const _Shape(
      {this.top,
      this.bottom,
      this.left,
      this.right,
      required this.color,
      required this.size,
      this.opacity = 0.4});
  @override
  Widget build(BuildContext context) {
    return Positioned(
        top: top,
        bottom: bottom,
        left: left,
        right: right,
        child: ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
            child: Opacity(
                opacity: opacity,
                child: Container(
                    width: size,
                    height: size,
                    decoration:
                        BoxDecoration(shape: BoxShape.circle, color: color)))));
  }
}
