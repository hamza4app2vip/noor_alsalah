import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart';

import '../../../../core/utils/prayer_name_helper.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../../domain/entities/prayer_day.dart';
import '../providers/timer_engine_provider.dart';
import 'pure_glass_theme_layout.dart';

class EmeraldThemeLayout extends StatelessWidget {
  final AppSettings settings;
  final String dayName;
  final String gregorianStr;
  final HijriCalendar hijriDate;
  final AsyncValue<PrayerDay> asyncData;
  final String nextPrayerId;
  final String nextPrayerStr;
  final String timeUntilStr;
  final List<String> tickerItems;
  final TimerState timerState;
  final Widget Function(AppSettings) buildHeader;
  final ImageProvider? backgroundImage;
  final String iqamaTimerText;

  const EmeraldThemeLayout({
    super.key,
    required this.settings,
    required this.dayName,
    required this.gregorianStr,
    required this.hijriDate,
    required this.asyncData,
    required this.nextPrayerId,
    required this.nextPrayerStr,
    required this.timeUntilStr,
    required this.tickerItems,
    required this.timerState,
    required this.buildHeader,
    this.backgroundImage,
    required this.iqamaTimerText,
  });

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context).languageCode;
    final hourPart = settings.padTimesWithZero
        ? (settings.is24HourFormat ? 'HH' : 'hh')
        : (settings.is24HourFormat ? 'H' : 'h');
    final secondsPart = settings.showSecondsClock ? ':ss' : '';
    final amPmPart = settings.is24HourFormat ? '' : ' a';
    final clockFormat = '$hourPart:mm$secondsPart$amPmPart';
    final currentTime = DateFormat(clockFormat, locale).format(timerState.now);

    final emeraldGlassSettings = settings.copyWith(
      appTheme: 'EMERALD',
      pureGlassColor1: '#5CD8C4',
      pureGlassColor2: '#144633',
      pureGlassColor3: '#D4A95B',
      pureGlassTextColor: '#E2C473',
      selectedBackgroundId: -999,
    );

    return PureGlassThemeLayout(
      settings: emeraldGlassSettings,
      dayName: dayName,
      gregorianStr: gregorianStr,
      hijriDate: hijriDate,
      nextPrayerId: nextPrayerId,
      nextPrayerStr: nextPrayerStr,
      timeUntilStr: timeUntilStr,
      tickerItems: tickerItems,
      timerState: timerState,
      buildHeader: buildHeader,
      currentTime: currentTime,
      iqamaTimerText: iqamaTimerText,
      prayers: _getPrayersForLayout(settings),
      backgroundImage: null,
    );
  }

  List<Map<String, dynamic>> _getPrayersForLayout(AppSettings currentSettings) {
    if (!asyncData.hasValue) return [];
    final prayerDay = asyncData.value!;
    final format = currentSettings.is24HourFormat ? 'HH:mm' : 'hh:mm';

    final prayers = <Map<String, dynamic>>[
      {
        'id': 'fajr',
        'nameAr': PrayerNameHelper.getArName(PrayerName.fajr),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.fajr),
        'time': DateFormat(format, 'en').format(prayerDay.fajr),
        'iqama': '+${currentSettings.fajrIqamaTime}',
      },
      {
        'id': 'sunrise',
        'nameAr': PrayerNameHelper.getArName(PrayerName.sunrise),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.sunrise),
        'time': DateFormat(format, 'en').format(prayerDay.sunrise),
        'iqama': null,
      },
      {
        'id': 'dhuhr',
        'nameAr': PrayerNameHelper.getArName(PrayerName.dhuhr),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.dhuhr),
        'time': DateFormat(format, 'en').format(prayerDay.dhuhr),
        'iqama': '+${currentSettings.dhuhrIqamaTime}',
      },
      {
        'id': 'asr',
        'nameAr': PrayerNameHelper.getArName(PrayerName.asr),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.asr),
        'time': DateFormat(format, 'en').format(prayerDay.asr),
        'iqama': '+${currentSettings.asrIqamaTime}',
      },
      {
        'id': 'maghrib',
        'nameAr': PrayerNameHelper.getArName(PrayerName.maghrib),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.maghrib),
        'time': DateFormat(format, 'en').format(prayerDay.maghrib),
        'iqama': '+${currentSettings.maghribIqamaTime}',
      },
      {
        'id': 'isha',
        'nameAr': PrayerNameHelper.getArName(PrayerName.isha),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.isha),
        'time': DateFormat(format, 'en').format(prayerDay.isha),
        'iqama': '+${currentSettings.ishaIqamaTime}',
      },
    ];

    if (currentSettings.showNightPrayers) {
      final tomorrowFajr = prayerDay.fajr.add(const Duration(days: 1));
      final nightDuration = tomorrowFajr.difference(prayerDay.maghrib);
      final midnight = prayerDay.maghrib
          .add(Duration(seconds: nightDuration.inSeconds ~/ 2));
      final lastThird = prayerDay.maghrib
          .add(Duration(seconds: (nightDuration.inSeconds * 2) ~/ 3));

      prayers.add({
        'id': 'midnight',
        'nameAr': PrayerNameHelper.getArName('midnight'),
        'nameEn': PrayerNameHelper.getEnName('midnight'),
        'time': DateFormat(format, 'en').format(midnight),
        'iqama': null,
      });
      prayers.add({
        'id': 'last_third',
        'nameAr': PrayerNameHelper.getArName('last_third'),
        'nameEn': PrayerNameHelper.getEnName('last_third'),
        'time': DateFormat(format, 'en').format(lastThird),
        'iqama': null,
      });
    }

    return prayers;
  }
}
