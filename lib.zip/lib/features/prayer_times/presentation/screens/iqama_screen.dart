import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../settings/presentation/providers/settings_provider.dart';
import '../../../../core/utils/number_helper.dart';
import '../../../../core/tv/tv_remote_support.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';

class IqamaScreen extends ConsumerWidget {
  final String prayerName;
  final String remainingTime;
  final String hadith;
  final VoidCallback? onClose;

  const IqamaScreen({
    super.key,
    required this.prayerName,
    required this.remainingTime,
    this.hadith = '',
    this.onClose,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsNotifierProvider);
    final isPureGlass = settings.appTheme == 'PURE_GLASS';
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;

    // Parse remaining time to determine if we're in last 90s (green mode)
    bool isGreen = false;
    if (settings.countdownGreenLast90s) {
      String rawTime = remainingTime;
      for (int i = 0; i < 10; i++) {
        rawTime = rawTime.replaceAll(NumberHelper.arabic[i], NumberHelper.english[i]);
      }
      final parts = rawTime.split(':');
      if (parts.length == 2 && int.tryParse(parts[0]) != null && int.tryParse(parts[1]) != null) {
        final totalSecs = (int.parse(parts[0]) * 60) + int.parse(parts[1]);
        if (totalSecs <= 90) isGreen = true;
      }
    }

    final accentColor = isGreen
        ? const Color(0xFF2ECC71)
        : (isPureGlass
            ? _parseHex(settings.pureGlassColor1, fallback: AppColors.primaryGold)
            : AppColors.primaryGold);

    final textColor = isPureGlass ? _parseHex(settings.pureGlassTextColor) : Colors.white;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (isPureGlass) ...[
            _BackgroundShapes(settings: settings),
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                child: Container(color: Colors.black.withValues(alpha: 0.2)),
              ),
            ),
          ] else ...[
            // ── خلفية متدرجة ──
            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.2),
                  colors: [
                    accentColor.withValues(alpha: 0.15),
                    Colors.black.withValues(alpha: 0.97),
                  ],
                  radius: 1.5,
                ),
              ),
            ),
          ],

          // ── المحتوى الرئيسي ──
          Center(
            child: isLandscape
                ? _buildLandscapeLayout(settings, prayerName, remainingTime, accentColor, textColor, hadith, context)
                : _buildPortraitLayout(settings, prayerName, remainingTime, accentColor, textColor, hadith, context),
          ),

          // ── زر الإغلاق (X) ──
          Positioned(
            top: 24,
            right: 24,
            child: TvFocusable(
              onPressed: () => onClose != null ? onClose!() : Navigator.pop(context),
              borderRadius: BorderRadius.circular(40),
              focusColor: accentColor,
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isPureGlass ? Colors.white.withValues(alpha: 0.05) : Colors.black38,
                  border: Border.all(color: isPureGlass ? Colors.white.withValues(alpha: 0.1) : Colors.white10),
                ),
                child: Icon(Icons.close_rounded, color: textColor.withValues(alpha: 0.7), size: 28),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  Widget _buildPortraitLayout(AppSettings settings, String name, String time, Color accent, Color textColor, String hadith, BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // ── عنوان إقامة ──
        Text(
          l10n.iqamatSalat,
          style: TextStyle(
            fontSize: 22,
            color: textColor.withValues(alpha: 0.54),
            fontFamily: settings.textFontFamily,
            fontWeight: FontWeight.w300,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 8),
        // ── اسم الصلاة ──
        ShaderMask(
          shaderCallback: (b) => LinearGradient(colors: [accent, textColor]).createShader(b),
          child: Text(
            name,
            style: TextStyle(
              fontSize: 52,
              fontWeight: FontWeight.w900,
              fontFamily: settings.timesFontFamily,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 40),
        // ── العد التنازلي ──
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accent.withValues(alpha: 0.3), width: 1.5),
          ),
          child: Text(
            NumberHelper.format(time, settings.useArabicIndicDigits),
            style: TextStyle(
              fontSize: 88,
              color: accent,
              fontWeight: FontWeight.bold,
              fontFamily: settings.clockFontFamily,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          l10n.minutesUntilIqama,
          style: TextStyle(
            fontSize: 18,
            color: textColor.withValues(alpha: 0.38),
            fontFamily: settings.textFontFamily,
          ),
        ),
        // ── حديث قبل الإقامة ──
        if (hadith.isNotEmpty) ...[
          const SizedBox(height: 40),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 32),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: Text(
              hadith,
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontSize: 18,
                color: textColor.withValues(alpha: 0.54),
                fontFamily: settings.textFontFamily,
                height: 1.7,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildLandscapeLayout(AppSettings settings, String name, String time, Color accent, Color textColor, String hadith, BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Left: countdown
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accent.withValues(alpha: 0.3), width: 1.5),
          ),
          child: Text(
            NumberHelper.format(time, settings.useArabicIndicDigits),
            style: TextStyle(
              fontSize: 80,
              color: accent,
              fontWeight: FontWeight.bold,
              fontFamily: settings.clockFontFamily,
            ),
          ),
        ),
        const SizedBox(width: 48),
        // Right: name
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              l10n.iqamatSalat,
              style: TextStyle(
                fontSize: 18,
                color: textColor.withValues(alpha: 0.54),
                fontFamily: settings.textFontFamily,
              ),
            ),
            const SizedBox(height: 8),
            ShaderMask(
              shaderCallback: (b) => LinearGradient(colors: [accent, textColor]).createShader(b),
              child: Text(
                name,
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.w900,
                  fontFamily: settings.timesFontFamily,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              l10n.minutesUntilIqama,
              style: TextStyle(
                fontSize: 16,
                color: textColor.withValues(alpha: 0.38),
                fontFamily: settings.textFontFamily,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _BackgroundShapes extends StatelessWidget {
  final AppSettings settings;
  const _BackgroundShapes({required this.settings});

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: -100,
          right: -100,
          child: _Blob(color: _parseHex(settings.pureGlassColor1, fallback: const Color(0xFF38BDF8)).withValues(alpha: 0.15), size: 400),
        ),
        Positioned(
          bottom: -150,
          left: -100,
          child: _Blob(color: _parseHex(settings.pureGlassColor2, fallback: const Color(0xFF818CF8)).withValues(alpha: 0.15), size: 500),
        ),
        Positioned(
          top: 200,
          left: -50,
          child: _Blob(color: _parseHex(settings.pureGlassColor3, fallback: const Color(0xFFE879F9)).withValues(alpha: 0.1), size: 300),
        ),
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  final Color color;
  final double size;
  const _Blob({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, color.withValues(alpha: 0)],
        ),
      ),
    );
  }
}
