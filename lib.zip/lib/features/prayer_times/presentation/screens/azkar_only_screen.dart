import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';

import '../../../../core/tv/tv_remote_support.dart';
import '../../../azkar_quran/presentation/providers/azkar_provider.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../widgets/special_screen_glass.dart';

class AzkarOnlyScreen extends ConsumerStatefulWidget {
  final AppSettings settings;
  final VoidCallback? onDisable;

  const AzkarOnlyScreen({
    super.key,
    required this.settings,
    this.onDisable,
  });

  @override
  ConsumerState<AzkarOnlyScreen> createState() => _AzkarOnlyScreenState();
}

class _AzkarOnlyScreenState extends ConsumerState<AzkarOnlyScreen> {
  static const double _pixelsPerSecond = 45;

  late final ScrollController _scrollController;
  bool _isScrolling = false;

  bool get _useGlassBackground => widget.settings.azkarOnlyScreenUseGlass;

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  Color get _textColor {
    if (_useGlassBackground) {
      return _parseHex(widget.settings.pureGlassTextColor);
    }
    return Colors.white;
  }

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startAutoScroll();
    });
  }

  @override
  void dispose() {
    _isScrolling = false;
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _startAutoScroll() async {
    if (!mounted) return;
    _isScrolling = true;

    // Small delay before starting the scroll
    await Future.delayed(const Duration(seconds: 3));

    while (_isScrolling && mounted) {
      if (_scrollController.hasClients) {
        final maxScroll = _scrollController.position.maxScrollExtent;
        if (maxScroll > 0) {
          final durationMs = ((maxScroll / _pixelsPerSecond) * 1000).round();
          await _scrollController.animateTo(
            maxScroll,
            duration: Duration(milliseconds: durationMs),
            curve: Curves.linear,
          );

          if (!mounted || !_isScrolling) break;
          // Wait a few seconds at the bottom for the user to finish reading
          await Future.delayed(const Duration(seconds: 5));
          
          if (mounted && _isScrolling) {
            widget.onDisable?.call();
          }
          break;
        } else {
          // If the text perfectly fits the screen and doesn't need to scroll
          await Future.delayed(const Duration(seconds: 30));
          if (mounted && _isScrolling) {
            widget.onDisable?.call();
          }
          break;
        }
      } else {
        // Retry if clients are not ready
        await Future.delayed(const Duration(seconds: 1));
      }
    }
  }

  int _timeToMinutes(String timeStr) {
    final parts = timeStr.split(':');
    if (parts.length < 2) return 0;
    return (int.tryParse(parts[0]) ?? 0) * 60 + (int.tryParse(parts[1]) ?? 0);
  }

  bool _isTimeBetween(String startStr, String endStr) {
    if (startStr.isEmpty || endStr.isEmpty) return false;
    final now = TimeOfDay.now();
    final nowMins = now.hour * 60 + now.minute;
    final startMins = _timeToMinutes(startStr);
    final endMins = _timeToMinutes(endStr);

    if (startMins <= endMins) {
      return nowMins >= startMins && nowMins <= endMins;
    } else {
      return nowMins >= startMins || nowMins <= endMins;
    }
  }

  List<Widget> _buildSection({
    required String title,
    required AsyncValue<List<ZikrItem>> value,
  }) {
    return value.when(
      data: (items) {
        final filtered = items
            .where((item) =>
                item.text.trim().isNotEmpty ||
                (item.repeatInfo?.trim().isNotEmpty ?? false))
            .toList();

        if (filtered.isEmpty) {
          final l10n = AppLocalizations.of(context);
          return [
            _buildSectionTitle(title),
            const SizedBox(height: 18),
            _buildInfoText(l10n.noItemsAvailable),
            const SizedBox(height: 48),
          ];
        }

        return [
          _buildSectionTitle(title),
          const SizedBox(height: 18),
          ...filtered.map(_buildZikrCard),
          const SizedBox(height: 54),
        ];
      },
      loading: () => [
        _buildSectionTitle(title),
        const SizedBox(height: 20),
        SizedBox(
          width: 36,
          height: 36,
          child: CircularProgressIndicator(
            color: _useGlassBackground
                ? _textColor.withValues(alpha: 0.8)
                : Colors.white70,
            strokeWidth: 2.6,
          ),
        ),
        const SizedBox(height: 54),
      ],
      error: (_, __) {
        final l10n = AppLocalizations.of(context);
        return [
          _buildSectionTitle(title),
          const SizedBox(height: 18),
          _buildInfoText(l10n.errorLoadingAzkar),
          const SizedBox(height: 54),
        ];
      },
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: _textColor,
        fontFamily: widget.settings.textFontFamily,
        fontSize: 38,
        fontWeight: FontWeight.w800,
        height: 1.2,
        shadows: _useGlassBackground
            ? const [
                Shadow(
                    color: Colors.black87, blurRadius: 8, offset: Offset(0, 2)),
              ]
            : null,
      ),
    );
  }

  Widget _buildInfoText(String text) {
    return Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: _useGlassBackground
            ? _textColor.withValues(alpha: 0.75)
            : Colors.white54,
        fontFamily: widget.settings.textFontFamily,
        fontSize: 24,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildZikrCard(ZikrItem item) {
    final content = Column(
      children: [
        Text(
          item.text,
          textAlign: TextAlign.center,
          textDirection: TextDirection.rtl,
          style: TextStyle(
            color: _textColor,
            fontFamily: widget.settings.azkarFontFamily,
            fontSize: 42,
            fontWeight: FontWeight.w700,
            height: 1.6,
            shadows: _useGlassBackground
                ? const [
                    Shadow(
                        color: Colors.black87,
                        blurRadius: 6,
                        offset: Offset(0, 2)),
                  ]
                : null,
          ),
        ),
        if (item.repeatInfo?.trim().isNotEmpty == true) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: _useGlassBackground
                  ? _textColor.withValues(alpha: 0.08)
                  : Colors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _useGlassBackground
                    ? _textColor.withValues(alpha: 0.18)
                    : Colors.white.withValues(alpha: 0.16),
              ),
            ),
            child: Text(
              item.repeatInfo!.trim(),
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _useGlassBackground
                    ? _textColor.withValues(alpha: 0.82)
                    : Colors.white70,
                fontFamily: widget.settings.azkarFontFamily,
                fontSize: 24,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ],
    );

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 22),
      child: _useGlassBackground
          ? PureGlassPrayerFrame(
              settings: widget.settings,
              borderRadius: 22,
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              child: content,
            )
          : Container(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
              ),
              child: content,
            ),
    );
  }

  bool _isCancelKey(LogicalKeyboardKey key) {
    final keyLabel = key.keyLabel.toLowerCase();
    final debugName = (key.debugName ?? '').toLowerCase();
    return key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.browserBack ||
        keyLabel == 'back' ||
        keyLabel == 'exit' ||
        debugName.contains('back') ||
        debugName.contains('exit');
  }

  KeyEventResult _handleRemoteCancel(KeyEvent event) {
    if (event is! KeyDownEvent || widget.onDisable == null) {
      return KeyEventResult.ignored;
    }

    if (_isCancelKey(event.logicalKey)) {
      widget.onDisable?.call();
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final sabahAzkar = ref.watch(sabahAzkarProvider);
    final masaaAzkar = ref.watch(masaaAzkarProvider);
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    bool showSabah = false;
    bool showMasaa = false;

    if (widget.settings.autoAzkarByTime) {
      showSabah = _isTimeBetween(
          widget.settings.sabahStartTime, widget.settings.sabahEndTime) && widget.settings.enableSabahAzkar;
      showMasaa = _isTimeBetween(
          widget.settings.masaaStartTime, widget.settings.masaaEndTime) && widget.settings.enableMasaaAzkar;
    } else {
      final manualType = widget.settings.manualAzkarType;
      if (manualType == 'SABAH' || manualType == 'BOTH') {
        showSabah = widget.settings.enableSabahAzkar;
      }
      if (manualType == 'MASAA' || manualType == 'BOTH') {
        showMasaa = widget.settings.enableMasaaAzkar;
      }
    }

    final sections = <Widget>[];
    if (showSabah) {
      sections.addAll(_buildSection(title: l10n.sabahAzkarTitle, value: sabahAzkar));
    }
    if (showMasaa) {
      sections.addAll(_buildSection(title: l10n.masaaAzkarTitle, value: masaaAzkar));
    }

    if (sections.isEmpty) {
      String msg = widget.settings.autoAzkarByTime
          ? l10n.noAzkarAtThisTime
          : l10n.enableAzkarInSettings;
      sections.addAll([
        _buildSectionTitle(l10n.azkarOnlyScreenTitle),
        const SizedBox(height: 18),
        _buildInfoText(msg),
        const SizedBox(height: 60),
      ]);
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (node, event) => _handleRemoteCancel(event),
        child: Stack(
          children: [
            Positioned.fill(
              child: SpecialScreenGlassBackground(
                settings: widget.settings,
                enabled: _useGlassBackground,
                customImagePath: widget.settings.azkarOnlyScreenCustomBgPath,
              ),
            ),
            Positioned.fill(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1200),
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: ListView(
                      controller: _scrollController,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 80),
                      children: sections,
                    ),
                  ),
                ),
              ),
            ),
            if (widget.onDisable != null)
              Positioned(
                left: isLandscape ? 0 : 24,
                right: isLandscape ? 0 : null,
                bottom: 24,
                child: isLandscape
                    ? Center(child: _buildDisableButton(isLandscape: true))
                    : _buildDisableButton(isLandscape: false),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDisableButton({required bool isLandscape}) {
    final l10n = AppLocalizations.of(context);
    return TvFocusable(
      onPressed: widget.onDisable!,
      borderRadius: BorderRadius.circular(16),
      focusColor: _useGlassBackground
          ? _parseHex(widget.settings.pureGlassColor1, fallback: Colors.white70)
          : Colors.white70,
      child: GlassToastSurface(
        width: isLandscape ? 300 : 270,
        enableShine: widget.settings.glassShineEnabled,
        height: isLandscape ? 44 : 42,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.stop_circle_outlined,
              color: _useGlassBackground
                  ? _textColor.withValues(alpha: 0.82)
                  : Colors.white70,
              size: 17,
            ),
            const SizedBox(width: 8),
            Text(
              l10n.stopAzkarOnlyScreen,
              style: TextStyle(
                color: _useGlassBackground ? _textColor : Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
