import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../settings/presentation/providers/settings_provider.dart';

class BlackScreen extends ConsumerWidget {
  final bool showClock;
  final String timeText;

  const BlackScreen({
    super.key,
    required this.showClock,
    required this.timeText,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsNotifierProvider);
    return Scaffold(
      backgroundColor: Colors.black, // شاشة سوداء تماماً لتوفير الطاقة وتقليل تشتت المصلين
      body: Center(
        child: showClock
            ? Text(
                timeText,
                style: TextStyle(
                  color: Colors.white24, // لون باهت جداً
                  fontSize: 72,
                  fontFamily: settings.clockFontFamily, // خط رقمي واضح
                ),
              )
            : const SizedBox.shrink(),
      ),
    );
  }
}
