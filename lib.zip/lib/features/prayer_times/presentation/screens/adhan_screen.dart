import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/timer_engine_provider.dart';
import '../../../settings/presentation/providers/settings_provider.dart';
import '../../../../core/tv/tv_remote_support.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';

class AdhanScreen extends ConsumerWidget {
  final PrayerName currentPrayer;
  final VoidCallback? onClose;

  const AdhanScreen({super.key, required this.currentPrayer, this.onClose});

  String _getLocalizedPrayerName(BuildContext context, PrayerName name) {
    final l10n = AppLocalizations.of(context);
    switch (name) {
      case PrayerName.fajr: return l10n.fajr;
      case PrayerName.dhuhr: return l10n.dhuhr;
      case PrayerName.asr: return l10n.asr;
      case PrayerName.maghrib: return l10n.maghrib;
      case PrayerName.isha: return l10n.isha;
      default: return l10n.prayer;
    }
  }

  Color _getPrayerColor(PrayerName name) {
    switch (name) {
      case PrayerName.fajr: return const Color(0xFF4A90D9);     // فجر: أزرق فاتح
      case PrayerName.dhuhr: return const Color(0xFFD4A017);    // ظهر: ذهبي
      case PrayerName.asr: return const Color(0xFF2ECC71);      // عصر: أخضر
      case PrayerName.maghrib: return const Color(0xFFE67E22);  // مغرب: برتقالي
      case PrayerName.isha: return const Color(0xFF8E44AD);     // عشاء: بنفسجي
      default: return AppColors.primaryGold;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsNotifierProvider);
    final isPureGlass = settings.appTheme == 'PURE_GLASS';
    final prayerColor = isPureGlass 
        ? _parseHex(settings.pureGlassColor1, fallback: _getPrayerColor(currentPrayer))
        : _getPrayerColor(currentPrayer);
    final textColor = isPureGlass 
        ? _parseHex(settings.pureGlassTextColor) 
        : Colors.white;
    
    final l10n = AppLocalizations.of(context);
    final prayerName = _getLocalizedPrayerName(context, currentPrayer);
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (isPureGlass) ...[
            _BackgroundShapes(settings: settings),
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                child: Container(color: Colors.black.withValues(alpha: 0.2)),
              ),
            ),
          ] else ...[
            // ── خلفية متدرجة مناسبة لكل صلاة ──
            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.3),
                  colors: [
                    prayerColor.withValues(alpha: 0.25),
                    Colors.black.withValues(alpha: 0.95),
                  ],
                  radius: 1.4,
                ),
              ),
            ),
            // ── نجوم خفيفة في الخلفية ──
            Positioned.fill(
              child: Opacity(
                opacity: 0.06,
                child: Image.asset(
                  'assets/images/logo.jpg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],

          // ── المحتوى الرئيسي ──
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // ── أيقونة الصلاة ──
                Container(
                  width: isLandscape ? 100 : 120,
                  height: isLandscape ? 100 : 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: prayerColor.withValues(alpha: 0.12),
                    border: Border.all(
                        color: prayerColor.withValues(alpha: 0.4), width: 1.5),
                  ),
                  child: Icon(Icons.mosque_rounded,
                      size: isLandscape ? 52 : 64, color: prayerColor),
                ),

                SizedBox(height: isLandscape ? 20 : 32),

                // ── نص "حان موعد أذان" ──
                Text(
                  l10n.adhanTimeHasCome,
                  style: TextStyle(
                    fontSize: isLandscape ? 20 : 24,
                    color: textColor.withValues(alpha: 0.6),
                    letterSpacing: 2,
                    fontFamily: settings.textFontFamily,
                    fontWeight: FontWeight.w300,
                  ),
                  textAlign: TextAlign.center,
                ),

                SizedBox(height: isLandscape ? 12 : 20),

                // ── اسم الصلاة بخط كبير ──
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [prayerColor, textColor.withValues(alpha: 0.9), prayerColor],
                  ).createShader(bounds),
                  child: Text(
                    l10n.prayerNameWithPrefix(prayerName),
                    style: TextStyle(
                      fontSize: isLandscape ? 56 : 72,
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontFamily: settings.timesFontFamily,
                      letterSpacing: 2,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),

                SizedBox(height: isLandscape ? 20 : 36),

                // ── خط فاصل ──
                Container(
                  width: 120,
                  height: 1.5,
                  color: prayerColor.withValues(alpha: 0.4),
                ),

                SizedBox(height: isLandscape ? 16 : 24),

                // ── التكبير ──
                Text(
                  l10n.allahuAkbar,
                  style: TextStyle(
                    fontSize: isLandscape ? 18 : 22,
                    color: textColor.withValues(alpha: 0.4),
                    fontFamily: settings.azkarFontFamily,
                    letterSpacing: 1,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),

          // ── حالة الإنترنت أسفل الشاشة ──
          if (settings.showInternetStatus)
            Positioned(
              bottom: 16,
              left: 0,
              right: 0,
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.wifi_rounded, color: Colors.green, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      l10n.internetConnected,
                      style: TextStyle(
                          color: textColor.withValues(alpha: 0.4),
                          fontSize: 12,
                          fontFamily: settings.textFontFamily),
                    ),
                  ],
                ),
              ),
            ),

          // ── زر الإغلاق (X) ──
          Positioned(
            top: 24,
            right: 24,
            child: TvFocusable(
              onPressed: () => onClose != null ? onClose!() : Navigator.pop(context),
              borderRadius: BorderRadius.circular(40),
              focusColor: prayerColor,
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isPureGlass ? Colors.white.withValues(alpha: 0.05) : Colors.black38,
                  border: Border.all(color: isPureGlass ? Colors.white.withValues(alpha: 0.1) : Colors.white10),
                ),
                child: Icon(Icons.close_rounded,
                    color: textColor.withValues(alpha: 0.7), size: 28),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }
}

class _BackgroundShapes extends StatelessWidget {
  final AppSettings settings;
  const _BackgroundShapes({required this.settings});

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: -100,
          right: -100,
          child: _Blob(color: _parseHex(settings.pureGlassColor1, fallback: const Color(0xFF38BDF8)).withValues(alpha: 0.15), size: 400),
        ),
        Positioned(
          bottom: -150,
          left: -100,
          child: _Blob(color: _parseHex(settings.pureGlassColor2, fallback: const Color(0xFF818CF8)).withValues(alpha: 0.15), size: 500),
        ),
        Positioned(
          top: 200,
          left: -50,
          child: _Blob(color: _parseHex(settings.pureGlassColor3, fallback: const Color(0xFFE879F9)).withValues(alpha: 0.1), size: 300),
        ),
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  final Color color;
  final double size;
  const _Blob({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, color.withValues(alpha: 0)],
        ),
      ),
    );
  }
}
