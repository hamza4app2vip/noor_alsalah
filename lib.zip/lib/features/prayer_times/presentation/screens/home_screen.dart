import 'dart:io';
import 'dart:async';
import 'package:path_provider/path_provider.dart';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';
import 'package:noor_prayer_tv/core/theme/app_styles.dart';
import '../../../../core/services/weather_provider.dart';
import '../../../../core/services/weather_service.dart';

import '../../../settings/presentation/providers/settings_provider.dart';
import '../../../settings/presentation/screens/settings_screen.dart';
import '../../../settings/domain/entities/app_settings.dart';
import '../../../azkar_quran/presentation/providers/ticker_provider.dart';
import '../../../announcements/presentation/providers/announcement_provider.dart';
import '../providers/prayer_times_provider.dart';
import '../../domain/entities/prayer_day.dart';
import '../providers/location_provider.dart';
import '../providers/timer_engine_provider.dart';
import 'adhan_screen.dart';
import 'iqama_screen.dart';
import 'black_screen.dart';
import 'azkar_only_screen.dart';
import '../widgets/analog_glass_clock.dart';
import '../widgets/digital_clock_new.dart';
import '../widgets/special_screen_glass.dart';
import '../../../../core/utils/audio_service.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/utils/number_helper.dart';

import '../widgets/slideshow_overlay.dart';
import '../widgets/post_prayer_azkar_overlay.dart';
import '../../../../core/utils/prayer_name_helper.dart';
import '../themes/emerald_theme_layout.dart';
import '../themes/pure_glass_theme_layout.dart';

// Mapping from Flutter PrayerName to ID String
String _getPrayerId(PrayerName name) {
  switch (name) {
    case PrayerName.fajr:
      return 'fajr';
    case PrayerName.sunrise:
      return 'sunrise';
    case PrayerName.dhuhr:
      return 'dhuhr';
    case PrayerName.asr:
      return 'asr';
    case PrayerName.maghrib:
      return 'maghrib';
    case PrayerName.isha:
      return 'isha';
    default:
      return '';
  }
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  // New state for Pure Glass specific skip flags
  bool _skipBlackScreen = false;
  bool _skipAdhanScreen = false;
  bool _skipIqamaScreen = false;
  String? _customBgPath;

  @override
  void initState() {
    super.initState();
    _initCustomBgPath();
  }

  Future<void> _initCustomBgPath() async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      _customBgPath = '${appDir.path}/custom_backgrounds/custom_bg.jpg';
    } catch (_) {}
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _exitBlackScreen(AppSettings settings) {
    setState(() {
      _skipBlackScreen = true;
    });
    if (settings.isKhushooManualActive) {
      ref
          .read(settingsNotifierProvider.notifier)
          .updateSettings(settings.copyWith(isKhushooManualActive: false));
    }
  }

  void _disableBlackClockMode(AppSettings settings) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(
          settings.copyWith(blackClockModeEnabled: false),
        );
  }

  void _disableAzkarOnlyMode(AppSettings settings) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(
          settings.copyWith(azkarOnlyScreenEnabled: false),
        );
  }

  bool _isCancelKey(LogicalKeyboardKey key) {
    final keyLabel = key.keyLabel.toLowerCase();
    final debugName = (key.debugName ?? '').toLowerCase();
    return key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.browserBack ||
        keyLabel == 'back' ||
        keyLabel == 'exit' ||
        debugName.contains('back') ||
        debugName.contains('exit');
  }

  KeyEventResult _handleBlackClockRemoteCancel(
      KeyEvent event, AppSettings settings) {
    if (event is! KeyDownEvent) {
      return KeyEventResult.ignored;
    }

    if (_isCancelKey(event.logicalKey)) {
      _disableBlackClockMode(settings);
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  Widget _buildBlackClockModeScreen(
      AppSettings settings, TimerState timerState) {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    final useGlassBackground = settings.blackClockModeUseGlass;
    final textColor = useGlassBackground
        ? _parseHex(settings.pureGlassTextColor, fallback: Colors.white)
        : Colors.white;

    final clockWidget = settings.enableAnalogGlassClock
        ? AnalogGlassClock(
            baseTime: timerState.now,
            size: isLandscape ? 340 : 270,
            brand: 'NOOR',
            showHourNumbers: settings.showAnalogClockNumbers,
            useArabicIndicDigits: settings.useArabicIndicDigits,
            style: settings.analogClockStyle,
            enableShine: settings.glassShineEnabled,
          )
        : DigitalClock(
            use24h: settings.is24HourFormat,
            useArabicIndicDigits: settings.useArabicIndicDigits,
            showFullClock: settings.showFullClock,
            showSeconds: settings.showSecondsClock,
            padTimesWithZero: settings.padTimesWithZero,
            fontFamily: settings.clockFontFamily,
            fontSize: isLandscape ? 132 : 104,
            color: textColor,
          );

    final displayedClock = useGlassBackground
        ? PureGlassPrayerFrame(
            settings: settings,
            borderRadius: 28,
            padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 22),
            child: clockWidget,
          )
        : clockWidget;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (node, event) =>
            _handleBlackClockRemoteCancel(event, settings),
        child: Stack(
          children: [
            Positioned.fill(
              child: SpecialScreenGlassBackground(
                settings: settings,
                enabled: useGlassBackground,
                customImagePath: settings.blackClockModeCustomBgPath,
              ),
            ),
            Center(child: displayedClock),
            Positioned(
              bottom: 24,
              left: 0,
              right: 0,
              child: Center(
                child: TvFocusable(
                  onPressed: () => _disableBlackClockMode(settings),
                  borderRadius: BorderRadius.circular(16),
                  focusColor: useGlassBackground
                      ? _parseHex(settings.pureGlassColor1,
                          fallback: Colors.white70)
                      : Colors.white70,
                  child: GlassToastSurface(
                    width: 390,
                    enableShine: settings.glassShineEnabled,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.stop_circle_outlined,
                          color: textColor.withValues(alpha: 0.82),
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          AppLocalizations.of(context).stopBlackClockWithHour,
                          style: TextStyle(
                            color: textColor,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _exitAdhanScreen() {
    AudioService.stop();
    setState(() {
      _skipAdhanScreen = true;
    });
  }

  void _exitIqamaScreen() {
    AudioService.stop();
    setState(() {
      _skipIqamaScreen = true;
    });
  }

  int _getCurrentBackgroundId(
      AppSettings settings, PrayerName currentPrayer, DateTime effectiveNow) {
    switch (settings.bgMode) {
      case 'MANUAL':
        return settings.selectedBackgroundId;
      case 'PER_PRAYER':
        final id = _getPrayerId(currentPrayer);
        return settings.backgroundPerPrayer[id] ?? 0;
      case 'PER_DAY':
        final dayStr = effectiveNow.weekday.toString();
        return settings.backgroundPerWeekday[dayStr] ?? 0;
      case 'DAILY_RANDOM_FROM_LIST':
        if (settings.randomBackgroundPool.isEmpty) return 0;
        final days = effectiveNow.difference(DateTime(1970)).inDays;
        final index = days % settings.randomBackgroundPool.length;
        return settings.randomBackgroundPool[index];
      default:
        return 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    final timerState = ref.watch(timerEngineProvider);
    final settings = ref.watch(settingsNotifierProvider);
    final l10n = AppLocalizations.of(context);
    AppStyles.currentSettings = settings;

    // Listen for phase changes
    ref.listen<TimerState>(timerEngineProvider, (previous, next) {
      if (previous?.phase != next.phase) {
        if (next.phase == PrayerPhase.adhan) {
          final prayerId = _getPrayerId(next.currentOrNextPrayer);
          if (!settings.isGlobalAudioMuted && !settings.isAzanAudioMuted) {
            AudioService.playAdhan(
                isShort: settings.useShortAdhan, prayerId: prayerId);
          }
        } else if (next.phase == PrayerPhase.iqama) {
          if (!settings.isGlobalAudioMuted) {
            AudioService.playIqama(isShort: settings.useShortIqama);
          }
        }

        // Reset skip flags when moving away from their respective phases
        if (next.phase != PrayerPhase.blackScreen && _skipBlackScreen) {
          setState(() => _skipBlackScreen = false);
        }
        if (next.phase != PrayerPhase.adhan && _skipAdhanScreen) {
          setState(() => _skipAdhanScreen = false);
        }
        if (next.phase != PrayerPhase.iqama && _skipIqamaScreen) {
          setState(() => _skipIqamaScreen = false);
        }
      }

      // Pre-Iqama Audio Alert (20 seconds before)
      if (next.phase == PrayerPhase.iqama &&
          next.timeUntilNext.inSeconds == 20 &&
          settings.playVoiceAlertBeforeIqama) {
        if (!settings.isGlobalAudioMuted) {
          AudioService.playPreIqamaAlert();
        }
      }
    });

    // Manage App Orientation based on user settings
    if (settings.appOrientation == 'PORTRAIT') {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    } else if (settings.appOrientation == 'LANDSCAPE') {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    } else {
      SystemChrome.setPreferredOrientations(DeviceOrientation.values); // AUTO
    }

    final isKhushooActive = (timerState.phase == PrayerPhase.blackScreen ||
            settings.isKhushooManualActive) &&
        !_skipBlackScreen;
    if (isKhushooActive) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Spacer(),
              TvFocusable(
                onPressed: () => _exitBlackScreen(settings),
                borderRadius: BorderRadius.circular(18),
                focusColor: Colors.white70,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: Colors.white.withValues(alpha: 0.1)),
                  ),
                  child: Text(
                    AppLocalizations.of(context).exitKhushooMode,
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 16,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      );
    }

    // Check phases
    switch (timerState.phase) {
      case PrayerPhase.adhan:
        if (settings.showAdhanScreen && !_skipAdhanScreen) {
          return AdhanScreen(
            currentPrayer: timerState.currentOrNextPrayer,
            onClose: _exitAdhanScreen,
          );
        }
        break; // disabled or skipped → falls to main screen
      case PrayerPhase.iqama:
        if (settings.showIqamaScreen && !_skipIqamaScreen) {
          final minutes =
              timerState.timeUntilNext.inMinutes.toString().padLeft(2, '0');
          final seconds = timerState.timeUntilNext.inSeconds
              .remainder(60)
              .toString()
              .padLeft(2, '0');
          return IqamaScreen(
            prayerName: _getLocalizedPrayerName(
                context, timerState.currentOrNextPrayer),
            remainingTime: NumberHelper.format(
                '$minutes:$seconds', settings.useArabicIndicDigits),
            hadith: timerState.timeUntilNext.inSeconds <= 33
                ? l10n.straightenRowsHadith
                : '',
            onClose: _exitIqamaScreen,
          );
        }
        break; // disabled or skipped → falls to main screen
      case PrayerPhase.blackScreen:
        final timeFormat = settings.is24HourFormat ? 'HH:mm' : 'hh:mm a';
        final formattedTime = DateFormat(timeFormat).format(timerState.now);
        return BlackScreen(
          showClock: false,
          timeText: formattedTime,
        );
      case PrayerPhase.countdown:
        break;
    }

    if (settings.azkarOnlyScreenEnabled) {
      return AzkarOnlyScreen(
        settings: settings,
        onDisable: () => _disableAzkarOnlyMode(settings),
      );
    }

    if (settings.blackClockModeEnabled) {
      return _buildBlackClockModeScreen(settings, timerState);
    }

    final now = timerState.now;
    final hijriDate = HijriCalendar.fromDate(now);
    final locale = Localizations.localeOf(context).languageCode;
    final dayName = DateFormat('EEEE', locale).format(now);

    // Ensure formatting is initialized
    initializeDateFormatting(locale);
    final gregorianStr = DateFormat('d MMMM y', locale).format(now);

    final hourPart = settings.padTimesWithZero
        ? (settings.is24HourFormat ? 'HH' : 'hh')
        : (settings.is24HourFormat ? 'H' : 'h');
    final secondsPart = settings.showSecondsClock ? ':ss' : '';
    final amPmPart = settings.is24HourFormat ? '' : ' a';
    final clockFormat = '$hourPart:mm$secondsPart$amPmPart';
    final currentTimeStr = DateFormat(clockFormat, locale).format(now);

    final iqamaMins = timerState.timeUntilNext.inMinutes;
    final iqamaSecs = timerState.timeUntilNext.inSeconds.remainder(60);
    final iqamaTimerText = timerState.phase == PrayerPhase.iqama
        ? '${iqamaMins.toString().padLeft(2, '0')}:${iqamaSecs.toString().padLeft(2, '0')}'
        : '00:00';

    final asyncData = ref.watch(todayPrayerTimesProvider);
    final baseTickerItems = ref.watch(tickerContentProvider);
    final announcementTickerItems =
        ref.watch(activeAnnouncementTickerTextsProvider);
    final tickerItems = announcementTickerItems.isEmpty
        ? baseTickerItems
        : [...announcementTickerItems, ...baseTickerItems];

    final String nextPrayerStr =
        _getLocalizedPrayerName(context, timerState.currentOrNextPrayer);
    final nextPrayerId = _getPrayerId(timerState.currentOrNextPrayer);

    final hours = timerState.timeUntilNext.inHours;
    final mins = timerState.timeUntilNext.inMinutes.remainder(60);
    final secs = timerState.timeUntilNext.inSeconds.remainder(60);
    final hText = hours > 0
        ? '${NumberHelper.format(hours, settings.useArabicIndicDigits)} ${l10n.hour} ${l10n.and} '
        : '';
    final mText =
        '${NumberHelper.format(mins, settings.useArabicIndicDigits)} ${l10n.minute} ${l10n.and} ';
    final sText =
        '${NumberHelper.format(secs, settings.useArabicIndicDigits)} ${l10n.second}';
    String timeUntilStr = '$hText$mText$sText';

    final int bgId = _getCurrentBackgroundId(
        settings, timerState.currentOrNextPrayer, timerState.now);

    return PostPrayerAzkarOverlay(
      child: SlideshowOverlay(
        child: Scaffold(
          backgroundColor: const Color(0xFF050505),
          body: Directionality(
            textDirection: ui.TextDirection.rtl,
            child: settings.appTheme == 'PURE_GLASS'
                ? PureGlassThemeLayout(
                    settings: settings,
                    dayName: dayName,
                    gregorianStr: gregorianStr,
                    hijriDate: hijriDate,
                    nextPrayerId: nextPrayerId,
                    nextPrayerStr: nextPrayerStr,
                    timeUntilStr: timeUntilStr,
                    tickerItems: tickerItems,
                    timerState: timerState,
                    buildHeader: _buildHeader,
                    currentTime: currentTimeStr,
                    iqamaTimerText: iqamaTimerText,
                    prayers: _getPrayersForGlass(asyncData, settings),
                    backgroundImage: _getBackgroundImage(bgId, settings),
                  )
                : Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: _getBackgroundImage(bgId, settings),
                        fit: settings.bgFitMode == 'CONTAIN'
                            ? BoxFit.contain
                            : (settings.bgFitMode == 'FILL'
                                ? BoxFit.fill
                                : BoxFit.cover),
                        onError: (err, stack) {},
                      ),
                    ),
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color.fromRGBO(13, 17, 23, 0.05),
                            Color.fromRGBO(10, 14, 20, 0.30),
                          ],
                        ),
                      ),
                      child: EmeraldThemeLayout(
                        settings: settings,
                        dayName: dayName,
                        gregorianStr: gregorianStr,
                        hijriDate: hijriDate,
                        asyncData: asyncData,
                        nextPrayerId: nextPrayerId,
                        nextPrayerStr: nextPrayerStr,
                        timeUntilStr: timeUntilStr,
                        tickerItems: tickerItems,
                        timerState: timerState,
                        buildHeader: _buildHeader,
                        backgroundImage: _getBackgroundImage(bgId, settings),
                        iqamaTimerText: iqamaTimerText,
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getPrayersForGlass(
      AsyncValue<PrayerDay> asyncData, AppSettings settings) {
    if (!asyncData.hasValue) return [];
    final prayerDay = asyncData.value!;
    final format = settings.is24HourFormat ? 'HH:mm' : 'hh:mm';

    final prayers = [
      {
        'id': 'fajr',
        'nameAr': PrayerNameHelper.getArName(PrayerName.fajr),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.fajr),
        'time': DateFormat(format, 'en').format(prayerDay.fajr),
        'iqama': '+${settings.fajrIqamaTime}'
      },
      {
        'id': 'sunrise',
        'nameAr': PrayerNameHelper.getArName(PrayerName.sunrise),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.sunrise),
        'time': DateFormat(format, 'en').format(prayerDay.sunrise),
        'iqama': null
      },
      {
        'id': 'dhuhr',
        'nameAr': PrayerNameHelper.getArName(PrayerName.dhuhr),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.dhuhr),
        'time': DateFormat(format, 'en').format(prayerDay.dhuhr),
        'iqama': '+${settings.dhuhrIqamaTime}'
      },
      {
        'id': 'asr',
        'nameAr': PrayerNameHelper.getArName(PrayerName.asr),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.asr),
        'time': DateFormat(format, 'en').format(prayerDay.asr),
        'iqama': '+${settings.asrIqamaTime}'
      },
      {
        'id': 'maghrib',
        'nameAr': PrayerNameHelper.getArName(PrayerName.maghrib),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.maghrib),
        'time': DateFormat(format, 'en').format(prayerDay.maghrib),
        'iqama': '+${settings.maghribIqamaTime}'
      },
      {
        'id': 'isha',
        'nameAr': PrayerNameHelper.getArName(PrayerName.isha),
        'nameEn': PrayerNameHelper.getEnName(PrayerName.isha),
        'time': DateFormat(format, 'en').format(prayerDay.isha),
        'iqama': '+${settings.ishaIqamaTime}'
      },
    ];

    if (settings.showNightPrayers) {
      DateTime tomorrowFajr = prayerDay.fajr.add(const Duration(days: 1));
      Duration nightDuration = tomorrowFajr.difference(prayerDay.maghrib);
      DateTime midnight = prayerDay.maghrib
          .add(Duration(seconds: nightDuration.inSeconds ~/ 2));
      DateTime lastThird = prayerDay.maghrib
          .add(Duration(seconds: (nightDuration.inSeconds * 2) ~/ 3));

      prayers.add({
        'id': 'midnight',
        'nameAr': PrayerNameHelper.getArName('midnight'),
        'nameEn': PrayerNameHelper.getEnName('midnight'),
        'time': DateFormat(format, 'en').format(midnight),
        'iqama': null
      });
      prayers.add({
        'id': 'last_third',
        'nameAr': PrayerNameHelper.getArName('last_third'),
        'nameEn': PrayerNameHelper.getEnName('last_third'),
        'time': DateFormat(format, 'en').format(lastThird),
        'iqama': null
      });
    }

    return prayers;
  }

  Widget _buildHeader(AppSettings settings) {
    return Consumer(
      builder: (context, headerRef, child) {
        final isLandscape =
            MediaQuery.of(context).orientation == Orientation.landscape;
        final countriesDataAsync = headerRef.watch(countriesNameProvider);
        final map = countriesDataAsync.valueOrNull ?? {};
        final weatherAsync = headerRef.watch(weatherForecastProvider);

        final countryName = map[settings.country] ?? settings.country;
        final cityName = settings.city;

        WeatherForecast? todayWeather;
        final forecasts = weatherAsync.valueOrNull;
        if (forecasts != null && forecasts.isNotEmpty) {
          todayWeather = forecasts.first;
        }

        String weatherIcon(int code) {
          if (code == 0) return '☀️';
          if (code <= 2) return '🌤️';
          if (code <= 3) return '☁️';
          if (code <= 48) return '🌫️';
          if (code <= 57) return '🌧️';
          if (code <= 67) return '🌧️';
          if (code <= 77) return '❄️';
          if (code <= 82) return '🌧️';
          if (code <= 86) return '🌨️';
          if (code <= 99) return '⚡';
          return '🌤️';
        }

        return GlassCard(
          settings: settings,
          borderRadius: isLandscape ? 32 : 30,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: SizedBox(
                  width: 54,
                  height: 54,
                  child: settings.mosqueIconPath != null
                      ? Image.file(
                          File(settings.mosqueIconPath!),
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, e, s) => Image.asset(
                              'assets/images/logo.jpg',
                              fit: BoxFit.cover),
                        )
                      : Image.asset('assets/images/logo.jpg',
                          fit: BoxFit.cover),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      settings.mosqueName,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFFF7FAFC),
                        fontFamily: 'Cairo',
                        shadows: [
                          Shadow(
                            color: Colors.black87,
                            blurRadius: 10,
                            offset: Offset(0, 3),
                          )
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        if (settings.showCountryFlag)
                          _buildFlagWidget(settings, 22),
                        if (settings.showCountryFlag) const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            '$countryName • $cityName',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFFD7E1EE),
                              fontFamily: 'Cairo',
                              shadows: [
                                Shadow(color: Colors.black87, blurRadius: 6)
                              ],
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (todayWeather != null && settings.weatherEnabled) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0E1827).withValues(alpha: 0.52),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                            color: Colors.white.withValues(alpha: 0.14)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(weatherIcon(todayWeather.weatherCode),
                              style: const TextStyle(fontSize: 16)),
                          const SizedBox(width: 6),
                          Text(
                            '${NumberHelper.format(todayWeather.minTemp.round(), settings.useArabicIndicDigits)}° / ${NumberHelper.format(todayWeather.maxTemp.round(), settings.useArabicIndicDigits)}°',
                            style: const TextStyle(
                              fontSize: 13,
                              color: Color(0xFFDCB881),
                              fontWeight: FontWeight.w800,
                              fontFamily: 'Cairo',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                  TvFocusable(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SettingsScreen(),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(18),
                    focusColor: settings.appTheme == 'PURE_GLASS'
                        ? _parseHex(settings.pureGlassColor1,
                            fallback: const Color(0xFF38BDF8))
                        : const Color(0xFFDCB881),
                    child: Container(
                      padding: EdgeInsets.all(isLandscape ? 12 : 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0E1827).withValues(alpha: 0.54),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                            color: Colors.white.withValues(alpha: 0.14)),
                      ),
                      child: Icon(Icons.settings_rounded,
                          color: settings.appTheme == 'PURE_GLASS'
                              ? _parseHex(settings.pureGlassColor1,
                                  fallback: const Color(0xFF38BDF8))
                              : const Color(0xFFDCB881),
                          size: isLandscape ? 30 : 22),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFlagWidget(AppSettings settings, double size) {
    if (settings.customFlagPath != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Image.file(
          File(settings.customFlagPath!),
          width: size * 1.4,
          height: size,
          fit: BoxFit.cover,
          errorBuilder: (ctx, e, s) => _defaultFlagPlaceholder(size, settings),
        ),
      );
    }
    return _defaultFlagPlaceholder(size, settings);
  }

  Widget _defaultFlagPlaceholder(double size, AppSettings settings) {
    return Icon(Icons.flag_rounded,
        color: settings.appTheme == 'PURE_GLASS'
            ? _parseHex(settings.pureGlassColor1,
                fallback: const Color(0xFF38BDF8))
            : const Color(0xFFDCB881),
        size: size);
  }

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  String _getLocalizedPrayerName(BuildContext context, PrayerName name) {
    final l10n = AppLocalizations.of(context);
    switch (name) {
      case PrayerName.fajr:
        return l10n.fajr;
      case PrayerName.sunrise:
        return l10n.sunrise;
      case PrayerName.dhuhr:
        return l10n.dhuhr;
      case PrayerName.asr:
        return l10n.asr;
      case PrayerName.maghrib:
        return l10n.maghrib;
      case PrayerName.isha:
        return l10n.isha;
      default:
        return '—';
    }
  }

  ImageProvider _getBackgroundImage(int bgId, AppSettings settings) {
    if (bgId == -1) {
      if (settings.selectedCustomBgPath != null) {
        final file = File(settings.selectedCustomBgPath!);
        if (file.existsSync()) {
          return FileImage(file);
        }
      }
      if (_customBgPath != null) {
        final file = File(_customBgPath!);
        if (file.existsSync()) {
          return FileImage(file);
        }
      }
    }
    if (bgId > 0) {
      return AssetImage('assets/images/backgrounds/bg_$bgId.jpg');
    }
    if (settings.appTheme == 'EMERALD') {
      final isLandscape =
          MediaQuery.of(context).orientation == Orientation.landscape;
      return AssetImage(
        isLandscape
            ? 'assets/images/backgrounds/background_only_1920x1080.png'
            : 'assets/images/backphone/background_only_1080x1920.png',
      );
    }
    return const AssetImage('assets/images/backphone/back1.png');
  }
}

// ---------------------------------------------------------
// مكون بطاقة الصلاة (Prayer Item)
// ---------------------------------------------------------
class PrayerItem extends StatelessWidget {
  final String name;
  final String nameEn;
  final String time;
  final String? iqama;
  final bool isActive;
  final bool isCountdown;
  final bool isPast;
  final bool isEnlargedNext;
  final AppSettings settings;

  const PrayerItem({
    super.key,
    required this.name,
    required this.nameEn,
    required this.time,
    this.iqama,
    this.isActive = false,
    this.isCountdown = false,
    this.isPast = false,
    this.isEnlargedNext = false,
    required this.settings,
  });

  @override
  Widget build(BuildContext context) {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    // Centering logic
    bool shouldCenter = false;
    if (isLandscape && settings.centerPrayerNamesLandscape) shouldCenter = true;
    if (!isLandscape && settings.centerPrayerNamesPortrait) shouldCenter = true;

    // Enlarging logic
    bool shouldEnlarge = isLandscape && settings.enlargePrayerNamesLandscape;
    double baseFontSize = shouldEnlarge ? 22.0 : 18.0;
    if (isEnlargedNext) baseFontSize *= 1.15;

    final shouldDim = isPast && settings.dimPastPrayers;

    return Opacity(
      opacity: shouldDim ? 0.4 : 1.0,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        margin: EdgeInsets.only(bottom: isEnlargedNext ? 12 : 8),
        transform: isEnlargedNext
            ? Matrix4.diagonal3Values(1.05, 1.05, 1.0)
            : Matrix4.identity(),
        child: GlassCard(
          settings: settings,
          borderRadius: isLandscape ? 32 : 30,
          isActive: isActive,
          padding: EdgeInsets.symmetric(
              horizontal: 18, vertical: isEnlargedNext ? 14 : 10),
          child: Row(
            mainAxisAlignment: shouldCenter
                ? MainAxisAlignment.center
                : MainAxisAlignment.spaceBetween,
            children: [
              Row(
                textDirection: settings.languageCode == 'ar'
                    ? ui.TextDirection.rtl
                    : ui.TextDirection.ltr,
                children: [
                  Text(
                    settings.languageCode == 'ar' ? name : nameEn,
                    style: TextStyle(
                      fontSize: baseFontSize,
                      fontWeight: FontWeight.w700,
                      color: isActive ? const Color(0xFFDCB881) : Colors.white,
                      fontFamily: settings.timesFontFamily,
                    ),
                  ),
                  if (settings.showPrayerNameInOtherLanguage) ...[
                    const SizedBox(width: 8),
                    Text(
                      settings.languageCode == 'ar' ? nameEn : name,
                      style: TextStyle(
                        fontSize: baseFontSize * 0.75,
                        fontWeight: FontWeight.w500,
                        color: isActive
                            ? const Color(0xFFDCB881).withValues(alpha: 0.8)
                            : Colors.white70,
                        fontFamily: settings.timesFontFamily,
                      ),
                    ),
                  ],
                  if (isActive && !shouldCenter)
                    Container(
                      margin: const EdgeInsets.only(right: 10),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE8CE9F), Color(0xFFCBA96E)],
                        ),
                        borderRadius: BorderRadius.circular(4),
                        boxShadow: const [
                          BoxShadow(
                              color: Color.fromRGBO(220, 184, 129, 0.4),
                              blurRadius: 8,
                              offset: Offset(0, 2))
                        ],
                      ),
                      child: const Text(
                        'القادمة',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF111822)),
                      ),
                    ),
                ],
              ),
              if (!shouldCenter)
                Row(
                  children: [
                    Text(
                      time,
                      textDirection: ui.TextDirection.ltr,
                      style: TextStyle(
                        fontSize: baseFontSize,
                        fontWeight: FontWeight.w700,
                        color:
                            isActive ? const Color(0xFFDCB881) : Colors.white,
                        fontFamily: settings.clockFontFamily,
                      ),
                    ),
                    if (iqama != null && settings.hideIqamaTime != true) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: isActive
                              ? const Color.fromRGBO(220, 184, 129, 0.2)
                              : Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          iqama!,
                          style: TextStyle(
                            fontSize: isCountdown
                                ? baseFontSize
                                : baseFontSize * 0.75,
                            fontWeight:
                                isActive ? FontWeight.bold : FontWeight.w500,
                            color: isActive
                                ? const Color(0xFFDCB881)
                                : Colors.white70,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------
// مكون الزجاج الشفاف (الأساس للبطاقات)
// ---------------------------------------------------------
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final bool isActive;
  final AppSettings? settings;
  final double borderRadius;

  const GlassCard({
    super.key,
    required this.child,
    required this.padding,
    this.isActive = false,
    this.settings,
    this.borderRadius = 30,
  });

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    final effectiveRadius = borderRadius >= 30 ? borderRadius : 30.0;
    final isPureGlass = settings?.appTheme == 'PURE_GLASS';
    final accentColor = isPureGlass
        ? _parseHex(settings?.pureGlassColor1 ?? '#38BDF8',
            fallback: const Color(0xFF38BDF8))
        : const Color(0xFFDCB881);

    final gradientColors = isPureGlass
        ? [
            const Color(0xFF202742).withValues(alpha: 0.88),
            const Color(0xFF101725).withValues(alpha: 0.72),
          ]
        : [
            const Color(0xFF214338).withValues(alpha: 0.94),
            const Color(0xFF0D241D).withValues(alpha: 0.96),
          ];

    final borderColor = isPureGlass
        ? Colors.white.withValues(alpha: isActive ? 0.20 : 0.13)
        : accentColor.withValues(alpha: isActive ? 0.54 : 0.26);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(effectiveRadius),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.28),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
          if (isActive)
            BoxShadow(
              color: accentColor.withValues(alpha: isPureGlass ? 0.18 : 0.16),
              blurRadius: 22,
              spreadRadius: -2,
            ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(effectiveRadius),
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(effectiveRadius),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: gradientColors,
              ),
              border: Border.all(color: borderColor, width: 1.05),
            ),
            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  height: 44,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(effectiveRadius),
                        topRight: Radius.circular(effectiveRadius),
                      ),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.white
                              .withValues(alpha: isPureGlass ? 0.10 : 0.08),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
                if (isActive)
                  Positioned(
                    left: 0,
                    top: 0,
                    bottom: 0,
                    child: Container(
                      width: 5,
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: 0.95),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(effectiveRadius),
                          bottomLeft: Radius.circular(effectiveRadius),
                        ),
                      ),
                    ),
                  ),
                Padding(
                  padding: padding,
                  child: child,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
