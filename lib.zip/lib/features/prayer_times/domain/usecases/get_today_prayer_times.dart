import 'package:fpdart/fpdart.dart';
import '../../../../core/errors/failures.dart';
import '../entities/prayer_day.dart';
import '../repositories/prayer_times_repository.dart';

class GetTodayPrayerTimes {
  final PrayerTimesRepository repository;

  GetTodayPrayerTimes(this.repository);

  // UseCase محدد لجلب صلوات اليوم الواحد لمدينة معينة
  Future<Either<Failure, PrayerDay>> call(String country, String city, DateTime requestDate, {String? customFilePath}) async {
    return await repository.getPrayerTimesForDate(country, city, requestDate, customFilePath: customFilePath);
  }
}
