import 'package:fpdart/fpdart.dart';
import '../../../../core/errors/failures.dart';
import '../entities/prayer_day.dart';

abstract class PrayerTimesRepository {
  // استخدام Either لضمان التعامل مع النجاح (Right) والفشل (Left) بشكل إلزامي
  Future<Either<Failure, PrayerDay>> getPrayerTimesForDate(
    String country, 
    String city, 
    DateTime date, {
    String? customFilePath,
  });
}
