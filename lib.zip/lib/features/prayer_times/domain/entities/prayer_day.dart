import 'package:freezed_annotation/freezed_annotation.dart';

part 'prayer_day.freezed.dart';

// الكيان النقي (Entity) الذي تحتاجه واجهة المستخدم مباشرة، 
// وهو يختلف عن الـ Model حيث تم تحويل الأوقات النصية إلى كائنات DateTime
@freezed
class PrayerDay with _$PrayerDay {
  const factory PrayerDay({
    required DateTime fajr,
    required DateTime sunrise,
    required DateTime dhuhr,
    required DateTime asr,
    required DateTime maghrib,
    required DateTime isha,
  }) = _PrayerDay;
}
