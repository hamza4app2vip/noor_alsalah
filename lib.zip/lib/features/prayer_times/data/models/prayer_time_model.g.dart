// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prayer_time_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PrayerTimesDayModelImpl _$$PrayerTimesDayModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PrayerTimesDayModelImpl(
      fajr: json['fajr'] as String,
      sunrise: json['sunrise'] as String,
      dhuhr: json['dhuhr'] as String,
      asr: json['asr'] as String,
      maghrib: json['maghrib'] as String,
      isha: json['isha'] as String,
    );

Map<String, dynamic> _$$PrayerTimesDayModelImplToJson(
        _$PrayerTimesDayModelImpl instance) =>
    <String, dynamic>{
      'fajr': instance.fajr,
      'sunrise': instance.sunrise,
      'dhuhr': instance.dhuhr,
      'asr': instance.asr,
      'maghrib': instance.maghrib,
      'isha': instance.isha,
    };

_$PrayerTimesDbModelImpl _$$PrayerTimesDbModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PrayerTimesDbModelImpl(
      data: (json['data'] as Map<String, dynamic>).map(
        (k, e) => MapEntry(
            k,
            (e as Map<String, dynamic>).map(
              (k, e) => MapEntry(
                  k,
                  (e as Map<String, dynamic>).map(
                    (k, e) => MapEntry(
                        k,
                        PrayerTimesDayModel.fromJson(
                            e as Map<String, dynamic>)),
                  )),
            )),
      ),
    );

Map<String, dynamic> _$$PrayerTimesDbModelImplToJson(
        _$PrayerTimesDbModelImpl instance) =>
    <String, dynamic>{
      'data': instance.data,
    };
