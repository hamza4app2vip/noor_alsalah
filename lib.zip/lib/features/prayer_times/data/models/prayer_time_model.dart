import 'package:freezed_annotation/freezed_annotation.dart';

part 'prayer_time_model.freezed.dart';
part 'prayer_time_model.g.dart';

@freezed
class PrayerTimesDayModel with _$PrayerTimesDayModel {
  const factory PrayerTimesDayModel({
    required String fajr,
    required String sunrise,
    required String dhuhr,
    required String asr,
    required String maghrib,
    required String isha,
  }) = _PrayerTimesDayModel;

  factory PrayerTimesDayModel.fromJson(Map<String, dynamic> json) =>
      _$PrayerTimesDayModelFromJson(json);
}

// نموذج لتمثيل قاعدة البيانات الكاملة للصلوات (الدول -> المدن -> الأشهر -> الأيام)
// يعتمد هيكل هذا الموديل على افتراض التنظيم الشائع في ملفات الـ JSON
@freezed
class PrayerTimesDbModel with _$PrayerTimesDbModel {
  const factory PrayerTimesDbModel({
    // Country -> City -> MM-DD -> Times
    required Map<String, Map<String, Map<String, PrayerTimesDayModel>>> data,
  }) = _PrayerTimesDbModel;

  factory PrayerTimesDbModel.fromJson(Map<String, dynamic> json) =>
      _$PrayerTimesDbModelFromJson(json);
}
