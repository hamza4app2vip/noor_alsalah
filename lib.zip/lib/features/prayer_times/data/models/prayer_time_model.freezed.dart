// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'prayer_time_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PrayerTimesDayModel _$PrayerTimesDayModelFromJson(Map<String, dynamic> json) {
  return _PrayerTimesDayModel.fromJson(json);
}

/// @nodoc
mixin _$PrayerTimesDayModel {
  String get fajr => throw _privateConstructorUsedError;
  String get sunrise => throw _privateConstructorUsedError;
  String get dhuhr => throw _privateConstructorUsedError;
  String get asr => throw _privateConstructorUsedError;
  String get maghrib => throw _privateConstructorUsedError;
  String get isha => throw _privateConstructorUsedError;

  /// Serializes this PrayerTimesDayModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of PrayerTimesDayModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $PrayerTimesDayModelCopyWith<PrayerTimesDayModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PrayerTimesDayModelCopyWith<$Res> {
  factory $PrayerTimesDayModelCopyWith(
          PrayerTimesDayModel value, $Res Function(PrayerTimesDayModel) then) =
      _$PrayerTimesDayModelCopyWithImpl<$Res, PrayerTimesDayModel>;
  @useResult
  $Res call(
      {String fajr,
      String sunrise,
      String dhuhr,
      String asr,
      String maghrib,
      String isha});
}

/// @nodoc
class _$PrayerTimesDayModelCopyWithImpl<$Res, $Val extends PrayerTimesDayModel>
    implements $PrayerTimesDayModelCopyWith<$Res> {
  _$PrayerTimesDayModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of PrayerTimesDayModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fajr = null,
    Object? sunrise = null,
    Object? dhuhr = null,
    Object? asr = null,
    Object? maghrib = null,
    Object? isha = null,
  }) {
    return _then(_value.copyWith(
      fajr: null == fajr
          ? _value.fajr
          : fajr // ignore: cast_nullable_to_non_nullable
              as String,
      sunrise: null == sunrise
          ? _value.sunrise
          : sunrise // ignore: cast_nullable_to_non_nullable
              as String,
      dhuhr: null == dhuhr
          ? _value.dhuhr
          : dhuhr // ignore: cast_nullable_to_non_nullable
              as String,
      asr: null == asr
          ? _value.asr
          : asr // ignore: cast_nullable_to_non_nullable
              as String,
      maghrib: null == maghrib
          ? _value.maghrib
          : maghrib // ignore: cast_nullable_to_non_nullable
              as String,
      isha: null == isha
          ? _value.isha
          : isha // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PrayerTimesDayModelImplCopyWith<$Res>
    implements $PrayerTimesDayModelCopyWith<$Res> {
  factory _$$PrayerTimesDayModelImplCopyWith(_$PrayerTimesDayModelImpl value,
          $Res Function(_$PrayerTimesDayModelImpl) then) =
      __$$PrayerTimesDayModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String fajr,
      String sunrise,
      String dhuhr,
      String asr,
      String maghrib,
      String isha});
}

/// @nodoc
class __$$PrayerTimesDayModelImplCopyWithImpl<$Res>
    extends _$PrayerTimesDayModelCopyWithImpl<$Res, _$PrayerTimesDayModelImpl>
    implements _$$PrayerTimesDayModelImplCopyWith<$Res> {
  __$$PrayerTimesDayModelImplCopyWithImpl(_$PrayerTimesDayModelImpl _value,
      $Res Function(_$PrayerTimesDayModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of PrayerTimesDayModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fajr = null,
    Object? sunrise = null,
    Object? dhuhr = null,
    Object? asr = null,
    Object? maghrib = null,
    Object? isha = null,
  }) {
    return _then(_$PrayerTimesDayModelImpl(
      fajr: null == fajr
          ? _value.fajr
          : fajr // ignore: cast_nullable_to_non_nullable
              as String,
      sunrise: null == sunrise
          ? _value.sunrise
          : sunrise // ignore: cast_nullable_to_non_nullable
              as String,
      dhuhr: null == dhuhr
          ? _value.dhuhr
          : dhuhr // ignore: cast_nullable_to_non_nullable
              as String,
      asr: null == asr
          ? _value.asr
          : asr // ignore: cast_nullable_to_non_nullable
              as String,
      maghrib: null == maghrib
          ? _value.maghrib
          : maghrib // ignore: cast_nullable_to_non_nullable
              as String,
      isha: null == isha
          ? _value.isha
          : isha // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PrayerTimesDayModelImpl implements _PrayerTimesDayModel {
  const _$PrayerTimesDayModelImpl(
      {required this.fajr,
      required this.sunrise,
      required this.dhuhr,
      required this.asr,
      required this.maghrib,
      required this.isha});

  factory _$PrayerTimesDayModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PrayerTimesDayModelImplFromJson(json);

  @override
  final String fajr;
  @override
  final String sunrise;
  @override
  final String dhuhr;
  @override
  final String asr;
  @override
  final String maghrib;
  @override
  final String isha;

  @override
  String toString() {
    return 'PrayerTimesDayModel(fajr: $fajr, sunrise: $sunrise, dhuhr: $dhuhr, asr: $asr, maghrib: $maghrib, isha: $isha)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PrayerTimesDayModelImpl &&
            (identical(other.fajr, fajr) || other.fajr == fajr) &&
            (identical(other.sunrise, sunrise) || other.sunrise == sunrise) &&
            (identical(other.dhuhr, dhuhr) || other.dhuhr == dhuhr) &&
            (identical(other.asr, asr) || other.asr == asr) &&
            (identical(other.maghrib, maghrib) || other.maghrib == maghrib) &&
            (identical(other.isha, isha) || other.isha == isha));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode =>
      Object.hash(runtimeType, fajr, sunrise, dhuhr, asr, maghrib, isha);

  /// Create a copy of PrayerTimesDayModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$PrayerTimesDayModelImplCopyWith<_$PrayerTimesDayModelImpl> get copyWith =>
      __$$PrayerTimesDayModelImplCopyWithImpl<_$PrayerTimesDayModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PrayerTimesDayModelImplToJson(
      this,
    );
  }
}

abstract class _PrayerTimesDayModel implements PrayerTimesDayModel {
  const factory _PrayerTimesDayModel(
      {required final String fajr,
      required final String sunrise,
      required final String dhuhr,
      required final String asr,
      required final String maghrib,
      required final String isha}) = _$PrayerTimesDayModelImpl;

  factory _PrayerTimesDayModel.fromJson(Map<String, dynamic> json) =
      _$PrayerTimesDayModelImpl.fromJson;

  @override
  String get fajr;
  @override
  String get sunrise;
  @override
  String get dhuhr;
  @override
  String get asr;
  @override
  String get maghrib;
  @override
  String get isha;

  /// Create a copy of PrayerTimesDayModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$PrayerTimesDayModelImplCopyWith<_$PrayerTimesDayModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

PrayerTimesDbModel _$PrayerTimesDbModelFromJson(Map<String, dynamic> json) {
  return _PrayerTimesDbModel.fromJson(json);
}

/// @nodoc
mixin _$PrayerTimesDbModel {
// Country -> City -> MM-DD -> Times
  Map<String, Map<String, Map<String, PrayerTimesDayModel>>> get data =>
      throw _privateConstructorUsedError;

  /// Serializes this PrayerTimesDbModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of PrayerTimesDbModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $PrayerTimesDbModelCopyWith<PrayerTimesDbModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PrayerTimesDbModelCopyWith<$Res> {
  factory $PrayerTimesDbModelCopyWith(
          PrayerTimesDbModel value, $Res Function(PrayerTimesDbModel) then) =
      _$PrayerTimesDbModelCopyWithImpl<$Res, PrayerTimesDbModel>;
  @useResult
  $Res call({Map<String, Map<String, Map<String, PrayerTimesDayModel>>> data});
}

/// @nodoc
class _$PrayerTimesDbModelCopyWithImpl<$Res, $Val extends PrayerTimesDbModel>
    implements $PrayerTimesDbModelCopyWith<$Res> {
  _$PrayerTimesDbModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of PrayerTimesDbModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
  }) {
    return _then(_value.copyWith(
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Map<String, Map<String, Map<String, PrayerTimesDayModel>>>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PrayerTimesDbModelImplCopyWith<$Res>
    implements $PrayerTimesDbModelCopyWith<$Res> {
  factory _$$PrayerTimesDbModelImplCopyWith(_$PrayerTimesDbModelImpl value,
          $Res Function(_$PrayerTimesDbModelImpl) then) =
      __$$PrayerTimesDbModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Map<String, Map<String, Map<String, PrayerTimesDayModel>>> data});
}

/// @nodoc
class __$$PrayerTimesDbModelImplCopyWithImpl<$Res>
    extends _$PrayerTimesDbModelCopyWithImpl<$Res, _$PrayerTimesDbModelImpl>
    implements _$$PrayerTimesDbModelImplCopyWith<$Res> {
  __$$PrayerTimesDbModelImplCopyWithImpl(_$PrayerTimesDbModelImpl _value,
      $Res Function(_$PrayerTimesDbModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of PrayerTimesDbModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
  }) {
    return _then(_$PrayerTimesDbModelImpl(
      data: null == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as Map<String, Map<String, Map<String, PrayerTimesDayModel>>>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PrayerTimesDbModelImpl implements _PrayerTimesDbModel {
  const _$PrayerTimesDbModelImpl(
      {required final Map<String, Map<String, Map<String, PrayerTimesDayModel>>>
          data})
      : _data = data;

  factory _$PrayerTimesDbModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PrayerTimesDbModelImplFromJson(json);

// Country -> City -> MM-DD -> Times
  final Map<String, Map<String, Map<String, PrayerTimesDayModel>>> _data;
// Country -> City -> MM-DD -> Times
  @override
  Map<String, Map<String, Map<String, PrayerTimesDayModel>>> get data {
    if (_data is EqualUnmodifiableMapView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_data);
  }

  @override
  String toString() {
    return 'PrayerTimesDbModel(data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PrayerTimesDbModelImpl &&
            const DeepCollectionEquality().equals(other._data, _data));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_data));

  /// Create a copy of PrayerTimesDbModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$PrayerTimesDbModelImplCopyWith<_$PrayerTimesDbModelImpl> get copyWith =>
      __$$PrayerTimesDbModelImplCopyWithImpl<_$PrayerTimesDbModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PrayerTimesDbModelImplToJson(
      this,
    );
  }
}

abstract class _PrayerTimesDbModel implements PrayerTimesDbModel {
  const factory _PrayerTimesDbModel(
      {required final Map<String, Map<String, Map<String, PrayerTimesDayModel>>>
          data}) = _$PrayerTimesDbModelImpl;

  factory _PrayerTimesDbModel.fromJson(Map<String, dynamic> json) =
      _$PrayerTimesDbModelImpl.fromJson;

// Country -> City -> MM-DD -> Times
  @override
  Map<String, Map<String, Map<String, PrayerTimesDayModel>>> get data;

  /// Create a copy of PrayerTimesDbModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$PrayerTimesDbModelImplCopyWith<_$PrayerTimesDbModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
