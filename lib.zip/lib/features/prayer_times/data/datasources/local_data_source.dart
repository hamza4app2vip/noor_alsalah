import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../../../../core/services/custom_location_service.dart';
import '../models/prayer_time_model.dart';
import '../../../../core/errors/failures.dart';

abstract class PrayerTimesLocalDataSource {
  Future<PrayerTimesDbModel> loadCityPrayerTimes(String countryCode, String cityCode, {String? customFilePath});
  Future<Map<String, List<String>>> loadAvailableLocations();
  Future<Map<String, String>> loadCountriesNames();
}


class PrayerTimesLocalDataSourceImpl implements PrayerTimesLocalDataSource {
  final CustomLocationService _customLocationService;
  
  PrayerTimesLocalDataSourceImpl([CustomLocationService? customLocationService]) 
      : _customLocationService = customLocationService ?? CustomLocationService();

  Map<String, List<String>>? _cachedLocations;
  Map<String, String>? _cachedCountriesNames;
  
  // مفتاح البلد والمدينة للبيانات المحملة حاليا لتجنب قراءة الملف الضخم مراراً
  String? _loadedCountry;
  String? _loadedCity;
  PrayerTimesDbModel? _cachedCityData;

  @override
  Future<PrayerTimesDbModel> loadCityPrayerTimes(String countryCode, String cityCode, {String? customFilePath}) async {
    if (customFilePath == null && _loadedCountry == countryCode && _loadedCity == cityCode && _cachedCityData != null) {
      return _cachedCityData!;
    }

    try {
      String jsonString;
      if (customFilePath != null) {
        final file = File(customFilePath);
        if (await file.exists()) {
          jsonString = await file.readAsString();
        } else {
          throw LocalDatabaseFailure('Custom file not found at $customFilePath');
        }
      } else {
        // Load specific city file directly: assets/time/EG/cairo.json
        final upperCountry = countryCode.trim().toUpperCase();
        final lowerCity = cityCode.trim().toLowerCase();
        final path = 'assets/time/$upperCountry/$lowerCity.json';
        jsonString = await rootBundle.loadString(path);
      }
      
      final cityData = await compute(_parseSpecificCityFile, {
        'json': jsonString,
        'countryCode': countryCode,
        'cityCode': cityCode,
      });

      if (customFilePath == null) {
        _loadedCountry = countryCode;
        _loadedCity = cityCode;
        _cachedCityData = cityData;
      }
      
      return cityData;
    } catch (e) {
      throw LocalDatabaseFailure('Failed to load prayer times: $e');
    }
  }

  @override
  Future<Map<String, List<String>>> loadAvailableLocations() async {
    if (_cachedLocations != null) return _cachedLocations!;

    try {
      final jsonString = await rootBundle.loadString('assets/data/locations_index.json');
      final baseLocations = await compute(_extractLocationsIndex, jsonString);
      
      final customCities = await _customLocationService.getCustomCities();
      customCities.forEach((code, cities) {
        final upperCode = code.toUpperCase();
        final List<String> existing = baseLocations[upperCode] ?? [];
        baseLocations[upperCode] = <String>{...existing, ...cities}.toList();
      });
      
      _cachedLocations = baseLocations;
      return _cachedLocations!;
    } catch (e) {
      throw LocalDatabaseFailure('Failed to load locations index: $e');
    }
  }

  @override
  Future<Map<String, String>> loadCountriesNames() async {
    if (_cachedCountriesNames != null) return _cachedCountriesNames!;
    try {
      final jsString = await rootBundle.loadString('assets/data/countries.js');
      final map = await compute(_parseCountriesJS, jsString);
      
      final customCountries = await _customLocationService.getCustomCountries();
      map.addAll(customCountries);
      
      _cachedCountriesNames = map;
      return _cachedCountriesNames!;
    } catch (e) {
      return {}; // return empty map if file formatting fails
    }
  }
}

// ==============================================
// الدوال التي تعمل في الـ Background Isolates
// ==============================================

PrayerTimesDbModel _parseSpecificCityFile(Map<String, dynamic> args) {
  final jsonString = args['json'] as String;
  final countryCode = (args['countryCode'] as String).trim().toUpperCase();
  final cityCode = (args['cityCode'] as String).trim().toLowerCase();

  final Map<String, dynamic> fullMap = jsonDecode(jsonString);
  
  // File structure: { "YE": { "taiz": { "01-01": {...} } } }
  final countryData = fullMap[countryCode] as Map<String, dynamic>?;
  if (countryData == null) {
      throw Exception('Country $countryCode not found in JSON data. Please re-import the Excel file for this location.');
  }

  final cityData = countryData[cityCode] as Map<String, dynamic>?;
  if (cityData == null) {
      throw Exception('City $cityCode not found in JSON data for $countryCode. Please re-import the Excel file for this location.');
  }

  final modelData = {
    countryCode: {
      cityCode: cityData
    }
  };

  return PrayerTimesDbModel.fromJson({'data': modelData});
}

Map<String, List<String>> _extractLocationsIndex(String jsonString) {
  final Map<String, dynamic> fullMap = jsonDecode(jsonString);
  final result = <String, List<String>>{};
  
  for (final country in fullMap.keys) {
    if (fullMap[country] is List) {
      final cityList = (fullMap[country] as List).map((e) => e.toString()).toList();
      // Ensure country keys are consistent (e.g. lowercase or uppercase, we use uppercase for files)
      result[country.toUpperCase()] = cityList;
    }
  }
  return result;
}

Map<String, String> _parseCountriesJS(String jsContent) {
  final map = <String, String>{};
  
  // Match lines like: "DZ|Algeria",
  final pattern = RegExp(r'"([A-Za-z0-9_]+)\|([^"]+)"');
  final matches = pattern.allMatches(jsContent);
  
  for (final match in matches) {
    if (match.groupCount >= 2) {
      final code = match.group(1)!;
      final name = match.group(2)!;
      map[code.toLowerCase()] = name; // نخزن الرمز بحروف صغيرة لمطابقته مع settings
    }
  }
  
  return map;
}
