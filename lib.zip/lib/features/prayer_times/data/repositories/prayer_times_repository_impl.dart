import 'package:fpdart/fpdart.dart';
import '../../../../core/errors/failures.dart';
import '../../domain/entities/prayer_day.dart';
import '../../domain/repositories/prayer_times_repository.dart';
import '../datasources/local_data_source.dart';

class PrayerTimesRepositoryImpl implements PrayerTimesRepository {
  final PrayerTimesLocalDataSource localDataSource;

  PrayerTimesRepositoryImpl(this.localDataSource);

  @override
  Future<Either<Failure, PrayerDay>> getPrayerTimesForDate(
    String country, 
    String city, 
    DateTime date, {
    String? customFilePath,
  }) async {
    try {
      // Fetch only the specific city database from the isolate
      final db = await localDataSource.loadCityPrayerTimes(
        country, 
        city, 
        customFilePath: customFilePath,
      );
      
      // format month and day to two digits e.g. "01", "02" to match JSON keys "MM-DD"
      final monthStr = date.month.toString().padLeft(2, '0');
      final dayStr = date.day.toString().padLeft(2, '0');
      final dateKey = '$monthStr-$dayStr';

      // Find times for given key
      final actualCountry = country.toUpperCase();
      final actualCity = city.toLowerCase();
      final times = db.data[actualCountry]?[actualCity]?[dateKey];
      if (times == null) {
        return left(const LocalDatabaseFailure('أوقات الصلاة غير متوفرة لهذا اليوم.'));
      }

      // تحويل النصوص ("05:30") إلى كائنات DateTime بنفس تاريخ اليوم
      DateTime parseTime(String time) {
        final parts = time.split(':');
        return DateTime(date.year, date.month, date.day, int.parse(parts[0]), int.parse(parts[1]));
      }

      final prayerDay = PrayerDay(
        fajr: parseTime(times.fajr),
        sunrise: parseTime(times.sunrise),
        dhuhr: parseTime(times.dhuhr),
        asr: parseTime(times.asr),
        maghrib: parseTime(times.maghrib),
        isha: parseTime(times.isha),
      );

      return right(prayerDay);
    } catch (e) {
      return left(LocalDatabaseFailure(e.toString()));
    }
  }
}
