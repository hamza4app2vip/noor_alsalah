// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticker_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$tickerContentHash() => r'0eed8f950f6a6613648e712016a881480a316b76';

/// See also [TickerContent].
@ProviderFor(TickerContent)
final tickerContentProvider =
    NotifierProvider<TickerContent, List<String>>.internal(
  TickerContent.new,
  name: r'tickerContentProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$tickerContentHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$TickerContent = Notifier<List<String>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
