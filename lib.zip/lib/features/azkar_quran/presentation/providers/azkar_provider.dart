import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ZikrItem {
  final String text;
  final String? repeatInfo;

  ZikrItem({required this.text, this.repeatInfo});
}

// Provider for general Azkar
final generalAzkarProvider = FutureProvider<List<ZikrItem>>((ref) async {
  return await _loadAndParseAzkar('assets/azkar/azkar.json');
});

// Provider for Morning Azkar
final sabahAzkarProvider = FutureProvider<List<ZikrItem>>((ref) async {
  return await _loadAndParseAzkar('assets/azkar/azkar-sabah.json');
});

// Provider for Evening Azkar
final masaaAzkarProvider = FutureProvider<List<ZikrItem>>((ref) async {
  return await _loadAndParseAzkar('assets/azkar/azkar-masaa.json');
});

Future<List<ZikrItem>> _loadAndParseAzkar(String path) async {
  final jsonStr = await rootBundle.loadString(path);
  final List<dynamic> rawList = jsonDecode(jsonStr);
  
  List<ZikrItem> items = [];
  List<String> currentBlock = [];
  
  for (var line in rawList) {
    if (line == "-------------------------------------") {
      if (currentBlock.isNotEmpty) {
        items.add(_parseBlockToZikrItem(currentBlock));
        currentBlock.clear();
      }
    } else {
      currentBlock.add(line.toString());
    }
  }
  // catch any dangling block
  if (currentBlock.isNotEmpty) {
     items.add(_parseBlockToZikrItem(currentBlock));
  }
  
  return items;
}

ZikrItem _parseBlockToZikrItem(List<String> block) {
  String text = "";
  String? repeat;
  
  for (var line in block) {
    if (line.contains("<span>")) {
      // Extract repeat text inside span
      repeat = line.replaceAll("<span>", "").replaceAll("</span>", "").trim();
    } else {
      if (text.isNotEmpty) text += "\n";
      text += line.trim();
    }
  }
  
  return ZikrItem(text: text, repeatInfo: repeat);
}
