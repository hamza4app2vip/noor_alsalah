import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:intl/intl.dart';
import 'package:hijri/hijri_calendar.dart';
import '../../../settings/presentation/providers/settings_provider.dart';
import '../../../settings/domain/entities/ticker_item.dart';
import '../../../../core/local_server/marquee_trigger_provider.dart';

part 'ticker_provider.g.dart';

@Riverpod(keepAlive: true)
class TickerContent extends _$TickerContent {
  @override
  List<String> build() {
    _loadContent();
    
    // إعادة التحميل إذا تغيرت الإعدادات المرتبطة بالشريط
    ref.listen(settingsNotifierProvider.select((s) => s.ayatsLanguageCode), (prev, next) {
      if (prev != next) _loadContent();
    });
    ref.listen(settingsNotifierProvider.select((s) => s.tickerItems), (prev, next) {
      if (prev != next) _loadContent();
    });
    ref.listen(settingsNotifierProvider.select((s) => s.ramadanCountdownInjectEnabled), (prev, next) {
      if (prev != next) _loadContent();
    });

    // مراقبة التنبيهات الفورية من لوحة تحكم الويب
    final trigger = ref.watch(marqueeTriggerProvider);
    if (trigger != null) {
      return [trigger];
    }
    
    
    return ['جاري تحميل الآيات والأذكار...']; // محتوى مبدئي
  }

  Future<void> _loadContent() async {
    final trigger = ref.read(marqueeTriggerProvider);
    if (trigger != null) {
      state = [trigger];
      return;
    }

    final settings = ref.read(settingsNotifierProvider);
    final ayatsLang = settings.ayatsLanguageCode.toLowerCase();
    
    try {
      // === Feature 7: Morning/Evening Azkar injection ===
      final now = DateTime.now();
      final currentHour = now.hour;

      // Helper to extract hour from "HH:mm"
      int getHour(String timeStr) => int.tryParse(timeStr.split(':')[0]) ?? 0;

      final sabahStart = getHour(settings.sabahStartTime);
      final sabahEnd = getHour(settings.sabahEndTime);
      final masaaStart = getHour(settings.masaaStartTime);
      final masaaEnd = getHour(settings.masaaEndTime);

      // Morning azkar window
      if (settings.enableSabahAzkar && currentHour >= sabahStart && currentHour < sabahEnd) {
        try {
          final sabahStr = await rootBundle.loadString('assets/azkar/azkar-sabah.json');
          final sabahList = List<String>.from(jsonDecode(sabahStr));
          final cleaned = sabahList
              .map((t) => t.replaceAll(RegExp(r'<[^>]*>|-------------------------------------'), '').trim())
              .where((t) => t.isNotEmpty)
              .toList();
          if (cleaned.isNotEmpty) {
            state = ['☀️ أذكار الصباح ☀️', ...cleaned];
            return;
          }
        } catch (_) {}
      }

      // Evening azkar window
      if (settings.enableMasaaAzkar && currentHour >= masaaStart && currentHour < masaaEnd) {
        try {
          final masaaStr = await rootBundle.loadString('assets/azkar/azkar-masaa.json');
          final masaaList = List<String>.from(jsonDecode(masaaStr));
          final cleaned = masaaList
              .map((t) => t.replaceAll(RegExp(r'<[^>]*>|-------------------------------------'), '').trim())
              .where((t) => t.isNotEmpty)
              .toList();
          if (cleaned.isNotEmpty) {
            state = ['🌙 أذكار المساء 🌙', ...cleaned];
            return;
          }
        } catch (_) {}
      }

      // === Normal content loading ===
      // قراءة الملفات من الأصول
      final azkarStr = await rootBundle.loadString('assets/azkar/azkar.json');
      // محاولة قراءة الآيات حسب اللغة، وإلا للغة العربية كبديل
      String ayatsStr;
      try {
        ayatsStr = await rootBundle.loadString('assets/ayats/ayats-$ayatsLang.json');
      } catch (_) {
        ayatsStr = await rootBundle.loadString('assets/ayats/ayats-ar.json');
      }
      
      // معالجة JSON في Isolate لعدم التأثير على نعومة الواجهة (UI FPS)
      final List<String> combinedList = await compute(_parseAndCombine, [azkarStr, ayatsStr]);
      
      // إضافة رسائل المستخدم المجدولة
      final isFriday = now.weekday == DateTime.friday;
      final todayDateStr = DateFormat('MM/dd').format(now);
      
      final customMessages = <String>[];
      for (final item in settings.tickerItems) {
        if (!item.enabled) continue;
        
        // Expiration check
        if (item.createdAt != null) {
          final expiry = item.createdAt!.add(Duration(seconds: item.displayDurationSeconds));
          if (now.isAfter(expiry)) continue;
        }
        
        if (item.scheduleType == TickerScheduleType.jomoa && !isFriday) continue;
        if (item.scheduleType == TickerScheduleType.date && item.date != todayDateStr) continue;
        
        customMessages.add(item.text);
      }
      
      // إضافة العد التنازلي لرمضان إذا كان مفعلا وقريباً
      if (settings.ramadanCountdownInjectEnabled) {
        final hijriNow = HijriCalendar.now();
        // Ramadan is month 9
        int targetYear = hijriNow.hYear;
        if (hijriNow.hMonth > 9) targetYear++;
        
        final ramadanStart = HijriCalendar()
          ..hYear = targetYear
          ..hMonth = 9
          ..hDay = 1;
          
        // Rough estimate of days (since Hijri length varies, we do a simple fast math or date difference)
        final daysDiff = ramadanStart.hijriToGregorian(ramadanStart.hYear, ramadanStart.hMonth, ramadanStart.hDay)
                         .difference(DateTime.now()).inDays;
                         
        if (daysDiff > 0 && daysDiff <= 60) {
           customMessages.insert(0, '🌙 المتبقي على شهر رمضان المبارك: $daysDiff يوم 🌙');
        } else if (daysDiff == 0 && hijriNow.hMonth == 9) {
           customMessages.insert(0, '✨ شهر رمضان المبارك - تقبل الله طاعتكم ✨');
        }
      }
      
      if (customMessages.isNotEmpty) {
        state = customMessages;
      } else {
        state = combinedList;
      }
      
    } catch (e) {
      // Error loading content
    }
  }
}

// دالة خارجية تعمل داخل Background Isolate
List<String> _parseAndCombine(List<String> jsonStrings) {
  final azkarList = List<String>.from(jsonDecode(jsonStrings[0]));
  final ayatsList = List<String>.from(jsonDecode(jsonStrings[1]));
  
  // دمج وتنظيف النصوص من العلامات غير المرغوبة (مثل <span>) أو ترتيبها
  final combined = <String>[];
  
  String cleanText(String text) {
    return text.replaceAll(RegExp(r'<[^>]*>|10DAYS|TAKBIR|10NIGHTS|3WHITEDAYS|-------------------------------------'), '').trim();
  }
  
  for (final a in ayatsList) {
    final cleaned = cleanText(a);
    if (cleaned.isNotEmpty) combined.add(cleaned);
  }
  
  for (final z in azkarList) {
    final cleaned = cleanText(z);
    if (cleaned.isNotEmpty) combined.add(cleaned);
  }
  
  // خلط القائمة لعرض عشوائي وممتع للمشاهد
  combined.shuffle();
  return combined;
}
