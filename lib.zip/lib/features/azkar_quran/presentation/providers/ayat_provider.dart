import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../settings/presentation/providers/settings_provider.dart';

final ayatProvider = FutureProvider<List<String>>((ref) async {
  final settings = ref.watch(settingsNotifierProvider);
  final langCode = settings.ayatsLanguageCode.toLowerCase();
  
  String jsonStr;
  try {
    jsonStr = await rootBundle.loadString('assets/ayats/ayats-$langCode.json');
  } catch (_) {
    jsonStr = await rootBundle.loadString('assets/ayats/ayats-ar.json');
  }
  
  final List<dynamic> mapped = jsonDecode(jsonStr);
  return mapped.map((e) => e.toString()).toList();
});
