import 'package:cloud_firestore/cloud_firestore.dart';

class AnnouncementItem {
  final String id;
  final String title;
  final String body;
  final String status;
  final String target;
  final int priority;
  final String? imageUrl;
  final DateTime? startAt;
  final DateTime? endAt;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const AnnouncementItem({
    required this.id,
    required this.title,
    required this.body,
    required this.status,
    required this.target,
    required this.priority,
    this.imageUrl,
    this.startAt,
    this.endAt,
    this.createdAt,
    this.updatedAt,
  });

  bool isVisibleAt(DateTime now) {
    final startsOk = startAt == null || !startAt!.isAfter(now);
    final endsOk = endAt == null || !endAt!.isBefore(now);
    return status == 'active' && startsOk && endsOk;
  }

  static DateTime? _asDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) {
      return DateTime.tryParse(value);
    }
    return null;
  }

  factory AnnouncementItem.fromFirestore(
      DocumentSnapshot<Map<String, dynamic>> doc) {
    final map = doc.data() ?? <String, dynamic>{};

    return AnnouncementItem(
      id: doc.id,
      title: (map['title'] as String?)?.trim() ?? '',
      body: (map['body'] as String?)?.trim() ?? '',
      status: (map['status'] as String?)?.trim() ?? 'active',
      target: (map['target'] as String?)?.trim() ?? 'all_users',
      priority: (map['priority'] as num?)?.toInt() ?? 0,
      imageUrl: (map['imageUrl'] as String?)?.trim(),
      startAt: _asDateTime(map['startAt']),
      endAt: _asDateTime(map['endAt']),
      createdAt: _asDateTime(map['createdAt']),
      updatedAt: _asDateTime(map['updatedAt']),
    );
  }
}
