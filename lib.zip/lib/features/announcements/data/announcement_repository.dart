import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

import '../domain/entities/announcement_item.dart';

class AnnouncementRepository {
  final FirebaseFirestore _firestore;

  AnnouncementRepository({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  Stream<List<AnnouncementItem>> watchActiveAnnouncements() {
    if (Firebase.apps.isEmpty) {
      return Stream<List<AnnouncementItem>>.value(const []);
    }

    return _firestore
        .collection('announcements')
        .where('status', isEqualTo: 'active')
        .snapshots()
        .map((snapshot) {
      final now = DateTime.now().toUtc();

      final items = snapshot.docs
          .map(AnnouncementItem.fromFirestore)
          .where((item) => item.isVisibleAt(now))
          .toList();

      items.sort((a, b) {
        final priorityCompare = b.priority.compareTo(a.priority);
        if (priorityCompare != 0) return priorityCompare;

        final aTime = a.updatedAt ??
            a.createdAt ??
            DateTime.fromMillisecondsSinceEpoch(0);
        final bTime = b.updatedAt ??
            b.createdAt ??
            DateTime.fromMillisecondsSinceEpoch(0);
        return bTime.compareTo(aTime);
      });

      return items;
    });
  }
}
