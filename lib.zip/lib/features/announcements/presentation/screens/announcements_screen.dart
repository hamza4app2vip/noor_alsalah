import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';
import '../providers/announcement_provider.dart';

class AnnouncementsScreen extends ConsumerWidget {
  const AnnouncementsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncAnnouncements = ref.watch(activeAnnouncementsProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(
          title: l10n.tr(ar: 'الإعلانات والتنبيهات', en: 'Announcements & Alerts'),
          showBackButton: true,
        ),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: asyncAnnouncements.when(
            data: (items) {
              if (items.isEmpty) {
                return Center(
                  child: Text(
                    l10n.tr(ar: 'لا توجد إعلانات فعّالة حاليًا', en: 'No active announcements right now'),
                    style: TextStyle(fontFamily: 'Cairo', fontSize: 16),
                  ),
                );
              }

              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final item = items[index];
                  final updatedAt = item.updatedAt ?? item.createdAt;
                  final updatedText = updatedAt == null
                      ? '--'
                      : '${updatedAt.year}-${updatedAt.month.toString().padLeft(2, '0')}-${updatedAt.day.toString().padLeft(2, '0')} ${updatedAt.hour.toString().padLeft(2, '0')}:${updatedAt.minute.toString().padLeft(2, '0')}';

                  return TvFocusable(
                    onPressed: () {}, // Allows it to be focused but doesn't do anything on enter
                    borderRadius: BorderRadius.circular(18),
                    focusColor: Colors.teal,
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: isDark
                            ? Colors.white.withValues(alpha: 0.06)
                            : Colors.white.withValues(alpha: 0.92),
                        border: Border.all(
                          color: isDark
                              ? Colors.white.withValues(alpha: 0.12)
                              : Colors.black.withValues(alpha: 0.06),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                item.title,
                                style: const TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.teal.withValues(alpha: 0.13),
                              ),
                              child: Text(
                                l10n.tr(ar: 'أولوية ${item.priority}', en: 'Priority ${item.priority}'),
                                style: const TextStyle(
                                  fontFamily: 'Cairo',
                                  fontWeight: FontWeight.w700,
                                  color: Colors.teal,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          item.body,
                          style: const TextStyle(
                              fontFamily: 'Cairo', height: 1.55),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          l10n.tr(ar: 'آخر تحديث: $updatedText', en: 'Last update: $updatedText'),
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: isDark ? Colors.white70 : Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  '${l10n.tr(ar: 'تعذر تحميل الإعلانات', en: 'Failed to load announcements')}: $error',
                  style: const TextStyle(fontFamily: 'Cairo'),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}



