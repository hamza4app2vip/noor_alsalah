import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/announcement_repository.dart';
import '../../domain/entities/announcement_item.dart';

final announcementRepositoryProvider = Provider<AnnouncementRepository>((ref) {
  return AnnouncementRepository();
});

final activeAnnouncementsProvider =
    StreamProvider<List<AnnouncementItem>>((ref) {
  final repository = ref.watch(announcementRepositoryProvider);
  return repository.watchActiveAnnouncements();
});

final activeAnnouncementTickerTextsProvider = Provider<List<String>>((ref) {
  final asyncAnnouncements = ref.watch(activeAnnouncementsProvider);
  return asyncAnnouncements.maybeWhen(
    data: (items) => items
        .map((item) => '${item.title} - ${item.body}')
        .where((line) => line.trim().isNotEmpty)
        .toList(),
    orElse: () => const [],
  );
});
