import 'dart:io';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../domain/entities/contact_message.dart';

class ContactUsState {
  static const int kDailyMessageLimit = 20;

  final bool isLoading;
  final String? error;
  final bool isSuccess;
  final int remainingMessagesToday;
  final double uploadProgress;

  ContactUsState({
    this.isLoading = false,
    this.error,
    this.isSuccess = false,
    this.remainingMessagesToday = kDailyMessageLimit,
    this.uploadProgress = 0,
  });

  ContactUsState copyWith({
    bool? isLoading,
    String? error,
    bool? isSuccess,
    int? remainingMessagesToday,
    double? uploadProgress,
  }) {
    return ContactUsState(
      isLoading: isLoading ?? this.isLoading,
      error: error,
      isSuccess: isSuccess ?? this.isSuccess,
      remainingMessagesToday:
          remainingMessagesToday ?? this.remainingMessagesToday,
      uploadProgress: uploadProgress ?? this.uploadProgress,
    );
  }
}

class ContactUsNotifier extends StateNotifier<ContactUsState> {
  static const String _kLastResetKey = 'contact_last_reset';
  static const String _kRemainingKey = 'contact_remaining_messages';

  ContactUsNotifier() : super(ContactUsState()) {
    _loadRateLimit();
  }

  Future<void> _loadRateLimit() async {
    final prefs = await SharedPreferences.getInstance();
    final lastResetStr = prefs.getString(_kLastResetKey);
    final now = DateTime.now();
    final todayStr = '${now.year}-${now.month}-${now.day}';

    if (lastResetStr != todayStr) {
      await prefs.setString(_kLastResetKey, todayStr);
      await prefs.setInt(_kRemainingKey, ContactUsState.kDailyMessageLimit);
      state = state.copyWith(
          remainingMessagesToday: ContactUsState.kDailyMessageLimit);
      return;
    }

    final remaining =
        prefs.getInt(_kRemainingKey) ?? ContactUsState.kDailyMessageLimit;
    state = state.copyWith(remainingMessagesToday: remaining);
  }

  Future<void> sendMessage({
    required String name,
    String? contact,
    String? subject,
    required String message,
    File? attachment,
  }) async {
    if (state.remainingMessagesToday <= 0) {
      state = state.copyWith(
        error:
            'لقد تجاوزت الحد الأقصى للرسائل اليومية (${ContactUsState.kDailyMessageLimit} رسائل). يرجى المحاولة غداً.',
      );
      return;
    }

    if (message.length > 1000) {
      state = state.copyWith(error: 'لا يمكن أن تتجاوز الرسالة 1000 حرف.');
      return;
    }

    if (Firebase.apps.isEmpty) {
      state = state.copyWith(
        error: 'خدمة المراسلة غير متاحة حالياً على هذا الجهاز.',
      );
      return;
    }

    state = state.copyWith(
      isLoading: true,
      error: null,
      isSuccess: false,
      uploadProgress: 0,
    );

    final payload = ContactMessage(
      name: name,
      contact: contact,
      subject: subject,
      message: message,
      attachment: attachment,
    );

    try {
      final callable =
          FirebaseFunctions.instance.httpsCallable('submitContactMessage');

      await callable.call(<String, dynamic>{
        'name': payload.name,
        'contact': payload.contact,
        'subject': payload.subject,
        'message': payload.message,
        'hasAttachment': payload.hasAttachment,
      });

      final prefs = await SharedPreferences.getInstance();
      final newRemaining = state.remainingMessagesToday - 1;
      await prefs.setInt(_kRemainingKey, newRemaining);

      state = state.copyWith(
        isLoading: false,
        isSuccess: true,
        remainingMessagesToday: newRemaining,
        uploadProgress: 1,
      );
    } on FirebaseFunctionsException catch (e) {
      state = state.copyWith(
        isLoading: false,
        uploadProgress: 0,
        error: e.message ?? 'تعذر إرسال الرسالة حالياً. حاول لاحقاً.',
      );
    } catch (_) {
      state = state.copyWith(
        isLoading: false,
        uploadProgress: 0,
        error: 'حدث خطأ غير متوقع أثناء إرسال الرسالة.',
      );
    }
  }

  void reset() {
    state = state.copyWith(error: null, isSuccess: false, uploadProgress: 0);
  }
}

final contactUsProvider =
    StateNotifierProvider<ContactUsNotifier, ContactUsState>((ref) {
  return ContactUsNotifier();
});
