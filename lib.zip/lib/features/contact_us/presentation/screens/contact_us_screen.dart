import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';
import '../providers/contact_us_provider.dart';

class ContactUsScreen extends ConsumerStatefulWidget {
  const ContactUsScreen({super.key});

  @override
  ConsumerState<ContactUsScreen> createState() => _ContactUsScreenState();
}

class _ContactUsScreenState extends ConsumerState<ContactUsScreen>
    with TickerProviderStateMixin {
  AppLocalizations get l10n => AppLocalizations.of(context);
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _contactController = TextEditingController();
  final _subjectController = TextEditingController();
  final _messageController = TextEditingController();

  File? _selectedImage;
  final _picker = ImagePicker();

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _fadeController.forward();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _contactController.dispose();
    _subjectController.dispose();
    _messageController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
      );
      if (image != null) {
        setState(() {
          _selectedImage = File(image.path);
        });
      }
    } catch (e) {
      if (mounted) {
        GlassToast.show(context, l10n.tr(ar: 'خطأ في اختيار الصورة', en: 'Error selecting image'), isError: true);
      }
    }
  }

  void _submit() async {
    final initialState = ref.read(contactUsProvider);
    if (initialState.remainingMessagesToday <= 0) {
      showDialog(
        context: context,
        builder: (context) => _buildLimitReachedDialog(),
      );
      return;
    }

    if (!_formKey.currentState!.validate()) return;

    final messageText = _messageController.text.trim();
    if (messageText.isEmpty && _selectedImage == null) {
      GlassToast.show(context, l10n.tr(ar: 'يرجى كتابة رسالة أو إرفاق صورة', en: 'Please type a message or attach an image'), isError: true);
      return;
    }

    await ref.read(contactUsProvider.notifier).sendMessage(
          name: _nameController.text.trim(),
          contact: _contactController.text.trim(),
          subject: _subjectController.text.trim(),
          message: messageText,
          attachment: _selectedImage,
        );

    final state = ref.read(contactUsProvider);
    if (state.isSuccess) {
      if (mounted) {
        _nameController.clear();
        _contactController.clear();
        _subjectController.clear();
        _messageController.clear();
        setState(() => _selectedImage = null);

        showDialog(
          context: context,
          builder: (context) => _buildSuccessDialog(),
        );
      }
    } else if (state.error != null) {
      if (mounted) GlassToast.show(context, state.error!, isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(contactUsProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? AppColors.goldAccent : const Color(0xFF0D6E47);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(
          title: l10n.tr(ar: 'تواصل معنا', en: 'Contact Us'),
          showBackButton: true,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new_rounded,
                color: isDark ? Colors.white70 : Colors.black54, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 130, // Space for the floating navbar
                bottom: 40,
              ),
              child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _buildHeaderInfo(
                          accent, isDark, state.remainingMessagesToday),
                      const SizedBox(height: 24),
                      _buildModernInputGroup(accent, isDark),
                      const SizedBox(height: 24),
                      _buildImagePickerSection(accent, isDark, state),
                      const SizedBox(height: 32),
                      _buildRoyalSubmitButton(state, accent, isDark),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
  }

  Widget _buildHeaderInfo(Color accent, bool isDark, int remaining) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: accent.withValues(alpha: 0.1),
            border:
                Border.all(color: accent.withValues(alpha: 0.2), width: 1.5),
          ),
          child:
              Icon(Icons.chat_bubble_outline_rounded, color: accent, size: 40),
        ),
        const SizedBox(height: 16),
        Text(
          l10n.tr(ar: 'نحن هنا لمساعدتك', en: 'We are here to help you'),
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.w900,
            color: isDark ? Colors.white : Colors.black87,
            fontFamily: 'Cairo',
            letterSpacing: -0.5,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: (remaining > 0 ? Colors.green : Colors.red)
                .withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                remaining > 0 ? Icons.bolt_rounded : Icons.lock_clock_rounded,
                size: 14,
                color: remaining > 0 ? Colors.green : Colors.red,
              ),
              const SizedBox(width: 4),
              Text(
                l10n.tr(ar: 'متبقي لك $remaining رسائل لهذا اليوم', en: '$remaining messages remaining for today'),
                style: TextStyle(
                  color: remaining > 0 ? Colors.green : Colors.red,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildModernInputGroup(Color accent, bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: isDark
            ? Colors.black.withValues(alpha: 0.2)
            : Colors.white.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
            color:
                isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                _buildFocusedTextField(
                  controller: _nameController,
                  label: l10n.tr(ar: 'الاسم', en: 'Name'),
                  hint: l10n.tr(ar: 'كيف ناديك؟', en: 'How should we address you?'),
                  icon: Icons.person_rounded,
                  isDark: isDark,
                  accent: accent,
                  validator: (v) =>
                      v?.isEmpty ?? true ? l10n.tr(ar: 'فضلاً، نحتاج لمعرفة اسمك', en: 'Please tell us your name') : null,
                ),
                _buildDivider(isDark),
                _buildFocusedTextField(
                  controller: _contactController,
                  label: l10n.tr(ar: 'التواصل', en: 'Contact'),
                  hint: l10n.tr(ar: 'رقم هاتفك أو بريدك', en: 'Your phone number or email'),
                  icon: Icons.alternate_email_rounded,
                  isDark: isDark,
                  accent: accent,
                ),
                _buildDivider(isDark),
                _buildFocusedTextField(
                  controller: _subjectController,
                  label: l10n.tr(ar: 'الموضوع', en: 'Subject'),
                  hint: l10n.tr(ar: 'عن ماذا تود الحديث؟', en: 'What would you like to talk about?'),
                  icon: Icons.auto_stories_rounded,
                  isDark: isDark,
                  accent: accent,
                ),
                _buildDivider(isDark),
                _buildMessageField(isDark, accent),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFocusedTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    required bool isDark,
    required Color accent,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        validator: validator,
        style: TextStyle(
            color: isDark ? Colors.white : Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 15),
        decoration: InputDecoration(
          prefixIcon:
              Icon(icon, color: accent.withValues(alpha: 0.6), size: 20),
          labelText: label,
          labelStyle: TextStyle(
              color: accent.withValues(alpha: 0.8),
              fontSize: 13,
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold),
          hintText: hint,
          hintStyle: TextStyle(
              color: (isDark ? Colors.white30 : Colors.black26),
              fontSize: 13,
              fontFamily: 'Cairo'),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(
                color: accent, width: 2.0, strokeAlign: BorderSide.strokeAlignOutside),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide.none,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildMessageField(bool isDark, Color accent) {
    return ListenableBuilder(
      listenable: _messageController,
      builder: (context, _) {
        final count = _messageController.text.length;
        return Column(
          children: [
            TextFormField(
              controller: _messageController,
              maxLines: 6,
              style: TextStyle(
                  color: isDark ? Colors.white : Colors.black87,
                  fontFamily: 'Cairo',
                  fontSize: 15),
              decoration: InputDecoration(
                labelText: l10n.tr(ar: 'تفاصيل الرسالة', en: 'Message details'),
                labelStyle: TextStyle(
                    color: accent.withValues(alpha: 0.8),
                    fontSize: 13,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold),
                hintText: l10n.tr(ar: 'اكتب لنا كل ما في خاطرك...', en: 'Write everything you want to tell us...'),
                hintStyle: TextStyle(
                    color: (isDark ? Colors.white30 : Colors.black26),
                    fontSize: 13,
                    fontFamily: 'Cairo'),
                floatingLabelBehavior: FloatingLabelBehavior.always,
                alignLabelWithHint: true,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(
                      color: accent, width: 2.0, strokeAlign: BorderSide.strokeAlignOutside),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  '$count / 1000',
                  style: TextStyle(
                    color: count > 1000
                        ? Colors.red
                        : (isDark ? Colors.white24 : Colors.black26),
                    fontSize: 10,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  Widget _buildDivider(bool isDark) {
    return Divider(
        color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
        height: 1);
  }

  Widget _buildImagePickerSection(
      Color accent, bool isDark, ContactUsState state) {
    final isLoading = state.isLoading;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Text(
            l10n.tr(ar: 'هل لديك صور توضيحية؟', en: 'Do you have reference images?'),
            style: TextStyle(
              color: isDark ? Colors.white70 : Colors.black54,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Cairo',
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_selectedImage == null)
          TvFocusable(
            onPressed: isLoading ? null : _pickImage,
            borderRadius: BorderRadius.circular(25),
            focusColor: accent,
            child: Container(
              height: 110,
              width: double.infinity,
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.03)
                    : Colors.black.withValues(alpha: 0.02),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(
                    color: accent.withValues(alpha: 0.2),
                    style: BorderStyle.solid),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_a_photo_rounded,
                      color: accent.withValues(alpha: 0.4), size: 32),
                  const SizedBox(height: 8),
                  Text(
                    l10n.tr(ar: 'إضافة مرفق صوري', en: 'Add image attachment'),
                    style: TextStyle(
                        color: accent.withValues(alpha: 0.5),
                        fontSize: 13,
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          )
        else
          _buildSelectedImagePreview(
              accent, isDark, isLoading, state.uploadProgress),
      ],
    );
  }

  Widget _buildSelectedImagePreview(
      Color accent, bool isDark, bool isLoading, double progress) {
    return Container(
      height: 110,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        image: DecorationImage(
            image: FileImage(_selectedImage!), fit: BoxFit.cover),
        boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10)],
      ),
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.4),
                  Colors.transparent,
                  Colors.black.withValues(alpha: 0.4)
                ],
              ),
            ),
          ),
          if (isLoading)
            Center(
              child: _buildElegantProgressBar(accent, progress),
            ),
          Positioned(
            top: 8,
            left: 8,
            child: TvFocusable(
              onPressed: isLoading
                  ? null
                  : () => setState(() => _selectedImage = null),
              borderRadius: BorderRadius.circular(30),
              focusColor: accent,
              child: IconButton(
                onPressed: isLoading
                    ? null
                    : () => setState(() => _selectedImage = null),
                icon: const Icon(Icons.close_rounded, color: Colors.white),
                style: IconButton.styleFrom(backgroundColor: Colors.black38),
                focusNode: FocusNode(skipTraversal: true),
              ),
            ),
          ),
          Positioned(
            bottom: 12,
            right: 16,
            child: Text(
              l10n.tr(ar: 'تم الاختيار بنجاح', en: 'Selected successfully'),
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildElegantProgressBar(Color accent, double progress) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 200,
          height: 8,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                  color: accent.withValues(alpha: 0.2),
                  blurRadius: 10,
                  spreadRadius: 1),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: progress > 0 ? progress : null,
              backgroundColor: Colors.white10,
              color: accent,
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          progress > 0
              ? l10n.tr(ar: 'تم رفع ${(progress * 100).toInt()}%', en: 'Uploaded ${(progress * 100).toInt()}%')
              : l10n.tr(ar: 'جارِ معالجة ورفع المرفقات...', en: 'Processing and uploading attachments...'),
          style: TextStyle(
              color: accent,
              fontSize: 11,
              fontFamily: 'Cairo',
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5),
        ),
      ],
    );
  }

  Widget _buildRoyalSubmitButton(
      ContactUsState state, Color accent, bool isDark) {
    return TvFocusable(
      onPressed: state.isLoading ? null : _submit,
      borderRadius: BorderRadius.circular(22),
      focusColor: accent,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: double.infinity,
      height: 64,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(
          colors: state.isLoading
              ? [accent.withValues(alpha: 0.5), accent.withValues(alpha: 0.3)]
              : [accent, accent.withValues(alpha: 0.8)],
        ),
        boxShadow: [
          BoxShadow(
            color: accent.withValues(alpha: isDark ? 0.4 : 0.3),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: state.isLoading ? null : _submit,
        focusNode: FocusNode(skipTraversal: true),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
        child: state.isLoading
            ? const SizedBox(
                height: 24,
                width: 24,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.5),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.rocket_launch_rounded,
                      color: Colors.white, size: 24),
                  SizedBox(width: 14),
                  Text(
                    l10n.tr(ar: 'إرسال', en: 'Send'),
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        fontFamily: 'Cairo'),
                  ),
                ],
              ),
        ),
      ),
    );
  }

  Widget _buildSuccessDialog() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? AppColors.goldAccent : const Color(0xFF0D6E47);

    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
      child: Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: isDark
                ? Colors.black.withValues(alpha: 0.4)
                : Colors.white.withValues(alpha: 0.6),
            borderRadius: BorderRadius.circular(40),
            border: Border.all(
                color: Colors.white.withValues(alpha: 0.1), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 30,
                  spreadRadius: 5),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.0, end: 1.0),
                duration: const Duration(milliseconds: 1200),
                curve: Curves.elasticOut,
                builder: (context, value, child) => Transform.scale(
                  scale: value,
                  child: Icon(
                    Icons.check_rounded,
                    color: isDark ? Colors.greenAccent : Colors.green,
                    size: 100,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                l10n.tr(ar: 'شكرًا لكونك جزءًا منا', en: 'Thank you for being with us'),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black87,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 12),
              Text(
                l10n.tr(ar: 'رسالتك في أيدٍ أمينة، وسنقوم بمراجعتها بعناية.', en: 'Your message is in safe hands, and we will review it carefully.'),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isDark ? Colors.white70 : Colors.black54,
                  fontSize: 14,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 35),
              TvFocusable(
                onPressed: () => Navigator.pop(context),
                borderRadius: BorderRadius.circular(20),
                focusColor: accent,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [accent, accent.withValues(alpha: 0.8)]),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: accent.withValues(alpha: 0.3),
                          blurRadius: 10,
                          offset: const Offset(0, 4)),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      l10n.tr(ar: 'تم', en: 'Done'),
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo',
                          fontSize: 16),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLimitReachedDialog() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
      child: Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: isDark
                ? Colors.black.withValues(alpha: 0.4)
                : Colors.white.withValues(alpha: 0.6),
            borderRadius: BorderRadius.circular(40),
            border: Border.all(
                color: Colors.red.withValues(alpha: 0.2), width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_clock_rounded,
                  color: Colors.redAccent, size: 80),
              const SizedBox(height: 24),
              Text(
                l10n.tr(ar: 'انتهت المحاولات اليومية', en: 'Daily attempts exhausted'),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 12),
              Text(
                l10n.tr(ar: 'لقد استهلكت جميع رسائلك المتاحة لهذا اليوم (${ContactUsState.kDailyMessageLimit} رسائل). يرجى المحاولة مرة أخرى غداً. نسعد دائماً بتواصلك.', en: 'You have used all available messages for today (${ContactUsState.kDailyMessageLimit} messages). Please try again tomorrow. We are always happy to hear from you.'),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isDark ? Colors.white70 : Colors.black54,
                  fontSize: 14,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                child: TvFocusable(
                  onPressed: () => Navigator.pop(context),
                  borderRadius: BorderRadius.circular(20),
                  focusColor: Colors.redAccent,
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    focusNode: FocusNode(skipTraversal: true),
                    style: TextButton.styleFrom(
                    backgroundColor: Colors.redAccent.withValues(alpha: 0.1),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                  ),
                  child: Text(l10n.tr(ar: 'حسناً، سأنتظر لغد', en: 'Okay, I will wait until tomorrow'),
                      style: TextStyle(
                          color: Colors.redAccent,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo')),
                ),
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}
