import 'dart:io';
import 'package:dio/dio.dart';
import 'secure_token_store.dart';

enum TelegramApiResult { 
  success, 
  networkError, 
  invalidToken, 
  invalidChatId, 
  blockedByUser,
  timeout, 
  apiError 
}

class TelegramApiClient {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 15),
    sendTimeout: const Duration(seconds: 15),
  ));

  Future<TelegramApiResult> sendMessage(String text) async {
    final creds = await SecureTokenStore.getCredentials();
    final String? token = creds['botToken']?.trim();
    final String? chatId = creds['chatId']?.trim();

    if (token == null || token.isEmpty || chatId == null || chatId.isEmpty) {
      return TelegramApiResult.invalidToken;
    }

    try {
      final url = 'https://api.telegram.org/bot$token/sendMessage';
      final response = await _dio.post(url, data: {
        'chat_id': chatId,
        'text': text,
        'parse_mode': 'HTML',
      });

      if (response.statusCode == 200) {
        return TelegramApiResult.success;
      }
      return TelegramApiResult.apiError;
    } on DioException catch (e) {
      return _handleDioException(e);
    } catch (e) {
      return TelegramApiResult.apiError;
    }
  }

  Future<TelegramApiResult> sendPhoto(File photo, {String? caption, void Function(int, int)? onSendProgress}) async {
    final creds = await SecureTokenStore.getCredentials();
    final String? token = creds['botToken']?.trim();
    final String? chatId = creds['chatId']?.trim();

    if (token == null || token.isEmpty || chatId == null || chatId.isEmpty) {
      return TelegramApiResult.invalidToken;
    }

    try {
      final url = 'https://api.telegram.org/bot$token/sendPhoto';
      
      final formData = FormData.fromMap({
        'chat_id': chatId,
        'photo': await MultipartFile.fromFile(photo.path),
        if (caption != null) 'caption': caption,
        'parse_mode': 'HTML',
      });

      final response = await _dio.post(
        url, 
        data: formData,
        onSendProgress: onSendProgress,
      );

      if (response.statusCode == 200) {
        return TelegramApiResult.success;
      }
      return TelegramApiResult.apiError;
    } on DioException catch (e) {
      return _handleDioException(e);
    } catch (e) {
      return TelegramApiResult.apiError;
    }
  }

  TelegramApiResult _handleDioException(DioException e) {
    if (e.type == DioExceptionType.connectionTimeout || 
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout) {
      return TelegramApiResult.timeout;
    }
    
    if (e.type == DioExceptionType.badResponse) {
      final statusCode = e.response?.statusCode;
      final data = e.response?.data;
      final String description = data is Map ? (data['description'] ?? '').toString().toLowerCase() : '';

      if (statusCode == 401) return TelegramApiResult.invalidToken;
      if (statusCode == 403) return TelegramApiResult.blockedByUser;
      
      if (statusCode == 400) {
        if (description.contains('chat not found') || description.contains('invalid chat id')) {
          return TelegramApiResult.invalidChatId;
        }
      }
      return TelegramApiResult.apiError;
    }
    
    return TelegramApiResult.networkError;
  }
}

