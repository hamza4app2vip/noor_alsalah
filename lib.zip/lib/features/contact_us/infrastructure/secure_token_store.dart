import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'package:crypto/crypto.dart';
import 'dart:typed_data';

/// [SecureTokenStore] manages sensitive Telegram credentials using double-layered protection:
/// 1. Android Keystore / iOS Keychain (via flutter_secure_storage).
/// 2. AES-256 local encryption with a derived key from a hard-coded obscured salt.
class SecureTokenStore {
  static final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _kBotTokenKey = 'tg_bot_token_enc';
  static const _kChatIdKey = 'tg_chat_id_enc';
  static const _kMasterKeySalt = 'noor_prayer_tv_premium_salt_2026';

  /// Obscured internal key derivation to make static analysis harder
  static encrypt.Key _deriveKey() {
    final bytes = utf8.encode(_kMasterKeySalt);
    final digest = sha256.convert(bytes);
    return encrypt.Key(Uint8List.fromList(digest.bytes));
  }

  static Future<void> saveCredentials(String botToken, String chatId) async {
    final key = _deriveKey();
    final iv = encrypt.IV.fromLength(16);
    final encrypter = encrypt.Encrypter(encrypt.AES(key));

    final encryptedToken = encrypter.encrypt(botToken, iv: iv);
    final encryptedChatId = encrypter.encrypt(chatId, iv: iv);

    // Store both the IV and the encrypted data
    await _storage.write(
      key: _kBotTokenKey,
      value: jsonEncode({'iv': iv.base64, 'data': encryptedToken.base64}),
    );
    await _storage.write(
      key: _kChatIdKey,
      value: jsonEncode({'iv': iv.base64, 'data': encryptedChatId.base64}),
    );
  }

  static Future<Map<String, String?>> getCredentials() async {
    final tokenRaw = await _storage.read(key: _kBotTokenKey);
    final chatIdRaw = await _storage.read(key: _kChatIdKey);

    if (tokenRaw == null || chatIdRaw == null) {
      return {'botToken': null, 'chatId': null};
    }

    try {
      final key = _deriveKey();
      final encrypter = encrypt.Encrypter(encrypt.AES(key));

      final tokenData = jsonDecode(tokenRaw);
      final chatIdData = jsonDecode(chatIdRaw);

      final tokenIv = encrypt.IV.fromBase64(tokenData['iv']);
      final chatIdIv = encrypt.IV.fromBase64(chatIdData['iv']);

      final token = encrypter.decrypt64(tokenData['data'], iv: tokenIv);
      final chatId = encrypter.decrypt64(chatIdData['data'], iv: chatIdIv);

      return {'botToken': token, 'chatId': chatId};
    } catch (e) {
      // In case of corruption or key issues
      return {'botToken': null, 'chatId': null};
    }
  }

  static Future<void> clear() async {
    await _storage.delete(key: _kBotTokenKey);
    await _storage.delete(key: _kChatIdKey);
  }
}
