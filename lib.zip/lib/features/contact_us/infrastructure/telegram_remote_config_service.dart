import 'dart:convert';
import 'package:http/http.dart' as http;
import 'secure_token_store.dart';

class TelegramRemoteConfigService {
  static const String _kConfigUrl =
      'https://raw.githubusercontent.com/hamza4app2vip/noor_alsalah/refs/heads/main/token.json';

  /// Fetches the latest credentials from GitHub and syncs them to secure storage.
  /// Returns true if the sync was successful.
  static Future<bool> syncFromRemote() async {
    try {
      final response = await http.get(Uri.parse(_kConfigUrl)).timeout(
            const Duration(seconds: 15),
          );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final String? botToken = data['bot_token']?.toString().trim();
        final String? chatId = data['chat_id']?.toString().trim();

        if (botToken != null && chatId != null && !botToken.contains('token') && !chatId.contains('Chat_ID')) {
          await SecureTokenStore.saveCredentials(botToken, chatId);
          return true;
        }
      }
      return false;
    } catch (e) {
      // Background sync failures should be silent
      return false;
    }
  }

  /// Checks if credentials exist, if not, tries to fetch them.
  static Future<void> ensureInitialized() async {
    final creds = await SecureTokenStore.getCredentials();
    // If we have no credentials, try to sync
    if (creds['botToken'] == null || creds['chatId'] == null) {
      await syncFromRemote();
    }
  }
}
