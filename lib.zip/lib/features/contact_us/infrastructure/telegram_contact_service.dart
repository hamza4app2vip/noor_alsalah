import 'dart:io';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import '../domain/entities/contact_message.dart';
import 'telegram_api_client.dart';

class TelegramContactService {
  final TelegramApiClient _apiClient = TelegramApiClient();

  Future<TelegramApiResult> sendContactMessage(ContactMessage message, {void Function(int, int)? onSendProgress}) async {
    try {
      final appInfo = await PackageInfo.fromPlatform();
      final deviceInfo = DeviceInfoPlugin();
      String deviceModel = 'Unknown';
      String osVersion = 'Unknown';

      if (Platform.isAndroid) {
        final androidInfo = await deviceInfo.androidInfo;
        deviceModel = '${androidInfo.manufacturer} ${androidInfo.model}';
        osVersion = 'Android ${androidInfo.version.release}';
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfo.iosInfo;
        deviceModel = iosInfo.utsname.machine;
        osVersion = 'iOS ${iosInfo.systemVersion}';
      }

      final formattedBody = _formatTelegramMessage(
        message: message,
        appVersion: '${appInfo.version}+${appInfo.buildNumber}',
        deviceModel: deviceModel,
        osVersion: osVersion,
      );

      if (message.hasAttachment) {
        // Telegram caption limit is ~1024 characters.
        // If message is too long, we send photo first then message.
        if (formattedBody.length > 1000) {
          final photoResult = await _apiClient.sendPhoto(
            message.attachment!,
            caption: ' مرفق من: ${message.name}',
            onSendProgress: onSendProgress,
          );
          if (photoResult != TelegramApiResult.success) return photoResult;
          
          return await _apiClient.sendMessage(formattedBody);
        } else {
          return await _apiClient.sendPhoto(
            message.attachment!,
            caption: formattedBody,
            onSendProgress: onSendProgress,
          );
        }
      } else {
        return await _apiClient.sendMessage(formattedBody);
      }
    } catch (e) {
      return TelegramApiResult.apiError;
    }
  }

  String _formatTelegramMessage({
    required ContactMessage message,
    required String appVersion,
    required String deviceModel,
    required String osVersion,
  }) {
    final buffer = StringBuffer();
    buffer.writeln('<b>━━━━━━━━━━━━</b>');
    buffer.writeln('<b> رسالة دعم جديدة</b>');
    buffer.writeln('<b>━━━━━━━━━━━━</b>');
    buffer.writeln('<b> الاسم:</b> ${message.name}');
    if (message.contact != null && message.contact!.isNotEmpty) {
      buffer.writeln('<b> التواصل:</b> ${message.contact}');
    }
    if (message.subject != null && message.subject!.isNotEmpty) {
      buffer.writeln('<b> الموضوع:</b> ${message.subject}');
    }
    buffer.writeln('\n<b> الرسالة:</b>');
    buffer.writeln(message.message);
    buffer.writeln('\n<b>━━━━━━━━━━━━</b>');
    buffer.writeln('<b> معلومات النظام</b>');
    buffer.writeln('<b> الإصدار:</b> $appVersion');
    buffer.writeln('<b> الجهاز:</b> $deviceModel');
    buffer.writeln('<b> النظام:</b> $osVersion');
    buffer.writeln('<b> الوقت:</b> ${DateTime.now().toString().split('.')[0]}');
    buffer.writeln('<b>━━━━━━━━━━━━</b>');
    
    return buffer.toString();
  }
}
