import 'dart:io';

class ContactMessage {
  final String name;
  final String? contact;
  final String? subject;
  final String message;
  final File? attachment;

  ContactMessage({
    required this.name,
    this.contact,
    this.subject,
    required this.message,
    this.attachment,
  });

  bool get hasAttachment => attachment != null;
  bool get hasMessage => message.trim().isNotEmpty;
}
