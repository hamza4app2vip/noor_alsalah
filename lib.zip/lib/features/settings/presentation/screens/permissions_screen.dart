import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionsScreen extends StatefulWidget {
  final Future<void> Function(bool granted) onResult;

  const PermissionsScreen({super.key, required this.onResult});

  @override
  State<PermissionsScreen> createState() => _PermissionsScreenState();
}

class _PermissionsScreenState extends State<PermissionsScreen> {
  bool _isRequesting = false;

  Future<void> _requestLocation() async {
    setState(() => _isRequesting = true);

    PermissionStatus status = await Permission.location.request();

    if (status.isGranted) {
      widget.onResult(true);
      if (mounted) Navigator.pop(context);
    } else if (status.isPermanentlyDenied) {
      // Re-prompt to Settings
      await openAppSettings();
      setState(() => _isRequesting = false);
    } else {
      widget.onResult(false);
      setState(() => _isRequesting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Get isDark from context
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // We don't have direct access to ref here because it's a StatefulWidget, 
    // but we can use the context or just pass the colors.
    // However, since it's a Dialog, it usually inherits from the parent.
    // For consistency, let's use the standard gold colors.
    final accent = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    final textColor = isDark ? Colors.white : Colors.black87;
    final subTextColor = isDark ? Colors.white70 : Colors.black54;
    final cardColor = isDark ? const Color(0xFF1E293B) : Colors.white;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      elevation: 0,
      child: Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.1),
                blurRadius: 20,
                offset: const Offset(0, 4))
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.location_on_rounded,
                size: 48,
                color: accent,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'صلاحية الموقع',
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: textColor,
                  fontFamily: 'Cairo'),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              'نحتاج للوصول إلى موقعك الجغرافي لتحديد المدينة وضبط مواقيت الصلاة تلقائيًا بدقة عالية.',
              style: TextStyle(
                  fontSize: 15,
                  color: subTextColor,
                  height: 1.6,
                  fontFamily: 'Cairo'),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            if (_isRequesting)
              Center(
                  child: CircularProgressIndicator(color: accent))
            else ...[
              ElevatedButton(
                onPressed: _requestLocation,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: accent,
                  foregroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
                  elevation: 0,
                  shadowColor: accent.withValues(alpha: 0.3),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('السماح بالموقع',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Cairo')),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () {
                  widget.onResult(false);
                  Navigator.pop(context);
                },
                child: Text('ليس الآن',
                    style: TextStyle(
                        color: subTextColor.withValues(alpha: 0.5),
                        fontSize: 14,
                        fontFamily: 'Cairo')),
              ),
            ]
          ],
        ),
      ),
    );
  }
}
