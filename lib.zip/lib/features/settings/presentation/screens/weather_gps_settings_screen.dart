﻿import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/widgets/settings_row.dart';
import '../../domain/entities/app_settings.dart';
import '../providers/settings_provider.dart';
import 'package:geolocator/geolocator.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class WeatherGpsSettingsScreen extends ConsumerStatefulWidget {
  const WeatherGpsSettingsScreen({super.key});

  @override
  ConsumerState<WeatherGpsSettingsScreen> createState() =>
      _WeatherGpsSettingsScreenState();
}

class _WeatherGpsSettingsScreenState
    extends ConsumerState<WeatherGpsSettingsScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  bool _isLoadingGps = false;

  Color get _accent => Theme.of(context).brightness == Brightness.dark
      ? AppColors.goldAccent
      : const Color(0xFF1AA85A);

  Color _getTextColor(bool isDark) => isDark ? Colors.white : Colors.black87;
  Color _getSubTextColor(bool isDark) =>
      isDark ? Colors.white70 : Colors.black54;
  Color _getCardColor(bool isDark) =>
      isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white;
  Color _getBg(bool isDark) =>
      isDark ? Colors.white.withValues(alpha: 0.03) : const Color(0xFFF2F5F9);

  void _updateSettings(AppSettings settings) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(settings);
    GlassToast.show(context, l10n.tr(ar: ' تم الحفظ بنجاح', en: 'Saved successfully'));
  }

  Widget _buildSectionLabel(String title, IconData icon, bool isDark) {
    final accentColor = _accent;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, right: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(icon, color: accentColor, size: 16),
          const SizedBox(width: 8),
          Text(title,
              style: TextStyle(
                  color: accentColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: 'Cairo')),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children, bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 12,
                    offset: const Offset(0, 2))
              ]
            : null,
      ),
      child: Column(children: children),
    );
  }

  Widget _divider(bool isDark) {
    return Divider(
        height: 1,
        color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
        indent: 56,
        endIndent: 16);
  }

  Future<void> _getAutoLocation(AppSettings settings) async {
    setState(() => _isLoadingGps = true);
    final status = await Permission.locationWhenInUse.request();
    if (status.isGranted) {
      try {
        Position position = await Geolocator.getCurrentPosition(
            locationSettings:
                const LocationSettings(accuracy: LocationAccuracy.high));
        _updateSettings(settings.copyWith(
          locationMode: 'AUTO',
          gpsLat: position.latitude,
          gpsLng: position.longitude,
        ));
        if (mounted) {
          GlassToast.show(context, l10n.tr(ar: '✅ تم تحديد الموقع بنجاح', en: '✅ Location selected successfully'));
        }
      } catch (e) {
        if (mounted) {
          GlassToast.show(
              context, l10n.tr(ar: '⚠️ تعذر الحصول على الموقع، راجع إعدادات GPS', en: '⚠️ Unable to get location, check GPS settings'),
              isError: true);
        }
      }
    } else {
      if (mounted) {
        GlassToast.show(context, l10n.tr(ar: '⚠️ تم رفض الصلاحية!', en: '⚠️ Permission denied!'), isError: true);
        openAppSettings();
      }
    }
    if (mounted) setState(() => _isLoadingGps = false);
  }

  void _getManualLocation(AppSettings settings) {
    final latCtrl = TextEditingController(text: settings.gpsLat.toString());
    final lngCtrl = TextEditingController(text: settings.gpsLng.toString());

    showDialog(
      context: context,
      builder: (ctx) {
        final isDark = Theme.of(ctx).brightness == Brightness.dark;
        final accent = _accent;
        return Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 32, vertical: 48),
          child: Container(
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF1E293B) : Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                  color: isDark ? Colors.white10 : Colors.transparent),
            ),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.close, color: _getSubTextColor(isDark)),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                    Text(
                      l10n.tr(ar: 'إدخال الموقع يدوياً', en: 'Enter location manually'),
                      style: TextStyle(
                          color: _getTextColor(isDark),
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildCoordField(
                  controller: latCtrl,
                  label: l10n.tr(ar: 'خط العرض (Latitude)', en: 'Latitude'),
                  hint: '21.3891',
                  isDark: isDark,
                  accent: accent,
                ),
                const SizedBox(height: 12),
                _buildCoordField(
                  controller: lngCtrl,
                  label: l10n.tr(ar: 'خط الطول (Longitude)', en: 'Longitude'),
                  hint: '39.8579',
                  isDark: isDark,
                  accent: accent,
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                            style: TextStyle(color: _getSubTextColor(isDark))),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: accent,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: () {
                          final double? lat = double.tryParse(latCtrl.text);
                          final double? lng = double.tryParse(lngCtrl.text);
                          if (lat != null && lng != null) {
                            _updateSettings(settings.copyWith(
                                locationMode: 'MANUAL',
                                gpsLat: lat,
                                gpsLng: lng));
                            Navigator.pop(ctx);
                          }
                        },
                        child: Text(l10n.tr(ar: 'حفظ الموقع', en: 'Save location'),
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo')),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCoordField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required bool isDark,
    required Color accent,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label,
            style: TextStyle(
                color: _getSubTextColor(isDark),
                fontSize: 12,
                fontFamily: 'Cairo')),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(
              decimal: true, signed: true),
          textDirection: TextDirection.ltr,
          style: TextStyle(color: _getTextColor(isDark)),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
                color: _getSubTextColor(isDark).withValues(alpha: 0.3)),
            filled: true,
            fillColor: _getBg(isDark),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                    color: isDark ? Colors.white10 : Colors.black12)),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: accent)),
          ),
        ),
      ],
    );
  }

  Widget _buildLocationButton({
    required String label,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
    required bool isDark,
    bool isLoading = false,
  }) {
    final accent = _accent;
    return Expanded(
      child: TvFocusable(
        onPressed: onTap,
        borderRadius: BorderRadius.circular(14),
        focusColor: accent,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: isActive
                ? accent.withValues(alpha: 0.12)
                : _getCardColor(isDark),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isActive
                  ? accent
                  : (isDark ? Colors.white10 : const Color(0xFFE0E0E0)),
              width: isActive ? 1.5 : 1.0,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isLoading)
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(accent)),
                )
              else
                Icon(icon,
                    color: isActive
                        ? accent
                        : _getSubTextColor(isDark).withValues(alpha: 0.5),
                    size: 22),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                    color: isActive ? accent : _getSubTextColor(isDark),
                    fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                    fontFamily: 'Cairo',
                    fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'الطقس والموقع', en: 'Weather & Location')),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
            children: [
              // Section label
              _buildSectionLabel(
                  l10n.tr(ar: 'خيارات الطقس', en: 'Weather options'), Icons.thermostat_rounded, isDark),
              const SizedBox(height: 10),

              _buildSettingsCard([
                SettingToggleRow(
                  title: l10n.tr(ar: 'تفعيل حالة الطقس', en: 'Enable weather status'),
                  icon: Icons.wb_cloudy_rounded,
                  iconColor: Colors.blueAccent,
                  value: settings.weatherEnabled,
                  onChanged: (v) =>
                      _updateSettings(settings.copyWith(weatherEnabled: v)),
                ),
                _divider(isDark),
                SettingToggleRow(
                  title: l10n.tr(ar: 'تفعيل حالة الطقس بجانب أوقات الصلاة', en: 'Show weather next to prayer times'),
                  icon: Icons.view_headline_rounded,
                  iconColor: Colors.teal,
                  value: settings.weatherShowNearPrayerTimes,
                  onChanged: (v) => _updateSettings(
                      settings.copyWith(weatherShowNearPrayerTimes: v)),
                ),
              ], isDark),

              const SizedBox(height: 24),

              // Section label
              _buildSectionLabel(
                  l10n.tr(ar: 'نظام الموقع وإحداثيات GPS', en: 'Location mode & GPS coordinates'), Icons.gps_fixed_rounded, isDark),
              const SizedBox(height: 10),

              // GPS mode selector
              _buildSettingsCard([
                const SizedBox(height: 12),
                Row(
                  children: [
                    _buildLocationButton(
                      label: l10n.tr(ar: 'تلقائي (GPS)', en: 'Automatic (GPS)'),
                      icon: Icons.near_me_rounded,
                      isActive: settings.locationMode == 'AUTO',
                      isLoading: _isLoadingGps,
                      onTap: () => _getAutoLocation(settings),
                      isDark: isDark,
                    ),
                    const SizedBox(width: 12),
                    _buildLocationButton(
                      label: l10n.tr(ar: 'يدوي (إحداثيات)', en: 'Manual (coordinates)'),
                      icon: Icons.edit_location_alt_rounded,
                      isActive: settings.locationMode == 'MANUAL',
                      onTap: () => _getManualLocation(settings),
                      isDark: isDark,
                    ),
                  ],
                ),

                const SizedBox(height: 20),
                _divider(isDark),
                const SizedBox(height: 16),

                // Coordinates display
                Row(
                  textDirection: TextDirection.rtl,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // 1. Mode Label (Right)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _accent.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        l10n.tr(ar: "الإحداثيات: ${settings.locationMode == 'AUTO' ? 'تلقائي' : 'يدوي'}", en: "Mode: ${settings.locationMode == 'AUTO' ? 'Automatic' : 'Manual'}"),
                        style: TextStyle(
                          color: _accent,
                          fontFamily: 'Cairo',
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    // 2. Coordinates (Left)
                    Text(
                      '${settings.gpsLat.toStringAsFixed(4)} , ${settings.gpsLng.toStringAsFixed(4)}',
                      style: TextStyle(
                        color: _accent,
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
              ], isDark),

              const SizedBox(height: 24),

              // Section label
              _buildSectionLabel(
                  l10n.tr(ar: 'إعدادات إضافية', en: 'Additional settings'), Icons.more_horiz_rounded, isDark),
              _buildSettingsCard([
                SettingToggleRow(
                  title: l10n.tr(ar: 'تفعيل التنبيهات الصوتية للطقس', en: 'Enable weather voice alerts'),
                  icon: Icons.volume_up_rounded,
                  iconColor: Colors.orange,
                  value: settings.weatherAlertsEnabled,
                  onChanged: (v) => _updateSettings(
                      settings.copyWith(weatherAlertsEnabled: v)),
                ),
              ], isDark),
            ],
          ),
        ),
      ),
    );
  }
}



