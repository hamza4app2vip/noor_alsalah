import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../providers/settings_provider.dart';
import '../../domain/entities/adhan_sound.dart';
import '../../../../core/utils/audio_service.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class AdhanSoundsManagementScreen extends ConsumerStatefulWidget {
  const AdhanSoundsManagementScreen({super.key});

  @override
  ConsumerState<AdhanSoundsManagementScreen> createState() =>
      _AdhanSoundsManagementScreenState();
}

class _AdhanSoundsManagementScreenState
    extends ConsumerState<AdhanSoundsManagementScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  String? _currentlyPlayingId;

  Future<void> _pickAndAddSound() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    if (file.path == null) return;

    final appDocDir = await getApplicationDocumentsDirectory();
    final customAdhanDir = Directory('${appDocDir.path}/custom_adhans');
    if (!await customAdhanDir.exists()) {
      await customAdhanDir.create(recursive: true);
    }

    final String fileExtension = file.extension ?? 'mp3';
    final String newFileName = '${const Uuid().v4()}.$fileExtension';
    final String localPath = '${customAdhanDir.path}/$newFileName';

    try {
      await File(file.path!).copy(localPath);
    } catch (e) {
      if (mounted) {
        GlassToast.show(context,
            '${l10n.tr(ar: 'فشل نسخ الملف', en: 'Failed to copy file')}: $e',
            isError: true);
      }
      return;
    }

    // Ask for a display name
    String? customName = file.name;
    if (mounted) {
      customName = await showDialog<String>(
        context: context,
        builder: (ctx) {
          final ctrl = TextEditingController(
              text: file.name.replaceAll('.$fileExtension', ''));
          return AlertDialog(
            title: Text(l10n.tr(ar: 'اسم الصوت', en: 'Sound name')),
            content: TextField(
              controller: ctrl,
              autofocus: true,
              textDirection: TextDirection.rtl,
              decoration: InputDecoration(
                  hintText: l10n.tr(
                      ar: 'أدخل اسماً يميز هذا الصوت',
                      en: 'Enter a name to identify this sound')),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'))),
              TextButton(
                  onPressed: () => Navigator.pop(ctx, ctrl.text),
                  child: Text(l10n.tr(ar: 'حفظ', en: 'Save'))),
            ],
          );
        },
      );
    }

    if (customName == null || customName.trim().isEmpty) {
      customName = file.name;
    }

    final newSound = AdhanSound(
      id: const Uuid().v4(),
      name: customName,
      filePath: localPath,
    );

    final settings = ref.read(settingsNotifierProvider);
    final updatedList = List<AdhanSound>.from(settings.customAdhanSounds)
      ..add(newSound);
    ref
        .read(settingsNotifierProvider.notifier)
        .updateSettings(settings.copyWith(customAdhanSounds: updatedList));

    if (mounted) {
      GlassToast.show(context,
          l10n.tr(ar: 'تمت إضافة الصوت بنجاح', en: 'Sound added successfully'));
    }
  }

  void _deleteSound(AdhanSound sound) async {
    final settings = ref.read(settingsNotifierProvider);

    // Check if it's assigned
    if (settings.defaultAdhanSoundId == sound.id ||
        settings.prayerAdhanSoundIds.containsValue(sound.id)) {
      GlassToast.show(
          context,
          l10n.tr(
              ar: 'لا يمكن الحذف: هذا الصوت قيد الاستخدام حالياً.',
              en: 'Cannot delete: this sound is currently in use.'),
          isError: true);
      return;
    }

    // Remove file
    try {
      final file = File(sound.filePath);
      if (await file.exists()) await file.delete();
    } catch (_) {}

    final updatedList =
        settings.customAdhanSounds.where((s) => s.id != sound.id).toList();
    ref
        .read(settingsNotifierProvider.notifier)
        .updateSettings(settings.copyWith(customAdhanSounds: updatedList));
  }

  void _previewSound(AdhanSound sound) async {
    if (_currentlyPlayingId == sound.id) {
      await AudioService.stop(); // Use existing stop mechanism
      setState(() => _currentlyPlayingId = null);
    } else {
      await AudioService.playDeviceFile(sound.filePath);
      setState(() => _currentlyPlayingId = sound.id);
    }
  }

  @override
  void deactivate() {
    AudioService.stop();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
      extendBodyBehindAppBar: true,
      appBar: PremiumGlassNavbar(
        title: l10n.tr(ar: 'أصوات الأذان المخصصة', en: 'Custom adhan sounds'),
      ),
      floatingActionButton: TvFocusable(
        onPressed: _pickAndAddSound,
        borderRadius: BorderRadius.circular(30),
        child: FloatingActionButton.extended(
          onPressed: _pickAndAddSound,
          label: Text(l10n.tr(ar: 'إضافة صوت', en: 'Add sound'),
              style:
                  TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
          icon: const Icon(Icons.add_rounded),
          backgroundColor: const Color(0xFFD4AF37),
        ),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView.builder(
          padding: const EdgeInsets.all(16).copyWith(bottom: 100),
          itemCount: settings.customAdhanSounds.length,
          itemBuilder: (ctx, index) {
            final sound = settings.customAdhanSounds[index];
            final isPlaying = _currentlyPlayingId == sound.id;

            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              color: isDark ? const Color(0xFF1E293B) : Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                title: Text(sound.name,
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        color: isDark ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.bold)),
                subtitle: Text(l10n.tr(ar: 'ملف مخصص', en: 'Custom file'),
                    style: TextStyle(fontSize: 12)),
                leading: TvFocusable(
                  onPressed: () => _previewSound(sound),
                  borderRadius: BorderRadius.circular(30),
                  child: IconButton(
                    icon: Icon(
                        isPlaying
                            ? Icons.stop_circle_rounded
                            : Icons.play_circle_fill_rounded,
                        color: isPlaying ? Colors.red : const Color(0xFFD4AF37),
                        size: 36),
                    onPressed: () => _previewSound(sound),
                  ),
                ),
                trailing: TvFocusable(
                  onPressed: () => _deleteSound(sound),
                  borderRadius: BorderRadius.circular(30),
                  child: IconButton(
                    icon: const Icon(Icons.delete_outline_rounded,
                        color: Colors.redAccent),
                    onPressed: () => _deleteSound(sound),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
