﻿import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/widgets/settings_row.dart';
import '../../domain/entities/app_settings.dart';
import '../providers/settings_provider.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/luxury_time_picker.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class PrayerAdjustmentsScreen extends ConsumerStatefulWidget {
  const PrayerAdjustmentsScreen({super.key});

  @override
  ConsumerState<PrayerAdjustmentsScreen> createState() =>
      _PrayerAdjustmentsScreenState();
}

class _PrayerAdjustmentsScreenState
    extends ConsumerState<PrayerAdjustmentsScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  void _update(AppSettings s) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(s);
    GlassToast.show(context, l10n.tr(ar: ' تم الحفظ', en: 'Saved'));
  }

  // ── بطاقة بيضاء موحدة ──
  Widget _buildSectionLabel(String title, IconData icon) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accentColor =
        isDark ? const Color(0xFFDCB881) : AppColors.primaryGold;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, right: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(icon, color: accentColor, size: 16),
          const SizedBox(width: 8),
          Text(title,
              style: TextStyle(
                  color: accentColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: 'Cairo')),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 12,
                    offset: const Offset(0, 2))
              ]
            : null,
      ),
      child: Column(children: children),
    );
  }

  // ── حساب ± للوقت ──
  Widget _adjuster(
      String label, int value, VoidCallback onPlus, VoidCallback onMinus,
      {bool showSign = true}) {
    final display = showSign && value > 0 ? '+$value' : '$value';
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final emerald = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    const red = Colors.redAccent;
    final color = value == 0 ? Colors.black38 : (value > 0 ? emerald : red);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              // 1. Label (Right)
              Expanded(
                child: Text(label,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black87,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Cairo',
                        fontSize: 15)),
              ),
              const SizedBox(width: 12),
              // 2. Adjuster (Left)
              Row(
                textDirection: TextDirection.ltr, // Keep buttons +/- order
                children: [
                  _roundBtn(Icons.remove_rounded, onMinus, red),
                  const SizedBox(width: 10),
                  Container(
                    width: 50,
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    decoration: BoxDecoration(
                      color: value == 0
                          ? (Theme.of(context).brightness == Brightness.dark
                              ? Colors.white10
                              : Colors.black.withValues(alpha: 0.05))
                          : color.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: color.withValues(alpha: 0.2)),
                    ),
                    alignment: Alignment.center,
                    child: Text(display,
                        style: TextStyle(
                            color: value == 0
                                ? (Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white38
                                    : Colors.black38)
                                : color,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                  ),
                  const SizedBox(width: 10),
                  _roundBtn(Icons.add_rounded, onPlus, emerald),
                ],
              ),
            ],
          ),
        ),
        Divider(
            height: 1,
            color: Colors.black.withValues(alpha: 0.05),
            indent: 16,
            endIndent: 16),
      ],
    );
  }

  Widget _roundBtn(IconData icon, VoidCallback onTap, Color color) {
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(18),
      focusColor: color,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          shape: BoxShape.circle,
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Icon(icon, color: color, size: 16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'تعديل أوقات الصلوات', en: 'Adjust Prayer Times')),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
            children: [
              // ── الإزاحات العامة ──
              _buildSectionLabel(l10n.tr(ar: 'إزاحات عامة', en: 'General offsets'), Icons.tune_rounded),
              _buildSettingsCard([
                SettingToggleRow(
                  title: l10n.tr(ar: 'إضافة 30 دقيقة لصلاة العشاء في رمضان', en: 'Add 30 minutes to Isha during Ramadan'),
                  icon: Icons.lightbulb_outline,
                  iconColor: const Color(0xFFE67E22),
                  value: s.ramadanIshaPlus30Enabled,
                  onChanged: (v) =>
                      _update(s.copyWith(ramadanIshaPlus30Enabled: v)),
                ),
                _divider(),
                SettingToggleRow(
                  title: l10n.tr(ar: 'إضافة ساعة واحدة في التوقيت الصيفي', en: 'Add one hour during daylight saving time'),
                  icon: Icons.wb_sunny_rounded,
                  iconColor: const Color(0xFFF1C40F),
                  value: s.summerPlus1HourEnabled,
                  onChanged: (v) =>
                      _update(s.copyWith(summerPlus1HourEnabled: v)),
                ),
                _divider(),
                SettingToggleRow(
                  title: l10n.tr(ar: 'إضافة ساعة يدوياً لجميع الأوقات', en: 'Manually add one hour to all times'),
                  icon: Icons.add_alarm_rounded,
                  iconColor: const Color(0xFF1AA85A),
                  value: s.manualPlus1HourAllEnabled,
                  onChanged: (v) {
                    if (v && s.manualMinus1HourAllEnabled) {
                      _update(s.copyWith(
                          manualPlus1HourAllEnabled: true,
                          manualMinus1HourAllEnabled: false));
                    } else {
                      _update(s.copyWith(manualPlus1HourAllEnabled: v));
                    }
                  },
                ),
                _divider(),
                SettingToggleRow(
                  title: l10n.tr(ar: 'إزالة ساعة يدوياً من جميع الأوقات', en: 'Manually remove one hour from all times'),
                  icon: Icons.history_rounded,
                  iconColor: Colors.redAccent,
                  value: s.manualMinus1HourAllEnabled,
                  onChanged: (v) {
                    if (v && s.manualPlus1HourAllEnabled) {
                      _update(s.copyWith(
                          manualMinus1HourAllEnabled: true,
                          manualPlus1HourAllEnabled: false));
                    } else {
                      _update(s.copyWith(manualMinus1HourAllEnabled: v));
                    }
                  },
                ),
              ]),

              const SizedBox(height: 24),

              // ── تعديل دقائق التواقيت ──
              _buildSectionLabel(
                  l10n.tr(ar: 'تعديل التواقيت (دقائق)', en: 'Adjust times (minutes)'), Icons.access_time_rounded),
              _buildSettingsCard([
                _adjuster(
                    l10n.tr(ar: 'الفجر', en: 'Fajr'),
                    s.prayerOffsetFajr,
                    () => _update(
                        s.copyWith(prayerOffsetFajr: s.prayerOffsetFajr + 1)),
                    () => _update(
                        s.copyWith(prayerOffsetFajr: s.prayerOffsetFajr - 1))),
                _adjuster(
                    l10n.tr(ar: 'الشروق', en: 'Sunrise'),
                    s.prayerOffsetSunrise,
                    () => _update(s.copyWith(
                        prayerOffsetSunrise: s.prayerOffsetSunrise + 1)),
                    () => _update(s.copyWith(
                        prayerOffsetSunrise: s.prayerOffsetSunrise - 1))),
                _adjuster(
                    l10n.tr(ar: 'الظهر', en: 'Dhuhr'),
                    s.prayerOffsetDhuhr,
                    () => _update(
                        s.copyWith(prayerOffsetDhuhr: s.prayerOffsetDhuhr + 1)),
                    () => _update(s.copyWith(
                        prayerOffsetDhuhr: s.prayerOffsetDhuhr - 1))),
                _adjuster(
                    l10n.tr(ar: 'العصر', en: 'Asr'),
                    s.prayerOffsetAsr,
                    () => _update(
                        s.copyWith(prayerOffsetAsr: s.prayerOffsetAsr + 1)),
                    () => _update(
                        s.copyWith(prayerOffsetAsr: s.prayerOffsetAsr - 1))),
                _adjuster(
                    l10n.tr(ar: 'المغرب', en: 'Maghrib'),
                    s.prayerOffsetMaghrib,
                    () => _update(s.copyWith(
                        prayerOffsetMaghrib: s.prayerOffsetMaghrib + 1)),
                    () => _update(s.copyWith(
                        prayerOffsetMaghrib: s.prayerOffsetMaghrib - 1))),
                _adjuster(
                    l10n.tr(ar: 'العشاء', en: 'Isha'),
                    s.prayerOffsetIsha,
                    () => _update(
                        s.copyWith(prayerOffsetIsha: s.prayerOffsetIsha + 1)),
                    () => _update(
                        s.copyWith(prayerOffsetIsha: s.prayerOffsetIsha - 1))),
              ]),

              const SizedBox(height: 24),

              // ── وقت الإقامة ──
              _buildSectionLabel(l10n.tr(ar: 'وقت الإقامة', en: 'Iqama time'), Icons.alarm_rounded),
              _buildSettingsCard([
                ...[
                  {
                    'id': 'fajr',
                    'name': l10n.tr(ar: 'الفجر', en: 'Fajr'),
                    'val': s.fajrIqamaTime,
                    'setter': (v) => _update(s.copyWith(fajrIqamaTime: v))
                  },
                  {
                    'id': 'dhuhr',
                    'name': l10n.tr(ar: 'الظهر', en: 'Dhuhr'),
                    'val': s.dhuhrIqamaTime,
                    'setter': (v) => _update(s.copyWith(dhuhrIqamaTime: v))
                  },
                  {
                    'id': 'asr',
                    'name': l10n.tr(ar: 'العصر', en: 'Asr'),
                    'val': s.asrIqamaTime,
                    'setter': (v) => _update(s.copyWith(asrIqamaTime: v))
                  },
                  {
                    'id': 'maghrib',
                    'name': l10n.tr(ar: 'المغرب', en: 'Maghrib'),
                    'val': s.maghribIqamaTime,
                    'setter': (v) => _update(s.copyWith(maghribIqamaTime: v))
                  },
                  {
                    'id': 'isha',
                    'name': l10n.tr(ar: 'العشاء', en: 'Isha'),
                    'val': s.ishaIqamaTime,
                    'setter': (v) => _update(s.copyWith(ishaIqamaTime: v))
                  },
                ].map((p) {
                  final id = p['id'] as String;
                  final isFixed = s.iqamaIsFixed[id] == true;
                  final fixedTime = s.iqamaFixedTimes[id] ?? '--:--';
                  final emerald = isDark
                      ? const Color(0xFFDCB881)
                      : const Color(0xFF1AA85A);

                  return Column(children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                      child: Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          // Right: Title + Mode text
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(p['name'] as String,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Cairo',
                                        fontSize: 15,
                                        color: textColor)),
                                TvFocusable(
                                  onPressed: () async {
                                    if (isFixed) {
                                      final m = Map<String, bool>.from(
                                          s.iqamaIsFixed);
                                      m[id] = false;
                                      _update(s.copyWith(iqamaIsFixed: m));
                                    } else {
                                      final TimeOfDay? picked =
                                          await LuxuryTimePicker.show(
                                              context,
                                              initialTime: TimeOfDay.now());
                                      if (picked != null) {
                                        final m = Map<String, bool>.from(
                                            s.iqamaIsFixed);
                                        final t = Map<String, String>.from(
                                            s.iqamaFixedTimes);
                                        m[id] = true;
                                        t[id] =
                                            '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
                                        _update(s.copyWith(
                                            iqamaIsFixed: m,
                                            iqamaFixedTimes: t));
                                      }
                                    }
                                  },
                                  borderRadius: BorderRadius.circular(8),
                                  focusColor: emerald,
                                  child: Text(
                                    isFixed ? l10n.tr(ar: '📌 وقت ثابت', en: '📌 Fixed time') : l10n.tr(ar: '⏱ بعد الأذان', en: '⏱ After adhan'),
                                    style: TextStyle(
                                        color: isFixed
                                            ? AppColors.primaryGold
                                            : Colors.black38,
                                        fontSize: 12,
                                        fontFamily: 'Cairo'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Left: Adjuster
                          isFixed
                              ? TvFocusable(
                                  onPressed: () async {
                                    final TimeOfDay? picked =
                                        await LuxuryTimePicker.show(
                                            context,
                                            initialTime: TimeOfDay.now());
                                    if (picked != null) {
                                      final m = Map<String, bool>.from(
                                          s.iqamaIsFixed);
                                      final t = Map<String, String>.from(
                                          s.iqamaFixedTimes);
                                      m[id] = true;
                                      t[id] =
                                          '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
                                      _update(s.copyWith(
                                          iqamaIsFixed: m, iqamaFixedTimes: t));
                                    }
                                  },
                                  borderRadius: BorderRadius.circular(12),
                                  focusColor: emerald,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 8),
                                    decoration: BoxDecoration(
                                      color: emerald.withValues(alpha: 0.08),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                          color:
                                              emerald.withValues(alpha: 0.2)),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.edit_rounded,
                                            size: 14, color: emerald),
                                        const SizedBox(width: 6),
                                        Text(fixedTime,
                                            style: TextStyle(
                                                color: emerald,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Cairo')),
                                      ],
                                    ),
                                  ),
                                )
                              : Row(
                                  textDirection: TextDirection.ltr,
                                  children: [
                                    _roundBtn(
                                        Icons.remove_rounded,
                                        () => (p['setter']
                                            as Function)((p['val'] as int) - 1),
                                        Colors.redAccent),
                                    const SizedBox(width: 10),
                                    Container(
                                      width: 44,
                                      alignment: Alignment.center,
                                      child: Text('${p['val']}',
                                          style: TextStyle(
                                              color: emerald,
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold)),
                                    ),
                                    const SizedBox(width: 10),
                                    _roundBtn(
                                        Icons.add_rounded,
                                        () => (p['setter']
                                            as Function)((p['val'] as int) + 1),
                                        emerald),
                                  ],
                                ),
                        ],
                      ),
                    ),
                    Divider(
                        height: 1,
                        color: textColor.withValues(alpha: 0.1),
                        indent: 16,
                        endIndent: 16),
                  ]);
                }),
              ]),

              const SizedBox(height: 24),

              // ── الجمعة ──
              _buildSectionLabel(l10n.tr(ar: 'إعدادات الجمعة', en: 'Friday settings'), Icons.mosque_rounded),
              _buildSettingsCard([
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Expanded(
                        child: Text(l10n.tr(ar: 'وقت خطبة الجمعة', en: 'Friday sermon time'),
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Cairo',
                                fontSize: 15)),
                      ),
                      const SizedBox(width: 12),
                      Row(
                        children: [
                          _choiceChip(
                              l10n.tr(ar: 'تلقائي', en: 'Automatic'),
                              s.jumuaKhutbahAutoMode,
                              () => _update(
                                  s.copyWith(jumuaKhutbahAutoMode: true))),
                          const SizedBox(width: 8),
                          _choiceChip(
                            s.jumuaKhutbahAutoMode
                                ? l10n.tr(ar: 'يدوي', en: 'Manual')
                                : s.jumuaKhutbahManualTime,
                            !s.jumuaKhutbahAutoMode,
                            () async {
                              final TimeOfDay? t = await LuxuryTimePicker.show(
                                  context,
                                  initialTime:
                                      const TimeOfDay(hour: 12, minute: 0));
                              if (t != null) {
                                _update(s.copyWith(
                                  jumuaKhutbahAutoMode: false,
                                  jumuaKhutbahManualTime:
                                      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}',
                                ));
                              }
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                _divider(),
                SettingToggleRow(
                  title: l10n.tr(ar: 'إظهار الجمعة في الشاشة الأفقية', en: 'Show Friday on landscape screen'),
                  icon: Icons.monitor_rounded,
                  iconColor: Colors.blueGrey,
                  value: s.showJumuaInLandscape,
                  onChanged: (v) =>
                      _update(s.copyWith(showJumuaInLandscape: v)),
                ),
                _divider(),
                SettingToggleRow(
                  title: l10n.tr(ar: 'تفعيل صوت أذان الجمعة', en: 'Enable Friday adhan sound'),
                  icon: Icons.volume_up_rounded,
                  iconColor: const Color(0xFF1AA85A),
                  value: s.enableJumuaAdhanSound,
                  onChanged: (v) =>
                      _update(s.copyWith(enableJumuaAdhanSound: v)),
                ),
              ]),

              const SizedBox(height: 24),

              // ── إعدادات متقدمة ──
              _buildSectionLabel(l10n.tr(ar: 'إعدادات متقدمة', en: 'Advanced settings'), Icons.settings_rounded),
              _buildSettingsCard([
                _adjuster(l10n.tr(ar: 'تعديل التاريخ الهجري', en: 'Adjust Hijri date'), s.hijriOffsetDays, () {
                  if (s.hijriOffsetDays < 3)
                    _update(s.copyWith(hijriOffsetDays: s.hijriOffsetDays + 1));
                }, () {
                  if (s.hijriOffsetDays > -3)
                    _update(s.copyWith(hijriOffsetDays: s.hijriOffsetDays - 1));
                }),
                _adjuster(
                    l10n.tr(ar: 'تنبيه قبل الفجر (دقيقة)', en: 'Pre-Fajr alert (minutes)'),
                    s.fajrPreAdhanAlertMinutes,
                    () => _update(s.copyWith(
                        fajrPreAdhanAlertMinutes:
                            s.fajrPreAdhanAlertMinutes + 1)), () {
                  if (s.fajrPreAdhanAlertMinutes > 0)
                    _update(s.copyWith(
                        fajrPreAdhanAlertMinutes:
                            s.fajrPreAdhanAlertMinutes - 1));
                }, showSign: false),
                SettingToggleRow(
                  title: l10n.tr(ar: 'الظهر = العصر − X دقيقة', en: 'Dhuhr = Asr − X minutes'),
                  icon: Icons.calculate_rounded,
                  iconColor: Colors.indigo,
                  value: s.dhuhrFromAsrMinusMinutesEnabled,
                  onChanged: (v) =>
                      _update(s.copyWith(dhuhrFromAsrMinusMinutesEnabled: v)),
                ),
                if (s.dhuhrFromAsrMinusMinutesEnabled)
                  _adjuster(
                      l10n.tr(ar: 'دقائق الطرح', en: 'Subtraction minutes'),
                      s.dhuhrEqualsAsrMinusMinutes,
                      () => _update(s.copyWith(
                          dhuhrEqualsAsrMinusMinutes:
                              s.dhuhrEqualsAsrMinusMinutes + 1)), () {
                    if (s.dhuhrEqualsAsrMinusMinutes > 0)
                      _update(s.copyWith(
                          dhuhrEqualsAsrMinusMinutes:
                              s.dhuhrEqualsAsrMinusMinutes - 1));
                  }, showSign: false),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _divider() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Divider(
        height: 1,
        color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
        indent: 56,
        endIndent: 16);
  }

  Widget _choiceChip(String label, bool selected, VoidCallback onTap) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final emerald = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(12),
      focusColor: emerald,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected
              ? emerald.withValues(alpha: 0.12)
              : const Color(0xFFF5F5F7),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: selected ? emerald : const Color(0xFFE0E0E0),
              width: selected ? 1.5 : 1.0),
        ),
        child: Text(label,
            style: TextStyle(
                color: selected ? emerald : Colors.black54,
                fontWeight: FontWeight.bold,
                fontFamily: 'Cairo',
                fontSize: 13)),
      ),
    );
  }
}


