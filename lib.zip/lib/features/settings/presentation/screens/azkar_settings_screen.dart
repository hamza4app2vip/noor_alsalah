import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/widgets/settings_row.dart';
import '../../domain/entities/app_settings.dart';
import '../providers/settings_provider.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/widgets/luxury_time_picker.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../l10n/app_localizations.dart';

class AzkarSettingsScreen extends ConsumerStatefulWidget {
  const AzkarSettingsScreen({super.key});

  @override
  ConsumerState<AzkarSettingsScreen> createState() =>
      _AzkarSettingsScreenState();
}

class _AzkarSettingsScreenState extends ConsumerState<AzkarSettingsScreen> {
  void _update(AppSettings s) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(s);
    GlassToast.show(context, AppLocalizations.of(context).savedSuccessfully);
  }

  Color get _accent => Theme.of(context).brightness == Brightness.dark 
      ? AppColors.goldAccent 
      : const Color(0xFF1AA85A);

  Widget _buildSectionLabel(String title, IconData icon, bool isDark) {
    final accentColor = _accent;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, right: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(icon, color: accentColor, size: 16),
          const SizedBox(width: 8),
          Text(title,
              style: TextStyle(
                  color: accentColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: 'Cairo')),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children, bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark ? [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 12,
              offset: const Offset(0, 2))
        ] : null,
      ),
      child: Column(children: children),
    );
  }

  Future<void> _selectTime(String current, Function(String) onSelected) async {
    final parts = current.split(':');
    final initialTime = TimeOfDay(
      hour: int.tryParse(parts[0]) ?? 0,
      minute: parts.length > 1 ? (int.tryParse(parts[1]) ?? 0) : 0,
    );

    final TimeOfDay? picked = await LuxuryTimePicker.show(
      context,
      initialTime: initialTime,
      title: AppLocalizations.of(context).selectTime,
    );

    if (picked != null) {
      final formatted = '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
      onSelected(formatted);
    }
  }

  Widget _buildTimeTile(String title, String value, IconData icon, Color iconColor, VoidCallback onTap, bool isDark) {
    return SettingRow(
      title: title,
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: iconColor.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: iconColor.withValues(alpha: 0.2)),
        ),
        child: Text(
          value,
          style: TextStyle(
            color: iconColor,
            fontWeight: FontWeight.bold,
            fontFamily: 'Cairo',
          ),
        ),
      ),
      icon: icon,
      iconColor: iconColor,
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(settingsNotifierProvider);
    final azkarOn = s.postPrayerAzkarEnabled;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: PremiumGlassNavbar(
            title: l10n.postPrayerAzkarTitle,
          ),
        ),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
          children: [

            // ── الإعدادات العامة ──
            _buildSectionLabel(l10n.generalSettingsLabel, Icons.tune_rounded, isDark),
            _buildSettingsCard([
              SettingToggleRow(
                title: l10n.azkar0,
                subtitle: l10n.enablePostPrayerAzkarSubtitle,
                icon: Icons.notifications_active_rounded,
                iconColor: const Color(0xFF1AA85A),
                value: azkarOn,
                onChanged: (v) => _update(s.copyWith(postPrayerAzkarEnabled: v)),
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.repeatAzkarOnce,
                icon: Icons.repeat_one_rounded,
                iconColor: const Color(0xFF3498DB),
                value: s.postPrayerAzkarRepeatOnce,
                onChanged: (v) => _update(s.copyWith(postPrayerAzkarRepeatOnce: v)),
                enabled: azkarOn && !s.postPrayerShowSingleSlide5Min,
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.showOneAzkarImage5Min,
                subtitle: l10n.showOneAzkarImage5MinSubtitle,
                icon: Icons.timer_rounded,
                iconColor: const Color(0xFFE67E22),
                value: s.postPrayerShowSingleSlide5Min,
                onChanged: (v) => _update(s.copyWith(postPrayerShowSingleSlide5Min: v)),
                enabled: azkarOn,
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.azkarBgWhite,
                icon: Icons.wallpaper_rounded,
                iconColor: const Color(0xFF9B59B6),
                value: s.postPrayerWhiteBackground,
                onChanged: (v) => _update(s.copyWith(postPrayerWhiteBackground: v)),
                enabled: azkarOn,
              ),
            ], isDark),

            const SizedBox(height: 24),

            // ── أذكار الشاشة الرئيسية ──
            _buildSectionLabel(l10n.mainScreenAzkar, Icons.today_rounded, isDark),
            _buildSettingsCard([
              SettingToggleRow(
                title: l10n.enableSabahAzkarOnMain,
                subtitle: l10n.appearsInMarquee,
                icon: Icons.wb_sunny_rounded,
                iconColor: const Color(0xFFF1C40F),
                value: s.enableSabahAzkar,
                onChanged: (v) => _update(s.copyWith(enableSabahAzkar: v)),
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.enableMasaaAzkarOnMain,
                subtitle: l10n.appearsInMarquee,
                icon: Icons.nightlight_rounded,
                iconColor: const Color(0xFF2C3E50),
                value: s.enableMasaaAzkar,
                onChanged: (v) => _update(s.copyWith(enableMasaaAzkar: v)),
              ),
            ], isDark),

            const SizedBox(height: 24),

            // ── أذكار الشاشة المستقلة ──
            _buildSectionLabel(l10n.standaloneAzkarScreenSettings, Icons.fullscreen_rounded, isDark),
            _buildSettingsCard([
              SettingToggleRow(
                title: l10n.appearByDesignatedTime,
                subtitle: l10n.automaticallyMorningEvening,
                icon: Icons.access_time_filled_rounded,
                iconColor: const Color(0xFF8E44AD),
                value: s.autoAzkarByTime,
                onChanged: (v) => _update(s.copyWith(autoAzkarByTime: v)),
              ),
              _divider(isDark),
              SettingRow(
                title: l10n.specificAzkarForManualPlayback,
                subtitle: l10n.whenAutoTimeOptionDisabled,
                icon: Icons.app_registration_rounded,
                iconColor: const Color(0xFF2980B9),
                trailing: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: s.manualAzkarType,
                    dropdownColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                    style: TextStyle(
                      color: isDark ? Colors.white : Colors.black87,
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                    items: [
                      DropdownMenuItem(value: 'SABAH', child: Text(l10n.sabahAzkarOnly)),
                      DropdownMenuItem(value: 'MASAA', child: Text(l10n.masaaAzkarOnly)),
                      DropdownMenuItem(value: 'BOTH', child: Text(l10n.bothSabahAndMasaa)),
                    ],
                    onChanged: (val) {
                      if (val != null) _update(s.copyWith(manualAzkarType: val));
                    },
                  ),
                ),
              ),
            ], isDark),

            const SizedBox(height: 24),

            // ── توقيت الأذكار ──
            _buildSectionLabel(l10n.azkarTiming, Icons.history_toggle_off_rounded, isDark),
            _buildSettingsCard([
              _buildTimeTile(
                l10n.sabahAzkarStartTime,
                s.sabahStartTime,
                Icons.login_rounded,
                const Color(0xFFF1C40F),
                () => _selectTime(s.sabahStartTime, (v) => _update(s.copyWith(sabahStartTime: v))),
                isDark,
              ),
              _divider(isDark),
              _buildTimeTile(
                l10n.sabahAzkarEndTime,
                s.sabahEndTime,
                Icons.logout_rounded,
                const Color(0xFFF39C12),
                () => _selectTime(s.sabahEndTime, (v) => _update(s.copyWith(sabahEndTime: v))),
                isDark,
              ),
              _divider(isDark),
              _buildTimeTile(
                l10n.masaaAzkarStartTime,
                s.masaaStartTime,
                Icons.login_rounded,
                const Color(0xFF34495E),
                () => _selectTime(s.masaaStartTime, (v) => _update(s.copyWith(masaaStartTime: v))),
                isDark,
              ),
              _divider(isDark),
              _buildTimeTile(
                l10n.masaaAzkarEndTime,
                s.masaaEndTime,
                Icons.logout_rounded,
                const Color(0xFF2C3E50),
                () => _selectTime(s.masaaEndTime, (v) => _update(s.copyWith(masaaEndTime: v))),
                isDark,
              ),
            ], isDark),

            const SizedBox(height: 24),

            // ── أذكار مرتبطة بالصلوات ──
            _buildSectionLabel(l10n.azkarAfterEveryPrayer, Icons.access_time_filled_rounded, isDark),
            _buildSettingsCard([
              SettingToggleRow(
                title: l10n.azkarSabah,
                icon: Icons.wb_twilight_rounded,
                iconColor: const Color(0xFFE67E22),
                value: s.enableSabahAfterFajr,
                onChanged: (v) => _update(s.copyWith(enableSabahAfterFajr: v)),
                enabled: azkarOn,
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.azkarAsr,
                icon: Icons.wb_sunny_rounded,
                iconColor: const Color(0xFFF39C12),
                value: s.enableMasaaAfterAsr,
                onChanged: (v) => _update(s.copyWith(enableMasaaAfterAsr: v)),
                enabled: azkarOn,
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.azkarMagrib,
                icon: Icons.nightlight_rounded,
                iconColor: const Color(0xFF34495E),
                value: s.enableMasaaAfterMaghrib,
                onChanged: (v) => _update(s.copyWith(enableMasaaAfterMaghrib: v)),
                enabled: azkarOn,
              ),
              _divider(isDark),
              SettingToggleRow(
                title: l10n.azkarIsha,
                icon: Icons.nights_stay_rounded,
                iconColor: const Color(0xFF2C3E50),
                value: s.enableMasaaAfterIsha,
                onChanged: (v) => _update(s.copyWith(enableMasaaAfterIsha: v)),
                enabled: azkarOn,
              ),
            ], isDark),

            const SizedBox(height: 24),

            // ── تلميح ──
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withValues(alpha: 0.05) : AppColors.primaryGold.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: isDark ? AppColors.goldAccent.withValues(alpha: 0.3) : AppColors.primaryGold.withValues(alpha: 0.2)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      l10n.postPrayerAzkarHint,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          color: isDark ? Colors.white70 : Colors.black54,
                          fontSize: 13,
                          fontFamily: 'Cairo',
                          height: 1.6),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Icon(Icons.info_outline_rounded, color: isDark ? AppColors.goldAccent : AppColors.primaryGold, size: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

  Widget _divider(bool isDark) {
    return Divider(height: 1, color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05), indent: 56, endIndent: 16);
  }
}
