﻿import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../settings/presentation/providers/settings_provider.dart';
import '../../../../core/services/excel_import_service.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../widgets/glass_selection_dialog.dart';
import '../widgets/luxury_confirm_dialog.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class ExcelImportScreen extends ConsumerStatefulWidget {
  const ExcelImportScreen({super.key});

  @override
  ConsumerState<ExcelImportScreen> createState() => _ExcelImportScreenState();
}

class _ExcelImportScreenState extends ConsumerState<ExcelImportScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  final ExcelImportService _importService = ExcelImportService();
  bool _isImporting = false;

  Map<String, String> get _durations => {
    'AUTO': l10n.tr(ar: 'تعرف تلقائي (جميع البيانات)', en: 'Auto detect (all data)'),
    'DAY_1': l10n.tr(ar: 'يوم واحد', en: 'One day'),
    'DAY_2': l10n.tr(ar: 'يومين', en: 'Two days'),
    'WEEK_1': l10n.tr(ar: 'أسبوع', en: 'One week'),
    'WEEK_2': l10n.tr(ar: 'أسبوعين', en: 'Two weeks'),
    'MONTH_1': l10n.tr(ar: 'شهر', en: 'One month'),
    'MONTH_2': l10n.tr(ar: 'شهرين', en: 'Two months'),
    'MONTH_6': l10n.tr(ar: '6 أشهر', en: '6 months'),
    'YEAR': l10n.tr(ar: 'سنة كاملة', en: 'Full year'),
  };

  Color get _accent => Theme.of(context).brightness == Brightness.dark 
      ? AppColors.goldAccent 
      : const Color(0xFF1AA85A);

  Color _getTextColor(bool isDark) => isDark ? Colors.white : Colors.black87;
  Color _getSubTextColor(bool isDark) => isDark ? Colors.white70 : Colors.black54;
  Color _getCardColor(bool isDark) => isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white;

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'استيراد ذكي لأوقات الصلاة (Excel)', en: 'Smart Prayer Times Import (Excel)')),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(Theme.of(context).brightness == Brightness.dark),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
            children: [
              _buildStatusHeader(settings),
              const SizedBox(height: 24),
              _buildSectionTitle(l10n.tr(ar: 'إعدادات الملف', en: 'File settings')),
              const SizedBox(height: 12),
              _buildGlassDurationPicker(settings),
              const SizedBox(height: 24),
              _buildSectionTitle(l10n.tr(ar: 'دليل التنسيق', en: 'Formatting guide')),
              const SizedBox(height: 12),
              _buildInstructionCard(settings.customTimesDuration),
              const SizedBox(height: 32),
              _buildImportActions(settings),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accentColor = isDark ? const Color(0xFFDCB881) : AppColors.primaryGold;
    return Row(
      children: [
        Container(
          width: 4, height: 16,
          decoration: BoxDecoration(color: accentColor, borderRadius: BorderRadius.circular(2)),
        ),
        const SizedBox(width: 8),
        Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Cairo', fontSize: 15, color: isDark ? Colors.white : Colors.black87)),
      ],
    );
  }

  Widget _buildStatusHeader(dynamic settings) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark ? [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 20, offset: const Offset(0, 4))] : null,
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: settings.useCustomPrayerTimes ? Colors.green.withValues(alpha: 0.1) : Colors.orange.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  settings.useCustomPrayerTimes ? Icons.verified_user_rounded : Icons.info_outline_rounded,
                  color: settings.useCustomPrayerTimes ? Colors.green : Colors.orange,
                  size: 28,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      settings.useCustomPrayerTimes ? l10n.tr(ar: 'النظام المخصص مفعّل', en: 'Custom system enabled') : l10n.tr(ar: 'النظام المخصص جاهز', en: 'Custom system ready'),
                      style: TextStyle(fontWeight: FontWeight.w900, fontFamily: 'Cairo', fontSize: 18, color: _getTextColor(isDark)),
                    ),
                    Text(
                      settings.customTimesFilePath != null ? l10n.tr(ar: 'يتم الآن استخدام بيانات ملف Excel المستورد', en: 'Imported Excel data is currently in use') : l10n.tr(ar: 'لم يتم استيراد أي ملف حتى الآن', en: 'No file has been imported yet'),
                      style: TextStyle(color: _getSubTextColor(isDark).withValues(alpha: 0.5), fontSize: 13, fontFamily: 'Cairo'),
                    ),
                  ],
                ),
              ),
              CupertinoSwitch(
                value: settings.useCustomPrayerTimes,
                activeTrackColor: _accent,
                inactiveTrackColor: isDark ? Colors.white12 : Colors.black12,
                onChanged: (val) {
                  if (val && settings.customTimesFilePath == null) {
                    GlassToast.show(context, l10n.tr(ar: 'يرجى استيراد ملف Excel أولاً', en: 'Please import an Excel file first'));
                    return;
                  }
                  ref.read(settingsNotifierProvider.notifier).updateSettings(
                    settings.copyWith(useCustomPrayerTimes: val)
                  );
                },
              ),
            ],
          ),
          if (settings.customTimesFilePath != null) ...[
             Padding(
               padding: const EdgeInsets.symmetric(vertical: 16),
               child: Divider(height: 1, color: isDark ? Colors.white10 : Colors.black12),
             ),
             Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 Text(l10n.tr(ar: 'إدارة البيانات المسجلة:', en: 'Manage stored data:'), style: TextStyle(fontSize: 13, fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
                 TextButton.icon(
                   onPressed: _handleDelete,
                   style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
                   icon: const Icon(Icons.delete_sweep_rounded, size: 18),
                   label: Text(l10n.tr(ar: 'مسح البيانات والملف', en: 'Delete data and file'), style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
                 ),
               ],
             )
          ]
        ],
      ),
    );
  }

  Widget _buildGlassDurationPicker(dynamic settings) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: () async {
        final List<GlassSelectionItem<String>> items = _durations.entries.map((e) => 
          GlassSelectionItem(title: e.value, value: e.key)
        ).toList();

        final result = await showDialog<String>(
          context: context,
          builder: (_) => GlassSelectionDialog<String>(
            title: l10n.tr(ar: 'مدة البيانات في الملف', en: 'Data duration in file'),
            items: items,
            initialValue: settings.customTimesDuration,
          ),
        );

        if (result != null) {
          ref.read(settingsNotifierProvider.notifier).updateSettings(
            settings.copyWith(customTimesDuration: result)
          );
        }
      },
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        decoration: BoxDecoration(
          color: _getCardColor(isDark),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05)),
          boxShadow: !isDark ? [BoxShadow(color: Colors.black.withValues(alpha: 0.02), blurRadius: 10)] : null,
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_month_rounded, color: _getSubTextColor(isDark).withValues(alpha: 0.5)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text(l10n.tr(ar: 'مدة البيانات المطلوب قراءتها', en: 'Data duration to read'), style: TextStyle(fontSize: 12, color: _getSubTextColor(isDark).withValues(alpha: 0.6), fontFamily: 'Cairo')),
                  Text(_durations[settings.customTimesDuration] ?? l10n.tr(ar: 'غير محدد', en: 'Not specified'), 
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, fontFamily: 'Cairo', color: _getTextColor(isDark))),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded, size: 16, color: _accent),
          ],
        ),
      ),
    );
  }

  Widget _buildInstructionCard(String durationKey) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;
    String message = l10n.tr(ar: 'سيتم قراءة جميع البيانات الصالحة المكتوبة في الملف.', en: 'All valid data in the file will be read.');
    if (durationKey != 'AUTO') {
      int rows = 1;
      if (durationKey == 'YEAR') {
        rows = 365;
      } else if (durationKey == 'MONTH_6') {
        rows = 180;
      } else if (durationKey == 'MONTH_2') {
        rows = 60;
      } else if (durationKey == 'MONTH_1') {
        rows = 30;
      } else if (durationKey == 'WEEK_2') {
        rows = 14;
      } else if (durationKey == 'WEEK_1') {
        rows = 7;
      } else if (durationKey == 'DAY_2') {
        rows = 2;
      } else if (durationKey == 'DAY_1') {
        rows = 1;
      }
      message = l10n.tr(ar: 'يجب أن يحتوي الملف على $rows صفًا من البيانات (بالإضافة لصف العنوان).', en: 'The file must contain $rows data rows (in addition to the header row).');
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark ? [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 15)] : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.auto_awesome, color: accent, size: 20),
              const SizedBox(width: 8),
              Text(l10n.tr(ar: 'كيفية تجهيز الملف', en: 'How to prepare the file'), style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Cairo', fontSize: 15, color: _getTextColor(isDark))),
            ],
          ),
          const SizedBox(height: 16),
          Text(l10n.tr(ar: '• نظام التعرف الذكي: سيبحث التطبيق تلقائياً عن أعمدة (التاريخ، الفجر، الظهر...) في أي مكان بالملف.', en: '• Smart detection: the app automatically searches for columns (date, Fajr, Dhuhr...) anywhere in the file.'), style: TextStyle(fontSize: 13, fontFamily: 'Cairo', color: isDark ? accent : Colors.blueGrey, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('• $message', style: TextStyle(fontSize: 13, fontFamily: 'Cairo', color: _getTextColor(isDark), height: 1.5)),
          const SizedBox(height: 12),
          _buildTableGuide(),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(12)),
            child: Row(
              children: [
                const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(l10n.tr(ar: 'يدعم النظام التاريخ والوقت بعدة صيغ (نص، وقت Excel فعلي، AM/PM، وفواصل مختلفة) مع تطبيع تلقائي للصيغة القياسية.', en: 'The system supports date/time in multiple formats (text, real Excel time, AM/PM, and different separators) with automatic normalization.'), 
                      style: TextStyle(fontSize: 12, color: Colors.redAccent, fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTableGuide() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? Colors.white.withValues(alpha: 0.05) : const Color(0xFFF9FAFB),
          border: Border.all(color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05)),
        ),
        child: Table(
          columnWidths: const {0: FlexColumnWidth(1.2)},
          border: TableBorder.symmetric(inside: BorderSide(color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05))),
          children: [
            _buildTableRow(['A', 'B', 'C', 'D', 'E', 'F', 'G'], isHeader: true),
            _buildTableRow([l10n.tr(ar: 'التاريخ', en: 'Date'), l10n.tr(ar: 'الفجر', en: 'Fajr'), l10n.tr(ar: 'الشروق', en: 'Sunrise'), l10n.tr(ar: 'الظهر', en: 'Dhuhr'), l10n.tr(ar: 'العصر', en: 'Asr'), l10n.tr(ar: 'المغرب', en: 'Maghrib'), l10n.tr(ar: 'العشاء', en: 'Isha')], isSubHeader: true),
            _buildTableRow(['01-01', '04:55', '06:15', '12:00', '15:30', '17:45', '19:15']),
          ],
        ),
      ),
    );
  }

  TableRow _buildTableRow(List<String> cells, {bool isHeader = false, bool isSubHeader = false}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    Color? bgColor;
    if (isHeader) bgColor = isDark ? const Color(0xFFDCB881).withValues(alpha: 0.15) : const Color(0xFF1AA85A).withValues(alpha: 0.1);
    if (isSubHeader) bgColor = isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03);

    return TableRow(
      decoration: BoxDecoration(color: bgColor),
      children: cells.map((c) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Text(c, textAlign: TextAlign.center, style: TextStyle(
          fontSize: 11, 
          fontWeight: isHeader || isSubHeader ? FontWeight.bold : FontWeight.normal, 
          fontFamily: 'Cairo',
          color: isHeader ? (isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A)) : (isDark ? Colors.white70 : Colors.black87)
        )),
      )).toList(),
    );
  }

  Widget _buildImportActions(dynamic settings) {
    return Column(
      children: [
        if (_isImporting)
          const LoadingLuxuryWidget()
        else
          SUpdateImportButton(onTap: _handleImport),
      ],
    );
  }

  Future<void> _handleImport() async {
    final settings = ref.read(settingsNotifierProvider);
    if (settings.country.isEmpty || settings.city.isEmpty) {
      GlassToast.show(context, l10n.tr(ar: 'يرجى اختيار الدولة والمدينة أولاً', en: 'Please select country and city first'));
      return;
    }

    setState(() => _isImporting = true);
    try {
      final preview = await _importService.pickAndPreviewExcel(
        settings.customTimesDuration,
        settings.country,
        settings.city,
      );
      if (preview == null || !mounted) {
        return;
      }

      final approved = await _showImportPreviewDialog(preview);
      if (!approved || !mounted) {
        return;
      }

      final path = await _importService.saveImportPreview(preview);
      if (!mounted) {
        return;
      }

      ref.read(settingsNotifierProvider.notifier).updateSettings(
          settings.copyWith(
            customTimesFilePath: path,
            useCustomPrayerTimes: true,
            customTimesCountry: settings.country,
            customTimesCity: settings.city,
          ));

      GlassToast.show(context, l10n.tr(ar: 'تم الاستيراد بنجاح (${preview.importedRowsCount} صف)', en: 'Import completed successfully (${preview.importedRowsCount} rows)'));
    } catch (e, st) {
      debugPrint('[ExcelImportScreen] import failed: $e');
      debugPrint(st.toString());
      final msg = _formatImportError(e);
      if (mounted) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(color: isDark ? Colors.white10 : Colors.transparent)),
            title: Text(l10n.tr(ar: 'لم يكتمل الاستيراد', en: 'Import incomplete'),
                style: TextStyle(
                    color: isDark ? Colors.white : Colors.black87,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold)),
            content: Text(msg,
                style: TextStyle(
                    color: isDark ? Colors.white70 : Colors.black87,
                    fontFamily: 'Cairo')),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(l10n.tr(ar: 'حسنًا', en: 'OK'),
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        color:
                            isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A))),
              ),
            ],
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isImporting = false);
    }
  }

  Future<bool> _showImportPreviewDialog(ExcelImportPreview preview) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final sampleLines = preview.sampleRows
        .map((row) =>
            "• ${row['date']} | ${l10n.tr(ar: 'فجر', en: 'Fajr')} ${row['fajr']} | ${l10n.tr(ar: 'شروق', en: 'Sunrise')} ${row['sunrise']} | ${l10n.tr(ar: 'ظهر', en: 'Dhuhr')} ${row['dhuhr']} | ${l10n.tr(ar: 'عصر', en: 'Asr')} ${row['asr']} | ${l10n.tr(ar: 'مغرب', en: 'Maghrib')} ${row['maghrib']} | ${l10n.tr(ar: 'عشاء', en: 'Isha')} ${row['isha']}")
        .toList();

    final approved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: isDark ? Colors.white10 : Colors.transparent),
        ),
        title: Text(
          l10n.tr(ar: 'معاينة الاستيراد', en: 'Import preview'),
          style: TextStyle(
            color: isDark ? Colors.white : Colors.black87,
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
          ),
        ),
        content: SizedBox(
          width: 560,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  l10n.tr(ar: 'الملف: ${preview.sourceFileName}', en: 'File: ${preview.sourceFileName}'),
                  style: TextStyle(
                    color: isDark ? Colors.white : Colors.black87,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  l10n.tr(ar: 'الورقة المختارة: ${preview.selectedSheetName}', en: 'Selected sheet: ${preview.selectedSheetName}'),
                  style: TextStyle(
                    color: isDark ? Colors.white70 : Colors.black87,
                    fontFamily: 'Cairo',
                  ),
                ),
                Text(
                  l10n.tr(ar: 'صف العناوين: ${preview.headerRowNumber}', en: 'Header row: ${preview.headerRowNumber}'),
                  style: TextStyle(
                    color: isDark ? Colors.white70 : Colors.black87,
                    fontFamily: 'Cairo',
                  ),
                ),
                Text(
                  l10n.tr(ar: 'عدد الصفوف المكتشفة: ${preview.importedRowsCount}', en: 'Detected rows: ${preview.importedRowsCount}'),
                  style: TextStyle(
                    color: isDark ? Colors.white70 : Colors.black87,
                    fontFamily: 'Cairo',
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  l10n.tr(ar: 'ربط الأعمدة:', en: 'Column mapping:'),
                  style: TextStyle(
                    color: isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A),
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                ...preview.mappedColumns.entries.map(
                  (e) => Text(
                    '• ${_columnTitle(e.key)} ⟵ ${e.value}',
                    style: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black87,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  l10n.tr(ar: 'أول الصفوف بعد التطبيع:', en: 'First rows after normalization:'),
                  style: TextStyle(
                    color: isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A),
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                if (sampleLines.isEmpty)
                  Text(
                    l10n.tr(ar: 'لا توجد عينة متاحة.', en: 'No sample available.'),
                    style: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black87,
                      fontFamily: 'Cairo',
                    ),
                  )
                else
                  ...sampleLines.map(
                    (line) => Text(
                      line,
                      style: TextStyle(
                        color: isDark ? Colors.white70 : Colors.black87,
                        fontFamily: 'Cairo',
                        fontSize: 12,
                      ),
                    ),
                  ),
                if (preview.warnings.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Text(
                    l10n.tr(ar: 'تحذيرات:', en: 'Warnings:'),
                    style: TextStyle(
                      color: Colors.orange,
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...preview.warnings.take(5).map(
                    (w) => Text(
                      '• $w',
                      style: const TextStyle(
                        color: Colors.orange,
                        fontFamily: 'Cairo',
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(
              l10n.tr(ar: 'إلغاء', en: 'Cancel'),
              style: TextStyle(
                fontFamily: 'Cairo',
                color: isDark ? Colors.white70 : Colors.black54,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A),
              foregroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
            ),
            child: Text(
              l10n.tr(ar: 'اعتماد الاستيراد', en: 'Confirm import'),
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );

    return approved ?? false;
  }

  String _columnTitle(String key) {
    switch (key) {
      case 'date':
        return l10n.tr(ar: 'التاريخ', en: 'Date');
      case 'fajr':
        return l10n.tr(ar: 'الفجر', en: 'Fajr');
      case 'sunrise':
        return l10n.tr(ar: 'الشروق', en: 'Sunrise');
      case 'dhuhr':
        return l10n.tr(ar: 'الظهر', en: 'Dhuhr');
      case 'asr':
        return l10n.tr(ar: 'العصر', en: 'Asr');
      case 'maghrib':
        return l10n.tr(ar: 'المغرب', en: 'Maghrib');
      case 'isha':
        return l10n.tr(ar: 'العشاء', en: 'Isha');
      default:
        return key;
    }
  }

  String _formatImportError(Object error) {
    if (error is ExcelImportException) {
      if (error.technicalDetails != null) {
        debugPrint('[ExcelImportScreen] details: ${error.technicalDetails}');
      }
      return error.userMessage;
    }

    final raw = error.toString();
    if (raw.contains('Exception:')) {
      return raw.split('Exception:').last.trim();
    }
    return raw.trim();
  }
  Future<void> _handleDelete() async {
    final settings = ref.read(settingsNotifierProvider);
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.1),
      builder: (ctx) => LuxuryConfirmDialog(
        title: l10n.tr(ar: 'تأكيد الحذف', en: 'Confirm deletion'),
        message: l10n.tr(ar: 'هل أنت متأكد من حذف البيانات المخصصة والعودة للتوقيت التلقائي؟', en: 'Are you sure you want to delete custom data and return to automatic timings?'),
        confirmLabel: l10n.tr(ar: 'نعم، حذف', en: 'Yes, delete'),
        onConfirm: () async {
          await _importService.deleteCustomFile(settings.country, settings.city);
          ref.read(settingsNotifierProvider.notifier).updateSettings(
            settings.copyWith(
              customTimesFilePath: null, 
              useCustomPrayerTimes: false,
              customTimesCountry: 'CUSTOM',
              customTimesCity: 'custom',
            )
          );
          if (mounted) GlassToast.show(context, l10n.tr(ar: 'تم استعادة النظام الأصلي', en: 'Original system restored'));
        },
      ),
    );
  }
}

class SUpdateImportButton extends StatelessWidget {
  final VoidCallback onTap;
  const SUpdateImportButton({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accentColor = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    return Container(
      width: double.infinity,
      height: 64,
      decoration: BoxDecoration(
        boxShadow: !isDark ? [BoxShadow(color: accentColor.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 8))] : null,
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentColor,
          foregroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          elevation: isDark ? 4 : 0,
        ),
        onPressed: onTap,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_upload_rounded),
            const SizedBox(width: 12),
            Text(AppLocalizations.of(context).tr(ar: 'استيراد ملف Excel الآن', en: 'Import Excel file now'), style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w900, fontSize: 18)),
          ],
        ),
      ),
    );
  }
}

class LoadingLuxuryWidget extends StatelessWidget {
  const LoadingLuxuryWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
        
    return Column(
      children: [
        CircularProgressIndicator(color: accent),
        const SizedBox(height: 12),
        Text(AppLocalizations.of(context).tr(ar: 'جاري معالجة البيانات...', en: 'Processing data...'), style: TextStyle(fontFamily: 'Cairo', color: accent, fontWeight: FontWeight.bold)),
      ],
    );
  }
}





