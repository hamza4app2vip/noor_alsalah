import 'dart:ui';
import 'dart:io';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/widgets/feature_tour_overlay.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../announcements/presentation/providers/announcement_provider.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/services/update_checker_service.dart';
import '../../../../core/services/custom_location_service.dart';
import '../../domain/entities/app_settings.dart';
import '../../../../core/widgets/glass_toast.dart';
import 'remote_control_screen.dart';
import '../../domain/entities/adhan_sound.dart';
import '../../../prayer_times/presentation/providers/location_provider.dart'
    as loc;
import '../../../prayer_times/presentation/providers/timer_engine_provider.dart';
import '../../../prayer_times/presentation/screens/adhan_screen.dart';
import '../../../prayer_times/presentation/screens/iqama_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'settings_export_import_screen.dart';
import 'marquee_settings_screen.dart';
import 'prayer_adjustments_screen.dart';
import 'background_changing_screen.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'azkar_settings_screen.dart';
import 'app_update_screen.dart';
import 'slides_management_screen.dart';
import 'weather_gps_settings_screen.dart';
import 'excel_import_screen.dart';
import '../../../../core/services/excel_import_service.dart';
import 'adhan_sounds_management_screen.dart';
import 'activity_log_screen.dart';
import '../providers/settings_provider.dart';
import '../widgets/glass_selection_dialog.dart';
import '../widgets/glassy_theme_picker.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/luxury_time_picker.dart';
import '../../../contact_us/presentation/screens/contact_us_screen.dart';
import '../../../announcements/presentation/screens/announcements_screen.dart';
import 'language_selection_screen.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  bool _isUpdateSkipped = false;

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isMandatory =
        UpdateCheckerService.instance.latestUpdate?.isMandatory == true;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Container(
              decoration: LuxuryGlassTheme.getPageDecoration(isDark),
              child: _SettingsContent(settings: settings),
            ),
            if (isMandatory && !_isUpdateSkipped)
              _MandatoryUpdateLock(
                onSkip: () {
                  setState(() {
                    _isUpdateSkipped = true;
                  });
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _SettingsContent extends ConsumerStatefulWidget {
  final AppSettings settings;
  const _SettingsContent({required this.settings});

  @override
  ConsumerState<_SettingsContent> createState() => _SettingsContentState();
}

class _SettingsContentState extends ConsumerState<_SettingsContent> {
  final GlobalKey _tourMosqueIconKey = GlobalKey();
  final GlobalKey _tourFlagIconKey = GlobalKey();
  final GlobalKey _tourGeneralKey = GlobalKey();
  final GlobalKey _tourLocationKey = GlobalKey();
  final GlobalKey _tourPrayerAdjustmentsKey = GlobalKey();
  final GlobalKey _tourIdentityKey = GlobalKey();
  final GlobalKey _tourLayoutKey = GlobalKey();
  final GlobalKey _tourBackgroundsKey = GlobalKey();
  final GlobalKey _tourSlidesKey = GlobalKey();
  final GlobalKey _tourAdhanAlertsKey = GlobalKey();
  final GlobalKey _tourAudioKey = GlobalKey();
  final GlobalKey _tourExcelKey = GlobalKey();
  final GlobalKey _tourMarqueeKey = GlobalKey();
  final GlobalKey _tourRemoteControlKey = GlobalKey();
  final GlobalKey _tourFontsKey = GlobalKey();
  final GlobalKey _tourContactKey = GlobalKey();
  final GlobalKey _tourChangelogKey = GlobalKey();
  final GlobalKey _tourLanguagesKey = GlobalKey();
  final GlobalKey _tourUpdateKey = GlobalKey();
  bool _tourStarted = false;

  AppLocalizations get l10n => AppLocalizations.of(context);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowTour());
  }

  Future<void> _maybeShowTour() async {
    if (_tourStarted || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    final seen = prefs.getBool('settings_feature_tour_v2') ?? false;
    if (seen) return;
    _tourStarted = true;
    if (!mounted) return;

    // Add a slight delay to ensure UI is fully rendered and animations settled
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;

    final dontShowAgain = await FeatureTourOverlay.show(
      context,
      steps: _buildTourSteps(),
      activeColor: _accent,
    );

    if (dontShowAgain == true) {
      await prefs.setBool('settings_feature_tour_v2', true);
    } else {
      if (mounted) {
        setState(() {
          _tourStarted = false;
        });
      }
    }
  }

  List<FeatureTourStep> _buildTourSteps() {
    return [
      FeatureTourStep(
        titleAr: 'شعار المسجد',
        bodyAr:
            'يمكنك وضع صورة مخصصة لشعار المسجد مباشرة من هذا الزر في الشريط العلوي.',
        titleEn: 'Mosque Logo',
        bodyEn:
            'You can assign a custom mosque logo directly from this top bar button.',
        targetKey: _tourMosqueIconKey,
        targetPadding: const EdgeInsets.all(1),
        targetRadius: 18,
      ),
      FeatureTourStep(
        titleAr: 'العلم أو الصورة البديلة',
        bodyAr:
            'يمكنك اختيار علم مخصص أو صورة بديلة تظهر في الشريط العلوي من هذا الزر.',
        titleEn: 'Flag or Alternate Image',
        bodyEn:
            'You can choose a custom flag or alternate image for the top bar from this button.',
        targetKey: _tourFlagIconKey,
        targetPadding: const EdgeInsets.all(1),
        targetRadius: 18,
      ),
      FeatureTourStep(
        titleAr: 'عامة وتقارير',
        bodyAr:
            'تصدير البيانات، تغيير التاريخ الهجري، واسم المسجد والإعدادات العامة الأساسية.',
        titleEn: 'General & Reports',
        bodyEn:
            'Export data, adjust Hijri date, mosque name, and core general settings.',
        targetKey: _tourGeneralKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الموقع والطقس',
        bodyAr: 'تحديد موقع المسجد والمدينة والبلد والطقس لضبط المواقيت بدقة.',
        titleEn: 'Location & Weather',
        bodyEn:
            'Configure mosque location, city, country, and weather for accurate timings.',
        targetKey: _tourLocationKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'تخصيص الأوقات والجمعة',
        bodyAr:
            'تعديل مواقيت الصلاة يدويًا وضبط الجمعة والعيد والانحرافات الخاصة.',
        titleEn: 'Prayer Adjustments',
        bodyEn:
            'Adjust prayer times manually and configure Jumuah, Eid, and timing offsets.',
        targetKey: _tourPrayerAdjustmentsKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الهوية والتنسيق',
        bodyAr:
            'التحكم بالهوية البصرية، الألوان، الاتجاه، وظهور بيانات الشاشة.',
        titleEn: 'Identity & Display',
        bodyEn:
            'Control visual identity, colors, orientation, and screen appearance.',
        targetKey: _tourIdentityKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الخلفيات والثيمات',
        bodyAr: 'اختيار الخلفيات والثيمات وربط صور مختلفة بكل صلاة أو بكل يوم.',
        titleEn: 'Themes & Backgrounds',
        bodyEn:
            'Manage themes and backgrounds per prayer, per day, or manually.',
        targetKey: _tourBackgroundsKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'النماذج والتخطيط',
        bodyAr:
            'تغيير شكل شاشة المواقيت، تخطيط الصلوات، وأسلوب العرض داخل الشاشة.',
        titleEn: 'Models & Layout',
        bodyEn:
            'Change prayer screen templates, card layout, and display behavior.',
        targetKey: _tourLayoutKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الرسائل والشرائح',
        bodyAr: 'إدارة الشرائح والرسائل والصور الدعائية التي تظهر على الشاشة.',
        titleEn: 'Messages & Slides',
        bodyEn:
            'Manage slides, messages, and promotional visuals shown on screen.',
        targetKey: _tourSlidesKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الأذان والتنبيهات',
        bodyAr:
            'ضبط تنبيهات الأذان والإقامة وشاشات الصلاة والتنبيهات المرتبطة بها.',
        titleEn: 'Adhan & Alerts',
        bodyEn:
            'Configure adhan, iqama, prayer screens, and related alert behavior.',
        targetKey: _tourAdhanAlertsKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الصوت والتنبيهات الصوتية',
        bodyAr: 'اختيار ملفات الأذان والتنبيهات والتحكم بسلوك الصوت العام.',
        titleEn: 'Audio & Voice Alerts',
        bodyEn: 'Manage adhan files, voice alerts, and global audio behavior.',
        targetKey: _tourAudioKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'استيراد Excel',
        bodyAr: 'استيراد جداول المواقيت من ملف Excel بشكل مباشر.',
        titleEn: 'Excel Import',
        bodyEn: 'Import prayer schedules directly from an Excel file.',
        targetKey: _tourExcelKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الشريط الإخباري',
        bodyAr:
            'إدارة الرسائل المتحركة التي تظهر أسفل الشاشة في الشريط الإخباري.',
        titleEn: 'Marquee Banner',
        bodyEn:
            'Manage moving ticker messages shown at the bottom of the screen.',
        targetKey: _tourMarqueeKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'التحكم عن بُعد',
        bodyAr:
            'إدارة الشاشة من الهاتف أو أي جهاز آخر من خلال لوحة التحكم عن بُعد.',
        titleEn: 'Remote Control',
        bodyEn:
            'Manage the screen from your phone or another device using remote control.',
        targetKey: _tourRemoteControlKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'الخطوط',
        bodyAr: 'اختيار خطوط التطبيق والساعة والأذكار وأوقات الصلاة.',
        titleEn: 'Fonts',
        bodyEn: 'Choose fonts for the app, clock, azkar, and prayer times.',
        targetKey: _tourFontsKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'تواصل معنا',
        bodyAr: 'الوصول إلى صفحة التواصل والدعم أو إرسال الملاحظات.',
        titleEn: 'Contact Us',
        bodyEn: 'Open the contact page for support and feedback.',
        targetKey: _tourContactKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'سجل التحديثات',
        bodyAr: 'عرض آخر التغييرات والإصلاحات والإضافات داخل التطبيق.',
        titleEn: 'Changelog',
        bodyEn: 'Review the latest changes, fixes, and additions in the app.',
        targetKey: _tourChangelogKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'اللغات',
        bodyAr: 'تغيير لغة التطبيق والتحكم بلغة الواجهة.',
        titleEn: 'Languages',
        bodyEn: 'Change the app language and interface localization.',
        targetKey: _tourLanguagesKey,
        targetPadding: EdgeInsets.zero,
      ),
      FeatureTourStep(
        titleAr: 'التحديثات',
        bodyAr: 'الوصول إلى صفحة التحديثات والتحقق من الإصدار الحالي والجديد.',
        titleEn: 'Updates',
        bodyEn:
            'Open the updates page and check the current and latest version.',
        targetKey: _tourUpdateKey,
        targetPadding: EdgeInsets.zero,
      ),
    ];
  }

  Color get _accent => Theme.of(context).brightness == Brightness.dark
      ? AppColors.goldAccent
      : const Color(0xFF1AA85A);

  Color _getTextColor(bool isDark) => isDark ? Colors.white : Colors.black87;
  Color _getSubTextColor(bool isDark) =>
      isDark ? Colors.white70 : Colors.black54;
  Color _getCardColor(bool isDark) =>
      isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white;
  Color _getBg(bool isDark) =>
      isDark ? const Color(0xFF0F172A) : const Color(0xFFF2F5F9);

  void _update(AppSettings newSettings) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(newSettings);
  }

  Widget _buildSectionHeader(String title) {
    final accentColor = _accent;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            width: 4,
            height: 20,
            decoration: BoxDecoration(
              color: accentColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                fontFamily: 'Cairo',
                color: accentColor),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 12,
                    offset: const Offset(0, 2))
              ]
            : null,
      ),
      child: Column(children: children),
    );
  }

  Widget _buildToggle(String title, bool value, Function(bool) onChanged) {
    return _buildDarkToggle(title, '', value, onChanged);
  }

  Widget _buildTextInput(
      String title, String value, Function(String) onChanged) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;

    Future<void> handleTap() async {
      final controller = TextEditingController(text: value);
      final result = await showDialog<String>(
        context: context,
        builder: (ctx) => Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E293B) : Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: isDark ? Colors.white10 : Colors.transparent),
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(l10n.tr(ar: 'تعديل $title', en: 'Edit $title'),
                        style: TextStyle(
                            color: _getTextColor(isDark),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo')),
                    const SizedBox(height: 20),
                    TextField(
                      controller: controller,
                      autofocus: true,
                      onSubmitted: (value) => Navigator.pop(ctx, value),
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                          color: _getTextColor(isDark),
                          fontSize: 16,
                          fontFamily: 'Cairo'),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: _getBg(isDark),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                              color: isDark ? Colors.white10 : Colors.black12),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: accent),
                        ),
                        hintText: l10n.tr(
                            ar: 'أدخل $title...', en: 'Enter $title...'),
                        hintStyle: TextStyle(
                            fontFamily: 'Cairo',
                            color: _getSubTextColor(isDark)
                                .withValues(alpha: 0.3)),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                                style: TextStyle(
                                    fontFamily: 'Cairo',
                                    color: _getSubTextColor(isDark))),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            onPressed: () =>
                                Navigator.pop(ctx, controller.text),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accent,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text(l10n.tr(ar: 'حفظ', en: 'Save'),
                                style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
      if (result != null) onChanged(result);
    }

    return Column(
      children: [
        TvFocusable(
          onPressed: handleTap,
          borderRadius: BorderRadius.circular(14),
          focusColor: accent,
          child: ListTile(
            onTap: null,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            title: Text(title,
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _getTextColor(isDark),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Cairo')),
            leading: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accent.withValues(alpha: 0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.edit_rounded, color: accent, size: 18),
                  const SizedBox(width: 8),
                  Text(value,
                      style: TextStyle(
                          color: accent,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo')),
                ],
              ),
            ),
          ),
        ),
        Divider(
            color:
                isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
            height: 1,
            indent: 16,
            endIndent: 16),
      ],
    );
  }

  Widget _buildNumericInput(String title, int value, Function(int) onChanged,
      {String suffix = ''}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;

    Future<void> handleTap() async {
      final controller = TextEditingController(text: value.toString());
      final result = await showDialog<String>(
        context: context,
        builder: (ctx) => Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E293B) : Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: isDark ? Colors.white10 : Colors.transparent),
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(l10n.tr(ar: 'تعديل $title', en: 'Edit $title'),
                        style: TextStyle(
                            color: _getTextColor(isDark),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo')),
                    const SizedBox(height: 20),
                    TextField(
                      controller: controller,
                      autofocus: true,
                      onSubmitted: (value) => Navigator.pop(ctx, value),
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                          color: _getTextColor(isDark),
                          fontSize: 16,
                          fontFamily: 'Cairo'),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: _getBg(isDark),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                              color: isDark ? Colors.white10 : Colors.black12),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: accent),
                        ),
                        hintText:
                            l10n.tr(ar: 'أدخل الرقم...', en: 'Enter number...'),
                        hintStyle: TextStyle(
                            fontFamily: 'Cairo',
                            color: _getSubTextColor(isDark)
                                .withValues(alpha: 0.3)),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                                style: TextStyle(
                                    fontFamily: 'Cairo',
                                    color: _getSubTextColor(isDark))),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            onPressed: () =>
                                Navigator.pop(ctx, controller.text),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accent,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text(l10n.tr(ar: 'حفظ', en: 'Save'),
                                style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
      if (result != null && int.tryParse(result) != null) {
        onChanged(int.parse(result));
      }
    }

    return Column(
      children: [
        TvFocusable(
          onPressed: handleTap,
          borderRadius: BorderRadius.circular(14),
          focusColor: accent,
          child: ListTile(
            onTap: null,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            title: Text(title,
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _getTextColor(isDark),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Cairo')),
            leading: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accent.withValues(alpha: 0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.edit_rounded, color: accent, size: 18),
                  const SizedBox(width: 8),
                  Text('$value $suffix',
                      style: TextStyle(
                          color: accent,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo')),
                ],
              ),
            ),
          ),
        ),
        Divider(
            color:
                isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
            height: 1,
            indent: 16,
            endIndent: 16),
      ],
    );
  }

  Widget _buildSmallNavAvatar({
    Key? key,
    String? imagePath,
    required IconData defaultIcon,
    required VoidCallback onTap,
    required bool isDark,
    required Color accent,
  }) {
    final iconColor = isDark ? Colors.white : Colors.black;
    final borderColor = isDark
        ? const Color.fromRGBO(255, 255, 255, 0.1)
        : const Color.fromRGBO(0, 0, 0, 0.1);
    final bgColor = isDark
        ? const Color.fromRGBO(255, 255, 255, 0.05)
        : const Color.fromRGBO(0, 0, 0, 0.05);

    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(18.0),
      focusColor: accent,
      child: Container(
        key: key,
        width: 36.0,
        height: 36.0,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: bgColor,
          border: Border.all(color: borderColor, width: 1.0),
        ),
        alignment: Alignment.center,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: imagePath != null
              ? Image.file(
                  File(imagePath),
                  width: 36.0,
                  height: 36.0,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Icon(defaultIcon, color: iconColor, size: 18),
                )
              : Icon(defaultIcon, color: iconColor, size: 18),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;
    final updateService = UpdateCheckerService.instance;
    final latestUpdate = updateService.latestUpdate;
    final bool showUpdateUi = latestUpdate?.showUpdateUi ?? true;
    final bool isUpToDate = !updateService.hasUpdate && latestUpdate != null;
    final hasAnnouncements = ref.watch(activeAnnouncementsProvider).maybeWhen(
          data: (items) => items.isNotEmpty,
          orElse: () => false,
        );

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: PremiumGlassNavbar(
        title: l10n.settingsTitle,
        hasNotifications: hasAnnouncements,
        showBell: true,
        onNotificationTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AnnouncementsScreen()),
          );
        },
        actions: [
          _buildSmallNavAvatar(
            key: _tourMosqueIconKey,
            imagePath: ref.watch(settingsNotifierProvider).mosqueIconPath,
            defaultIcon: Icons.mosque_rounded,
            onTap: _pickMosqueImage,
            isDark: isDark,
            accent: accent,
          ),
          const SizedBox(width: 8.0),
          _buildSmallNavAvatar(
            key: _tourFlagIconKey,
            imagePath: ref.watch(settingsNotifierProvider).customFlagPath,
            defaultIcon: Icons.flag_rounded,
            onTap: _pickCustomFlagImage,
            isDark: isDark,
            accent: accent,
          ),
        ],
      ),
      body: Container(
        decoration: LuxuryGlassTheme.getPageDecoration(isDark),
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
          children: [
            // ─── MODERN HEADER PROFILE ───
            Container(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
              child: Column(
                children: [
                  Text(
                    ref.read(settingsNotifierProvider).mosqueName,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: _getTextColor(isDark),
                      fontFamily: 'Cairo',
                    ),
                  ),
                  Text(
                    '${ref.read(settingsNotifierProvider).city}، ${ref.read(settingsNotifierProvider).country}',
                    style: TextStyle(
                      fontSize: 14,
                      color: _getSubTextColor(isDark),
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ],
              ),
            ),

            if (showUpdateUi && (updateService.hasUpdate || isUpToDate))
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: isUpToDate
                        ? (isDark
                            ? const Color(0xFF132A1F)
                            : const Color(0xFFECFDF5))
                        : (isDark
                            ? const Color(0xFF1E293B)
                            : const Color(0xFFF0FDF4)),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isUpToDate
                          ? (isDark
                              ? const Color(0xFF10B981).withValues(alpha: 0.3)
                              : const Color(0xFFBBF7D0))
                          : (isDark
                              ? const Color(0xFF334155)
                              : const Color(0xFFBBF7D0)),
                      width: 1,
                    ),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const AppUpdateScreen()));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: isUpToDate
                                    ? const Color(0xFF10B981)
                                        .withValues(alpha: 0.1)
                                    : const Color(0xFF22C55E)
                                        .withValues(alpha: 0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                  isUpToDate
                                      ? Icons.check_circle_rounded
                                      : Icons.system_update_rounded,
                                  color: const Color(0xFF10B981),
                                  size: 24),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    isUpToDate
                                        ? l10n.upToDate
                                        : l10n.newUpdateAvailable(
                                            latestUpdate?.version ?? ''),
                                    style: TextStyle(
                                      color: _getTextColor(isDark),
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Cairo',
                                    ),
                                  ),
                                  Text(
                                    isUpToDate
                                        ? l10n.appFullyUpdated(
                                            updateService.currentVersion)
                                        : l10n.clickToDownload,
                                    style: TextStyle(
                                      color: _getSubTextColor(isDark),
                                      fontSize: 12,
                                      fontFamily: 'Cairo',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.arrow_forward_ios_rounded,
                                size: 16, color: Colors.grey),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),

            // ─── SETTINGS GROUPS ───
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 40),
              child: Column(
                children: [
                  _buildSettingsGroup(l10n.locationTimeGroup, [
                    _buildEmeraldMenuTile(
                      key: _tourGeneralKey,
                      title: l10n.menuGeneralReports,
                      subtitle: l10n.menuGeneralReportsSubtitle,
                      icon: Icons.tune_rounded,
                      onTap: () => _openSubScreen(
                          l10n.general, () => _buildGeneralTab()),
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourLocationKey,
                      title: l10n.menuLocationWeather,
                      subtitle: l10n.menuLocationSubtitle,
                      icon: Icons.location_on_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const WeatherGpsSettingsScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourPrayerAdjustmentsKey,
                      title: l10n.menuPrayerAdjustments,
                      subtitle: l10n.menuPrayerAdjustSubtitle,
                      icon: Icons.calendar_month_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const PrayerAdjustmentsScreen()));
                      },
                    ),
                  ]),
                  _buildSettingsGroup(l10n.settingsAppearanceSlides, [
                    _buildEmeraldMenuTile(
                      key: _tourIdentityKey,
                      title: l10n.menuIdentityLayout,
                      subtitle: l10n.menuIdentitySubtitle,
                      icon: Icons.dashboard_customize_rounded,
                      onTap: () => _openSubScreen(
                          l10n.display, () => _buildDisplayTab()),
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourBackgroundsKey,
                      title: l10n.menuThemesBackgrounds,
                      subtitle: l10n.menuThemesSubtitle,
                      icon: Icons.image_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const BackgroundChangingScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourLayoutKey,
                      title: l10n.menuModelsLayout,
                      subtitle: l10n.menuModelsSubtitle,
                      icon: Icons.view_quilt_rounded,
                      onTap: () => _openSubScreen(
                          l10n.prayers, () => _buildPrayersListTab()),
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourSlidesKey,
                      title: l10n.menuMessagesSlides,
                      subtitle: l10n.menuMessagesSubtitle,
                      icon: Icons.view_carousel_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const SlidesManagementScreen()));
                      },
                    ),
                  ]),
                  _buildSettingsGroup(l10n.settingsAdhanFiles, [
                    _buildEmeraldMenuTile(
                      key: _tourAdhanAlertsKey,
                      title: l10n.menuAdhanAlerts,
                      subtitle: l10n.menuAdhanSubtitle,
                      icon: Icons.notifications_active_rounded,
                      onTap: () => _openSubScreen(
                          l10n.adhanIqama, () => _buildAdhanIqamaTab()),
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourAudioKey,
                      title: l10n.menuAudioAlarms,
                      subtitle: l10n.menuAudioSubtitle,
                      icon: Icons.volume_up_rounded,
                      onTap: () => _openSubScreen(
                          l10n.audio,
                          () => ListView(
                                padding:
                                    const EdgeInsets.fromLTRB(16, 110, 16, 40),
                                children: [
                                  ..._buildAlertsItems(),
                                  const SizedBox(height: 16),
                                  ..._buildAudioItems(),
                                ],
                              )),
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourExcelKey,
                      title: l10n.menuExcelImport,
                      subtitle: l10n.menuExcelSubtitle,
                      icon: Icons.description_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const ExcelImportScreen()));
                      },
                    ),
                  ]),
                  _buildSettingsGroup(l10n.settingsAdvanced, [
                    _buildEmeraldMenuTile(
                      key: _tourMarqueeKey,
                      title: l10n.menuMarqueeTitle,
                      subtitle: l10n.menuMarqueeSubtitle,
                      icon: Icons.chat_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const MarqueeSettingsScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourRemoteControlKey,
                      title: l10n.menuRemoteTitle,
                      subtitle: l10n.menuRemoteSubtitle,
                      icon: Icons.wifi_tethering_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const RemoteControlScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourFontsKey,
                      title: l10n.appFonts,
                      subtitle: l10n.appFontsSubtitle,
                      icon: Icons.font_download_rounded,
                      onTap: () => _openSubScreen(
                          l10n.appFonts, () => _buildFontsTab(),
                          isFull: true),
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourContactKey,
                      title: l10n.menuContact,
                      subtitle: l10n.menuContactSubtitle,
                      icon: Icons.alternate_email_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const ContactUsScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourChangelogKey,
                      title: l10n.changelog,
                      subtitle: l10n.menuChangelogSubtitle,
                      icon: Icons.assignment_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const ActivityLogScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourLanguagesKey,
                      title: l10n.languages,
                      subtitle: l10n.menuLanguagesSubtitle,
                      icon: Icons.language_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const LanguageSelectionScreen()));
                      },
                    ),
                    _buildEmeraldMenuTile(
                      key: _tourUpdateKey,
                      title: l10n.menuUpdateTitle,
                      subtitle: l10n.menuUpdateSubtitle,
                      icon: Icons.system_update_rounded,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const AppUpdateScreen()));
                      },
                    ),
                    FutureBuilder<PackageInfo>(
                      future: PackageInfo.fromPlatform(),
                      builder: (context, snapshot) {
                        final version = snapshot.data?.version ?? '...';
                        return Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 24.0, horizontal: 16.0),
                          child: Center(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 16.0, horizontal: 24.0),
                              decoration: BoxDecoration(
                                color: isDark
                                    ? _getCardColor(isDark)
                                        .withValues(alpha: 0.1)
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(
                                  color: isDark
                                      ? _accent.withValues(alpha: 0.15)
                                      : _accent.withValues(alpha: 0.3),
                                  width: 1.5,
                                ),
                                boxShadow: isDark
                                    ? [
                                        BoxShadow(
                                          color: Colors.black
                                              .withValues(alpha: 0.2),
                                          blurRadius: 15,
                                          offset: const Offset(0, 5),
                                        ),
                                      ]
                                    : [
                                        BoxShadow(
                                          color:
                                              _accent.withValues(alpha: 0.08),
                                          blurRadius: 15,
                                          offset: const Offset(0, 5),
                                        ),
                                      ],
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.info_outline_rounded,
                                        color: isDark
                                            ? _accent.withValues(alpha: 0.8)
                                            : _accent,
                                        size: 18,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        l10n.appVersion(version),
                                        style: TextStyle(
                                          color: _getTextColor(isDark)
                                              .withValues(
                                                  alpha: isDark ? 0.9 : 0.7),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Cairo',
                                          letterSpacing: 0.5,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: _accent.withValues(
                                          alpha: isDark ? 0.1 : 0.08),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          Icons.code_rounded,
                                          color: _accent,
                                          size: 16,
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          l10n.developmentBy('XTeam'),
                                          style: TextStyle(
                                            color: _accent,
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Cairo',
                                            letterSpacing: 0.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGeneralTab() {
    final accent = _accent;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 90, 16, 32),
      children: [
        _buildSectionHeader(l10n.helpAndRestore),
        _buildSettingsCard([
          _buildInfoTile(Icons.import_export_rounded, accent,
              l10n.menuSynchronize, l10n.menuSynchronize, () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const SettingsExportImportScreen()));
          }),
          _darkDivider(),
          _buildTextInput(
              l10n.mosqueName,
              ref.read(settingsNotifierProvider).mosqueName,
              (v) => _update(
                  ref.read(settingsNotifierProvider).copyWith(mosqueName: v))),
          _darkDivider(),
          _buildInfoTile(Icons.add_photo_alternate_rounded, accent,
              l10n.mosqueIcon, l10n.chooseFromGallery, _pickMosqueImage),
          _darkDivider(),
          _buildNumericInput(
              l10n.mainClockOffset,
              ref.read(settingsNotifierProvider).clockOffsetMinutes,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(clockOffsetMinutes: v)),
              suffix: l10n.unitMinute),
          _darkDivider(),
          _buildToggle(
              l10n.showHijriDate,
              ref.read(settingsNotifierProvider).showHijriDate,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(showHijriDate: v))),
        ]),
        const SizedBox(height: 16),
        _buildSectionHeader(l10n.appTimeCustomization),
        _buildSettingsCard([
          _buildToggle(
              l10n.manualTimeEntry,
              ref.read(settingsNotifierProvider).isManualTimeEnabled,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(isManualTimeEnabled: v))),
          if (ref.read(settingsNotifierProvider).isManualTimeEnabled) ...[
            _darkDivider(),
            _buildInfoTile(
                Icons.access_time_filled_rounded,
                accent,
                l10n.manualTimeAdjustment,
                ref.read(settingsNotifierProvider).manualTimeValue ??
                    l10n.notSet,
                () => _selectManualTime()),
          ],
        ]),
        const SizedBox(height: 16),
        _buildSectionHeader(l10n.location),
        _buildSettingsCard([
          _buildInfoTile(Icons.gps_fixed_rounded, accent,
              l10n.weatherLocationSettings, l10n.gpsWeatherStatus, () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const WeatherGpsSettingsScreen()));
          }),
          _darkDivider(),
          FutureBuilder<Map<String, String>>(
            future: ref.read(loc.countriesNameProvider.future),
            builder: (context, snapshot) {
              final countryCode = ref.watch(settingsNotifierProvider).country;
              final countryName =
                  snapshot.data?[countryCode.toLowerCase()] ?? countryCode;
              return _buildInfoTile(
                Icons.public_rounded,
                accent,
                l10n.countryWithName(countryName),
                l10n.tapToChangeCountry,
                () {
                  if (mounted) _selectCountry();
                },
              );
            },
          ),
          _darkDivider(),
          _buildInfoTile(
              Icons.location_city_rounded,
              accent,
              l10n.cityWithName(
                  _formatCityName(ref.watch(settingsNotifierProvider).city)),
              l10n.tapToChangeCity, () {
            if (mounted) _selectCity();
          }),
        ]),
        const SizedBox(height: 16),
        _buildSectionHeader(l10n.settingsAdvanced),
        _buildSettingsCard([
          _buildDarkNavTile(l10n.factoryReset, l10n.resetSettingsToDefault,
              Icons.restore_page_rounded, Colors.redAccent, () {
            _factoryResetSettings();
          }),
        ]),
        const SizedBox(height: 32),
      ],
    );
  }

  Future<void> _selectManualTime() async {
    final settings = ref.read(settingsNotifierProvider);
    TimeOfDay initialTime = TimeOfDay.now();
    if (settings.manualTimeValue != null) {
      final parts = settings.manualTimeValue!.split(':');
      if (parts.length == 2) {
        initialTime = TimeOfDay(
          hour: int.tryParse(parts[0]) ?? 0,
          minute: int.tryParse(parts[1]) ?? 0,
        );
      }
    }

    final l10n = AppLocalizations.of(context);
    final TimeOfDay? picked = await LuxuryTimePicker.show(
      context,
      initialTime: initialTime,
      title: l10n.manualTimeAdjustment,
    );

    if (picked != null) {
      final String timeStr =
          '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
      _update(settings.copyWith(manualTimeValue: timeStr));
    }
  }

  Future<void> _factoryResetSettings() async {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;

    final confirm1 = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        title: Text(l10n.factoryReset,
            style:
                TextStyle(fontFamily: 'Cairo', color: _getTextColor(isDark))),
        content: Text(l10n.confirmFactoryReset1,
            style: TextStyle(
                fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(l10n.cancel, style: TextStyle(color: accent))),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white),
              child: Text(l10n.yesSure,
                  style: const TextStyle(fontFamily: 'Cairo'))),
        ],
      ),
    );

    if (confirm1 != true) return;

    if (!mounted) return;

    final confirm2 = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        title: Text(l10n.factoryReset,
            style: TextStyle(fontFamily: 'Cairo', color: Colors.redAccent)),
        content: Text(l10n.confirmFactoryReset2,
            style: TextStyle(
                fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(l10n.cancel, style: TextStyle(color: accent))),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white),
              child: Text(l10n.yesSure,
                  style: const TextStyle(fontFamily: 'Cairo'))),
        ],
      ),
    );

    if (confirm2 != true) return;

    ref.read(settingsNotifierProvider.notifier).resetToDefault();
    if (mounted) {
      GlassToast.show(context, l10n.settingsResetSuccess);
    }
    _selectClockStyle();
  }

  Future<void> _selectClockStyle() async {
    final l10n = AppLocalizations.of(context);
    final settings = ref.read(settingsNotifierProvider);

    final greenGoldTitle = Localizations.localeOf(context).languageCode == 'ar'
        ? 'أخضر ذهبي فاخر'
        : 'Green Gold';

    final String? result = await showDialog<String>(
      context: context,
      builder: (ctx) => GlassSelectionDialog<String>(
        title: l10n.analogClockStyle,
        items: [
          GlassSelectionItem(
            title: l10n.classicGlass,
            value: 'GLASS',
          ),
          GlassSelectionItem(
            title: l10n.luxuryGold,
            value: 'GOLDEN',
          ),
          GlassSelectionItem(
            title: l10n.royalIslamic,
            value: 'ROYAL',
          ),
          GlassSelectionItem(
            title: greenGoldTitle,
            value: 'GREEN_GOLD',
          ),
        ],
        initialValue: settings.analogClockStyle,
      ),
    );

    if (result != null) {
      _update(settings.copyWith(analogClockStyle: result));
    }
  }

  String _analogClockStyleTitle(String style) {
    final l10n = AppLocalizations.of(context);
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    switch (style) {
      case 'GOLDEN':
        return l10n.luxuryGold;
      case 'ROYAL':
        return l10n.royalIslamic;
      case 'GREEN_GOLD':
        return isArabic ? 'أخضر ذهبي فاخر' : 'Green Gold';
      default:
        return l10n.classicGlass;
    }
  }

  Future<void> _selectNavbarPosition() async {
    final l10n = AppLocalizations.of(context);
    final settings = ref.read(settingsNotifierProvider);

    final String? result = await showDialog<String>(
      context: context,
      builder: (ctx) => GlassSelectionDialog<String>(
        title: l10n.navbarPositionLandscape,
        items: [
          GlassSelectionItem(
            title: l10n.fullScreenWidth,
            value: 'FULL',
          ),
          GlassSelectionItem(
            title: l10n.centered,
            value: 'CENTER',
          ),
          GlassSelectionItem(
            title: l10n.sideMode,
            value: 'SIDE',
          ),
        ],
        initialValue: settings.navbarPosition,
      ),
    );

    if (result != null) {
      _update(settings.copyWith(navbarPosition: result));
    }
  }

  Widget _buildDisplayTab() {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 90, 16, 32),
      children: [
        _buildDarkSection(l10n.appTheme, Icons.palette_rounded),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GlassyThemePicker(
            currentValue: ref.read(settingsNotifierProvider).themeMode,
            onChanged: (v) => _update(
                ref.read(settingsNotifierProvider).copyWith(themeMode: v)),
          ),
        ),
        _buildDarkSection(l10n.prayerScreenTheme, Icons.style_rounded),
        _buildThemeSelector(),
        _buildDarkSection(l10n.visualIdentity, Icons.palette_rounded),
        _buildDarkCard([
          _buildDarkToggle(
              l10n.countryFlag,
              l10n.showCountryFlagDesc,
              ref.read(settingsNotifierProvider).showCountryFlag,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(showCountryFlag: v)),
              icon: Icons.flag_rounded,
              iconColor: const Color(0xFF2ECC71)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.format24h,
              l10n.format24hDesc,
              ref.read(settingsNotifierProvider).is24HourFormat,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(is24HourFormat: v)),
              icon: Icons.access_time_rounded,
              iconColor: const Color(0xFF3498DB)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.padWithZero,
              l10n.padWithZeroDesc,
              ref.read(settingsNotifierProvider).padTimesWithZero,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(padTimesWithZero: v)),
              icon: Icons.format_list_numbered_rounded,
              iconColor: const Color(0xFFDAA520)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.fullClock,
              l10n.fullClockDesc,
              ref.read(settingsNotifierProvider).showFullClock,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(showFullClock: v)),
              icon: Icons.timer_rounded,
              iconColor: const Color(0xFFE74C3C)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.analogClock,
              l10n.analogClockDesc,
              ref.read(settingsNotifierProvider).enableAnalogGlassClock,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(enableAnalogGlassClock: v)),
              icon: Icons.watch_later_rounded,
              iconColor: const Color(0xFF38BDF8)),
          if (ref.read(settingsNotifierProvider).enableAnalogGlassClock) ...[
            _darkDivider(),
            _buildInfoTile(
              Icons.auto_awesome_motion_rounded,
              const Color(0xFFDAA520),
              l10n.analogClockStyle,
              _analogClockStyleTitle(
                ref.read(settingsNotifierProvider).analogClockStyle,
              ),
              () => _selectClockStyle(),
            ),
            _darkDivider(),
            _buildDarkToggle(
                l10n.analogClockDateFrame,
                l10n.analogClockDateFrameDesc,
                ref.read(settingsNotifierProvider).showAnalogClockDateFrame,
                (v) => _update(ref
                    .read(settingsNotifierProvider)
                    .copyWith(showAnalogClockDateFrame: v)),
                icon: Icons.date_range_rounded,
                iconColor: const Color(0xFFF39C12)),
          ],
          _darkDivider(),
          _buildDarkToggle(
              l10n.analogClockNumbers,
              l10n.analogClockNumbersDesc,
              ref.read(settingsNotifierProvider).showAnalogClockNumbers,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(showAnalogClockNumbers: v)),
              icon: Icons.format_list_numbered_rounded,
              iconColor: const Color(0xFF7DD3FC)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.glassShine,
              l10n.glassShineDesc,
              ref.read(settingsNotifierProvider).glassShineEnabled,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(glassShineEnabled: v)),
              icon: Icons.auto_awesome_rounded,
              iconColor: const Color(0xFF5DADE2)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.nightPrayerTimes,
              l10n.nightPrayerTimesDesc,
              ref.read(settingsNotifierProvider).showNightPrayers,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(showNightPrayers: v)),
              icon: Icons.nights_stay_rounded,
              iconColor: const Color(0xFF8E44AD)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.marqueeTicker,
              l10n.marqueeTickerDesc,
              ref.read(settingsNotifierProvider).showMarqueeTicker,
              (v) => _update(ref
                  .read(settingsNotifierProvider)
                  .copyWith(showMarqueeTicker: v)),
              icon: Icons.pending_actions_rounded,
              iconColor: const Color(0xFF16A085)),
          _darkDivider(),
          _buildInfoTile(
            Icons.view_quilt_rounded,
            const Color(0xFF9B59B6),
            l10n.navbarPositionLandscape,
            ref.read(settingsNotifierProvider).navbarPosition == 'FULL'
                ? l10n.fullScreenWidth
                : ref.read(settingsNotifierProvider).navbarPosition == 'CENTER'
                    ? l10n.centered
                    : l10n.sideMode,
            () => _selectNavbarPosition(),
          ),
        ]),
        if (ref.read(settingsNotifierProvider).appTheme == 'PURE_GLASS') ...[
          _buildDarkSection(
              l10n.pureGlassCustomization, Icons.color_lens_rounded),
          _buildDarkCard([
            _buildDarkNavTile(
              l10n.fontColor,
              l10n.fontColorDesc,
              Icons.format_color_text_rounded,
              _parseHex(ref.read(settingsNotifierProvider).pureGlassTextColor),
              () => _selectColor(
                title: l10n.chooseFontColor,
                currentValue:
                    ref.read(settingsNotifierProvider).pureGlassTextColor,
                onSelected: (hex) => _update(ref
                    .read(settingsNotifierProvider)
                    .copyWith(pureGlassTextColor: hex)),
              ),
            ),
            _darkDivider(),
            _buildDarkNavTile(
              l10n.bgColor1,
              l10n.bgColor1Desc,
              Icons.circle,
              _parseHex(ref.read(settingsNotifierProvider).pureGlassColor1),
              () => _selectColor(
                title: l10n.bgColor1,
                currentValue:
                    ref.read(settingsNotifierProvider).pureGlassColor1,
                onSelected: (hex) => _update(ref
                    .read(settingsNotifierProvider)
                    .copyWith(pureGlassColor1: hex)),
              ),
            ),
            _darkDivider(),
            _buildDarkNavTile(
              l10n.bgColor2,
              l10n.bgColor2Desc,
              Icons.circle,
              _parseHex(ref.read(settingsNotifierProvider).pureGlassColor2),
              () => _selectColor(
                title: l10n.bgColor2,
                currentValue:
                    ref.read(settingsNotifierProvider).pureGlassColor2,
                onSelected: (hex) => _update(ref
                    .read(settingsNotifierProvider)
                    .copyWith(pureGlassColor2: hex)),
              ),
            ),
            _darkDivider(),
            _buildDarkNavTile(
              l10n.bgColor3,
              l10n.bgColor3Desc,
              Icons.circle,
              _parseHex(ref.read(settingsNotifierProvider).pureGlassColor3),
              () => _selectColor(
                title: l10n.bgColor3,
                currentValue:
                    ref.read(settingsNotifierProvider).pureGlassColor3,
                onSelected: (hex) => _update(ref
                    .read(settingsNotifierProvider)
                    .copyWith(pureGlassColor3: hex)),
              ),
            ),
          ]),
        ],
        _buildDarkSection(
            l10n.screenOrientation, Icons.screen_rotation_rounded),
        _buildDarkCard([
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                for (final e in <Map<String, dynamic>>[
                  {
                    'key': 'AUTO',
                    'label': l10n.auto,
                    'icon': Icons.screen_rotation_rounded
                  },
                  {
                    'key': 'PORTRAIT',
                    'label': l10n.portrait,
                    'icon': Icons.stay_current_portrait_rounded
                  },
                  {
                    'key': 'LANDSCAPE',
                    'label': l10n.landscape,
                    'icon': Icons.stay_current_landscape_rounded
                  },
                ])
                  Expanded(
                    child: TvFocusable(
                      onPressed: () => _update(ref
                          .read(settingsNotifierProvider)
                          .copyWith(appOrientation: e['key'] as String)),
                      borderRadius: BorderRadius.circular(12),
                      focusColor: accent,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: ref
                                      .read(settingsNotifierProvider)
                                      .appOrientation ==
                                  e['key']
                              ? accent.withValues(alpha: 0.12)
                              : _getBg(isDark),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: ref
                                          .read(settingsNotifierProvider)
                                          .appOrientation ==
                                      e['key']
                                  ? accent
                                  : (isDark
                                      ? Colors.white10
                                      : const Color(0xFFE0E0E0)),
                              width: ref
                                          .read(settingsNotifierProvider)
                                          .appOrientation ==
                                      e['key']
                                  ? 1.5
                                  : 1.0),
                          boxShadow: ref
                                          .read(settingsNotifierProvider)
                                          .appOrientation ==
                                      e['key'] &&
                                  !isDark
                              ? [
                                  BoxShadow(
                                      color: accent.withValues(alpha: 0.15),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2))
                                ]
                              : null,
                        ),
                        child: Column(children: [
                          Icon(e['icon'] as IconData,
                              color: ref
                                          .read(settingsNotifierProvider)
                                          .appOrientation ==
                                      e['key']
                                  ? accent
                                  : _getSubTextColor(isDark),
                              size: 22),
                          const SizedBox(height: 6),
                          Text(e['label'] as String,
                              style: TextStyle(
                                  color: ref
                                              .read(settingsNotifierProvider)
                                              .appOrientation ==
                                          e['key']
                                      ? accent
                                      : _getSubTextColor(isDark),
                                  fontSize: 12,
                                  fontFamily: 'Cairo',
                                  fontWeight: ref
                                              .read(settingsNotifierProvider)
                                              .appOrientation ==
                                          e['key']
                                      ? FontWeight.bold
                                      : FontWeight.w500)),
                        ]),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ]),
        _buildDarkSection(l10n.announcementsSlides, Icons.announcement_rounded),
        _buildDarkCard([
          _buildInfoTile(Icons.wallpaper_rounded, accent, l10n.changeWallpaper,
              l10n.changeWallpaperDesc, () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const BackgroundChangingScreen()));
          }),
          _darkDivider(),
          _buildInfoTile(Icons.slideshow_rounded, accent,
              l10n.advertisingSlides, l10n.manageSlidesDesc, () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const SlidesManagementScreen()));
          }),
          _darkDivider(),
          _buildInfoTile(Icons.text_snippet_rounded, accent,
              l10n.newsTickerVerses, l10n.marqueeTickerDesc, () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const MarqueeSettingsScreen()));
          }),
        ]),
      ],
    );
  }

  Widget _buildDarkSlider(
    String title,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged, {
    IconData? icon,
    Color? iconColor,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          if (icon != null) ...[
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: (iconColor ?? _accent).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: iconColor ?? _accent, size: 22),
            ),
            const SizedBox(width: 16),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: isDark ? Colors.white : const Color(0xFF1E293B),
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Cairo',
                  ),
                ),
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 4.0,
                    thumbShape:
                        const RoundSliderThumbShape(enabledThumbRadius: 8.0),
                    overlayShape:
                        const RoundSliderOverlayShape(overlayRadius: 16.0),
                  ),
                  child: Focus(
                    canRequestFocus: true,
                    onKeyEvent: (node, event) {
                      if (event is KeyDownEvent || event is KeyRepeatEvent) {
                        if (event.logicalKey == LogicalKeyboardKey.arrowRight ||
                            event.logicalKey ==
                                LogicalKeyboardKey.audioVolumeUp) {
                          final newValue =
                              (value + (max - min) / 20).clamp(min, max);
                          if (newValue != value) onChanged(newValue);
                          return KeyEventResult.handled;
                        }
                        if (event.logicalKey == LogicalKeyboardKey.arrowLeft ||
                            event.logicalKey ==
                                LogicalKeyboardKey.audioVolumeDown) {
                          final newValue =
                              (value - (max - min) / 20).clamp(min, max);
                          if (newValue != value) onChanged(newValue);
                          return KeyEventResult.handled;
                        }
                        if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
                          FocusManager.instance.primaryFocus
                              ?.focusInDirection(TraversalDirection.up);
                          return KeyEventResult.handled;
                        }
                        if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
                          FocusManager.instance.primaryFocus
                              ?.focusInDirection(TraversalDirection.down);
                          return KeyEventResult.handled;
                        }
                      }
                      return KeyEventResult.ignored;
                    },
                    child: Builder(builder: (context) {
                      final isFocused = Focus.of(context).hasFocus;
                      return Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 2),
                        decoration: isFocused
                            ? BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: _accent, width: 2),
                                color: _accent.withValues(alpha: 0.1),
                              )
                            : const BoxDecoration(
                                border: Border.fromBorderSide(BorderSide(
                                    color: Colors.transparent, width: 2)),
                              ),
                        child: ExcludeFocus(
                          child: Slider(
                            value: value,
                            min: min,
                            max: max,
                            activeColor: _accent,
                            inactiveColor:
                                isDark ? Colors.white12 : Colors.grey[300],
                            onChanged: onChanged,
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            value.toInt().toString(),
            style: TextStyle(
              color: isDark ? Colors.white70 : Colors.black87,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayersListTab() {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsNotifierProvider);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 90, 16, 32),
      children: [
        _buildDarkSection(l10n.displayOptions, Icons.display_settings_rounded),
        _buildDarkCard([
          _buildDarkToggle(
              l10n.option2,
              l10n.dimPastPrayersDesc,
              settings.dimPastPrayers,
              (v) => _update(settings.copyWith(dimPastPrayers: v)),
              icon: Icons.brightness_medium_rounded,
              iconColor: const Color(0xFF64748B)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.centerNamesLandscape,
              l10n.centerNamesLandscapeDesc,
              settings.centerPrayerNamesLandscape,
              (v) => _update(settings.copyWith(centerPrayerNamesLandscape: v)),
              icon: Icons.format_align_center_rounded,
              iconColor: const Color(0xFF10B981)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.centerNamesPortrait,
              l10n.centerNamesPortraitDesc,
              settings.centerPrayerNamesPortrait,
              (v) => _update(settings.copyWith(centerPrayerNamesPortrait: v)),
              icon: Icons.align_horizontal_center_rounded,
              iconColor: const Color(0xFF38BDF8)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.centerPrayerNameMixed,
              l10n.tr(
                  ar: 'يُوسّط الاسم ويضع وقت الأذان والإقامة على الجانبين في الكلاسيكي والزجاجي',
                  en: 'Centers the prayer name and places adhan and iqama on the sides in classic and glass themes'),
              settings.centerNameWithTimesOnSides,
              (v) => _update(settings.copyWith(centerNameWithTimesOnSides: v)),
              icon: Icons.list_alt_rounded,
              iconColor: const Color(0xFF8B5CF6)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.tr(
                  ar: 'اسم الصلاة بلغة أخرى',
                  en: 'Prayer name in other language'),
              l10n.tr(
                  ar:
                      'يعرض اسم الصلاة باللغة الثانية بجانب الاسم الحالي بشكل أنيق في شاشة المواقيت',
                  en:
                      'Show the prayer name in the second language alongside the current one on the prayer screen'),
              settings.showPrayerNameInOtherLanguage,
              (v) =>
                  _update(settings.copyWith(showPrayerNameInOtherLanguage: v)),
              icon: Icons.translate_rounded,
              iconColor: const Color(0xFF22C55E)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.enlargeNamesLandscape,
              l10n.enlargeNamesLandscapeDesc,
              settings.enlargePrayerNamesLandscape,
              (v) => _update(settings.copyWith(enlargePrayerNamesLandscape: v)),
              icon: Icons.zoom_in_rounded,
              iconColor: const Color(0xFFF59E0B)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.showIqamaWithClock,
              l10n.hideIqamaTimeDesc,
              settings.showIqamaWithClock,
              (v) => _update(settings.copyWith(showIqamaWithClock: v)),
              icon: Icons.access_time_filled_rounded,
              iconColor: const Color(0xFF10B981)),
          _darkDivider(),
          _buildDarkToggle(l10n.blackClockMode, l10n.blackClockModeDesc,
              settings.blackClockModeEnabled, (v) {
            final current = ref.read(settingsNotifierProvider);
            _update(current.copyWith(
              blackClockModeEnabled: v,
              azkarOnlyScreenEnabled:
                  v ? false : current.azkarOnlyScreenEnabled,
            ));
          }, icon: Icons.dark_mode_rounded, iconColor: const Color(0xFF1E293B)),
          if (settings.blackClockModeEnabled) ...[
            _darkDivider(),
            _buildDarkToggle(
                l10n.blackClockUseGlass,
                l10n.blackClockUseGlassDesc,
                settings.blackClockModeUseGlass,
                (v) => _update(settings.copyWith(blackClockModeUseGlass: v)),
                icon: Icons.blur_on_rounded,
                iconColor: const Color(0xFF38BDF8)),
            _darkDivider(),
            _buildInfoTile(
              Icons.image_rounded,
              const Color(0xFFF59E0B),
              l10n.customClockBg,
              settings.blackClockModeCustomBgPath == null
                  ? l10n.noCustomImage
                  : l10n.customImageSet,
              _pickBlackClockModeCustomBgImage,
            ),
            if (settings.blackClockModeCustomBgPath != null) ...[
              _darkDivider(),
              _buildInfoTile(
                Icons.delete_outline_rounded,
                const Color(0xFFEF4444),
                l10n.removeClockBg,
                l10n.returnToGlassOrBlack,
                _clearBlackClockModeCustomBgImage,
              ),
            ],
          ],
        ]),
        _buildDarkSection(l10n.prayerListFontSizes, Icons.format_size_rounded),
        _buildDarkCard([
          _buildDarkSlider(
            l10n.prayerNameFontSize,
            settings.prayerNameFontSize,
            14.0,
            50.0,
            (v) => _update(settings.copyWith(prayerNameFontSize: v)),
            icon: Icons.text_fields_rounded,
            iconColor: const Color(0xFF3498DB),
          ),
          _darkDivider(),
          _buildDarkSlider(
            l10n.adhanTimeFontSize,
            settings.prayerTimeFontSize,
            14.0,
            55.0,
            (v) => _update(settings.copyWith(prayerTimeFontSize: v)),
            icon: Icons.access_time_rounded,
            iconColor: const Color(0xFF2ECC71),
          ),
          _darkDivider(),
          _buildDarkSlider(
            l10n.iqamaTimeFontSize,
            settings.iqamaTimeFontSize,
            12.0,
            45.0,
            (v) => _update(settings.copyWith(iqamaTimeFontSize: v)),
            icon: Icons.timer_outlined,
            iconColor: const Color(0xFFE74C3C),
          ),
        ]),
        _buildDarkSection(l10n.countdown, Icons.hourglass_top_rounded),
        _buildDarkCard([
          _buildDarkToggle(
              l10n.showCountdown,
              l10n.nextPrayerTimeDesc,
              settings.showCountdown,
              (v) => _update(settings.copyWith(showCountdown: v)),
              icon: Icons.timer_rounded,
              iconColor: const Color(0xFF2ECC71)),
          _darkDivider(),
          _buildDarkToggle(l10n.enlargeCountdown, '', settings.enlargeCountdown,
              (v) => _update(settings.copyWith(enlargeCountdown: v)),
              icon: Icons.zoom_in_map_rounded,
              iconColor: const Color(0xFF3498DB)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.largeCountdownLastMin,
              l10n.opensSeparateBlackScreen,
              settings.showFullscreenCountdownAtThreshold,
              (v) => _update(
                  settings.copyWith(showFullscreenCountdownAtThreshold: v)),
              icon: Icons.fullscreen_rounded,
              iconColor: const Color(0xFFE74C3C)),
          _buildDarkToggle(
              l10n.enlargeNextPrayerCountdown,
              l10n.largeCountdownNextPrayer,
              settings.enlargeNextPrayerCountdown,
              (v) => _update(settings.copyWith(enlargeNextPrayerCountdown: v)),
              icon: Icons.expand_rounded,
              iconColor: const Color(0xFF9B59B6)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.colorGreenLast90s,
              l10n.changeCountdownColorGreen,
              settings.countdownGreenLast90s,
              (v) => _update(settings.copyWith(countdownGreenLast90s: v)),
              icon: Icons.color_lens_rounded,
              iconColor: const Color(0xFF2ECC71)),
        ]),
        _buildDarkSection(l10n.otherOptions, Icons.settings_rounded),
        _buildDarkCard([
          _buildDarkToggle(
              l10n.useArabicIndicDigits,
              l10n.useArabicIndicDigitsDesc,
              settings.useArabicIndicDigits,
              (v) => _update(settings.copyWith(useArabicIndicDigits: v)),
              iconColor: _accent),
        ]),
      ],
    );
  }

  Widget _buildAdhanIqamaTab() {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsNotifierProvider);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 90, 16, 32),
      children: [
        // ── معاينة الأذان والإقامة ──
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Row(
            children: [
              Expanded(
                child: TvFocusable(
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => IqamaScreen(
                                prayerName: l10n.prayerDhuhr,
                                remainingTime: '08:30',
                                hadith: l10n.straightenRowsHadith,
                              ))),
                  borderRadius: BorderRadius.circular(16),
                  focusColor: _accent,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    decoration: BoxDecoration(
                      color: _accent.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _accent.withValues(alpha: 0.4)),
                    ),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.timer_rounded, color: _accent, size: 28),
                      const SizedBox(height: 8),
                      Text(l10n.previewIqamaScreen,
                          style: TextStyle(
                              color: _accent,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                              fontSize: 12),
                          textAlign: TextAlign.center),
                    ]),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TvFocusable(
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AdhanScreen(
                                currentPrayer: PrayerName.dhuhr,
                              ))),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    decoration: BoxDecoration(
                      color: Colors.green.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: Colors.green.withValues(alpha: 0.35)),
                    ),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.mosque_rounded,
                          color: Colors.green, size: 28),
                      const SizedBox(height: 8),
                      Text(l10n.previewAdhanScreen,
                          style: const TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                              fontSize: 12),
                          textAlign: TextAlign.center),
                    ]),
                  ),
                ),
              ),
            ],
          ),
        ),
        _buildDarkSection(l10n.adhanIqamaScreens, Icons.mosque_rounded),
        _buildDarkCard([
          _buildDarkToggle(l10n.showAdhanScreen, '', settings.showAdhanScreen,
              (v) => _update(settings.copyWith(showAdhanScreen: v)),
              icon: Icons.speaker_rounded, iconColor: Colors.green),
          _darkDivider(),
          _buildDarkToggle(
              l10n.iqamaScreenLabel,
              l10n.showBeforeBlackScreen,
              settings.showIqamaScreen,
              (v) => _update(settings.copyWith(showIqamaScreen: v)),
              icon: Icons.timer_rounded,
              iconColor: _accent),
          _darkDivider(),
          _buildDarkToggle(
              l10n.translucentScreens,
              l10n.enableTranslucencyDesc,
              settings.useTranslucentScreens,
              (v) => _update(settings.copyWith(useTranslucentScreens: v)),
              icon: Icons.blur_on_rounded,
              iconColor: const Color(0xFF3498DB)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.shadingBehindTimes,
              l10n.shadingBehindTimesDesc,
              settings.showBackgroundShadingBehindTimes,
              (v) => _update(
                  settings.copyWith(showBackgroundShadingBehindTimes: v)),
              icon: Icons.gradient_rounded,
              iconColor: const Color(0xFF8E44AD)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.swapDateMosqueLandscape,
              '',
              settings.swapDateAndMosqueLandscape,
              (v) => _update(settings.copyWith(swapDateAndMosqueLandscape: v)),
              icon: Icons.swap_horiz_rounded,
              iconColor: const Color(0xFFE67E22)),
          _darkDivider(),
          _buildDarkToggle(
              l10n.internetStatusIndicator,
              '',
              settings.showInternetStatus,
              (v) => _update(settings.copyWith(showInternetStatus: v)),
              icon: Icons.wifi_rounded,
              iconColor: const Color(0xFF16A085)),
        ]),
      ],
    );
  }

  // Helper: returns alert items for use in combined ListView
  List<Widget> _buildAlertsItems() {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsNotifierProvider);
    return [
      _buildDarkSection(
          l10n.adhanIqamaAlerts, Icons.notifications_active_rounded),
      _buildDarkCard([
        _buildDarkToggle(
            l10n.alertBeforeAdhan,
            l10n.alertBeforeAdhanDesc,
            settings.showPreAdhanBeep,
            (v) => _update(settings.copyWith(showPreAdhanBeep: v)),
            icon: Icons.notifications_none_rounded,
            iconColor: const Color(0xFF3498DB)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.fajrFirstAdhan,
            l10n.fajrFirstAdhanDesc,
            (settings.fajrPreAdhanAlertMinutes > 0),
            (v) => _update(
                settings.copyWith(fajrPreAdhanAlertMinutes: v ? 10 : 0)),
            icon: Icons.wb_twilight_rounded,
            iconColor: const Color(0xFFF39C12)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.alertIqamaTime,
            l10n.alertIqamaTimeDesc,
            settings.playVoiceAlertBeforeIqama,
            (v) => _update(settings.copyWith(playVoiceAlertBeforeIqama: v)),
            icon: Icons.alarm_rounded,
            iconColor: const Color(0xFFE74C3C)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.prayerDhikr,
            l10n.prayerDhikrDesc,
            settings.showHadithBeforeIqama,
            (v) => _update(settings.copyWith(showHadithBeforeIqama: v)),
            icon: Icons.mosque_rounded,
            iconColor: const Color(0xFF2ECC71)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.tasbihAfterAdhan,
            l10n.tasbihAfterAdhanDesc,
            settings.enablePostPrayerAzkar,
            (v) => _update(settings.copyWith(enablePostPrayerAzkar: v)),
            icon: Icons.linear_scale_rounded,
            iconColor: const Color(0xFFDAA520)),
      ]),
      _buildDarkSection(l10n.morningEveningAzkar, Icons.wb_sunny_rounded),
      _buildDarkCard([
        _buildDarkToggle(
            l10n.morningAzkar,
            l10n.morningAzkarDesc,
            settings.enableSabahAzkar,
            (v) => _update(settings.copyWith(enableSabahAzkar: v)),
            icon: Icons.wb_sunny_rounded,
            iconColor: const Color(0xFFF5B041)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.eveningAzkar,
            l10n.eveningAzkarDesc,
            settings.enableMasaaAzkar,
            (v) => _update(settings.copyWith(enableMasaaAzkar: v)),
            icon: Icons.nightlight_rounded,
            iconColor: const Color(0xFF8E44AD)),
        _darkDivider(),
        _buildDarkToggle(l10n.azkarOnlyScreen, l10n.azkarOnlyScreenDesc,
            settings.azkarOnlyScreenEnabled, (v) {
          final current = ref.read(settingsNotifierProvider);
          _update(current.copyWith(
            azkarOnlyScreenEnabled: v,
            blackClockModeEnabled: v ? false : current.blackClockModeEnabled,
          ));
        },
            icon: Icons.vertical_align_top_rounded,
            iconColor: const Color(0xFF16A085)),
        if (settings.azkarOnlyScreenEnabled) ...[
          _darkDivider(),
          _buildDarkToggle(
              l10n.azkarGlassBg,
              l10n.azkarGlassBgDesc,
              settings.azkarOnlyScreenUseGlass,
              (v) => _update(settings.copyWith(azkarOnlyScreenUseGlass: v)),
              icon: Icons.blur_on_rounded,
              iconColor: const Color(0xFF58D68D)),
          _darkDivider(),
          _buildInfoTile(
              Icons.image_rounded,
              const Color(0xFF58D68D),
              l10n.customAzkarBg,
              settings.azkarOnlyScreenCustomBgPath == null
                  ? l10n.noCustomImage
                  : l10n.customImageSet,
              _pickAzkarOnlyScreenCustomBgImage),
          if (settings.azkarOnlyScreenCustomBgPath != null) ...[
            _darkDivider(),
            _buildInfoTile(
                Icons.delete_outline_rounded,
                const Color(0xFFE74C3C),
                l10n.removeAzkarBg,
                l10n.returnToGlassOrBlack,
                _clearAzkarOnlyScreenCustomBgImage),
          ],
        ],
        _darkDivider(),
        _buildDarkNavTile(l10n.postPrayerAzkarAdv, l10n.postPrayerAzkarAdvDesc,
            Icons.menu_book_rounded, const Color(0xFF08452F), () {
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AzkarSettingsScreen()));
        }),
      ]),
    ];
  }

  // Helper: returns audio items for use in combined ListView
  List<Widget> _buildAudioItems() {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final defaultSoundName = settings.defaultAdhanSoundId == null
        ? l10n.defaultSoundName
        : settings.customAdhanSounds
            .firstWhere((s) => s.id == settings.defaultAdhanSoundId,
                orElse: () =>
                    AdhanSound(id: '', name: l10n.unknown, filePath: ''))
            .name;

    return [
      _buildDarkSection(
          l10n.customAdhanSoundsGroup, Icons.library_music_rounded),
      _buildDarkCard([
        _buildDarkNavTile(l10n.manageAdhanSounds, l10n.manageAdhanSoundsDesc,
            Icons.queue_music_rounded, const Color(0xFFD4AF37), () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const AdhanSoundsManagementScreen()));
        }),
        _darkDivider(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(l10n.defaultAdhanSound,
                  style: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black87,
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  Expanded(
                    child: Text(defaultSoundName,
                        style: TextStyle(
                            color: _accent, fontFamily: 'Cairo', fontSize: 13)),
                  ),
                  _buildEmeraldButton(
                      l10n.change,
                      () => _selectAdhanSound(
                          title: l10n.selectDefaultSound,
                          currentId: settings.defaultAdhanSoundId,
                          onSelected: (id) => _update(
                              settings.copyWith(defaultAdhanSoundId: id)))),
                ],
              ),
            ],
          ),
        ),
        _darkDivider(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(l10n.customizePerPrayer,
                  style: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black87,
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildPrayerSoundSelector(l10n.prayerFajr, 'fajr', settings),
              _buildPrayerSoundSelector(l10n.prayerDhuhr, 'dhuhr', settings),
              _buildPrayerSoundSelector(l10n.prayerAsr, 'asr', settings),
              _buildPrayerSoundSelector(
                  l10n.prayerMaghrib, 'maghrib', settings),
              _buildPrayerSoundSelector(l10n.prayerIsha, 'isha', settings),
            ],
          ),
        ),
      ]),
      _buildDarkSection(l10n.adhanTypeSpeedGroup, Icons.surround_sound_rounded),
      _buildDarkCard([
        _buildDarkToggle(
            l10n.mp3Adhan,
            l10n.mp3AdhanDesc,
            settings.useMp3ForAdhan,
            (v) => _update(settings.copyWith(useMp3ForAdhan: v)),
            icon: Icons.audiotrack_rounded,
            iconColor: const Color(0xFF2ECC71)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.shortAdhan,
            l10n.shortAdhanDesc,
            settings.useShortAdhan,
            (v) => _update(settings.copyWith(useShortAdhan: v)),
            icon: Icons.fast_forward_rounded,
            iconColor: const Color(0xFF3498DB)),
        _darkDivider(),
        _buildDarkToggle(
            l10n.shortIqama,
            l10n.shortIqamaDesc,
            settings.useShortIqama,
            (v) => _update(settings.copyWith(useShortIqama: v)),
            icon: Icons.compress_rounded,
            iconColor: _accent),
      ]),
    ];
  }

  Widget _buildPrayerSoundSelector(
      String prayerNameAr, String prayerId, AppSettings settings) {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final soundId = settings.prayerAdhanSoundIds[prayerId];
    final soundName = soundId == null
        ? l10n.followsDefault
        : settings.customAdhanSounds
            .firstWhere((s) => s.id == soundId,
                orElse: () =>
                    AdhanSound(id: '', name: l10n.unknown, filePath: ''))
            .name;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          SizedBox(
            width: 60,
            child: Text(prayerNameAr,
                style: TextStyle(
                    color: isDark ? Colors.white54 : Colors.black54,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(soundName,
                style: TextStyle(
                    color: soundId == null ? Colors.grey : _accent,
                    fontFamily: 'Cairo',
                    fontSize: 13),
                overflow: TextOverflow.ellipsis),
          ),
          _buildEmeraldButton(
              l10n.select,
              () => _selectAdhanSound(
                  title: l10n.adhanSoundFor(prayerNameAr),
                  currentId: soundId,
                  allowDefault: true,
                  onSelected: (id) {
                    final map =
                        Map<String, String>.from(settings.prayerAdhanSoundIds);
                    if (id == null) {
                      map.remove(prayerId);
                    } else {
                      map[prayerId] = id;
                    }
                    _update(settings.copyWith(prayerAdhanSoundIds: map));
                  })),
        ],
      ),
    );
  }

  Future<void> _selectAdhanSound(
      {required String title,
      String? currentId,
      bool allowDefault = false,
      required Function(String?) onSelected}) async {
    final l10n = AppLocalizations.of(context);
    final settings = ref.read(settingsNotifierProvider);
    final items = <GlassSelectionItem<String?>>[];

    if (allowDefault) {
      items.add(
          GlassSelectionItem<String?>(title: l10n.followsDefault, value: null));
    } else {
      items.add(
          GlassSelectionItem<String?>(title: l10n.builtInSound, value: null));
    }

    for (var s in settings.customAdhanSounds) {
      items.add(GlassSelectionItem<String?>(title: s.name, value: s.id));
    }

    final result = await showDialog<String?>(
      context: context,
      builder: (_) => GlassSelectionDialog<String?>(
        title: title,
        items: items,
        initialValue: currentId,
      ),
    );

    if (result != currentId) {
      onSelected(result);
    }
  }

  Widget _buildEmeraldButton(String text, VoidCallback onTap) {
    final accent = _accent;

    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(10),
      focusColor: accent,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: accent.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: accent.withValues(alpha: 0.2)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.keyboard_arrow_down_rounded, color: accent, size: 18),
            const SizedBox(width: 6),
            Text(
              text,
              style: TextStyle(
                color: accent,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFontDropdownCard({
    required String label,
    required String icon,
    required String currentFont,
    required List<String> fonts,
    required Function(String) onChanged,
  }) {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final textColor = _getTextColor(isDark);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color:
                isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05)),
        boxShadow: !isDark
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.03),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        label,
                        style: TextStyle(
                          color: textColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Cairo',
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        l10n.currentFontLabel(currentFont),
                        style: TextStyle(
                          color: _getSubTextColor(isDark),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                _buildEmeraldButton(
                  l10n.change,
                  () async {
                    final items = fonts
                        .map((f) => GlassSelectionItem<String>(
                              title: f,
                              value: f,
                            ))
                        .toList();

                    final result = await showDialog<String>(
                      context: context,
                      builder: (_) => GlassSelectionDialog<String>(
                        title: l10n.chooseFontFor(label),
                        items: items,
                        initialValue: currentFont,
                      ),
                    );

                    if (result != null) onChanged(result);
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Divider(
                color: isDark
                    ? Colors.white10
                    : Colors.black.withValues(alpha: 0.05),
                height: 1),
            const SizedBox(height: 16),
            Align(
              alignment: Alignment.centerRight,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    l10n.tr(
                        ar: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
                        en: 'In the name of Allah, the Most Compassionate, the Most Merciful'),
                    style: TextStyle(
                        color: textColor,
                        fontFamily: currentFont,
                        fontSize: 24,
                        height: 1.6),
                    textDirection: TextDirection.rtl,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '0123456789   —   $currentFont',
                    style: TextStyle(
                        color: _getSubTextColor(isDark),
                        fontFamily: currentFont,
                        fontSize: 14),
                    textDirection: TextDirection.ltr,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFontsTab() {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final commonFonts = ['Cairo', 'Amiri', 'Tajawal', 'Almarai', 'Changa'];
    final textFonts = ['Cairo', 'Roboto', 'Inter', 'Outfit'];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 90, 16, 32),
      children: [
        // Hint card
        Container(
          margin: const EdgeInsets.only(bottom: 24, top: 8),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _accent.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _accent.withValues(alpha: 0.2)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Icon(Icons.info_outline_rounded, color: _accent, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  l10n.changeFontHint,
                  style: TextStyle(
                      color: _getSubTextColor(isDark),
                      fontSize: 13,
                      fontFamily: 'Cairo'),
                  textDirection: TextDirection.rtl,
                ),
              ),
            ],
          ),
        ),
        // Font cards
        _buildFontDropdownCard(
          label: l10n.azkarFont,
          icon: '',
          currentFont: settings.azkarFontFamily,
          fonts: commonFonts,
          onChanged: (v) => _update(settings.copyWith(azkarFontFamily: v)),
        ),
        _buildFontDropdownCard(
          label: l10n.clockFont,
          icon: '',
          currentFont: settings.clockFontFamily,
          fonts: commonFonts,
          onChanged: (v) => _update(settings.copyWith(clockFontFamily: v)),
        ),
        _buildFontDropdownCard(
          label: l10n.prayerTimesFont,
          icon: '',
          currentFont: settings.timesFontFamily,
          fonts: commonFonts,
          onChanged: (v) => _update(settings.copyWith(timesFontFamily: v)),
        ),
        _buildFontDropdownCard(
          label: l10n.generalTextFont,
          icon: '',
          currentFont: settings.textFontFamily,
          fonts: textFonts,
          onChanged: (v) => _update(settings.copyWith(textFontFamily: v)),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Future<void> _selectCountry() async {
    BuildContext? loadingDialogContext;

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (dialogCtx) {
        loadingDialogContext = dialogCtx;
        return const Center(child: CircularProgressIndicator());
      },
    );

    try {
      final locations = await ref.read(loc.availableLocationsProvider.future);
      final names = await ref.read(loc.countriesNameProvider.future);
      await Future.delayed(const Duration(milliseconds: 100));

      if (mounted && loadingDialogContext?.mounted == true) {
        Navigator.of(loadingDialogContext!).pop();
        loadingDialogContext = null;
      }

      if (!mounted) return;

      final items = <GlassSelectionItem<String>>[];

      // Add first option "Add your country"
      items.add(GlassSelectionItem<String>(
        title: l10n.addNewLocation,
        subtitle: l10n.addNewLocationDesc,
        value: 'ADD_YOUR_COUNTRY',
      ));

      for (var code in locations.keys) {
        final lowerCode = code.toLowerCase();
        items.add(GlassSelectionItem<String>(
          title: names[lowerCode] ?? code,
          subtitle: code,
          value: code,
        ));
      }

      final result = await showDialog<String>(
        context: context,
        builder: (_) => GlassSelectionDialog<String>(
          title: l10n.chooseCountry,
          items: items,
          initialValue: ref.read(settingsNotifierProvider).country,
        ),
      );

      if (result == 'ADD_YOUR_COUNTRY') {
        if (mounted) await _addNewCustomLocation();
        return;
      }

      if (result != null &&
          result != ref.read(settingsNotifierProvider).country) {
        final oldCountry = ref.read(settingsNotifierProvider).country;
        final oldCity = ref.read(settingsNotifierProvider).city;

        // Find default first city for new country
        final cities = locations[result] ?? [];
        final newCity = cities.isNotEmpty ? cities.first : 'Unknown';

        if (mounted) {
          await _handleExcelDependencyOnLocationChange(
            oldCountry: oldCountry,
            oldCity: oldCity,
            newCountry: result,
            newCity: newCity,
            onApproved: (updatedSettings) {
              _update(updatedSettings.copyWith(
                country: result,
                city: newCity,
                isAutoLocation: false,
              ));
            },
          );
        }
      }
    } catch (e) {
      if (mounted && loadingDialogContext?.mounted == true) {
        Navigator.of(loadingDialogContext!).pop();
        loadingDialogContext = null;
      }
    }
  }

  Future<void> _selectCity() async {
    BuildContext? loadingDialogContext;

    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (dialogCtx) {
        loadingDialogContext = dialogCtx;
        return const Center(child: CircularProgressIndicator());
      },
    );

    try {
      final locations = await ref.read(loc.availableLocationsProvider.future);
      await Future.delayed(const Duration(milliseconds: 100));

      if (mounted && loadingDialogContext?.mounted == true) {
        Navigator.of(loadingDialogContext!).pop();
        loadingDialogContext = null;
      }

      if (!mounted) return;

      final cities =
          locations[ref.read(settingsNotifierProvider).country] ?? [];
      final items = cities
          .map((city) => GlassSelectionItem<String>(
                title: city,
                value: city,
              ))
          .toList();

      final result = await showDialog<String>(
        context: context,
        builder: (_) => GlassSelectionDialog<String>(
          title: l10n.chooseCity,
          items: items,
          initialValue: ref.read(settingsNotifierProvider).city,
        ),
      );

      if (result != null && result != ref.read(settingsNotifierProvider).city) {
        final oldCountry = ref.read(settingsNotifierProvider).country;
        final oldCity = ref.read(settingsNotifierProvider).city;

        if (mounted) {
          await _handleExcelDependencyOnLocationChange(
            oldCountry: oldCountry,
            oldCity: oldCity,
            newCountry: oldCountry,
            newCity: result,
            onApproved: (updatedSettings) {
              _update(updatedSettings.copyWith(
                city: result,
                isAutoLocation: false,
              ));
            },
          );
        }
      }
    } catch (e) {
      if (mounted && loadingDialogContext?.mounted == true) {
        Navigator.of(loadingDialogContext!).pop();
        loadingDialogContext = null;
      }
    }
  }

  Future<void> _handleExcelDependencyOnLocationChange({
    required String oldCountry,
    required String oldCity,
    required String newCountry,
    required String newCity,
    required Function(AppSettings) onApproved,
  }) async {
    final settings = ref.read(settingsNotifierProvider);
    final excelService = ExcelImportService();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // 1. Check if new location already has its own Excel data
    final hasExistingDataForNew =
        await excelService.existsCustomData(newCountry, newCity);

    if (hasExistingDataForNew) {
      if (!mounted) return;
      final useExisting = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
              title: Text(l10n.excelDataExists,
                  style: TextStyle(
                      fontFamily: 'Cairo', color: _getTextColor(isDark))),
              content: Text(l10n.excelDataExistsDesc,
                  style: TextStyle(
                      fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(l10n.noUseOriginal,
                      style:
                          TextStyle(fontFamily: 'Cairo', color: Colors.grey)),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _accent, foregroundColor: Colors.white),
                  child: Text(l10n.yesActivateData,
                      style: TextStyle(fontFamily: 'Cairo')),
                ),
              ],
            ),
          ) ??
          false;

      if (useExisting) {
        final path = await excelService.getCustomFile(
          newCountry,
          newCity,
        );
        onApproved(settings.copyWith(
          useCustomPrayerTimes: true,
          customTimesFilePath: path.path,
          customTimesCountry: newCountry,
          customTimesCity: newCity,
        ));
      } else {
        onApproved(settings.copyWith(
          useCustomPrayerTimes: false,
          customTimesFilePath: null,
        ));
      }
      return;
    }

    // 2. If no existing data for new, but current location HAS Excel data active
    if (settings.useCustomPrayerTimes && settings.customTimesFilePath != null) {
      if (!mounted) return;
      final migrate = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
              title: Text(l10n.applyExcelData,
                  style: TextStyle(
                      fontFamily: 'Cairo', color: _getTextColor(isDark))),
              content: Text(l10n.applyExcelDataDesc,
                  style: TextStyle(
                      fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(l10n.noUseOriginal,
                      style:
                          TextStyle(fontFamily: 'Cairo', color: Colors.grey)),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _accent, foregroundColor: Colors.white),
                  child: Text(l10n.yesApplyData,
                      style: TextStyle(fontFamily: 'Cairo')),
                ),
              ],
            ),
          ) ??
          false;

      if (migrate) {
        final success = await excelService.migrateExcelData(
          oldCountry: oldCountry,
          oldCity: oldCity,
          newCountry: newCountry,
          newCity: newCity,
        );

        if (success) {
          final newFile = await excelService.getCustomFile(newCountry, newCity);
          onApproved(settings.copyWith(
            useCustomPrayerTimes: true,
            customTimesFilePath: newFile.path,
            customTimesCountry: newCountry,
            customTimesCity: newCity,
          ));
        } else {
          onApproved(settings.copyWith(
            useCustomPrayerTimes: false,
            customTimesFilePath: null,
          ));
        }
      } else {
        onApproved(settings.copyWith(
          useCustomPrayerTimes: false,
          customTimesFilePath: null,
        ));
      }
    } else {
      // No active excel logic, just proceed
      onApproved(settings);
    }
  }

  Future<void> _addNewCustomLocation() async {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // 1. Warning Dialog
    final proceed = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Row(
              textDirection: TextDirection.rtl,
              children: [
                const Icon(Icons.warning_amber_rounded,
                    color: Colors.orange, size: 28),
                const SizedBox(width: 8),
                Text(l10n.importantNotice,
                    style: const TextStyle(
                        fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
              ],
            ),
            content: Text(
              l10n.addNewLocationMandatoryExcelDesc,
              style: const TextStyle(fontFamily: 'Cairo', fontSize: 14),
              textDirection: TextDirection.rtl,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(l10n.cancel,
                    style: const TextStyle(
                        fontFamily: 'Cairo', color: Colors.grey)),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accent,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(l10n.yesContinue,
                    style: const TextStyle(fontFamily: 'Cairo')),
              ),
            ],
          ),
        ) ??
        false;

    if (!proceed) return;

    // 2. Prompt for Country Name & Code
    final countryNameCtrl = TextEditingController();
    final countryCodeCtrl = TextEditingController();

    if (!mounted) return;
    final countryData = await showDialog<Map<String, String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(l10n.newCountryData,
            style: const TextStyle(
                fontFamily: 'Cairo', fontWeight: FontWeight.bold),
            textDirection: TextDirection.rtl),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: countryNameCtrl,
              decoration: InputDecoration(
                labelText: l10n.countryNameHint,
                labelStyle: const TextStyle(fontFamily: 'Cairo'),
                filled: true,
                fillColor: _getBg(isDark),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              textDirection: TextDirection.rtl,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: countryCodeCtrl,
              maxLength: 2,
              decoration: InputDecoration(
                labelText: l10n.countryCodeHint,
                labelStyle: const TextStyle(fontFamily: 'Cairo'),
                filled: true,
                fillColor: _getBg(isDark),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              textCapitalization: TextCapitalization.characters,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(l10n.back,
                style: TextStyle(
                    fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
          ),
          ElevatedButton(
            onPressed: () {
              if (countryNameCtrl.text.isNotEmpty &&
                  countryCodeCtrl.text.length == 2) {
                Navigator.pop(ctx, {
                  'name': countryNameCtrl.text.trim(),
                  'code': countryCodeCtrl.text.trim().toUpperCase(),
                });
              } else {
                GlassToast.show(context, l10n.pleaseCompleteDataCorrectly,
                    isError: true);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: Text(l10n.next, style: const TextStyle(fontFamily: 'Cairo')),
          ),
        ],
      ),
    );

    if (countryData == null) return;

    // 3. Prompt for City Name
    final cityNameCtrl = TextEditingController();
    if (!mounted) return;
    final cityName = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(l10n.addFirstCity,
            style: const TextStyle(
                fontFamily: 'Cairo', fontWeight: FontWeight.bold),
            textDirection: TextDirection.rtl),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(l10n.addFirstCityDesc,
                style: const TextStyle(fontFamily: 'Cairo', fontSize: 13),
                textDirection: TextDirection.rtl),
            const SizedBox(height: 16),
            TextField(
              controller: cityNameCtrl,
              decoration: InputDecoration(
                labelText: l10n.cityNameHint,
                labelStyle: const TextStyle(fontFamily: 'Cairo'),
                filled: true,
                fillColor: _getBg(isDark),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              textDirection: TextDirection.rtl,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(l10n.back,
                style: TextStyle(
                    fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
          ),
          ElevatedButton(
            onPressed: () {
              if (cityNameCtrl.text.isNotEmpty) {
                Navigator.pop(ctx, cityNameCtrl.text.trim());
              } else {
                GlassToast.show(context, l10n.pleaseEnterCityName,
                    isError: true);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: Text(l10n.addAndSave,
                style: const TextStyle(fontFamily: 'Cairo')),
          ),
        ],
      ),
    );

    if (cityName == null) return;

    // 4. Save and Update
    final customService = CustomLocationService();
    await customService.saveCountry(countryData['code']!, countryData['name']!);
    await customService.saveCity(countryData['code']!, cityName);

    // Refresh providers
    ref.invalidate(loc.availableLocationsProvider);
    ref.invalidate(loc.countriesNameProvider);

    // Apply change
    _update(ref.read(settingsNotifierProvider).copyWith(
          country: countryData['code']!,
          city: cityName,
          useCustomPrayerTimes: false, // User MUST add excel now
        ));

    // 5. Redirect to Excel Import Screen
    if (mounted) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ExcelImportScreen()),
      );
    }
  }

  Widget _buildThemeSelector() {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final themes = [
      {
        'id': 'EMERALD',
        'name': l10n.themeEmeraldClassic,
        'desc': l10n.themeEmeraldClassicDesc,
        'icon': Icons.grid_view_rounded,
        'color': const Color(0xFF1ABC9C),
      },
      {
        'id': 'PURE_GLASS',
        'name': l10n.themePureGlass,
        'desc': l10n.themePureGlassDesc,
        'icon': Icons.blur_on_rounded,
        'color': const Color(0xFF38BDF8),
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: themes.map((t) {
          final isSelected = settings.appTheme == t['id'];
          final themeColor = t['color'] as Color;

          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: TvFocusable(
                onPressed: () =>
                    _update(settings.copyWith(appTheme: t['id'] as String)),
                borderRadius: BorderRadius.circular(24),
                focusColor: themeColor,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 400),
                  curve: Curves.easeOutQuart,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? themeColor.withValues(alpha: 0.12)
                        : (isDark
                            ? Colors.white.withValues(alpha: 0.03)
                            : Colors.black.withValues(alpha: 0.02)),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: isSelected
                          ? themeColor
                          : (isDark
                              ? Colors.white10
                              : Colors.black.withValues(alpha: 0.05)),
                      width: isSelected ? 2.5 : 1,
                    ),
                    boxShadow: isSelected
                        ? [
                            BoxShadow(
                                color: themeColor.withValues(alpha: 0.15),
                                blurRadius: 20,
                                offset: const Offset(0, 8))
                          ]
                        : null,
                  ),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Column(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 400),
                            curve: Curves.easeOutBack,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? themeColor
                                  : themeColor.withValues(alpha: 0.1),
                              shape: BoxShape.circle,
                              boxShadow: isSelected
                                  ? [
                                      BoxShadow(
                                          color:
                                              themeColor.withValues(alpha: 0.4),
                                          blurRadius: 12,
                                          offset: const Offset(0, 4))
                                    ]
                                  : null,
                            ),
                            child: Icon(t['icon'] as IconData,
                                color: isSelected ? Colors.white : themeColor,
                                size: 32),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            t['name'] as String,
                            style: TextStyle(
                              color: _getTextColor(isDark),
                              fontSize: 16,
                              fontWeight: isSelected
                                  ? FontWeight.w900
                                  : FontWeight.w700,
                              fontFamily: 'Cairo',
                              letterSpacing: 0.2,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            t['desc'] as String,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _getSubTextColor(isDark)
                                  .withValues(alpha: 0.8),
                              fontSize: 11,
                              fontFamily: 'Cairo',
                              height: 1.3,
                            ),
                          ),
                        ],
                      ),
                      Positioned(
                        top: -8,
                        right: -8,
                        child: AnimatedScale(
                          scale: isSelected ? 1.0 : 0.0,
                          duration: const Duration(milliseconds: 400),
                          curve: Curves.elasticOut,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 4,
                                    offset: Offset(0, 2))
                              ],
                            ),
                            child: const Icon(Icons.check_circle_rounded,
                                color: Color(0xFF2ECC71), size: 24),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Future<void> _selectColor({
    required String title,
    required String currentValue,
    required Function(String) onSelected,
  }) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;

    final List<String> colors = [
      '#FFFFFF', // White
      '#38BDF8', // Sky Blue
      '#0EA5E9', // Deep Sky
      '#2ECC71', // Emerald
      '#10B981', // Grass
      '#F59E0B', // Amber
      '#F97316', // Orange
      '#EF4444', // Red
      '#EC4899', // Pink
      '#8B5CF6', // Violet
      '#6366F1', // Indigo
      '#818CF8', // Soft Indigo
      '#E879F9', // Fuchsia
      '#000000', // Black
      '#1E293B', // Slate
      '#64748B', // Blue Gray
    ];

    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: 400,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E293B) : Colors.white,
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 20,
                  offset: const Offset(0, 10))
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title,
                  style: TextStyle(
                      color: _getTextColor(isDark),
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo')),
              const SizedBox(height: 24),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: colors.map((c) {
                  final color = _parseHex(c);
                  final isSelected =
                      currentValue.toUpperCase() == c.toUpperCase();
                  return TvFocusable(
                    onPressed: () => Navigator.pop(ctx, c),
                    borderRadius: BorderRadius.circular(12),
                    focusColor: color,
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: isSelected ? accent : Colors.transparent,
                            width: 3),
                        boxShadow: [
                          BoxShadow(
                              color: color.withValues(alpha: 0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2))
                        ],
                      ),
                      child: isSelected
                          ? const Icon(Icons.check,
                              color: Colors.white, size: 24)
                          : null,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text(l10n.cancel,
                      style: TextStyle(
                          color: _getSubTextColor(isDark),
                          fontFamily: 'Cairo'))),
            ],
          ),
        ),
      ),
    );

    if (result != null) onSelected(result);
  }

  Color _parseHex(String hex, {Color fallback = Colors.white}) {
    try {
      final String safeHex = hex.replaceFirst('#', 'FF');
      return Color(int.parse(safeHex, radix: 16));
    } catch (_) {
      return fallback;
    }
  }

  Future<String> _savePersistentImage(
      String sourcePath, String fileName) async {
    final directory = await getApplicationDocumentsDirectory();
    final appDir = Directory(p.join(directory.path, 'custom_assets'));
    if (!await appDir.exists()) {
      await appDir.create(recursive: true);
    }
    final extension = p.extension(sourcePath);
    final targetPath = p.join(appDir.path, '$fileName$extension');
    final sourceFile = File(sourcePath);
    await sourceFile.copy(targetPath);
    return targetPath;
  }

  Future<void> _pickMosqueImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        final persistentPath =
            await _savePersistentImage(pickedFile.path, 'mosque_icon');
        if (mounted) {
          _update(ref
              .read(settingsNotifierProvider)
              .copyWith(mosqueIconPath: persistentPath));
        }
      }
    } catch (e) {
      if (mounted) {
        GlassToast.show(context, '⚠️ Error picking image: $e', isError: true);
      }
    }
  }

  Future<void> _pickCustomFlagImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        final persistentPath =
            await _savePersistentImage(pickedFile.path, 'custom_flag');
        if (mounted) {
          _update(ref
              .read(settingsNotifierProvider)
              .copyWith(customFlagPath: persistentPath));
        }
      }
    } catch (e) {
      if (mounted) {
        GlassToast.show(context, '⚠️ Error picking image: $e', isError: true);
      }
    }
  }

  Future<void> _pickBlackClockModeCustomBgImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        final persistentPath =
            await _savePersistentImage(pickedFile.path, 'black_clock_bg');
        if (mounted) {
          _update(ref
              .read(settingsNotifierProvider)
              .copyWith(blackClockModeCustomBgPath: persistentPath));
        }
      }
    } catch (e) {
      if (mounted) {
        GlassToast.show(context, '⚠️ Error picking image: $e', isError: true);
      }
    }
  }

  void _clearBlackClockModeCustomBgImage() {
    _update(ref
        .read(settingsNotifierProvider)
        .copyWith(blackClockModeCustomBgPath: null));
  }

  Future<void> _pickAzkarOnlyScreenCustomBgImage() async {
    final l10n = AppLocalizations.of(context);
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        final persistentPath =
            await _savePersistentImage(pickedFile.path, 'azkar_only_bg');
        if (mounted) {
          _update(ref
              .read(settingsNotifierProvider)
              .copyWith(azkarOnlyScreenCustomBgPath: persistentPath));
        }
      }
    } catch (e) {
      if (mounted) {
        GlassToast.show(context, l10n.errorPickingImage(e.toString()),
            isError: true);
      }
    }
  }

  void _clearAzkarOnlyScreenCustomBgImage() {
    _update(ref
        .read(settingsNotifierProvider)
        .copyWith(azkarOnlyScreenCustomBgPath: null));
  }

  String _formatCityName(String city) {
    if (city.isEmpty) return city;
    // Remove prefixes like "ad__" or "db__" and underscores
    String cleaned = city;
    if (cleaned.contains('__')) {
      cleaned = cleaned.split('__').last;
    }
    cleaned = cleaned.replaceAll('_', ' ').replaceAll('-', ' ');

    // Capitalize words
    cleaned = cleaned
        .split(' ')
        .map((word) => word.isNotEmpty
            ? '${word[0].toUpperCase()}${word.substring(1).toLowerCase()}'
            : '')
        .join(' ');
    return cleaned;
  }

  Widget _buildSettingsGroup(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(title),
        ...children,
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildEmeraldMenuTile({
    Key? key,
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(20),
      focusColor: accent,
      child: Container(
        key: key,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _getCardColor(isDark),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: isDark
                  ? Colors.white10
                  : Colors.black.withValues(alpha: 0.05)),
        ),
        child: Row(
          children: [
            Icon(icon, color: accent, size: 28),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                          color: _getTextColor(isDark),
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo')),
                  Text(subtitle,
                      style: TextStyle(
                          color: _getSubTextColor(isDark),
                          fontSize: 12,
                          fontFamily: 'Cairo')),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                color: _getSubTextColor(isDark), size: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildDarkSection(String title, IconData icon) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Icon(icon, color: _accent, size: 20),
          const SizedBox(width: 8),
          Text(title,
              style: TextStyle(
                  color: _getTextColor(isDark),
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo')),
        ],
      ),
    );
  }

  Widget _buildDarkCard(List<Widget> children) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.black12),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildDarkToggle(
      String title, String subtitle, bool value, Function(bool) onChanged,
      {IconData? icon, Color? iconColor}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return TvFocusable(
      onPressed: () => onChanged(!value),
      borderRadius: BorderRadius.circular(14),
      focusColor: iconColor ?? _accent,
      child: ListTile(
        onTap: null,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        title: Text(title,
            textAlign: TextAlign.right,
            style: TextStyle(
                color: _getTextColor(isDark),
                fontSize: 15,
                fontWeight: FontWeight.bold,
                fontFamily: 'Cairo')),
        subtitle: subtitle.isEmpty
            ? null
            : Text(subtitle,
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _getSubTextColor(isDark),
                    fontSize: 11,
                    fontFamily: 'Cairo')),
        leading: ExcludeFocus(
          child: Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: _accent,
          ),
        ),
        trailing: icon != null
            ? Icon(icon, color: iconColor ?? _accent, size: 22)
            : null,
      ),
    );
  }

  Widget _darkDivider() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Divider(
        color: isDark ? Colors.white10 : Colors.black12,
        height: 1,
        indent: 16,
        endIndent: 16);
  }

  Widget _buildInfoTile(IconData icon, Color color, String title, String value,
      VoidCallback onTap) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(14),
      focusColor: color,
      child: ListTile(
        onTap: null,
        leading: Icon(icon, color: color, size: 24),
        title: Text(title,
            textAlign: TextAlign.right,
            style: TextStyle(
                color: _getTextColor(isDark),
                fontSize: 15,
                fontWeight: FontWeight.bold,
                fontFamily: 'Cairo')),
        trailing: Text(value,
            style: TextStyle(
                color: _getSubTextColor(isDark),
                fontSize: 13,
                fontFamily: 'Cairo')),
      ),
    );
  }

  Widget _buildDarkNavTile(String title, String subtitle, IconData icon,
      Color iconColor, VoidCallback onTap) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(14),
      focusColor: iconColor,
      child: ListTile(
        onTap: null,
        leading: Icon(icon, color: iconColor, size: 24),
        title: Text(title,
            textAlign: TextAlign.right,
            style: TextStyle(
                color: _getTextColor(isDark),
                fontSize: 15,
                fontWeight: FontWeight.bold,
                fontFamily: 'Cairo')),
        subtitle: Text(subtitle,
            textAlign: TextAlign.right,
            style: TextStyle(
                color: _getSubTextColor(isDark),
                fontSize: 11,
                fontFamily: 'Cairo')),
        trailing: Icon(Icons.arrow_forward_ios_rounded,
            color: _getSubTextColor(isDark), size: 16),
      ),
    );
  }

  void _openSubScreen(String title, Widget Function() builder,
      {bool isFull = false}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            _SettingsSubScreen(title: title, builder: builder, isFull: isFull),
      ),
    );
  }
}

class _SettingsSubScreen extends StatelessWidget {
  final String title;
  final Widget Function() builder;
  final bool isFull;
  const _SettingsSubScreen(
      {required this.title, required this.builder, this.isFull = false});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Directionality(
      textDirection: isDark
          ? TextDirection.rtl
          : TextDirection
              .rtl, // Default to RTL for now as app is mainly Arabic, but should ideally be dynamic
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: title),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: builder(),
        ),
      ),
    );
  }
}

class _MandatoryUpdateLock extends StatelessWidget {
  final VoidCallback? onSkip;
  const _MandatoryUpdateLock({this.onSkip});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);

    final latestUpdate = UpdateCheckerService.instance.latestUpdate;
    final allowSkip = latestUpdate?.allowSkip ?? false;
    final sigma = isDark ? 8.0 : 4.0;
    final opacity = isDark ? 0.25 : 0.15;

    return Positioned.fill(
      child: FocusScope(
        autofocus: true,
        child: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
            child: Container(
              color: (isDark ? Colors.black : Colors.white)
                  .withValues(alpha: opacity),
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 450),
                    margin: const EdgeInsets.symmetric(horizontal: 40),
                    padding: const EdgeInsets.all(40),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: isDark
                            ? Colors.white10
                            : Colors.white.withValues(alpha: 0.8),
                        width: 1.5,
                      ),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: isDark
                            ? [
                                Colors.black.withValues(alpha: 0.7),
                                Colors.black.withValues(alpha: 0.5),
                              ]
                            : [
                                Colors.white.withValues(alpha: 0.95),
                                Colors.white.withValues(alpha: 0.85),
                              ],
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: accent.withValues(alpha: 0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.system_update_rounded,
                              color: accent, size: 64),
                        ),
                        const SizedBox(height: 30),
                        Text(
                          l10n.mandatoryUpdateAvailable,
                          style: TextStyle(
                            color: isDark ? Colors.white : Colors.black87,
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo',
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          l10n.mandatoryUpdateDesc,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: isDark ? Colors.white70 : Colors.black54,
                            fontSize: 16,
                            height: 1.6,
                            fontFamily: 'Cairo',
                          ),
                        ),
                        const SizedBox(height: 40),
                        Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: TvFocusable(
                                autofocus: true,
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const AppUpdateScreen()),
                                  );
                                },
                                borderRadius: BorderRadius.circular(20),
                                focusColor: accent,
                                child: Container(
                                  height: 60,
                                  decoration: BoxDecoration(
                                    color: accent,
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [
                                      BoxShadow(
                                        color: accent.withValues(alpha: 0.3),
                                        blurRadius: 15,
                                        offset: const Offset(0, 5),
                                      )
                                    ],
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    l10n.updateNow,
                                    style: TextStyle(
                                      color:
                                          isDark ? Colors.black : Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 18,
                                      fontFamily: 'Cairo',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            if (allowSkip) ...[
                              const SizedBox(height: 16),
                              SizedBox(
                                width: double.infinity,
                                child: TvFocusable(
                                  onPressed:
                                      onSkip ?? () => Navigator.pop(context),
                                  borderRadius: BorderRadius.circular(20),
                                  focusColor:
                                      isDark ? Colors.white24 : Colors.black12,
                                  child: Container(
                                    height: 50,
                                    decoration: BoxDecoration(
                                      color: isDark
                                          ? Colors.white.withValues(alpha: 0.05)
                                          : Colors.black
                                              .withValues(alpha: 0.03),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: isDark
                                            ? Colors.white10
                                            : Colors.black
                                                .withValues(alpha: 0.05),
                                      ),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      l10n.updateLater,
                                      style: TextStyle(
                                        color: isDark
                                            ? Colors.white70
                                            : Colors.black54,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        fontFamily: 'Cairo',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
