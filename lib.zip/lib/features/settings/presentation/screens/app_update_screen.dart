﻿import 'dart:async';
import 'dart:io';
import 'dart:ui';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:open_filex/open_filex.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

import '../../../../core/services/update_service.dart';
import '../../../../core/services/notification_service.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/tv/tv_remote_support.dart';

class _DownloadStatus {
  final int receivedBytes;
  final int totalBytes;

  const _DownloadStatus({this.receivedBytes = 0, this.totalBytes = 0});

  double? get progress => totalBytes > 0 ? receivedBytes / totalBytes : null;
}

class _UpdateConfigs {
  final NotificationConfig updateAvailable;
  final NotificationConfig appUsage;
  final NotificationConfig whatsNew;

  const _UpdateConfigs({
    required this.updateAvailable,
    required this.appUsage,
    required this.whatsNew,
  });
}

class AppUpdateScreen extends StatefulWidget {
  const AppUpdateScreen({super.key});

  @override
  State<AppUpdateScreen> createState() => _AppUpdateScreenState();
}

class _AppUpdateScreenState extends State<AppUpdateScreen> {
  bool _checkingUpdate = false;
  final UpdateService _updateService = const UpdateService();
  final NotificationService _notificationService = NotificationService.instance;
  static const String _appLogoPath = 'assets/images/logo.jpg';

  Color get _accent => Theme.of(context).brightness == Brightness.dark
      ? AppColors.goldAccent
      : const Color(0xFF1AA85A);

  Color _getTextColor(bool isDark) => isDark ? Colors.white : Colors.black87;
  Color _getSubTextColor(bool isDark) =>
      isDark ? Colors.white70 : Colors.black54;

  void _showMessage(String message) {
    if (!mounted) return;
    GlassToast.show(context, message);
  }

  Future<void> _checkForUpdate({bool silentIfLatest = false}) async {
    if (_checkingUpdate) return;

    setState(() => _checkingUpdate = true);
    final l10n = AppLocalizations.of(context);
    try {
      final current = await PackageInfo.fromPlatform();
      final remoteInfo = await _updateService.fetchRemoteInfo(
        allowBundledFallback: false,
      );
      final bundledInfo = await _updateService.loadBundledInfo();
      final candidate = _updateService.pickNewer(remoteInfo, bundledInfo);

      if (candidate == null ||
          !_updateService.isNewerThanVersion(candidate, current.version)) {
        if (!silentIfLatest) {
          _showMessage(l10n.tr(ar: 'أنت على آخر إصدار (${current.version}).', en: 'You are on the latest version (${current.version}).'));
        }
        return;
      }

      final configs = await _loadUpdateConfigs();
      final proceed = await _showUpdateDialog(
        candidate,
        current.version,
        configs,
      );
      if (proceed != true) return;

      await _downloadAndInstall(candidate);
    } catch (e) {
      if (await _isNoConnection(e)) {
        _showNoInternetBar();
      } else {
        _showMessage(l10n.tr(ar: 'تعذر التحقق من التحديثات', en: 'Failed to check for updates'));
      }
    } finally {
      if (mounted) setState(() => _checkingUpdate = false);
    }
  }

  Future<_UpdateConfigs> _loadUpdateConfigs() async {
    final updateAvailable =
        await _notificationService.getUpdateAvailableConfig();
    final appUsage = await _notificationService.getAppUsageConfig();
    final whatsNew = await _notificationService.getWhatsNewConfig();
    return _UpdateConfigs(
      updateAvailable: updateAvailable,
      appUsage: appUsage,
      whatsNew: whatsNew,
    );
  }

  Future<bool> _hasInternet() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      return result.isNotEmpty && result.first.rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<bool> _isNoConnection(Object e) async {
    if (e is DioException) {
      if (e.type == DioExceptionType.connectionError ||
          e.error is SocketException) {
        return true;
      }
    }
    if (e is SocketException) return true;
    return !await _hasInternet();
  }

  void _showNoInternetBar() {
    if (!mounted) return;
    final l10n = AppLocalizations.of(context);
    GlassToast.show(context, l10n.tr(ar: 'لا يوجد اتصال بالإنترنت', en: 'No internet connection'), isError: true);
  }

  Color _parseColor(String? hex, Color fallback) {
    if (hex == null || hex.isEmpty) return fallback;
    final value = hex.replaceAll('#', '');
    final normalized = value.length == 6 ? 'FF$value' : value;
    final parsed = int.tryParse(normalized, radix: 16);
    if (parsed == null) return fallback;
    return Color(parsed);
  }

  String _localizeConfigText({
    NotificationConfig? config,
    required String? Function(NotificationConfig) pickAr,
    required String? Function(NotificationConfig) pickEn,
  }) {
    final value = config != null ? (pickAr(config)?.trim() ?? '') : '';
    if (value.isNotEmpty) return value;
    final enValue = config != null ? (pickEn(config)?.trim() ?? '') : '';
    if (enValue.isNotEmpty) return enValue;
    return '';
  }

  List<String> _localizedItemsFromConfig(
    NotificationConfig? config,
    UpdateInfo info,
  ) {
    final arItems = (config?.items ?? [])
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList();
    final changelogAr = info.changelog
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    if (arItems.isNotEmpty) return arItems;
    if (changelogAr.isNotEmpty) return changelogAr;
    return (config?.itemsEn ?? [])
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList();
  }

  Future<bool?> _showUpdateDialog(
    UpdateInfo info,
    String currentVersion,
    _UpdateConfigs configs,
  ) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);

    // Base colors for surface
    final Color surface = isDark
        ? const Color(0xFF0F172A).withValues(alpha: 0.85) // Deep navy glass
        : Colors.white.withValues(alpha: 0.95); // Clear white glass

    final Color textColor = isDark ? Colors.white : const Color(0xFF1E293B);
    final Color subColor = isDark ? Colors.white70 : const Color(0xFF64748B);
    final Color accent = _accent;

    final Color whatsNewAccent = _parseColor(
      configs.whatsNew.color,
      isDark ? AppColors.goldAccent : const Color(0xFF2563EB),
    );

    final String updateTitle = _localizeConfigText(
      config: info.updateAvailable ?? configs.updateAvailable,
      pickAr: (c) => c.title,
      pickEn: (c) => c.titleEn,
    ).isNotEmpty
        ? _localizeConfigText(
            config: info.updateAvailable ?? configs.updateAvailable,
            pickAr: (c) => c.title,
            pickEn: (c) => c.titleEn,
          )
        : l10n.newUpdateAvailable(info.version);

    final String updateMessage = _localizeConfigText(
      config: info.updateAvailable ?? configs.updateAvailable,
      pickAr: (c) => c.message,
      pickEn: (c) => c.messageEn,
    ).isNotEmpty
        ? _localizeConfigText(
            config: info.updateAvailable ?? configs.updateAvailable,
            pickAr: (c) => c.message,
            pickEn: (c) => c.messageEn,
          )
        : l10n.tr(ar: 'لتستمر في استخدام التطبيق وتحصل على أحدث المزايا قم بتنزيل آخر إصدار الآن.', en: 'To continue using the app and get the latest features, download the newest version now.');

    final String appUsageMessage = _localizeConfigText(
      config: info.appUsage ?? configs.appUsage,
      pickAr: (c) => c.message,
      pickEn: (c) => c.messageEn,
    ).isNotEmpty
        ? _localizeConfigText(
            config: info.appUsage ?? configs.appUsage,
            pickAr: (c) => c.message,
            pickEn: (c) => c.messageEn,
          )
        : l10n.tr(ar: 'يمكنك متابعة استخدام التطبيق أثناء تنزيل التحديث دون التأثير على عملك.', en: 'You can keep using the app while the update downloads without interrupting your work.');

    final String whatsNewTitle = _localizeConfigText(
      config: info.whatsNew ?? configs.whatsNew,
      pickAr: (c) => c.title,
      pickEn: (c) => c.titleEn,
    ).isNotEmpty
        ? _localizeConfigText(
            config: info.whatsNew ?? configs.whatsNew,
            pickAr: (c) => c.title,
            pickEn: (c) => c.titleEn,
          )
        : l10n.tr(ar: 'ما الجديد!', en: 'Whats New!');

    final String whatsNewSubtitle = _localizeConfigText(
      config: info.whatsNew ?? configs.whatsNew,
      pickAr: (c) => c.message,
      pickEn: (c) => c.messageEn,
    ).isNotEmpty
        ? _localizeConfigText(
            config: info.whatsNew ?? configs.whatsNew,
            pickAr: (c) => c.message,
            pickEn: (c) => c.messageEn,
          )
        : l10n.tr(ar: 'تغييرات هذا الإصدار:', en: 'Changes in this release:');

    final sizeText = (info.sizeBytes ?? 0) > 0
        ? _formatBytes(info.sizeBytes ?? 0, 1)
        : l10n.tr(ar: 'غير متاح', en: 'Unavailable');
    final whatsNewItems =
        _localizedItemsFromConfig(info.whatsNew ?? configs.whatsNew, info);

    Widget versionBadge({
      required String label,
      required String value,
      IconData? icon,
    }) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: subColor.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: subColor.withValues(alpha: 0.2)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 16, color: accent),
              const SizedBox(width: 6),
            ],
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                      color: subColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Cairo'),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }

    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl, // fixed dead code warning
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            12,
            12,
            12,
            12 + MediaQuery.of(context).padding.bottom,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(
                      color: isDark ? Colors.white10 : Colors.black12),
                  boxShadow: [
                    BoxShadow(
                      color:
                          Colors.black.withValues(alpha: isDark ? 0.35 : 0.12),
                      blurRadius: 24,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              icon: Icon(Icons.close, color: subColor),
                            ),
                            const Spacer(),
                            Container(
                              width: 72,
                              height: 72,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: accent.withValues(alpha: 0.35),
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: accent.withValues(alpha: 0.28),
                                    blurRadius: 22,
                                    spreadRadius: 1,
                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(18),
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Image.asset(
                                      _appLogoPath,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Container(
                                        color: accent.withValues(alpha: 0.18),
                                        alignment: Alignment.center,
                                        child: Icon(
                                          Icons.mosque_rounded,
                                          color: accent,
                                          size: 30,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            Colors.white
                                                .withValues(alpha: 0.18),
                                            Colors.transparent,
                                            Colors.black
                                                .withValues(alpha: 0.16),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          updateTitle,
                          style: TextStyle(
                              color: textColor,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              fontFamily: 'Cairo'),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 10,
                          runSpacing: 8,
                          children: [
                            versionBadge(
                              label: l10n.tr(ar: 'الحالي', en: 'Current'),
                              value: 'v$currentVersion',
                            ),
                            versionBadge(
                              label: l10n.tr(ar: 'الجديد', en: 'New'),
                              value: 'v${info.version}',
                            ),
                            versionBadge(
                              label: l10n.tr(ar: 'حجم التحديث', en: 'Update size'),
                              value: sizeText,
                              icon: Icons.sd_card,
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          updateMessage,
                          style: TextStyle(
                              color: textColor,
                              fontSize: 14.5,
                              height: 1.45,
                              fontFamily: 'Cairo'),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          appUsageMessage,
                          style: TextStyle(
                              color: subColor,
                              height: 1.35,
                              fontSize: 13.5,
                              fontFamily: 'Cairo'),
                        ),
                        const SizedBox(height: 18),
                        Text(
                          whatsNewTitle,
                          style: TextStyle(
                              color: whatsNewAccent,
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              fontFamily: 'Cairo'),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          whatsNewSubtitle,
                          style: TextStyle(
                              color: subColor,
                              height: 1.3,
                              fontFamily: 'Cairo'),
                        ),
                        const SizedBox(height: 10),
                        ...whatsNewItems.map(
                          (item) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  Icons.check_circle_rounded,
                                  size: 18,
                                  color: whatsNewAccent,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    item,
                                    style: TextStyle(
                                        color: subColor,
                                        height: 1.4,
                                        fontFamily: 'Cairo'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () =>
                                    Navigator.of(context).pop(false),
                                style: OutlinedButton.styleFrom(
                                  side: BorderSide(
                                      color: subColor.withValues(alpha: 0.4)),
                                  foregroundColor: textColor,
                                  backgroundColor: isDark
                                      ? Colors.white.withValues(alpha: 0.03)
                                      : Colors.black.withValues(alpha: 0.03),
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                ),
                                child: Text(
                                  l10n.tr(ar: 'لاحقاً', en: 'Later'),
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Cairo'),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: TvFocusable(
                                onPressed: () =>
                                    Navigator.of(context).pop(true),
                                focusColor: accent.withValues(alpha: 0.8),
                                borderRadius: BorderRadius.circular(16),
                                child: ElevatedButton(
                                  onPressed: () =>
                                      Navigator.of(context).pop(true),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: accent,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 14),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    elevation: 0,
                                  ),
                                  child: Text(
                                    l10n.tr(ar: 'حمل الآن', en: 'Download now'),
                                    style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontFamily: 'Cairo'),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _downloadAndInstall(UpdateInfo info) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    final downloadState = await _updateService.getDownloadState(info);
    if (!mounted) return;
    final status = ValueNotifier<_DownloadStatus>(
      _DownloadStatus(
        receivedBytes: downloadState.receivedBytes,
        totalBytes: downloadState.totalBytes > 0
            ? downloadState.totalBytes
            : (info.sizeBytes ?? 0),
      ),
    );
    final cancelToken = CancelToken();
    Timer? internetCheckTimer;

    if (downloadState.receivedBytes > 0 && !downloadState.isCompleted) {
      _showMessage(
        l10n.tr(ar: 'استئناف التحميل من ${_formatBytes(downloadState.receivedBytes, 1)}', en: 'Resuming download from ${_formatBytes(downloadState.receivedBytes, 1)}'),
      );
    }

    _showDownloadDialog(status, cancelToken: cancelToken);

    internetCheckTimer =
        Timer.periodic(const Duration(seconds: 1), (timer) async {
      if (!await _hasInternet()) {
        cancelToken.cancel("no_internet");
        timer.cancel();
      }
    });

    try {
      final filePath = await _updateService.downloadApk(
        info,
        cancelToken: cancelToken,
        onReceiveProgress: (received, total) {
          final totalBytes = total > 0 ? total : status.value.totalBytes;
          status.value =
              _DownloadStatus(receivedBytes: received, totalBytes: totalBytes);
        },
      );

      internetCheckTimer.cancel();

      if (mounted) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // close download dialog

        bool granted = true;

        if (Platform.isAndroid) {
          final installPerm = await Permission.requestInstallPackages.request();
          if (!installPerm.isGranted) {
            granted = false;
          }
        }

        if (!mounted) return;

        if (!granted) {
          // Show error dialog
          await showDialog(
            context: context,
            builder: (_) => Directionality(
              textDirection: TextDirection.rtl,
              child: AlertDialog(
                backgroundColor:
                    isDark ? const Color(0xFF1E293B) : Colors.white,
                title: Text(l10n.tr(ar: 'تعذر التثبيت', en: 'Installation failed'),
                    style: TextStyle(
                        fontFamily: 'Cairo', color: Colors.red.shade400)),
                content: Text(
                    l10n.tr(ar: 'يرجى منح التطبيق صلاحية تثبيت التطبيقات المجهولة من الإعدادات لإكمال التحديث.', en: 'Please allow the app to install unknown apps from settings to complete the update.'),
                    style: TextStyle(fontFamily: 'Cairo')),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(l10n.tr(ar: 'حسنًا', en: 'OK'),
                        style: TextStyle(fontFamily: 'Cairo')),
                  ),
                ],
              ),
            ),
          );
          return;
        }

        // Show confirmation dialog before installation
        await showDialog(
          context: context,
          builder: (_) => Directionality(
            textDirection: TextDirection.rtl,
            child: AlertDialog(
              backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
              title: Text(l10n.tr(ar: 'اكتمل التنزيل', en: 'Download complete'),
                  style:
                      TextStyle(fontFamily: 'Cairo', color: Color(0xFF22C55E))),
              content: Text(
                  l10n.tr(ar: 'تم تنزيل التحديث بنجاح. سيتم الآن فتح صفحة التثبيت، يرجى الموافقة على التثبيت.', en: 'The update was downloaded successfully. The installer will open now, please approve installation.'),
                  style: TextStyle(fontFamily: 'Cairo')),
              actions: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF22C55E),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: Text(l10n.tr(ar: 'تثبيت الآن', en: 'Install now'),
                      style: TextStyle(
                          fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        );
      }

      await OpenFilex.open(filePath);
    } catch (e) {
      internetCheckTimer.cancel();
      if (mounted) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // close download dialog
        bool isNoInternetCancel = e is DioException &&
            e.type == DioExceptionType.cancel &&
            e.error == "no_internet";

        String errorTitle = l10n.tr(ar: 'خطأ في التنزيل', en: 'Download error');
        String errorMessage = l10n.tr(ar: 'تعذر تنزيل التحديث. يرجى المحاولة في وقت لاحق.', en: 'Unable to download the update. Please try again later.');

        if (isNoInternetCancel || await _isNoConnection(e)) {
          errorTitle = l10n.tr(ar: 'انقطع الاتصال', en: 'Connection lost');
          errorMessage =
              l10n.tr(ar: 'عذراً، تم إيقاف التنزيل بسبب انقطاع مفاجئ في اتصال الإنترنت. تحقق من شبكتك وحاول مرة أخرى.', en: 'Sorry, download stopped due to a sudden internet interruption. Check your network and try again.');
        }

        if (!mounted) return;

        await showDialog(
          context: context,
          builder: (_) => Directionality(
            textDirection: TextDirection.rtl,
            child: AlertDialog(
              backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
              title: Text(errorTitle,
                  style: TextStyle(
                      fontFamily: 'Cairo', color: Colors.red.shade400)),
              content: Text(errorMessage,
                  style: const TextStyle(fontFamily: 'Cairo')),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                    child: Text(l10n.tr(ar: 'حسنًا', en: 'OK'),
                      style: TextStyle(fontFamily: 'Cairo')),
                ),
              ],
            ),
          ),
        );
      }
    } finally {
      internetCheckTimer.cancel();
      status.dispose();
    }
  }

  void _showDownloadDialog(ValueNotifier<_DownloadStatus> notifier,
      {CancelToken? cancelToken}) {
    final start = DateTime.now();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return PopScope(
          canPop: false,
          child: Dialog(
            backgroundColor: Colors.transparent,
            insetPadding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Directionality(
              textDirection: TextDirection.rtl, // noor_prayer_tv is RTL
              child: ValueListenableBuilder<_DownloadStatus>(
                valueListenable: notifier,
                builder: (context, status, __) {
                  final l10n = AppLocalizations.of(context);
                  final isDark =
                      Theme.of(context).brightness == Brightness.dark;
                  final cardBg =
                      isDark ? const Color(0xFF0F172A) : Colors.white;
                  final textColor =
                      isDark ? Colors.white : const Color(0xFF0B1022);
                  final muted =
                      isDark ? Colors.white70 : const Color(0xFF6B7280);
                  final barBase = isDark
                      ? Colors.white.withValues(alpha: 0.06)
                      : Colors.black.withValues(alpha: 0.06);
                  final percentValue = status.progress != null
                      ? (status.progress! * 100).clamp(0, 100)
                      : 0.0;
                  final percentText = status.progress == null
                      ? l10n.tr(ar: 'جارٍ التحضير...', en: 'Preparing...')
                      : '${percentValue.toStringAsFixed(0)}%';
                  final downloaded = _formatBytes(status.receivedBytes);
                  final total = status.totalBytes > 0
                      ? _formatBytes(status.totalBytes)
                      : '—';
                  final elapsedSeconds =
                      DateTime.now().difference(start).inMilliseconds / 1000.0;
                  final bytesPerSecond = elapsedSeconds > 0
                      ? status.receivedBytes / elapsedSeconds
                      : 0;
                  final speedText = bytesPerSecond > 0
                      ? '${_formatBytes(bytesPerSecond.toInt(), 1)}/s'
                      : l10n.tr(ar: '... جارٍ الحساب', en: 'Calculating...');
                  String etaText = '--:--';
                  if (bytesPerSecond > 0 && status.totalBytes > 0) {
                    final remaining = status.totalBytes - status.receivedBytes;
                    final seconds = remaining / bytesPerSecond;
                    final mins = seconds ~/ 60;
                    final secs = (seconds % 60).round();
                    etaText =
                        '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
                  }

                  return Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black
                              .withValues(alpha: isDark ? 0.35 : 0.12),
                          blurRadius: 32,
                          offset: const Offset(0, 18),
                          spreadRadius: -8,
                        ),
                      ],
                      border: Border.all(
                        color: Colors.white
                            .withValues(alpha: isDark ? 0.04 : 0.08),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              l10n.tr(ar: 'جارٍ تنزيل التحديث', en: 'Downloading update'),
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'Cairo'),
                            ),
                            Text(
                              percentText,
                              style: TextStyle(
                                color: _accent,
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          height: 9,
                          decoration: BoxDecoration(
                            color: barBase,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Align(
                            alignment: AlignmentDirectional.centerStart,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 400),
                              curve: Curves.fastLinearToSlowEaseIn,
                              height: 9,
                              width: (status.progress ?? 0) *
                                  MediaQuery.of(context).size.width *
                                  0.7,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(99),
                                gradient: LinearGradient(
                                  colors: [
                                    _accent,
                                    _accent.withValues(alpha: 0.65),
                                  ],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _accent.withValues(alpha: 0.35),
                                    blurRadius: 10,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    height: 4,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            const BorderRadius.vertical(
                                                top: Radius.circular(99)),
                                        gradient: LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            Colors.white
                                                .withValues(alpha: 0.38),
                                            Colors.white.withValues(alpha: 0.0),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '$downloaded / $total',
                              style: TextStyle(fontSize: 12.5, color: muted),
                            ),
                            Text(
                              speedText,
                              style: TextStyle(fontSize: 12.5, color: muted),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              l10n.tr(ar: 'الوقت المتبقي', en: 'Time remaining'),
                              style: TextStyle(
                                  fontSize: 12.5,
                                  color: muted,
                                  fontFamily: 'Cairo'),
                            ),
                            Text(
                              etaText,
                              style: TextStyle(
                                  fontSize: 12.5,
                                  color: textColor,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  String _formatBytes(int bytes, [int decimals = 2]) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = (bytes.toString().length - 1) ~/ 3;
    return '${(bytes / (1 << (i * 10))).toStringAsFixed(decimals)} ${suffixes[i]}';
  }

  Future<void> _rateApp(BuildContext context) async {
    const packageName = 'com.noor.noor_prayer_tv';
    final url = Uri.parse("market://details?id=$packageName");
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url);
      } else {
        final webUrl = Uri.parse(
            "https://play.google.com/store/apps/details?id=$packageName");
        if (await canLaunchUrl(webUrl)) {
          await launchUrl(webUrl);
        }
      }
    } catch (e) {
      debugPrint('Error launching store: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: PremiumGlassNavbar(
        title: l10n.tr(ar: 'تحديث التطبيق', en: 'App Update'),
        showBackButton: true,
      ),
      body: Container(
        decoration: LuxuryGlassTheme.getPageDecoration(isDark),
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
          children: [
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.05)
                    : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border:
                    Border.all(color: isDark ? Colors.white10 : Colors.black12),
              ),
              child: Column(
                children: [
                  TvFocusable(
                    onPressed: _checkingUpdate ? () {} : _checkForUpdate,
                    borderRadius: BorderRadius.circular(12),
                    focusColor: _accent,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _accent.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: _checkingUpdate
                                ? SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      color: _accent,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Icon(Icons.system_update_alt_rounded,
                                    color: _accent, size: 24),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  l10n.tr(ar: 'تحديث يدوي', en: 'Manual update'),
                                  style: TextStyle(
                                      color: _getTextColor(isDark),
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Cairo'),
                                ),
                                Text(
                                  l10n.tr(ar: 'التحقق من وجود تحديثات عن طريق رابط مباشر', en: 'Check for updates through a direct link'),
                                  style: TextStyle(
                                      color: _getSubTextColor(isDark),
                                      fontSize: 12,
                                      fontFamily: 'Cairo'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Divider(
                    color: isDark
                        ? Colors.white10
                        : Colors.black.withValues(alpha: 0.05),
                    height: 1,
                  ),
                  TvFocusable(
                    onPressed: () => _rateApp(context),
                    borderRadius: BorderRadius.circular(12),
                    focusColor: _accent,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF3498DB)
                                  .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.shop_rounded,
                                color: Color(0xFF3498DB), size: 24),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  l10n.tr(ar: 'تحديث من المتجر', en: 'Store update'),
                                  style: TextStyle(
                                      color: _getTextColor(isDark),
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Cairo'),
                                ),
                                Text(
                                  l10n.tr(ar: 'الذهاب لصفحة التطبيق على Google Play', en: 'Open the app page on Google Play'),
                                  style: TextStyle(
                                      color: _getSubTextColor(isDark),
                                      fontSize: 12,
                                      fontFamily: 'Cairo'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}







