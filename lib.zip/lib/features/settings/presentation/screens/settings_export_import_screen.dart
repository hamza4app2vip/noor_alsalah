﻿import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../domain/entities/app_settings.dart';
import '../providers/settings_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class SettingsExportImportScreen extends ConsumerStatefulWidget {
  const SettingsExportImportScreen({super.key});

  @override
  ConsumerState<SettingsExportImportScreen> createState() =>
      _SettingsExportImportScreenState();
}

class _SettingsExportImportScreenState
    extends ConsumerState<SettingsExportImportScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  bool _isLoading = false;

  void _showLoading(bool show) {
    if (mounted) setState(() => _isLoading = show);
  }

  Color get _accent => Theme.of(context).brightness == Brightness.dark 
      ? AppColors.goldAccent 
      : const Color(0xFF1AA85A);

  Color _getTextColor(bool isDark) => isDark ? Colors.white : Colors.black87;
  Color _getSubTextColor(bool isDark) => isDark ? Colors.white70 : Colors.black54;
  Color _getCardColor(bool isDark) => isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white;
  Color _getBg(bool isDark) => isDark ? Colors.white.withValues(alpha: 0.03) : const Color(0xFFF5F5F7);

  void _showToast(String msg, {bool isError = false}) {
    if (mounted) GlassToast.show(context, msg, isError: isError);
  }

  Future<void> _exportSettings() async {
    _showLoading(true);
    try {
      final settings = ref.read(settingsNotifierProvider);
      final exportData = {
        'schemaVersion': '1.0',
        'appVersion': '1.0.0',
        'createdAt': DateTime.now().toIso8601String(),
        'platform': Platform.operatingSystem,
        'settings': settings.toJson(),
      };
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/noor_settings_export.json');
      await file.writeAsString(jsonEncode(exportData));
      if (mounted) {
        final box = context.findRenderObject() as RenderBox?;
        // ignore: deprecated_member_use
        await Share.shareXFiles(
          [XFile(file.path)],
          subject: 'Noor Prayer TV Settings',
          sharePositionOrigin: box!.localToGlobal(Offset.zero) & box.size,
        );
      }
      _showToast(l10n.tr(ar: '✅ تم تصدير الإعدادات بنجاح', en: '✅ Settings exported successfully'));
    } catch (e) {
      _showToast(l10n.tr(ar: '❌ فشل التصدير: $e', en: '❌ Export failed: $e'), isError: true);
    } finally {
      _showLoading(false);
    }
  }

  Future<void> _importLocalFile() async {
    _showLoading(true);
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );
      if (result != null && result.files.single.path != null) {
        final file = File(result.files.single.path!);
        await _applyImportedJson(await file.readAsString());
        _showToast(l10n.tr(ar: '✅ تم استيراد الإعدادات من الملف', en: '✅ Settings imported from file'));
      }
    } catch (e) {
      _showToast(l10n.tr(ar: '❌ ملف غير صالح: $e', en: '❌ Invalid file: $e'), isError: true);
    } finally {
      _showLoading(false);
    }
  }

  Future<void> _importById() async {
    final idCtrl = TextEditingController();
    final id = await showDialog<String>(
      context: context,
      builder: (ctx) {
        final isDark = Theme.of(ctx).brightness == Brightness.dark;
        final accent = _accent;
        return AlertDialog(
          backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(l10n.tr(ar: 'أدخل رمز الاستيراد (ID)', en: 'Enter import code (ID)'),
              textAlign: TextAlign.right,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                  color: _getTextColor(isDark),
                  fontSize: 18)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              TextField(
                controller: idCtrl,
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                style: TextStyle(color: _getTextColor(isDark)),
                decoration: InputDecoration(
                  hintText: l10n.tr(ar: 'مثال: 12345', en: 'Example: 12345'),
                  hintStyle: TextStyle(color: _getSubTextColor(isDark).withValues(alpha: 0.5)),
                  filled: true,
                  fillColor: _getBg(isDark),
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: isDark ? const BorderSide(color: Colors.white10) : BorderSide.none),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(color: accent, width: 1.5)),
                ),
              ),
            ],
          ),
          actions: [
            Row(
              children: [
                Expanded(
                  child: TvFocusable(
                    onPressed: () => Navigator.pop(ctx),
                    borderRadius: BorderRadius.circular(12),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Center(
                        child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                            style: TextStyle(fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TvFocusable(
                    autofocus: true,
                    onPressed: () => Navigator.pop(ctx, idCtrl.text.trim()),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: accent,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(l10n.tr(ar: 'استيراد', en: 'Import'),
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
    if (id == null || id.isEmpty) return;
    _showLoading(true);
    try {
      final response =
          await http.get(Uri.parse('https://settings.tawkit.net/api/settings/$id'));
      if (response.statusCode == 200) {
        await _applyImportedJson(response.body);
        _showToast(l10n.tr(ar: '✅ تم استيراد الإعدادات (ID: $id)', en: '✅ Settings imported (ID: $id)'));
      } else {
        _showToast(l10n.tr(ar: '❌ لم يتم العثور على ID', en: '❌ ID not found'), isError: true);
      }
    } catch (e) {
      _showToast(l10n.tr(ar: '❌ خطأ في الاتصال بالخادم', en: '❌ Server connection error'), isError: true);
    } finally {
      _showLoading(false);
    }
  }

  Future<void> _applyImportedJson(String jsonString) async {
    final decoded = jsonDecode(jsonString) as Map<String, dynamic>;
    final settingsData =
        decoded.containsKey('settings') ? decoded['settings'] : decoded;
    final newSettings =
        AppSettings.fromJson(settingsData as Map<String, dynamic>);
    ref.read(settingsNotifierProvider.notifier).updateSettings(newSettings);
  }

  Widget _actionTile({
    required IconData icon,
    required Color iconBg,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;
    return TvFocusable(
      onPressed: _isLoading ? null : onTap,
      borderRadius: BorderRadius.circular(20),
      focusColor: accent.withValues(alpha: 0.4),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _getCardColor(isDark),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05)),
          boxShadow: !isDark ? [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 10,
                offset: const Offset(0, 2))
          ] : null,
        ),
        child: Row(
          children: [
            // 1. Arrow (Left)
            Icon(Icons.arrow_back_ios_new_rounded, color: _getSubTextColor(isDark).withValues(alpha: 0.3), size: 14),
            const Spacer(),
            // 2. Text (Middle-Right)
            Expanded(
              flex: 10,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(title,
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo',
                          fontSize: 15,
                          color: _getTextColor(isDark))),
                  const SizedBox(height: 4),
                  Text(subtitle,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          color: _getSubTextColor(isDark).withValues(alpha: 0.6),
                          fontSize: 12,
                          fontFamily: 'Cairo',
                          height: 1.4)),
                ],
              ),
            ),
            const SizedBox(width: 16),
            // 3. Icon (Right)
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: iconBg.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: iconBg, size: 24),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = _accent;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'تصدير / استيراد الإعدادات', en: 'Export / Import Settings')),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: Stack(
            children: [
              ListView(
                padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
                children: [
                  // ── معلومات ──
                  Container(
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 24),
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: accent.withValues(alpha: 0.2)),
                    ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          l10n.tr(ar: 'يمكنك نقل إعداداتك بين الأجهزة عبر التصدير والاستيراد. يُحفظ الملف بصيغة JSON.', en: 'You can move your settings between devices via export/import. The file is saved as JSON.'),
                          textAlign: TextAlign.right,
                          style: TextStyle(
                              color: _getSubTextColor(isDark),
                              fontSize: 13,
                              fontFamily: 'Cairo',
                              height: 1.6),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Icon(Icons.info_outline_rounded,
                          color: accent),
                    ],
                  ),
                ),

                // ── قسم التصدير ──
                Padding(
                  padding: const EdgeInsets.only(bottom: 12, right: 8),
                  child: Text(l10n.tr(ar: 'تصدير البيانات', en: 'Export data'),
                      style: TextStyle(
                          color: accent,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          fontFamily: 'Cairo')),
                ),
                _actionTile(
                  icon: Icons.share_rounded,
                  iconBg: accent,
                  title: l10n.tr(ar: 'تصدير الإعدادات الحالية', en: 'Export current settings'),
                  subtitle: l10n.tr(ar: 'مشاركة ملف JSON يحتوي على جميع الإعدادات الحالية للجهاز', en: 'Share a JSON file containing all current device settings'),
                  onTap: _exportSettings,
                ),

                const SizedBox(height: 20),

                // ── قسم الاستيراد ──
                Padding(
                  padding: const EdgeInsets.only(bottom: 12, right: 8),
                  child: Text(l10n.tr(ar: 'استيراد البيانات', en: 'Import data'),
                      style: TextStyle(
                          color: accent,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          fontFamily: 'Cairo')),
                ),
                _actionTile(
                  icon: Icons.file_download_outlined,
                  iconBg: const Color(0xFF2196F3),
                  title: l10n.tr(ar: 'استيراد من ملف محلي', en: 'Import from local file'),
                  subtitle: l10n.tr(ar: 'اختر ملف JSON محفوظ مسبقاً على هذا الجهاز', en: 'Choose a JSON file previously saved on this device'),
                  onTap: _importLocalFile,
                ),
                _actionTile(
                  icon: Icons.cloud_download_outlined,
                  iconBg: const Color(0xFF9C27B0),
                  title: l10n.tr(ar: 'استيراد بواسطة الرمز (ID)', en: 'Import by code (ID)'),
                  subtitle: l10n.tr(ar: 'جلب الإعدادات من خوادم tawkit.net عبر الرمز الموفر', en: 'Fetch settings from tawkit.net servers using the provided code'),
                  onTap: _importById,
                ),

                const SizedBox(height: 24),

                // ── تحذير ──
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.red.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.red.withValues(alpha: 0.15)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          l10n.tr(ar: '⚠️ الاستيراد سيستبدل جميع إعداداتك الحالية بلا رجعة.', en: '⚠️ Import will replace all your current settings permanently.'),
                          textAlign: TextAlign.right,
                          style: TextStyle(
                              color: Colors.red.shade700,
                              fontSize: 13,
                              fontFamily: 'Cairo'),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          if (_isLoading)
            Container(
              color: Colors.black.withValues(alpha: 0.25),
              child: Center(
                child: CircularProgressIndicator(color: accent),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
}




