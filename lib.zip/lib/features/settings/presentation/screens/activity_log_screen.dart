import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' as intl;

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';
import '../../domain/entities/activity_source.dart';
import '../providers/activity_log_provider.dart';
import '../../../../core/tv/tv_remote_support.dart';

class ActivityLogScreen extends ConsumerWidget {
  const ActivityLogScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final logsAsync = ref.watch(activityLogNotifierProvider);
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    final secondaryColor = isDark ? Colors.white70 : Colors.black54;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'سجل النشاطات', en: 'Activity Log')),
        body: Container(
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: logsAsync.when(
            data: (logs) {
              if (logs.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.assignment_turned_in_rounded,
                        size: 64,
                        color: secondaryColor.withValues(alpha: 0.2),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        l10n.tr(ar: 'لا يوجد نشاطات مسجلة بعد', en: 'No activities recorded yet'),
                        style: TextStyle(
                            color: secondaryColor, fontFamily: 'Cairo'),
                      ),
                    ],
                  ),
                );
              }

              return ListView.builder(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 110, 16, 40),
                itemCount: logs.length + 1,
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: TvFocusable(
                          onPressed: () => _confirmClear(context, ref),
                          borderRadius: BorderRadius.circular(12),
                          focusColor: Colors.redAccent,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(12),
                                  onTap: () => _confirmClear(context, ref),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 14,
                                    vertical: 10,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.red.withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.red.withValues(alpha: 0.35),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.delete_sweep_rounded,
                                        color: Colors.redAccent,
                                        size: 18,
                                      ),
                                      SizedBox(width: 8),
                                      Text(
                                        l10n.tr(ar: 'مسح السجل', en: 'Clear log'),
                                        style: TextStyle(
                                          color: Colors.redAccent,
                                          fontFamily: 'Cairo',
                                          fontWeight: FontWeight.w700,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        ),
                      ),
                    );
                  }

                  final log = logs[index - 1];
                  final isWeb = log.source == ActivitySource.web;

                  return TvFocusable(
                    onPressed: log.details.isNotEmpty ? () => _showDetails(context, log) : null,
                    borderRadius: BorderRadius.circular(16),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: isDark
                              ? Colors.white.withValues(alpha: 0.05)
                              : Colors.white.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isDark
                                ? Colors.white10
                                : Colors.black.withValues(alpha: 0.05),
                          ),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          leading: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color:
                                  (isWeb ? AppColors.info : AppColors.success)
                                      .withValues(alpha: 0.1),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              isWeb ? Icons.language_rounded : Icons.tv_rounded,
                              color: isWeb ? AppColors.info : AppColors.success,
                              size: 20,
                            ),
                          ),
                          title: Text(
                            log.action,
                            style: TextStyle(
                              color: textColor,
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 4),
                              Text(
                                '${l10n.tr(ar: 'المصدر', en: 'Source')}: ${isWeb ? l10n.tr(ar: "موقع الويب", en: "Web app") : l10n.tr(ar: "تطبيق التلفاز", en: "TV app")}',
                                style: TextStyle(
                                  color: secondaryColor,
                                  fontSize: 13,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                              Text(
                                intl.DateFormat('yyyy/MM/dd | HH:mm:ss')
                                    .format(log.timestamp),
                                style: TextStyle(
                                  color: secondaryColor.withValues(alpha: 0.6),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                          trailing: log.details.isNotEmpty
                              ? Container(
                                  decoration: BoxDecoration(
                                    color: AppColors.goldAccent.withValues(
                                      alpha: 0.1,
                                    ),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: TvFocusable(
                                    onPressed: () => _showDetails(context, log),
                                    borderRadius: BorderRadius.circular(8),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: const Icon(
                                        Icons.chevron_left_rounded,
                                        color: AppColors.goldAccent,
                                      ),
                                    ),
                                  ),
                                )
                              : null,
                        ),
                      ),
                    ),
                  ),
                );
                },
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, st) => Center(child: Text('${l10n.tr(ar: 'خطأ في تحميل السجل', en: 'Failed to load activity log')}: $e', style: const TextStyle(fontFamily: 'Cairo'))),
          ),
        ),
      ),
    );
  }

  String _translateValue(AppLocalizations l10n, String value) {
    final lowerValue = value.toLowerCase();
    switch (lowerValue) {
      case 'true':
        return l10n.tr(ar: 'مفعل', en: 'Enabled');
      case 'false':
        return l10n.tr(ar: 'معطل', en: 'Disabled');
      case 'system':
        return l10n.tr(ar: 'تلقائي (حسب النظام)', en: 'Automatic (system)');
      case 'light':
        return l10n.tr(ar: 'فاتح', en: 'Light');
      case 'dark':
        return l10n.tr(ar: 'داكن', en: 'Dark');
      case 'horizontal':
        return l10n.tr(ar: 'أفقي', en: 'Horizontal');
      case 'vertical':
        return l10n.tr(ar: 'عمودي', en: 'Vertical');
      case '24hour':
        return l10n.tr(ar: '24 ساعة', en: '24-hour');
      case '12hour':
        return l10n.tr(ar: '12 ساعة', en: '12-hour');
      case 'am':
        return l10n.tr(ar: 'صباحاً', en: 'AM');
      case 'pm':
        return l10n.tr(ar: 'مساءً', en: 'PM');
      case 'primary':
        return l10n.tr(ar: 'أساسي', en: 'Primary');
      case 'secondary':
        return l10n.tr(ar: 'ثانوي', en: 'Secondary');
      case 'pureglass':
        return l10n.tr(ar: 'الزجاج النقي (Pure Glass)', en: 'Pure Glass');
      case 'emerald':
        return l10n.tr(ar: 'الزمرد (Emerald)', en: 'Emerald');
      default:
        return value;
    }
  }

  void _showDetails(BuildContext context, dynamic log) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        title: Text(
          l10n.tr(ar: 'تفاصيل التغيير', en: 'Change details'),
          textAlign: TextAlign.right,
          style: TextStyle(
            color: isDark ? Colors.white : Colors.black87,
            fontFamily: 'Cairo',
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: (log.details as Map<String, dynamic>).entries.map((e) {
              final detail = e.value as Map<String, dynamic>;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '• ${e.key}:',
                      style: TextStyle(
                        color: isDark ? AppColors.goldAccent : AppColors.primaryBrandPath,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Cairo',
                      ),
                    ),
                    Text(
                      '  ${l10n.tr(ar: 'من', en: 'From')}: ${_translateValue(l10n, detail["من"].toString())}',
                      style: TextStyle(
                        color: isDark ? Colors.white70 : Colors.black54,
                        fontSize: 13,
                        fontFamily: 'Cairo',
                      ),
                    ),
                    Text(
                      '  ${l10n.tr(ar: 'إلى', en: 'To')}: ${_translateValue(l10n, detail["إلى"].toString())}',
                      style: TextStyle(
                        color: isDark ? Colors.white : Colors.black87,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Cairo',
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              l10n.tr(ar: 'إغلاق', en: 'Close'),
              style: TextStyle(
                fontFamily: 'Cairo',
                color: isDark ? Colors.white70 : AppColors.primaryBrandPath,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmClear(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        title: Text(
          l10n.tr(ar: 'مسح السجل', en: 'Clear log'),
          textAlign: TextAlign.right,
          style: TextStyle(
            fontFamily: 'Cairo',
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        content: Text(
          l10n.tr(ar: 'هل أنت متأكد من مسح جميع النشاطات من السجل؟', en: 'Are you sure you want to clear all activities from the log?'),
          textAlign: TextAlign.right,
          style: TextStyle(
            fontFamily: 'Cairo',
            color: isDark ? Colors.white70 : Colors.black54,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              l10n.tr(ar: 'إلغاء', en: 'Cancel'),
              style: TextStyle(
                fontFamily: 'Cairo',
                color: isDark ? Colors.white54 : Colors.black54,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              ref.read(activityLogNotifierProvider.notifier).clearLogs();
              Navigator.pop(ctx);
            },
            child: Text(
              l10n.tr(ar: 'مسح', en: 'Clear'),
              style: TextStyle(color: Colors.red, fontFamily: 'Cairo'),
            ),
          ),
        ],
      ),
    );
  }
}










