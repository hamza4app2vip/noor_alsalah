﻿import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:io';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../domain/entities/app_settings.dart';
import '../../domain/entities/slide_item.dart';
import '../providers/settings_provider.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../widgets/glass_selection_dialog.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class SlidesManagementScreen extends ConsumerStatefulWidget {
  const SlidesManagementScreen({super.key});

  @override
  ConsumerState<SlidesManagementScreen> createState() =>
      _SlidesManagementScreenState();
}

class _SlidesManagementScreenState
    extends ConsumerState<SlidesManagementScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  final _uuid = const Uuid();

  Color get _accent => Theme.of(context).brightness == Brightness.dark
      ? AppColors.goldAccent
      : const Color(0xFF1AA85A);

  Color _getTextColor(bool isDark) => isDark ? Colors.white : Colors.black87;
  Color _getSubTextColor(bool isDark) =>
      isDark ? Colors.white70 : Colors.black54;
  Color _getCardColor(bool isDark) =>
      isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white;
  Color _getBg(bool isDark) =>
      isDark ? const Color(0xFF0F172A) : const Color(0xFFF2F5F9);

  void _updateSettings(AppSettings newSettings) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(newSettings);
    GlassToast.show(context, l10n.tr(ar: ' تم الحفظ بنجاح', en: 'Saved successfully'));
  }

  void _addOrEditSlide(AppSettings settings, {SlideItem? slide}) {
    final isEditing = slide != null;
    String type = slide?.type ?? 'TEXT';
    final contentController = TextEditingController(text: slide?.content ?? '');
    final durationController = TextEditingController(text: slide?.durationSeconds?.toString() ?? '');

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setStateBuilder) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final accent = _accent;
          return Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            insetPadding:
                const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
            child: Container(
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF1E293B) : Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                    color: isDark ? Colors.white10 : Colors.transparent),
              ),
              padding: const EdgeInsets.all(24),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: Icon(Icons.close,
                              color: _getSubTextColor(isDark)),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                        Text(
                          isEditing ? l10n.tr(ar: 'تعديل الشريحة', en: 'Edit slide') : l10n.tr(ar: 'إضافة شريحة جديدة', en: 'Add new slide'),
                          style: TextStyle(
                              color: _getTextColor(isDark),
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // Type selector
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(l10n.tr(ar: 'نوع الشريحة', en: 'Slide type'),
                          style: TextStyle(
                              color: _getSubTextColor(isDark),
                              fontSize: 12,
                              fontFamily: 'Cairo')),
                    ),
                    const SizedBox(height: 6),
                    InkWell(
                      onTap: () async {
                        final currentVal = type;
                        final result = await showDialog<String>(
                          context: context,
                          builder: (context) => GlassSelectionDialog<String>(
                            title: l10n.tr(ar: 'نوع الشريحة', en: 'Slide type'),
                            initialValue: currentVal,
                            items: [
                              GlassSelectionItem(
                                  title: l10n.tr(ar: 'نص', en: 'Text'),
                                  subtitle: l10n.tr(ar: 'نص (TEXT)', en: 'Text (TEXT)'),
                                  value: 'TEXT'),
                              GlassSelectionItem(
                                  title: l10n.tr(ar: 'صورة من الجهاز', en: 'Image from device'),
                                  subtitle: l10n.tr(ar: 'ملف (FILE)', en: 'File (FILE)'),
                                  value: 'FILE'),
                              GlassSelectionItem(
                                  title: l10n.tr(ar: 'رابط صورة/صفحة', en: 'Image/Page URL'),
                                  subtitle: l10n.tr(ar: 'رابط (LINK)', en: 'Link (LINK)'),
                                  value: 'LINK'),
                            ],
                          ),
                        );
                        if (result != null)
                          setStateBuilder(() => type = result);
                      },
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: _getBg(isDark),
                          borderRadius: BorderRadius.circular(14),
                          border:
                              Border.all(color: accent.withValues(alpha: 0.3)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(Icons.keyboard_arrow_down_rounded,
                                color: accent),
                            Text(
                              type == 'TEXT'
                                  ? l10n.tr(ar: 'نص', en: 'Text')
                                  : type == 'FILE'
                                      ? l10n.tr(ar: 'صورة من الجهاز', en: 'Image from device')
                                      : l10n.tr(ar: 'رابط صورة/صفحة', en: 'Image/Page URL'),
                              style: TextStyle(
                                  color: _getTextColor(isDark),
                                  fontFamily: 'Cairo',
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Content input
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(l10n.tr(ar: 'المحتوى', en: 'Content'),
                          style: TextStyle(
                              color: _getSubTextColor(isDark),
                              fontSize: 12,
                              fontFamily: 'Cairo')),
                    ),
                    const SizedBox(height: 6),
                    if (type != 'FILE')
                      Container(
                        decoration: BoxDecoration(
                          color: type == 'TEXT'
                              ? accent.withValues(alpha: 0.03)
                              : _getBg(isDark),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: type == 'TEXT'
                                  ? accent.withValues(alpha: 0.2)
                                  : isDark
                                      ? Colors.white10
                                      : Colors.black12,
                              width: type == 'TEXT' ? 1.5 : 1.0),
                        ),
                        child: TextField(
                          controller: contentController,
                          maxLines: type == 'TEXT' ? 5 : 1,
                          textDirection: TextDirection.rtl,
                          textAlign: type == 'TEXT'
                              ? TextAlign.center
                              : TextAlign.right,
                          style: TextStyle(
                              color: type == 'TEXT'
                                  ? accent
                                  : _getTextColor(isDark),
                              fontSize: type == 'TEXT' ? 18 : 14,
                              fontWeight: type == 'TEXT'
                                  ? FontWeight.w800
                                  : FontWeight.normal,
                              height: 1.6,
                              fontFamily: 'Cairo'),
                          decoration: InputDecoration(
                            hintText: type == 'TEXT'
                                ? l10n.tr(ar: 'أدخل نص الشريحة هنا...\n(استخدم | لتقسيم الأسطر بشكل أنيق)', en: 'Enter slide text here...\n(use | to split lines neatly)')
                                : l10n.tr(ar: 'أدخل الرابط (https://...)', en: 'Enter URL (https://...)'),
                            hintStyle: TextStyle(
                                color: _getSubTextColor(isDark)
                                    .withValues(alpha: 0.4),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'Cairo'),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                          ),
                        ),
                      ),
                    if (type == 'FILE') ...[
                      TvFocusable(
                        onPressed: () async {
                          final picker = ImagePicker();
                          final picked = await picker.pickImage(
                              source: ImageSource.gallery);
                          if (picked != null) {
                            try {
                              final appDir =
                                  await getApplicationDocumentsDirectory();
                              final slidesDir =
                                  Directory('${appDir.path}/slides');
                              if (!await slidesDir.exists()) {
                                await slidesDir.create(recursive: true);
                              }
                              final fileName =
                                  '${DateTime.now().millisecondsSinceEpoch}_${picked.name}';
                              final targetPath = '${slidesDir.path}/$fileName';
                              await File(picked.path).copy(targetPath);
                              if (!ctx.mounted) return;
                              contentController.text = fileName;
                              setStateBuilder(() {});
                            } catch (e) {
                              if (!ctx.mounted) return;
                              GlassToast.show(ctx, '⚠️ Error saving file',
                                  isError: true);
                            }
                          }
                        },
                        borderRadius: BorderRadius.circular(14),
                        focusColor: accent,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          decoration: BoxDecoration(
                            color: accent.withValues(alpha: 0.07),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                                color: accent.withValues(alpha: 0.3),
                                style: BorderStyle.solid),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                contentController.text.isEmpty
                                    ? Icons.add_photo_alternate_rounded
                                    : Icons.check_circle_rounded,
                                color: accent,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                contentController.text.isEmpty
                                    ? l10n.tr(ar: 'اختر صورة من المعرض', en: 'Choose image from gallery')
                                    : l10n.tr(ar: 'تم اختيار الصورة ✓', en: 'Image selected ✓'),
                                style: TextStyle(
                                    color: accent,
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 16),
                    // Duration input
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(l10n.tr(ar: 'مدة عرض الشريحة (ثانية) - اختياري', en: 'Slide duration (seconds) - optional'),
                          style: TextStyle(
                              color: _getSubTextColor(isDark),
                              fontSize: 12,
                              fontFamily: 'Cairo')),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      decoration: BoxDecoration(
                        color: _getBg(isDark),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: isDark ? Colors.white10 : Colors.black12),
                      ),
                      child: TextField(
                        controller: durationController,
                        keyboardType: TextInputType.number,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        style: TextStyle(color: _getTextColor(isDark), fontFamily: 'Cairo'),
                        decoration: InputDecoration(
                          hintText: l10n.tr(ar: 'اتركه فارغاً للافتراضي (${settings.slideDurationSeconds})', en: 'Leave empty for default (${settings.slideDurationSeconds})'),
                          hintStyle: TextStyle(
                              color: _getSubTextColor(isDark).withValues(alpha: 0.4),
                              fontSize: 13,
                              fontFamily: 'Cairo'),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            style: TextButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                            child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                                style: TextStyle(
                                    color: _getSubTextColor(isDark),
                                    fontFamily: 'Cairo')),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accent,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            onPressed: () {
                              if (contentController.text.trim().isEmpty) return;
                                final newItem = SlideItem(
                                  id: slide?.id ?? _uuid.v4(),
                                  type: type,
                                  content: contentController.text.trim(),
                                  enabled: slide?.enabled ?? true,
                                  order:
                                      slide?.order ?? settings.slidesList.length,
                                  durationSeconds: int.tryParse(durationController.text),
                                );
                              final currentParsed = settings.slidesList
                                  .map((e) => SlideItem.fromJson(e))
                                  .toList();
                              if (isEditing) {
                                final slideId = slide.id;
                                final index = currentParsed
                                    .indexWhere((e) => e.id == slideId);
                                if (index != -1) currentParsed[index] = newItem;
                              } else {
                                currentParsed.add(newItem);
                              }
                              _updateSettings(settings.copyWith(
                                slidesList: currentParsed
                                    .map((e) => e.toJson())
                                    .toList(),
                              ));
                              Navigator.pop(ctx);
                            },
                            child: Text(l10n.tr(ar: 'حفظ الشريحة', en: 'Save slide'),
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Cairo')),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children, bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: !isDark
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.02), blurRadius: 10)
              ]
            : null,
      ),
      child: Column(children: children),
    );
  }

  Widget _divider(bool isDark) => Divider(
      height: 1,
      color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
      indent: 56,
      endIndent: 16);

  Widget _buildDurationRow(
      String title, int value, Function(int) onChange, bool isDark) {
    final accent = _accent;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        textDirection: TextDirection.rtl,
        children: [
          // 1. Title (Right)
          Expanded(
            child: Text(title,
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _getTextColor(isDark),
                    fontSize: 14,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.w500)),
          ),
          const SizedBox(width: 12),
          // 2. Counter controls (Left)
          Row(
            textDirection: TextDirection.ltr,
            children: [
              _buildCounterButton(
                  icon: Icons.remove,
                  onTap: () => onChange(value > 1 ? value - 1 : 1),
                  color: Colors.redAccent),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 10),
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: accent.withValues(alpha: 0.2)),
                ),
                child: Text('$value',
                    style: TextStyle(
                        color: accent,
                        fontSize: 17,
                        fontWeight: FontWeight.bold)),
              ),
              _buildCounterButton(
                  icon: Icons.add,
                  onTap: () => onChange(value + 1),
                  color: accent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCounterButton(
      {required IconData icon,
      required VoidCallback onTap,
      required Color color}) {
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(8),
      focusColor: color,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: color.withValues(alpha: 0.1),
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Icon(icon, color: color, size: 16),
      ),
    );
  }

  Widget _buildSlideCard(AppSettings settings, List<SlideItem> slides, int idx,
      SlideItem slide, bool isDark) {
    final accent = _accent;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: _getCardColor(isDark),
        borderRadius: BorderRadius.circular(18),
        boxShadow: !isDark
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.02),
                    blurRadius: 8,
                    offset: const Offset(0, 2))
              ]
            : null,
        border: Border.all(
            color: slide.enabled
                ? accent.withValues(alpha: 0.3)
                : (isDark
                    ? Colors.white10
                    : Colors.black.withValues(alpha: 0.05))),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          textDirection: TextDirection.rtl,
          children: [
            // 1. Badge & Text info (Right)
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: slide.enabled
                              ? accent.withValues(alpha: 0.1)
                              : (isDark
                                  ? Colors.white.withValues(alpha: 0.1)
                                  : const Color(0xFFF0F0F0)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          slide.type == 'TEXT'
                              ? l10n.tr(ar: 'نص', en: 'Text')
                              : slide.type == 'FILE'
                                  ? l10n.tr(ar: 'صورة', en: 'Image')
                                  : l10n.tr(ar: 'رابط', en: 'Link'),
                          style: TextStyle(
                              color: slide.enabled
                                  ? accent
                                  : _getSubTextColor(isDark),
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo'),
                        ),
                      ),
                      if (slide.durationSeconds != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.blue.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            l10n.tr(ar: '${slide.durationSeconds}ث', en: '${slide.durationSeconds}s'),
                            style: const TextStyle(
                                color: Colors.blue,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo'),
                          ),
                        ),
                      ],
                      const SizedBox(width: 8),
                      Text(l10n.tr(ar: 'شريحة #${idx + 1}', en: 'Slide #${idx + 1}'),
                          style: TextStyle(
                              color: _getSubTextColor(isDark)
                                  .withValues(alpha: 0.5),
                              fontSize: 11,
                              fontFamily: 'Cairo')),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    slide.type == 'TEXT'
                        ? slide.content.replaceAll('|', ' • ')
                        : slide.content,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                        color: slide.enabled
                            ? _getTextColor(isDark)
                            : _getSubTextColor(isDark).withValues(alpha: 0.5),
                        fontSize: 14,
                        fontFamily: 'Cairo',
                        fontWeight: slide.enabled
                            ? FontWeight.w500
                            : FontWeight.normal),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            // 2. Actions (Left)
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.edit_rounded,
                      color: accent.withValues(alpha: 0.7), size: 22),
                  onPressed: () => _addOrEditSlide(settings, slide: slide),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded,
                      color: Colors.redAccent, size: 22),
                  onPressed: () => _deleteDialog(settings, slides, idx, isDark),
                ),
                const SizedBox(width: 4),
                CupertinoSwitch(
                  value: slide.enabled,
                  activeTrackColor: accent,
                  onChanged: (v) {
                    final updated = List<SlideItem>.from(slides);
                    updated[idx] = slide.copyWith(enabled: v);
                    _updateSettings(settings.copyWith(
                        slidesList: updated.map((e) => e.toJson()).toList()));
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _deleteDialog(
      AppSettings settings, List<SlideItem> slides, int idx, bool isDark) {
    showDialog(
      context: context,
      builder: (ctx2) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(l10n.tr(ar: 'حذف الشريحة؟', en: 'Delete slide?'),
            textAlign: TextAlign.right,
            style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
                color: _getTextColor(isDark))),
        content: Text(l10n.tr(ar: 'لا يمكن التراجع عن هذا الإجراء', en: 'This action cannot be undone'),
            textAlign: TextAlign.right,
            style: TextStyle(
                fontFamily: 'Cairo', color: _getSubTextColor(isDark))),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx2),
              child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                  style: TextStyle(color: _getSubTextColor(isDark)))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
                elevation: 0),
            onPressed: () {
              final updated = List<SlideItem>.from(slides);
              updated.removeAt(idx);
              _updateSettings(settings.copyWith(
                  slidesList: updated.map((e) => e.toJson()).toList()));
              Navigator.pop(ctx2);
            },
            child: Text(l10n.tr(ar: 'حذف', en: 'Delete'),
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final settings = ref.watch(settingsNotifierProvider);
    final slides =
        settings.slidesList.map((e) => SlideItem.fromJson(e)).toList();
    final accent = _accent;

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'إدارة شرائح الإعلانات', en: 'Announcement Slides Management')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addOrEditSlide(settings),
        backgroundColor: accent,
        foregroundColor: Colors.white,
        elevation: 4,
        icon: const Icon(Icons.add_rounded),
        label: Text(l10n.tr(ar: 'إضافة شريحة جديد', en: 'Add new slide'),
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
      ),
      body: Container(
        decoration: LuxuryGlassTheme.getPageDecoration(isDark),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 120, 16, 120),
          children: [
            // ── ① إعدادات عامة ──
            _buildSettingsCard([
              _buildDurationRow(
                  l10n.tr(ar: 'مدة عرض الشريحة (ثانية)', en: 'Slide display duration (seconds)'), settings.slideDurationSeconds,
                  (v) {
                _updateSettings(settings.copyWith(slideDurationSeconds: v));
              }, isDark),
              _divider(isDark),
              _buildDurationRow(l10n.tr(ar: 'وقت الشاشة الرئيسية (ثانية)', en: 'Home screen time (seconds)'),
                  settings.mainScreenDurationSeconds, (v) {
                _updateSettings(
                    settings.copyWith(mainScreenDurationSeconds: v));
              }, isDark),
              _divider(isDark),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(l10n.tr(ar: 'وضع ظهور الشرائح:', en: 'Slides display mode:'),
                        style: TextStyle(
                            color: _getTextColor(isDark),
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo')),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        _buildModeOption(
                          label: l10n.tr(ar: 'بعد الصلاة', en: 'After prayer'),
                          value: 'AFTER_PRAYER',
                          current: settings.slidesShowMode,
                          onSelect: (v) => _updateSettings(
                              settings.copyWith(slidesShowMode: v)),
                          isDark: isDark,
                          accent: accent,
                        ),
                        const SizedBox(width: 8),
                        _buildModeOption(
                          label: l10n.tr(ar: 'يدوي الآن', en: 'Manual now'),
                          value: 'MANUAL',
                          current: settings.slidesShowMode,
                          onSelect: (v) => _updateSettings(
                              settings.copyWith(slidesShowMode: v)),
                          isDark: isDark,
                          accent: accent,
                        ),
                        const SizedBox(width: 8),
                        _buildModeOption(
                          label: l10n.tr(ar: 'إيقاف', en: 'Off'),
                          value: 'OFF',
                          current: settings.slidesShowMode,
                          onSelect: (v) => _updateSettings(
                              settings.copyWith(slidesShowMode: v)),
                          isDark: isDark,
                          accent: accent,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ], isDark),

            const SizedBox(height: 24),

            // ── ② قائمة الشرائح ──
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(Icons.collections_rounded,
                    color: AppColors.primaryGold, size: 18),
                const SizedBox(width: 8),
                Text(l10n.tr(ar: 'قائمة الشرائح (${slides.length})', en: 'Slides list (${slides.length})'),
                    style: TextStyle(
                        color: AppColors.primaryGold,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        fontFamily: 'Cairo')),
              ],
            ),
            const SizedBox(height: 10),

            if (slides.isEmpty)
              Container(
                padding: const EdgeInsets.all(40),
                decoration: BoxDecoration(
                    color: _getCardColor(isDark),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: isDark
                            ? Colors.white10
                            : Colors.black.withValues(alpha: 0.05))),
                child: Column(
                  children: [
                    Icon(Icons.layers_clear_rounded,
                        size: 48,
                        color: isDark ? Colors.white24 : Colors.black12),
                    const SizedBox(height: 12),
                    Text(l10n.tr(ar: 'لا توجد شرائح حالياً', en: 'No slides currently'),
                        style: TextStyle(
                            color: _getSubTextColor(isDark),
                            fontFamily: 'Cairo')),
                  ],
                ),
              )
            else
              ...slides.asMap().entries.map((e) =>
                  _buildSlideCard(settings, slides, e.key, e.value, isDark)),
          ],
        ),
      ),
    );
  }

  Widget _buildModeOption(
      {required String label,
      required String value,
      required String current,
      required ValueChanged<String> onSelect,
      required bool isDark,
      required Color accent}) {
    final bool isSelected = current == value;
    return Expanded(
      child: TvFocusable(
        onPressed: () => onSelect(value),
        borderRadius: BorderRadius.circular(10),
        focusColor: accent,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? accent
                : (isDark
                    ? Colors.white.withValues(alpha: 0.05)
                    : Colors.white),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
                color: isSelected
                    ? accent
                    : (isDark
                        ? Colors.white10
                        : Colors.black.withValues(alpha: 0.1))),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
                color: isSelected ? Colors.white : _getSubTextColor(isDark),
                fontFamily: 'Cairo',
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal),
          ),
        ),
      ),
    );
  }
}




