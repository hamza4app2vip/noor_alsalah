﻿import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import 'package:noor_prayer_tv/features/settings/presentation/widgets/admin_server_tile.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class RemoteControlScreen extends ConsumerStatefulWidget {
  const RemoteControlScreen({super.key});

  @override
  ConsumerState<RemoteControlScreen> createState() =>
      _RemoteControlScreenState();
}

class _RemoteControlScreenState extends ConsumerState<RemoteControlScreen> {
  bool _didRequestInitialFocus = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_didRequestInitialFocus) return;
    _didRequestInitialFocus = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      FocusScope.of(context).nextFocus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'لوحة التحكم عن بعد', en: 'Remote Control Panel')),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: LuxuryGlassTheme.getPageDecoration(isDark),
        child: FocusTraversalGroup(
          policy: OrderedTraversalPolicy(),
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 120, 16, 40),
              children: const [
                AdminServerTile(),
                SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


