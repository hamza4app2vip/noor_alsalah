﻿import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../domain/entities/app_settings.dart';
import '../../domain/entities/ticker_item.dart';
import '../providers/settings_provider.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';
import 'package:uuid/uuid.dart';

class MarqueeSettingsScreen extends ConsumerStatefulWidget {
  const MarqueeSettingsScreen({super.key});

  @override
  ConsumerState<MarqueeSettingsScreen> createState() =>
      _MarqueeSettingsScreenState();
}

class _MarqueeSettingsScreenState extends ConsumerState<MarqueeSettingsScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  final _uuid = const Uuid();

  // ────────────────────────────────────────────
  // ألوان تعتمد على الثيم
  // ────────────────────────────────────────────
  Color get _emerald => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFFDCB881)
      : const Color(0xFF1AA85A);

  void _updateSettings(AppSettings settings) =>
      ref.read(settingsNotifierProvider.notifier).updateSettings(settings);

  // ──────────────────────────── ADD / EDIT DIALOG ────────────────────────────
  void _addOrEditItem({TickerItem? existingItem}) {
    final textController =
        TextEditingController(text: existingItem?.text ?? '');
    TickerScheduleType selectedType =
        existingItem?.scheduleType ?? TickerScheduleType.daily;
    String dateInput = existingItem?.date ?? '01/01';
    int durationSeconds =
        existingItem?.displayDurationSeconds ?? 86400; // Default 24h
    bool isEnabled = existingItem?.enabled ?? true;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (ctx, setS) {
        final isDarkMode = Theme.of(ctx).brightness == Brightness.dark;
        final bgColor = isDarkMode ? const Color(0xFF1E293B) : Colors.white;
        final textColor = isDarkMode ? Colors.white : Colors.black87;
        final subTextColor = isDarkMode ? Colors.white60 : Colors.black54;
        final fieldBg =
            isDarkMode ? const Color(0xFF0F172A) : const Color(0xFFF2F5F9);
        final borderColor =
            isDarkMode ? Colors.white12 : const Color(0xFFE0E0E0);
        return Dialog(
          backgroundColor: bgColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // ── HEADER ──
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.close_rounded,
                          color: subTextColor, size: 22),
                      onPressed: () => Navigator.pop(ctx),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                    Text(
                      existingItem == null ? l10n.tr(ar: 'إضافة رسالة', en: 'Add message') : l10n.tr(ar: 'تعديل رسالة', en: 'Edit message'),
                      style: TextStyle(
                          color: textColor,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo'),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _emerald.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(Icons.edit_note_rounded,
                          color: _emerald, size: 18),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // ── TEXT FIELD ──
                TextField(
                  controller: textController,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: textColor, fontFamily: 'Cairo', fontSize: 15),
                  maxLines: 3,
                  decoration: InputDecoration(
                    hintText: l10n.tr(ar: 'أدخل نص الرسالة هنا...', en: 'Enter message text here...'),
                    hintTextDirection: TextDirection.rtl,
                    hintStyle: TextStyle(
                        color: subTextColor, fontFamily: 'Cairo', fontSize: 14),
                    filled: true,
                    fillColor: fieldBg,
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: borderColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: _emerald, width: 1.5)),
                  ),
                ),
                const SizedBox(height: 16),

                // ── SCHEDULE TYPE ──
                Container(
                  decoration: BoxDecoration(
                    color: fieldBg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: borderColor),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<TickerScheduleType>(
                      value: selectedType,
                      isExpanded: true,
                      dropdownColor:
                          isDarkMode ? const Color(0xFF1E293B) : Colors.white,
                      alignment: AlignmentDirectional.centerEnd,
                      icon: Icon(Icons.keyboard_arrow_down_rounded,
                          color: _emerald),
                      style: TextStyle(
                          color: textColor, fontFamily: 'Cairo', fontSize: 14),
                      items: TickerScheduleType.values.map((type) {
                        final label = type == TickerScheduleType.daily
                            ? l10n.tr(ar: 'يومياً', en: 'Daily')
                            : type == TickerScheduleType.jomoa
                                ? l10n.tr(ar: 'يوم الجمعة', en: 'Friday')
                                : l10n.tr(ar: 'تاريخ معين', en: 'Specific date');
                        final icon = type == TickerScheduleType.daily
                            ? Icons.repeat_rounded
                            : type == TickerScheduleType.jomoa
                                ? Icons.mosque_rounded
                                : Icons.calendar_today_rounded;
                        return DropdownMenuItem(
                          value: type,
                          child: Row(
                            textDirection: TextDirection.rtl,
                            children: [
                              Icon(icon, color: _emerald, size: 16),
                              const SizedBox(width: 8),
                              Text(label,
                                  style: const TextStyle(fontFamily: 'Cairo')),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: (val) {
                        if (val != null) setS(() => selectedType = val);
                      },
                    ),
                  ),
                ),

                // ── DATE INPUT ──
                if (selectedType == TickerScheduleType.date) ...[
                  const SizedBox(height: 12),
                  TextField(
                    onChanged: (val) => dateInput = val,
                    controller: TextEditingController(text: dateInput),
                    textDirection: TextDirection.ltr,
                    style: TextStyle(color: textColor, fontFamily: 'Cairo'),
                    decoration: InputDecoration(
                      hintText: l10n.tr(ar: 'مثال: 10/01', en: 'Example: 10/01'),
                      filled: true,
                      fillColor: fieldBg,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: borderColor)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: _emerald, width: 1.5)),
                    ),
                  ),
                ],
                const SizedBox(height: 16),

                // ── DURATION SELECTOR ──
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: fieldBg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: borderColor),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _formatDuration(durationSeconds, l10n),
                            style: TextStyle(
                                color: _emerald,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                fontFamily: 'Cairo'),
                          ),
                          Text(l10n.tr(ar: 'فترة ظهور الخبر', en: 'News display duration'),
                              style: TextStyle(
                                  color: textColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  fontFamily: 'Cairo')),
                        ],
                      ),
                      Focus(
                        canRequestFocus: true,
                        onKeyEvent: (node, event) {
                          if (event is KeyDownEvent || event is KeyRepeatEvent) {
                            if (event.logicalKey == LogicalKeyboardKey.arrowRight || event.logicalKey == LogicalKeyboardKey.audioVolumeUp) {
                              final newValue = (durationSeconds + (604800 - 60) ~/ 20).clamp(60, 604800);
                              if (newValue != durationSeconds) setS(() => durationSeconds = newValue);
                              return KeyEventResult.handled;
                            }
                            if (event.logicalKey == LogicalKeyboardKey.arrowLeft || event.logicalKey == LogicalKeyboardKey.audioVolumeDown) {
                              final newValue = (durationSeconds - (604800 - 60) ~/ 20).clamp(60, 604800);
                              if (newValue != durationSeconds) setS(() => durationSeconds = newValue);
                              return KeyEventResult.handled;
                            }
                            if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
                              FocusManager.instance.primaryFocus?.focusInDirection(TraversalDirection.up);
                              return KeyEventResult.handled;
                            }
                            if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
                              FocusManager.instance.primaryFocus?.focusInDirection(TraversalDirection.down);
                              return KeyEventResult.handled;
                            }
                          }
                          return KeyEventResult.ignored;
                        },
                        child: Builder(
                          builder: (context) {
                            final isFocused = Focus.of(context).hasFocus;
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                              decoration: isFocused
                                  ? BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: _emerald, width: 2),
                                      color: _emerald.withValues(alpha: 0.1),
                                    )
                                  : const BoxDecoration(
                                      border: Border.fromBorderSide(BorderSide(color: Colors.transparent, width: 2)),
                                    ),
                              child: ExcludeFocus(
                                child: Slider(
                                  value: durationSeconds.toDouble(),
                                  min: 60, // Min 1 minute
                                  max: 604800, // Max 7 days
                                  activeColor: _emerald,
                                  inactiveColor: borderColor,
                                  onChanged: (val) =>
                                      setS(() => durationSeconds = val.toInt()),
                                ),
                              ),
                            );
                          }
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildDurationChip(setS, l10n.tr(ar: 'دقيقة', en: 'minute'), 60, durationSeconds,
                              _emerald, (v) => setS(() => durationSeconds = v)),
                          _buildDurationChip(
                              setS,
                              l10n.tr(ar: 'ساعة', en: 'hour'),
                              3600,
                              durationSeconds,
                              _emerald,
                              (v) => setS(() => durationSeconds = v)),
                          _buildDurationChip(
                              setS,
                              l10n.tr(ar: 'يوم', en: 'day'),
                              86400,
                              durationSeconds,
                              _emerald,
                              (v) => setS(() => durationSeconds = v)),
                          _buildDurationChip(
                              setS,
                              l10n.tr(ar: 'أسبوع', en: 'week'),
                              604800,
                              durationSeconds,
                              _emerald,
                              (v) => setS(() => durationSeconds = v)),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // ── ENABLE TOGGLE ──
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: isEnabled
                        ? _emerald.withValues(alpha: 0.06)
                        : (isDarkMode
                            ? Colors.white.withValues(alpha: 0.04)
                            : const Color(0xFFF5F5F7)),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isEnabled
                          ? _emerald.withValues(alpha: 0.2)
                          : borderColor,
                    ),
                  ),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Icon(Icons.toggle_on_rounded, color: _emerald, size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(l10n.tr(ar: 'تفعيل الرسالة', en: 'Enable message'),
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                                color: textColor,
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.w600,
                                fontSize: 14)),
                      ),
                      CupertinoSwitch(
                        value: isEnabled,
                        activeTrackColor: _emerald,
                        inactiveTrackColor:
                            Colors.black.withValues(alpha: 0.10),
                        onChanged: (val) => setS(() => isEnabled = val),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // ── ACTIONS ──
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: borderColor),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                            style: TextStyle(
                                color: subTextColor,
                                fontFamily: 'Cairo',
                                fontSize: 15)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _emerald,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: () {
                          if (textController.text.trim().length < 3) {
                            GlassToast.show(ctx, l10n.tr(ar: ' النص قصير جداً', en: 'Text is too short'),
                                isError: true);
                            return;
                          }
                          Navigator.pop(
                              ctx,
                              TickerItem(
                                id: existingItem?.id ?? _uuid.v4(),
                                enabled: isEnabled,
                                order: existingItem?.order ??
                                    DateTime.now().millisecondsSinceEpoch,
                                scheduleType: selectedType,
                                text: textController.text.trim(),
                                date: selectedType == TickerScheduleType.date
                                    ? dateInput
                                    : null,
                                displayDurationSeconds: durationSeconds,
                                createdAt:
                                    existingItem?.createdAt ?? DateTime.now(),
                              ));
                        },
                        child: Text(l10n.tr(ar: 'حفظ', en: 'Save'),
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo',
                                fontSize: 15)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }),
    ).then((result) {
      if (!mounted || result is! TickerItem) return;
      final settings = ref.read(settingsNotifierProvider);
      final list = List<TickerItem>.from(settings.tickerItems);

      if (existingItem != null) {
        final index = list.indexWhere((e) => e.id == result.id);
        if (index != -1) list[index] = result;
      } else {
        list.add(result);
      }
      list.sort((a, b) => a.order.compareTo(b.order));
      _updateSettings(settings.copyWith(tickerItems: list));
      GlassToast.show(context, l10n.tr(ar: ' تم الحفظ بنجاح', en: 'Saved successfully'));
    });
  }

  // ──────────────────────────── DELETE DIALOG ────────────────────────────────
  void _deleteItem(TickerItem item) {
    showDialog<bool>(
      context: context,
      builder: (ctx) {
        final isDark = Theme.of(ctx).brightness == Brightness.dark;
        return Dialog(
          backgroundColor: Colors.transparent,
          child: _DialogCard(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.08),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.delete_outline_rounded,
                    color: Colors.red, size: 30),
              ),
              const SizedBox(height: 16),
              Text(l10n.tr(ar: 'حذف الرسالة', en: 'Delete message'),
                  style: TextStyle(
                      color: isDark ? Colors.white : Colors.black87,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo')),
              const SizedBox(height: 8),
              Text(l10n.tr(ar: 'هل أنت متأكد من حذف هذه الرسالة؟', en: 'Are you sure you want to delete this message?'),
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black54,
                      fontSize: 14,
                      fontFamily: 'Cairo')),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFE0E0E0)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel'),
                          style: TextStyle(
                              color: isDark ? Colors.white70 : Colors.black54, fontFamily: 'Cairo')),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      onPressed: () => Navigator.pop(ctx, true),
                      child: Text(l10n.tr(ar: 'حذف', en: 'Delete'),
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo')),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ); // This closes the Dialog widget
      }, // This closes the builder function
    ).then((confirmed) {
      if (!mounted || confirmed != true) return;
      final settings = ref.read(settingsNotifierProvider);
      final list = List<TickerItem>.from(settings.tickerItems)
        ..removeWhere((e) => e.id == item.id);
      _updateSettings(settings.copyWith(tickerItems: list));
      GlassToast.show(context, l10n.tr(ar: '🗑️ تم حذف الرسالة', en: '🗑️ Message deleted'));
    });
  }

  void _moveItemUp(TickerItem item, int currentIndex) {
    if (currentIndex == 0) return;
    final settings = ref.read(settingsNotifierProvider);
    final list = List<TickerItem>.from(settings.tickerItems);
    final prev = list[currentIndex - 1];
    list[currentIndex - 1] = prev.copyWith(order: item.order);
    list[currentIndex] = item.copyWith(order: prev.order);
    list.sort((a, b) => a.order.compareTo(b.order));
    _updateSettings(settings.copyWith(tickerItems: list));
  }

  // ──────────────────────────── BUILD ────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    final items = settings.tickerItems;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? const Color(0xFF0F172A)
            : Colors.white,
        extendBodyBehindAppBar: true,
        appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'الشريط الإخباري والآيات', en: 'News Ticker & Verses')),
        // ──── FAB: إضافة رسالة ────
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _addOrEditItem(),
          backgroundColor: _emerald,
          foregroundColor: Colors.white,
          elevation: 4,
          icon: const Icon(Icons.add_rounded),
          label: Text(l10n.tr(ar: 'إضافة رسالة', en: 'Add message'),
              style:
                  TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 100, 16, 120),
          children: [
            // ──── قسم التفعيل ────
            _SectionLabel(
                label: l10n.tr(ar: 'إعدادات عامة', en: 'General settings'), icon: Icons.settings_rounded),
            _SettingsCard(children: [
              // تفعيل الشريط
              _LightToggleRow(
                title: l10n.tr(ar: 'تفعيل الشريط المتحرك', en: 'Enable scrolling ticker'),
                subtitle: l10n.tr(ar: 'عرض الرسائل أسفل الشاشة', en: 'Show messages at the bottom of the screen'),
                icon: Icons.text_fields_rounded,
                iconColor: _emerald,
                value: settings.showMarqueeTicker,
                onChanged: (v) =>
                    _updateSettings(settings.copyWith(showMarqueeTicker: v)),
              ),
              const Divider(
                  height: 1,
                  color: Colors.white12,
                  indent: 56,
                  endIndent: 16),
              // عداد رمضان
              _LightToggleRow(
                title: l10n.tr(ar: 'إدماج عداد رمضان', en: 'Integrate Ramadan countdown'),
                subtitle: l10n.tr(ar: 'يُضاف تلقائياً قبل رمضان', en: 'Added automatically before Ramadan'),
                icon: Icons.nightlight_round,
                iconColor: const Color(0xFF8E44AD),
                value: settings.ramadanCountdownInjectEnabled,
                onChanged: (v) => _updateSettings(
                    settings.copyWith(ramadanCountdownInjectEnabled: v)),
              ),
            ]),
            const SizedBox(height: 24),

            // ──── قسم الرسائل ────
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // عدد الرسائل badge
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _emerald.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    l10n.tr(ar: '${items.length} رسائل', en: '${items.length} messages'),
                    style: TextStyle(
                        color: _emerald,
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 12),
                  ),
                ),
                _SectionLabel(
                    label: l10n.tr(ar: 'الرسائل والإعلانات', en: 'Messages & announcements'),
                    icon: Icons.campaign_rounded,
                    compact: true),
              ],
            ),
            const SizedBox(height: 12),

            // ──── قائمة الرسائل ────
            if (items.isEmpty)
              _EmptyState(
                onAdd: () => _addOrEditItem(),
              )
            else
              ...items.asMap().entries.map((entry) {
                final index = entry.key;
                final item = entry.value;
                return _TickerItemCard(
                  item: item,
                  index: index,
                  totalItems: items.length,
                  onEdit: () => _addOrEditItem(existingItem: item),
                  onDelete: () => _deleteItem(item),
                  onMoveUp: () => _moveItemUp(item, index),
                  onToggle: (v) {
                    final list = List<TickerItem>.from(settings.tickerItems);
                    list[index] = item.copyWith(enabled: v);
                    _updateSettings(settings.copyWith(tickerItems: list));
                  },
                );
              }),

            // ──── تلميح ────
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _emerald.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _emerald.withValues(alpha: 0.15)),
              ),
              child: Row(
                textDirection: TextDirection.rtl,
                children: [
                  Icon(Icons.info_outline_rounded, color: _emerald, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      l10n.tr(ar: 'اضغط على الرسالة لتعديلها، وارتّب الرسائل بالسهم. رمز الأعلى = تقديم الأولوية.', en: 'Tap a message to edit it, and reorder messages with the arrow. Up icon = higher priority.'),
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white70
                              : Colors.black54,
                          fontSize: 12,
                          fontFamily: 'Cairo',
                          height: 1.6),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// SUB WIDGETS
// ════════════════════════════════════════════════════════════════════════════

/// بطاقة الديالوج البيضاء
class _DialogCard extends StatelessWidget {
  const _DialogCard({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: [
          BoxShadow(
              color: isDark ? Colors.black26 : Colors.black.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 4)),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: child,
    );
  }
}

String _formatDuration(int seconds, AppLocalizations l10n) {
  if (seconds < 3600) {
    return l10n.tr(ar: '${(seconds / 60).toStringAsFixed(0)} دقيقة', en: '${(seconds / 60).toStringAsFixed(0)} min');
  } else if (seconds < 86400) {
    return l10n.tr(ar: '${(seconds / 3600).toStringAsFixed(1)} ساعة', en: '${(seconds / 3600).toStringAsFixed(1)} hr');
  } else {
    return l10n.tr(ar: '${(seconds / 86400).toStringAsFixed(1)} يوم', en: '${(seconds / 86400).toStringAsFixed(1)} day');
  }
}

Widget _buildDurationChip(void Function(void Function()) setS, String label,
    int value, int current, Color emerald, ValueChanged<int> onSelect) {
  final bool isSelected = (current - value).abs() < (value * 0.1);
  return TvFocusable(
    onPressed: () => onSelect(value),
    borderRadius: BorderRadius.circular(8),
    focusColor: emerald,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: isSelected ? emerald : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border:
            Border.all(color: isSelected ? emerald : const Color(0xFFE0E0E0)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.black54,
          fontSize: 10,
          fontFamily: 'Cairo',
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    ),
  );
}

/// عنوان قسم
class _SectionLabel extends StatelessWidget {
  const _SectionLabel({
    required this.label,
    required this.icon,
    this.compact = false,
  });
  final String label;
  final IconData icon;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final emerald = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    return Padding(
      padding: EdgeInsets.only(bottom: compact ? 0 : 10),
      child: Row(
        textDirection: TextDirection.rtl,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: emerald,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.white, size: 14),
          ),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: emerald,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Cairo')),
        ],
      ),
    );
  }
}

/// بطاقة الإعدادات البيضاء
class _SettingsCard extends StatelessWidget {
  const _SettingsCard({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isDark ? Colors.white10 : Colors.transparent),
        boxShadow: [
          BoxShadow(
              color: isDark ? Colors.transparent : Colors.black.withValues(alpha: 0.04),
              blurRadius: 10,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(children: children),
    );
  }
}

/// صف تبديل خفيف RTL
class _LightToggleRow extends StatelessWidget {
  const _LightToggleRow({
    required this.title,
    this.subtitle,
    required this.icon,
    required this.iconColor,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String? subtitle;
  final IconData icon;
  final Color iconColor;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final emerald = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          // أيقونة يمين
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 12),
          // نص وسط
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(title,
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                        color: isDark ? Colors.white : Colors.black87,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Cairo')),
                if (subtitle != null && subtitle!.isNotEmpty)
                  Text(subtitle!,
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                          color: isDark ? Colors.white70 : Colors.black45,
                          fontSize: 11,
                          fontFamily: 'Cairo')),
              ],
            ),
          ),
          const SizedBox(width: 12),
          // سويتش يسار
          CupertinoSwitch(
            value: value,
            activeTrackColor: emerald,
            inactiveTrackColor: Colors.black.withValues(alpha: 0.10),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

/// بطاقة رسالة واحدة
class _TickerItemCard extends StatelessWidget {
  const _TickerItemCard({
    required this.item,
    required this.index,
    required this.totalItems,
    required this.onEdit,
    required this.onDelete,
    required this.onMoveUp,
    required this.onToggle,
  });

  final TickerItem item;
  final int index;
  final int totalItems;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onMoveUp;
  final ValueChanged<bool> onToggle;

  // schedule label
  String _typeLabel(AppLocalizations l10n) {
    switch (item.scheduleType) {
      case TickerScheduleType.jomoa:
        return l10n.tr(ar: 'الجمعة', en: 'Friday');
      case TickerScheduleType.date:
        return item.date ?? l10n.tr(ar: 'تاريخ', en: 'Date');
      default:
        return l10n.tr(ar: 'يومياً', en: 'Daily');
    }
  }

  IconData get _typeIcon {
    switch (item.scheduleType) {
      case TickerScheduleType.jomoa:
        return Icons.mosque_rounded;
      case TickerScheduleType.date:
        return Icons.calendar_today_rounded;
      default:
        return Icons.repeat_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final enabled = item.enabled;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    final emerald = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onEdit,
          borderRadius: BorderRadius.circular(16),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: enabled
                  ? (isDark
                      ? Colors.white.withValues(alpha: 0.05)
                      : Colors.white)
                  : (isDark ? Colors.black12 : const Color(0xFFFAFAFA)),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: enabled
                    ? emerald.withValues(alpha: 0.3)
                    : (isDark ? Colors.white10 : const Color(0xFFE8E8E8)),
                width: enabled ? 1.5 : 1.0,
              ),
              boxShadow: enabled
                  ? [
                      BoxShadow(
                          color: emerald.withValues(alpha: 0.06),
                          blurRadius: 8,
                          offset: const Offset(0, 2))
                    ]
                  : null,
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                textDirection: TextDirection.rtl,
                children: [
                  // ── ① Switch ────────────────────────────────────
                  CupertinoSwitch(
                    value: enabled,
                    activeTrackColor: emerald,
                    inactiveTrackColor: Colors.black.withValues(alpha: 0.09),
                    onChanged: onToggle,
                  ),
                  const SizedBox(width: 10),

                  // ── ② نوع الجدولة badge ─────────────────────────
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: enabled
                          ? emerald.withValues(alpha: 0.10)
                          : Colors.black.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(_typeIcon,
                            color: enabled ? emerald : Colors.black38,
                            size: 12),
                        const SizedBox(width: 4),
                        Text(
                          _typeLabel(l10n),
                          style: TextStyle(
                              color: enabled ? emerald : Colors.black38,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),

                  // ── ③ نص الرسالة ────────────────────────────────
                  Expanded(
                    child: Text(
                      item.text,
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: enabled
                              ? (isDark ? Colors.white : Colors.black87)
                              : (isDark ? Colors.white38 : Colors.black38),
                          fontFamily: 'Cairo',
                          fontSize: 14,
                          height: 1.4,
                          decoration:
                              enabled ? null : TextDecoration.lineThrough),
                    ),
                  ),
                  const SizedBox(width: 4),

                  // ── ④ Actions ───────────────────────────────────
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // تقديم الأولوية
                      InkWell(
                        onTap: index > 0 ? onMoveUp : null,
                        borderRadius: BorderRadius.circular(6),
                        child: Padding(
                          padding: const EdgeInsets.all(4),
                          child: Icon(
                            Icons.keyboard_arrow_up_rounded,
                            color: index > 0
                                ? (isDark ? Colors.white54 : Colors.black45)
                                : (isDark ? Colors.white10 : Colors.black12),
                            size: 22,
                          ),
                        ),
                      ),
                    ],
                  ),
                  // حذف
                  InkWell(
                    onTap: onDelete,
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.all(6),
                      child: Icon(
                        Icons.delete_outline_rounded,
                        color: Colors.red.withValues(alpha: 0.7),
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// حالة فارغة
class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onAdd});
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    final emerald = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: !isDark
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 10,
                    offset: const Offset(0, 2)),
              ]
            : null,
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: emerald.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.campaign_outlined, size: 40, color: emerald),
          ),
          const SizedBox(height: 16),
          Text(l10n.tr(ar: 'لا توجد رسائل بعد', en: 'No messages yet'),
              style: TextStyle(
                  color: isDark ? Colors.white : Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo')),
          const SizedBox(height: 6),
          Text(
            l10n.tr(ar: 'أضف رسائل إعلانية ستظهر كشريط متحرك أسفل الشاشة', en: 'Add announcement messages that will appear as a moving ticker at the bottom of the screen'),
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: TextStyle(
                color: isDark ? Colors.white54 : Colors.black45,
                fontSize: 13,
                fontFamily: 'Cairo'),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: onAdd,
            style: ElevatedButton.styleFrom(
              backgroundColor: emerald,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            icon: const Icon(Icons.add_rounded),
            label: Text(l10n.tr(ar: 'إضافة رسالة', en: 'Add message'),
                style: TextStyle(
                    fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}




