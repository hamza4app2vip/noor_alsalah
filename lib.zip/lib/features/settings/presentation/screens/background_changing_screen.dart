﻿import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../../../../core/widgets/luxury_glass_container.dart';
import '../../domain/entities/app_settings.dart';
import '../providers/custom_backgrounds_provider.dart';
import '../providers/settings_provider.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

class BackgroundChangingScreen extends ConsumerStatefulWidget {
  const BackgroundChangingScreen({super.key});

  @override
  ConsumerState<BackgroundChangingScreen> createState() =>
      _BackgroundChangingScreenState();
}

class _BackgroundChangingScreenState
    extends ConsumerState<BackgroundChangingScreen> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  final List<String> _prayers = const [
    'fajr',
    'sunrise',
    'dhuhr',
    'asr',
    'maghrib',
    'isha'
  ];
  List<String> get _prayerNames => [
    l10n.tr(ar: 'الفجر', en: 'Fajr'),
    l10n.tr(ar: 'الشروق', en: 'Sunrise'),
    l10n.tr(ar: 'الظهر', en: 'Dhuhr'),
    l10n.tr(ar: 'العصر', en: 'Asr'),
    l10n.tr(ar: 'المغرب', en: 'Maghrib'),
    l10n.tr(ar: 'العشاء', en: 'Isha'),
  ];

  final List<String> _days = const ['1', '2', '3', '4', '5', '6', '7'];
  List<String> get _dayNames => [
    l10n.tr(ar: 'الإثنين', en: 'Monday'),
    l10n.tr(ar: 'الثلاثاء', en: 'Tuesday'),
    l10n.tr(ar: 'الأربعاء', en: 'Wednesday'),
    l10n.tr(ar: 'الخميس', en: 'Thursday'),
    l10n.tr(ar: 'الجمعة', en: 'Friday'),
    l10n.tr(ar: 'السبت', en: 'Saturday'),
    l10n.tr(ar: 'الأحد', en: 'Sunday'),
  ];

  final int totalThemes = 25;

  Color get _accent => Theme.of(context).brightness == Brightness.dark
      ? AppColors.goldAccent
      : const Color(0xFF1AA85A);

  void _update(AppSettings newSettings) {
    ref.read(settingsNotifierProvider.notifier).updateSettings(newSettings);
    GlassToast.show(context, l10n.tr(ar: ' تم الحفظ بنجاح', en: 'Saved successfully'));
  }

  void _setMode(AppSettings settings, String mode) {
    if (settings.bgMode == mode) return;
    _update(settings.copyWith(bgMode: mode));
  }

  void _cycleFitMode(AppSettings settings) {
    const modes = ['COVER', 'CONTAIN', 'FILL'];
    final currentIndex = modes.indexOf(settings.bgFitMode);
    final nextMode =
        modes[(currentIndex == -1 ? 0 : currentIndex + 1) % modes.length];
    _update(settings.copyWith(bgFitMode: nextMode));
  }

  Future<void> _pickManualTheme(AppSettings settings) async {
    _setMode(settings, 'MANUAL');
    final picked = await _pickThemeDialog(settings.selectedBackgroundId);
    if (picked != null) {
      _update(settings.copyWith(
        bgMode: 'MANUAL',
        selectedBackgroundId: picked,
      ));
    }
  }

  void _handleDigitShortcut(AppSettings settings, int digit) {
    switch (digit) {
      case 1:
        _setMode(settings, 'MANUAL');
        break;
      case 2:
        _setMode(settings, 'PER_PRAYER');
        break;
      case 3:
        _setMode(settings, 'PER_DAY');
        break;
      case 4:
        _setMode(settings, 'DAILY_RANDOM_FROM_LIST');
        break;
      case 5:
        _cycleFitMode(settings);
        break;
      case 6:
        _pickManualTheme(settings);
        break;
      default:
        break;
    }
  }

  Future<int?> _pickThemeDialog(int initialId) async {
    final accentColor = _accent;
    return showDialog<int>(
      context: context,
      builder: (ctx) {
        final isDark = Theme.of(ctx).brightness == Brightness.dark;
        return AlertDialog(
          backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(
              color: isDark ? Colors.white10 : Colors.transparent,
            ),
          ),
          title: Text(
            l10n.tr(ar: 'اختر رقم الخلفية', en: 'Choose background number'),
            textAlign: TextAlign.right,
            style: TextStyle(
              color: isDark ? Colors.white : Colors.black87,
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
            ),
          ),
          content: FocusTraversalGroup(
            policy: OrderedTraversalPolicy(),
            child: SizedBox(
              width: double.maxFinite,
              height: 350,
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  childAspectRatio: 1,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: totalThemes,
                itemBuilder: (dialogContext, index) {
                  final isSelected = index == initialId;
                  return TvFocusable(
                    autofocus: index == initialId,
                    onPressed: () => Navigator.pop(dialogContext, index),
                    borderRadius: BorderRadius.circular(12),
                    focusColor: accentColor,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? accentColor
                            : (isDark
                                ? Colors.white.withValues(alpha: 0.05)
                                : const Color(0xFFF5F5F7)),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isSelected
                              ? accentColor
                              : (isDark
                                  ? Colors.white10
                                  : Colors.black.withValues(alpha: 0.05)),
                        ),
                        boxShadow: isSelected
                            ? [
                                BoxShadow(
                                  color: accentColor.withValues(alpha: 0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ]
                            : null,
                      ),
                      child: Text(
                        '$index',
                        style: TextStyle(
                          color: isSelected
                              ? Colors.white
                              : (isDark ? Colors.white70 : Colors.black87),
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildModeRadio(AppSettings settings, String title, String mode) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    final isSelected = settings.bgMode == mode;

    return TvFocusable(
      onPressed: () => _setMode(settings, mode),
      borderRadius: BorderRadius.circular(14),
      focusColor: _accent,
      child: Container(
        decoration: BoxDecoration(
          color: isSelected
              ? _accent.withValues(alpha: isDark ? 0.16 : 0.08)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected
                ? _accent.withValues(alpha: 0.45)
                : Colors.transparent,
          ),
        ),
        child: IgnorePointer(
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: RadioListTile<String>(
              title: Text(
                title,
                style: TextStyle(
                  color: textColor,
                  fontSize: 16,
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                ),
              ),
              value: mode,
              activeColor: _accent,
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.trailing,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopPreview(AppSettings settings) {
    final iconColor = Theme.of(context).iconTheme.color ?? Colors.white;

    Future<void> chooseThemeFromPreview() async {
      _setMode(settings, 'MANUAL');
      final picked = await _pickThemeDialog(settings.selectedBackgroundId);
      if (picked != null) {
        _update(settings.copyWith(selectedBackgroundId: picked));
      }
    }

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TvFocusable(
              onPressed: () {
                _setMode(settings, 'MANUAL');
                final next = (settings.selectedBackgroundId + 1) % totalThemes;
                _update(settings.copyWith(selectedBackgroundId: next));
              },
              borderRadius: BorderRadius.circular(12),
              focusColor: _accent,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Icon(Icons.arrow_right, color: iconColor, size: 36),
              ),
            ),
            const SizedBox(width: 6),
            TvFocusable(
              onPressed: chooseThemeFromPreview,
              borderRadius: BorderRadius.circular(12),
              focusColor: _accent,
              child: Container(
                width: 150,
                height: 100,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white12,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _accent, width: 2),
                  image: DecorationImage(
                    image: AssetImage(
                      'assets/images/backgrounds/bg_${settings.selectedBackgroundId}.jpg',
                    ),
                    fit: BoxFit.cover,
                    onError: (err, stack) => {},
                  ),
                ),
                child: Text(
                  '${settings.selectedBackgroundId}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    backgroundColor: Colors.black45,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 6),
            TvFocusable(
              onPressed: () {
                _setMode(settings, 'MANUAL');
                var prev = settings.selectedBackgroundId - 1;
                if (prev < 0) prev = totalThemes - 1;
                _update(settings.copyWith(selectedBackgroundId: prev));
              },
              borderRadius: BorderRadius.circular(12),
              focusColor: _accent,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Icon(Icons.arrow_left, color: iconColor, size: 36),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Theme Number: ${settings.selectedBackgroundId}',
          style: TextStyle(color: _accent, fontSize: 16),
        ),
      ],
    );
  }

  Widget _buildPerPrayerGrid(AppSettings settings) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;

    return LuxuryGlassContainer(
      padding: const EdgeInsets.all(16),
      child: Wrap(
        spacing: 14,
        runSpacing: 14,
        alignment: WrapAlignment.center,
        children: List.generate(_prayers.length, (index) {
          final id = _prayers[index];
          final currentBg = settings.backgroundPerPrayer[id] ?? 0;
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _prayerNames[index],
                style: TextStyle(color: textColor, fontFamily: 'Cairo'),
              ),
              const SizedBox(height: 8),
              TvFocusable(
                onPressed: () async {
                  _setMode(settings, 'PER_PRAYER');
                  final picked = await _pickThemeDialog(currentBg);
                  if (picked != null) {
                    final map =
                        Map<String, int>.from(settings.backgroundPerPrayer);
                    map[id] = picked;
                    _update(settings.copyWith(backgroundPerPrayer: map));
                  }
                },
                borderRadius: BorderRadius.circular(8),
                focusColor: _accent,
                child: Container(
                  width: 50,
                  height: 50,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white12,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.primaryGold),
                  ),
                  child: Text(
                    '$currentBg',
                    style: const TextStyle(
                      color: Color(0xFF1AA85A),
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildPerDayGrid(AppSettings settings) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    const emerald = Color(0xFF1AA85A);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05),
        ),
      ),
      child: Wrap(
        spacing: 16,
        runSpacing: 16,
        alignment: WrapAlignment.center,
        children: List.generate(_days.length, (index) {
          final id = _days[index];
          final currentBg = settings.backgroundPerWeekday[id] ?? 0;
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _dayNames[index],
                style: TextStyle(
                  color: textColor,
                  fontFamily: 'Cairo',
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 8),
              TvFocusable(
                onPressed: () async {
                  _setMode(settings, 'PER_DAY');
                  final picked = await _pickThemeDialog(currentBg);
                  if (picked != null) {
                    final map =
                        Map<String, int>.from(settings.backgroundPerWeekday);
                    map[id] = picked;
                    _update(settings.copyWith(backgroundPerWeekday: map));
                  }
                },
                borderRadius: BorderRadius.circular(10),
                focusColor: _accent,
                child: Container(
                  width: 50,
                  height: 50,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: emerald.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: emerald.withValues(alpha: 0.2)),
                  ),
                  child: Text(
                    '$currentBg',
                    style: const TextStyle(
                      color: emerald,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildRandomList(AppSettings settings) {
    const emerald = Color(0xFF1AA85A);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withValues(alpha: 0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            l10n.tr(ar: 'انقر على الأرقام لإدارتها لتتغير يومياً بشكل عشوائي:', en: 'Tap numbers to manage them for daily random changes:'),
            textAlign: TextAlign.right,
            style: TextStyle(
              color: Colors.black54,
              fontFamily: 'Cairo',
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            textDirection: TextDirection.rtl,
            children: [
              ...settings.randomBackgroundPool.map((bgId) => TvFocusable(
                    onPressed: () {
                      _setMode(settings, 'DAILY_RANDOM_FROM_LIST');
                      final list = List<int>.from(settings.randomBackgroundPool)
                        ..remove(bgId);
                      _update(settings.copyWith(randomBackgroundPool: list));
                    },
                    borderRadius: BorderRadius.circular(10),
                    focusColor: emerald,
                    child: Chip(
                      label: Text(
                        '$bgId',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      backgroundColor: emerald,
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      deleteIcon: const Icon(
                        Icons.close,
                        color: Colors.white,
                        size: 14,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      side: BorderSide(color: emerald.withValues(alpha: 0.5)),
                    ),
                  )),
              TvFocusable(
                onPressed: () async {
                  _setMode(settings, 'DAILY_RANDOM_FROM_LIST');
                  final picked = await _pickThemeDialog(0);
                  if (picked != null &&
                      !settings.randomBackgroundPool.contains(picked)) {
                    final list = List<int>.from(settings.randomBackgroundPool)
                      ..add(picked);
                    _update(settings.copyWith(randomBackgroundPool: list));
                  }
                },
                borderRadius: BorderRadius.circular(10),
                focusColor: emerald,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F5F7),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Colors.black.withValues(alpha: 0.05),
                    ),
                  ),
                  child: const Icon(Icons.add_rounded,
                      color: Colors.black54, size: 18),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _pickFromDevice(AppSettings settings) async {
    final picker = ImagePicker();
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1920,
      maxHeight: 1080,
      imageQuality: 90,
    );
    if (image == null) return;

    try {
      final appDir = await getApplicationDocumentsDirectory();
      final bgDir = Directory('${appDir.path}/custom_backgrounds');
      if (!bgDir.existsSync()) bgDir.createSync(recursive: true);

      final fileName = 'bg_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final destFile = File('${bgDir.path}/$fileName');
      await File(image.path).copy(destFile.path);

      _update(settings.copyWith(
        bgMode: 'MANUAL',
        selectedBackgroundId: -1,
        selectedCustomBgPath: destFile.path,
      ));

      if (mounted) {
        ref.read(customBackgroundsProvider.notifier).refresh();
        GlassToast.show(context, l10n.tr(ar: 'تم حفظ الخلفية المخصصة بنجاح ✅', en: 'Custom background saved successfully ✅'));
      }
    } catch (_) {
      if (mounted) {
        GlassToast.show(context, l10n.tr(ar: 'خطأ في حفظ الصورة', en: 'Error saving image'));
      }
    }
  }

  Future<void> _deleteCustomBackground(
    AppSettings settings,
    File file,
    bool isSelected,
  ) async {
    final confirm = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text(l10n.tr(ar: 'حذف الخلفية', en: 'Delete background'),
                style: TextStyle(fontFamily: 'Cairo')),
            content: Text(
              l10n.tr(ar: 'هل أنت متأكد من حذف هذه الخلفية؟', en: 'Are you sure you want to delete this background?'),
              style: TextStyle(fontFamily: 'Cairo'),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(l10n.tr(ar: 'إلغاء', en: 'Cancel')),
              ),
              TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: Text(l10n.tr(ar: 'حذف', en: 'Delete'), style: TextStyle(color: Colors.red)),
              ),
            ],
          ),
        ) ??
        false;

    if (!confirm) return;

    try {
      await file.delete();
      if (isSelected) {
        _update(settings.copyWith(
            selectedBackgroundId: 0, selectedCustomBgPath: null));
      }
      ref.read(customBackgroundsProvider.notifier).refresh();
    } catch (_) {}
  }

  Widget _buildCustomGalleryList(AppSettings settings) {
    final files = ref.watch(customBackgroundsProvider);
    if (files.isEmpty) return const SizedBox.shrink();

    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(height: 32),
        Text(
          l10n.tr(ar: 'الخلفيات المضافة من الاستوديو:', en: 'Backgrounds added from gallery:'),
          style: TextStyle(
            color: isDark ? Colors.white70 : Colors.black54,
            fontFamily: 'Cairo',
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.5,
          ),
          itemCount: files.length,
          itemBuilder: (context, index) {
            final file = files[index];
            final isSelected = settings.selectedBackgroundId == -1 &&
                settings.selectedCustomBgPath == file.path;

            return Stack(
              children: [
                TvFocusable(
                  onPressed: () {
                    _update(settings.copyWith(
                      bgMode: 'MANUAL',
                      selectedBackgroundId: -1,
                      selectedCustomBgPath: file.path,
                    ));
                  },
                  borderRadius: BorderRadius.circular(12),
                  focusColor: _accent,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? _accent : Colors.white10,
                        width: 2,
                      ),
                      image: DecorationImage(
                        image: FileImage(file),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 4,
                  right: 4,
                  child: TvFocusable(
                    onPressed: () =>
                        _deleteCustomBackground(settings, file, isSelected),
                    borderRadius: BorderRadius.circular(20),
                    focusColor: Colors.redAccent,
                    ensureVisibleOnFocus: false,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.black54,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close,
                          color: Colors.white, size: 14),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: PremiumGlassNavbar(title: l10n.tr(ar: 'تغيير خلفية الشاشة', en: 'Change screen background')),
      body: Container(
        decoration: LuxuryGlassTheme.getPageDecoration(isDark),
        child: FocusTraversalGroup(
          policy: OrderedTraversalPolicy(),
          child: RadioGroup<String>(
            groupValue: settings.bgMode,
            onChanged: (val) {
              if (val != null) _update(settings.copyWith(bgMode: val));
            },
            child: Actions(
              actions: <Type, Action<Intent>>{
                TvDigitIntent: CallbackAction<TvDigitIntent>(
                  onInvoke: (intent) {
                    _handleDigitShortcut(settings, intent.digit);
                    return null;
                  },
                ),
              },
              child: ListView(
                padding: const EdgeInsets.fromLTRB(24, 110, 24, 40),
                children: [
                  Text(
                    l10n.tr(ar: 'تغيير الخلفيات المخصصة لكل وقت أو يوم', en: 'Change custom backgrounds for each time or day'),
                    style: TextStyle(
                      color: textColor,
                      fontFamily: 'Cairo',
                      fontSize: 16,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: _accent.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _accent.withValues(alpha: 0.2)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          l10n.tr(ar: 'عرض الخلفيات المخصصة:', en: 'Display custom backgrounds:'),
                          style: TextStyle(
                            color: textColor,
                            fontFamily: 'Cairo',
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TvFocusable(
                          autofocus: true,
                          onPressed: () => _cycleFitMode(settings),
                          borderRadius: BorderRadius.circular(10),
                          focusColor: _accent,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: _accent.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: _accent.withValues(alpha: 0.3)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  settings.bgFitMode == 'CONTAIN'
                                      ? l10n.tr(ar: 'احتواء وعرض كامل الصورة', en: 'Contain and show full image')
                                      : (settings.bgFitMode == 'FILL'
                                          ? l10n.tr(ar: 'تمدد للصورة', en: 'Stretch image')
                                          : l10n.tr(ar: 'تعبئة وقص الشاشة', en: 'Fill and crop screen')),
                                  style: TextStyle(
                                    color: _accent,
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Icon(Icons.swap_horiz_rounded,
                                    color: _accent, size: 20),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (settings.appTheme == 'PURE_GLASS') ...[
                    TvFocusable(
                      onPressed: () {
                        _update(settings.copyWith(
                          bgMode: 'MANUAL',
                          selectedBackgroundId: 0,
                          selectedCustomBgPath: null,
                        ));
                      },
                      borderRadius: BorderRadius.circular(15),
                      focusColor: _accent,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 16,
                          horizontal: 20,
                        ),
                        decoration: BoxDecoration(
                          color: _accent.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(
                            color: _accent.withValues(alpha: 0.3),
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.auto_awesome_motion_rounded,
                              color: _accent,
                              size: 24,
                            ),
                            const SizedBox(width: 12),
                            Text(
                              l10n.tr(ar: 'الرجوع للخلفية الافتراضية (الثيم الزجاجي)', en: 'Revert to default background (glass theme)'),
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Cairo',
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Divider(color: Colors.white10),
                    const SizedBox(height: 16),
                  ],
                  _buildModeRadio(settings, l10n.tr(ar: 'تغيير الخلفية يدوياً', en: 'Change background manually'), 'MANUAL'),
                  Opacity(
                    opacity: settings.bgMode == 'MANUAL' ? 1.0 : 0.4,
                    child: _buildTopPreview(settings),
                  ),
                  Divider(
                      color: isDark ? Colors.white10 : Colors.black12,
                      height: 48),
                  _buildModeRadio(
                      settings, l10n.tr(ar: 'تغيير الخلفية عند كل صلاة', en: 'Change background at each prayer'), 'PER_PRAYER'),
                  Opacity(
                    opacity: settings.bgMode == 'PER_PRAYER' ? 1.0 : 0.4,
                    child: _buildPerPrayerGrid(settings),
                  ),
                  Divider(
                      color: isDark ? Colors.white10 : Colors.black12,
                      height: 48),
                  _buildModeRadio(settings, l10n.tr(ar: 'تغيير الخلفية يومياً', en: 'Change background daily'), 'PER_DAY'),
                  Opacity(
                    opacity: settings.bgMode == 'PER_DAY' ? 1.0 : 0.4,
                    child: _buildPerDayGrid(settings),
                  ),
                  Divider(
                      color: isDark ? Colors.white10 : Colors.black12,
                      height: 48),
                  _buildModeRadio(
                    settings,
                    l10n.tr(ar: 'تبديل الخلفية عشوائياً من قائمة', en: 'Switch background randomly from list'),
                    'DAILY_RANDOM_FROM_LIST',
                  ),
                  Opacity(
                    opacity:
                        settings.bgMode == 'DAILY_RANDOM_FROM_LIST' ? 1.0 : 0.4,
                    child: _buildRandomList(settings),
                  ),
                  const SizedBox(height: 32),
                  LuxuryGlassContainer(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Text(
                          l10n.tr(ar: 'إضافة خلفية مخصصة من الجهاز', en: 'Add custom background from device'),
                          style: TextStyle(
                            color: textColor,
                            fontFamily: 'Cairo',
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          l10n.tr(ar: 'اختر صورة من المعرض لاستخدامها كخلفية مخصصة', en: 'Choose an image from gallery to use as custom background'),
                          style: TextStyle(
                            color: textColor.withValues(alpha: 0.7),
                            fontFamily: 'Cairo',
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        TvFocusable(
                          onPressed: () => _pickFromDevice(settings),
                          borderRadius: BorderRadius.circular(14),
                          focusColor: _accent,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 14,
                            ),
                            decoration: BoxDecoration(
                              color: _accent,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.add_photo_alternate_rounded,
                                  color: Colors.white,
                                ),
                                SizedBox(width: 8),
                                Text(
                                  l10n.tr(ar: 'اختيار صورة من المعرض', en: 'Choose image from gallery'),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _buildCustomGalleryList(settings),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}



