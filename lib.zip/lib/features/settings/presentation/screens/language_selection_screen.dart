import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/luxury_glass_theme.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/premium_glass_navbar.dart';
import '../providers/settings_provider.dart';
import 'package:noor_prayer_tv/l10n/app_localizations.dart';

class LanguageSelectionScreen extends ConsumerWidget {
  final bool isFirstRun;

  const LanguageSelectionScreen({super.key, this.isFirstRun = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsNotifierProvider);
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);

    return Directionality(
      textDirection: settings.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: !isFirstRun
            ? PremiumGlassNavbar(
                title: l10n.languages,
                showBackButton: true,
              )
            : null,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: LuxuryGlassTheme.getPageDecoration(isDark),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: !isFirstRun ? 120 : 40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (isFirstRun) const SizedBox(height: 60),
                  Hero(
                    tag: 'logo',
                    child: Container(
                      padding: const EdgeInsets.all(28),
                      decoration: BoxDecoration(
                        color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white.withValues(alpha: 0.6),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
                        ),
                        boxShadow: !isDark 
                            ? [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 20)]
                            : [],
                      ),
                      child: Icon(Icons.language_rounded, size: 80, color: accent),
                    ),
                  ),
                  const SizedBox(height: 32),
                  Text(
                    l10n.selectLanguage,
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 48),
                  
                  // Wrap with FocusTraversalGroup for safe TV DPAD Focus across elements
                  FocusTraversalGroup(
                    policy: OrderedTraversalPolicy(),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 600),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: _LanguageCard(
                              title: l10n.arabic,
                              subtitle: 'Arabic',
                              isSelected: settings.languageCode == 'ar',
                              onTap: () => _updateLanguage(ref, 'ar'),
                              isDark: isDark,
                              accent: accent,
                            ),
                          ),
                          const SizedBox(width: 24),
                          Expanded(
                            child: _LanguageCard(
                              title: l10n.english,
                              subtitle: 'English',
                              isSelected: settings.languageCode == 'en',
                              onTap: () => _updateLanguage(ref, 'en'),
                              isDark: isDark,
                              accent: accent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  if (isFirstRun) ...[
                    const SizedBox(height: 60),
                    _SaveButton(
                      isDark: isDark,
                      accent: accent,
                      text: l10n.save,
                      onTap: () {
                        ref.read(settingsNotifierProvider.notifier).updateSettings(
                          settings.copyWith(hasSelectedLanguage: true),
                        );
                        // Navigation is handled automatically in the router logic waiting for hasSelectedLanguage = true
                      },
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _updateLanguage(WidgetRef ref, String code) {
    final settings = ref.read(settingsNotifierProvider);
    ref.read(settingsNotifierProvider.notifier).updateSettings(
          settings.copyWith(
            languageCode: code,
            hasSelectedLanguage: !isFirstRun,
          ),
        );
  }
}

class _LanguageCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool isSelected;
  final VoidCallback onTap;
  final bool isDark;
  final Color accent;

  const _LanguageCard({
    required this.title,
    required this.subtitle,
    required this.isSelected,
    required this.onTap,
    required this.isDark,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(24),
      focusColor: accent,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? accent.withValues(alpha: 0.12)
              : (isDark ? Colors.white.withValues(alpha: 0.03) : Colors.white.withValues(alpha: 0.6)),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: isSelected
                ? accent
                : (isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05)),
            width: isSelected ? 2 : 1.5,
          ),
          boxShadow: !isDark && !isSelected
              ? [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 15, offset: const Offset(0, 4))]
              : [],
        ),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: isSelected ? accent : (isDark ? Colors.white : Colors.black87),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 14,
                color: isSelected ? accent.withValues(alpha: 0.8) : (isDark ? Colors.white60 : Colors.black54),
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 18),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
              child: isSelected
                  ? Icon(Icons.check_circle_rounded, color: accent, size: 32, key: const ValueKey('checked'))
                  : Icon(Icons.circle_outlined, color: isDark ? Colors.white24 : Colors.black12, size: 32, key: const ValueKey('unchecked')),
            ),
          ],
        ),
      ),
    );
  }
}

class _SaveButton extends StatelessWidget {
  final VoidCallback onTap;
  final String text;
  final bool isDark;
  final Color accent;

  const _SaveButton({
    required this.onTap,
    required this.text,
    required this.isDark,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return TvFocusable(
      onPressed: onTap,
      borderRadius: BorderRadius.circular(18),
      focusColor: accent,
      child: Container(
        width: double.infinity,
        constraints: const BoxConstraints(maxWidth: 300),
        height: 64,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: accent,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
             BoxShadow(
                 color: accent.withValues(alpha: 0.3),
                 blurRadius: 20,
                 offset: const Offset(0, 8),
             ),
          ],
        ),
        child: Text(
          text,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: isDark ? const Color(0xFF0F172A) : Colors.white,
          ),
        ),
      ),
    );
  }
}
