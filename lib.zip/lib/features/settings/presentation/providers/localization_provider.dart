import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'settings_provider.dart';

part 'localization_provider.g.dart';

@Riverpod(keepAlive: true)
class Localization extends _$Localization {
  @override
  Map<String, String> build() {
    // Return empty map initially while waiting for load
    _loadLanguage(ref.read(settingsNotifierProvider).languageCode);

    // Listen to changes in settings language code
    ref.listen(settingsNotifierProvider.select((s) => s.languageCode), (prev, next) {
      if (prev != next) {
        _loadLanguage(next);
      }
    });

    return {};
  }

  Future<void> _loadLanguage(String langCode) async {
    try {
      final jsonStr = await rootBundle.loadString('assets/languages/lang-${langCode.toLowerCase()}.json');
      final Map<String, dynamic> jsonMap = jsonDecode(jsonStr);
      final strings = jsonMap.map((key, value) => MapEntry(key, value.toString()));
      state = strings;
    } catch (e) {
      if (kDebugMode) {
        debugPrint('Error loading language file: $e');
      }
      // Fallback
      if (langCode != 'ar') {
        await _loadLanguage('ar');
      }
    }
  }

  // Helper method to get localized string via key
  String translate(String key, {String fallback = ''}) {
    return state[key] ?? fallback;
  }
}
