import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/activity_log_item.dart';
import '../../domain/entities/activity_source.dart';

part 'activity_log_provider.g.dart';

@Riverpod(keepAlive: true)
class ActivityLogNotifier extends _$ActivityLogNotifier {
  static const _logFileName = 'activity_logs.json';

  @override
  Future<List<ActivityLogItem>> build() async {
    return _loadLogs();
  }

  Future<List<ActivityLogItem>> _loadLogs() async {
    try {
      final file = await _getLogFile();
      if (!await file.exists()) return [];
      
      final content = await file.readAsString();
      final List<dynamic> jsonList = jsonDecode(content);
      return jsonList.map((e) => ActivityLogItem.fromJson(e)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> log({
    required ActivitySource source,
    required String action,
    Map<String, dynamic> details = const {},
  }) async {
    final newItem = ActivityLogItem(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      timestamp: DateTime.now(),
      source: source,
      action: action,
      details: details,
    );

    final currentLogs = state.value ?? [];
    final updatedLogs = [newItem, ...currentLogs].take(1000).toList(); // Keep last 1000 logs
    
    state = AsyncData(updatedLogs);
    await _saveLogs(updatedLogs);
  }

  Future<void> _saveLogs(List<ActivityLogItem> logs) async {
    try {
      final file = await _getLogFile();
      await file.writeAsString(jsonEncode(logs.map((e) => e.toJson()).toList()));
    } catch (_) {}
  }

  Future<File> _getLogFile() async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/$_logFileName');
  }

  Future<void> clearLogs() async {
    state = const AsyncData([]);
    try {
      final file = await _getLogFile();
      if (await file.exists()) await file.delete();
    } catch (_) {}
  }
}
