import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/app_settings.dart';
import '../../domain/entities/activity_source.dart';
import 'activity_log_provider.dart';
import '../../../../core/local_server/admin_server_provider.dart';

part 'settings_provider.g.dart';

// Provider للوصول لـ SharedPreferences بشكل متزامن داخل التطبيق (بعد تهيئته في main)
@Riverpod(keepAlive: true)
SharedPreferences sharedPreferences(Ref ref) {
  throw UnimplementedError('Must be initialized before runApp');
}

@riverpod
class SettingsNotifier extends _$SettingsNotifier {
  static const _settingsKey = 'app_settings_v1';

  @override
  AppSettings build() {
    final prefs = ref.watch(sharedPreferencesProvider);
    final jsonStr = prefs.getString(_settingsKey);

    if (jsonStr != null) {
      try {
        return AppSettings.fromJson(jsonDecode(jsonStr));
      } catch (_) {
        return const AppSettings();
      }
    }
    return const AppSettings(); // الإعدادات الافتراضية
  }

  Future<void> updateSettings(AppSettings newSettings,
      {ActivitySource source = ActivitySource.app}) async {
    final oldSettings = state;

    // تحديث الحالة لتنعكس فوراً على الشاشات
    state = newSettings;
    await _saveSettings(newSettings);

    // تسجيل التغييرات في سجل النشاطات
    _logChanges(oldSettings, newSettings, source);
  }

  void _logChanges(AppSettings oldS, AppSettings newS, ActivitySource source) {
    final changes = <String>[];
    final details = <String, dynamic>{};

    void check<T>(String label, T Function(AppSettings) getField) {
      final oldVal = getField(oldS);
      final newVal = getField(newS);
      if (oldVal != newVal) {
        changes.add(label);
        details[label] = {"من": oldVal.toString(), "إلى": newVal.toString()};
      }
    }

    check('اسم المسجد', (s) => s.mosqueName);
    check('وقت الإقامة (الفجر)', (s) => s.fajrIqamaTime);
    check('وقت الإقامة (الظهر)', (s) => s.dhuhrIqamaTime);
    check('وقت الإقامة (العصر)', (s) => s.asrIqamaTime);
    check('وقت الإقامة (المغرب)', (s) => s.maghribIqamaTime);
    check('وقت الإقامة (العشاء)', (s) => s.ishaIqamaTime);
    check('تفعيل أذكار الصباح', (s) => s.enableSabahAzkar);
    check('تفعيل أذكار المساء', (s) => s.enableMasaaAzkar);
    check('شاشة الأذكار فقط', (s) => s.azkarOnlyScreenEnabled);
    check('خلفية زجاجية لشاشة الأذكار', (s) => s.azkarOnlyScreenUseGlass);
    check('صورة شاشة الأذكار الخاصة', (s) => s.azkarOnlyScreenCustomBgPath);
    check('وقت بدء أذكار الصباح', (s) => s.sabahStartTime);
    check('وقت انتهاء أذكار الصباح', (s) => s.sabahEndTime);
    check('وقت بدء أذكار المساء', (s) => s.masaaStartTime);
    check('وقت انتهاء أذكار المساء', (s) => s.masaaEndTime);
    check('الوضع اليدوي للخشوع', (s) => s.isKhushooManualActive);
    check('اللغة', (s) => s.languageCode);
    check('لغة الآيات', (s) => s.ayatsLanguageCode);
    check('الثيم', (s) => s.appTheme);
    check('نمط الوقت 24 ساعة', (s) => s.is24HourFormat);
    check('إظهار الثواني', (s) => s.showSecondsClock);
    check('تشغيل صوت الأذان', (s) => s.playAdhanSound);
    check('تنسيق الأرقام (عربي/إنجليزي)', (s) => s.useArabicIndicDigits);
    check('إظهار التاريخ الهجري', (s) => s.showHijriDate);
    check('فرق الأيام الهجري', (s) => s.hijriOffsetDays);
    check('إزاحة الساعة (دقائق)', (s) => s.clockOffsetMinutes);
    check('مدة الشاشة السوداء', (s) => s.blackScreenDurationMinutes);
    check('تفعيل برنامج خشوع', (s) => s.khushooModeEnabled);
    check('مدة برنامج خشوع', (s) => s.khushooModeDuration);
    check('عرض شريط الأخبار', (s) => s.showMarqueeTicker);
    check('مدة عرض الشريحة', (s) => s.slideDurationSeconds);
    check('مدة الشاشة الرئيسية', (s) => s.mainScreenDurationSeconds);
    check('نمط عرض الشرائح', (s) => s.slidesShowMode);
    check('الخط المستخدم', (s) => s.fontFamily);
    check('خط الساعة', (s) => s.clockFontFamily);
    check('خط الأوقات', (s) => s.timesFontFamily);
    check('خط الأذكار', (s) => s.azkarFontFamily);
    check('لون نص الثيم الزجاجي', (s) => s.pureGlassTextColor);
    check('لون1 الثيم الزجاجي', (s) => s.pureGlassColor1);
    check('لون2 الثيم الزجاجي', (s) => s.pureGlassColor2);
    check('لون3 الثيم الزجاجي', (s) => s.pureGlassColor3);
    check('تعديل فجر', (s) => s.prayerOffsetFajr);
    check('تعديل ظهر', (s) => s.prayerOffsetDhuhr);
    check('تعديل عصر', (s) => s.prayerOffsetAsr);
    check('تعديل مغرب', (s) => s.prayerOffsetMaghrib);
    check('تعديل عشاء', (s) => s.prayerOffsetIsha);

    // Additional Identity & UI options
    check('إظهار علم الدولة', (s) => s.showCountryFlag);
    check('إظهار صلوات الليل', (s) => s.showNightPrayers);
    check('توسيط أسماء الصلوات (عرضي)', (s) => s.centerPrayerNamesLandscape);
    check('تكبير أسماء الصلوات (عرضي)', (s) => s.enlargePrayerNamesLandscape);
    check('إظهار الإقامة مع الساعة', (s) => s.showIqamaWithClock);
    check('شاشة سوداء مع الساعة', (s) => s.blackClockModeEnabled);
    check('خلفية زجاجية لشاشة الساعة', (s) => s.blackClockModeUseGlass);
    check('صورة شاشة الساعة الخاصة', (s) => s.blackClockModeCustomBgPath);
    check('إظهار العد التنازلي', (s) => s.showCountdown);
    check('تكبير العد التنازلي', (s) => s.enlargeCountdown);
    check('تكبير العد التنازلي عند الاقتراب',
        (s) => s.showFullscreenCountdownAtThreshold);
    check('إخفاء وقت الإقامة', (s) => s.hideIqamaTime);
    check('توسيط أسماء الصلوات (طولي)', (s) => s.centerPrayerNamesPortrait);
    check('إظهار اسم الصلاة بلغة أخرى', (s) => s.showPrayerNameInOtherLanguage);
    check('إظهار شاشة الأذان', (s) => s.showAdhanScreen);
    check('إظهار شاشة الإقامة', (s) => s.showIqamaScreen);
    check('تبديل التاريخ والمسجد (عرضي)', (s) => s.swapDateAndMosqueLandscape);
    check('إظهار حالة الإنترنت', (s) => s.showInternetStatus);
    check('تظليل خلفية الأوقات', (s) => s.showBackgroundShadingBehindTimes);
    check('استخدام شاشات شفافة', (s) => s.useTranslucentScreens);
    check('تلوين العد التنازلي بالأخضر', (s) => s.countdownGreenLast90s);
    check('تكبير عداد الصلاة القادمة', (s) => s.enlargeNextPrayerCountdown);
    check('تنبيه صوتي قبل الإقامة', (s) => s.playVoiceAlertBeforeIqama);
    check('رسالة التنبيه الصوتي', (s) => s.voiceAlertMessage);
    check('إظهار حديث قبل الإقامة', (s) => s.showHadithBeforeIqama);
    check('كتم الصوت العام', (s) => s.isGlobalAudioMuted);
    check('كتم صوت الأذان', (s) => s.isAzanAudioMuted);
    check('وقت صلاة عيد الفطر', (s) => s.eidAlFitrTime);
    check('وقت صلاة عيد الأضحى', (s) => s.eidAlAdhaTime);
    check('استخدام MP3 للأذان', (s) => s.useMp3ForAdhan);
    check('استخدام أذان قصير', (s) => s.useShortAdhan);
    check('استخدام إقامة قصيرة', (s) => s.useShortIqama);
    check('تعديل صلاة العشاء برمضان', (s) => s.ramadanIshaPlus30Enabled);
    check('التوقيت الصيفي (+1 ساعة)', (s) => s.summerPlus1HourEnabled);
    check('إضافة ساعة يدوياً', (s) => s.manualPlus1HourAllEnabled);
    check('إنقاص ساعة يدوياً', (s) => s.manualMinus1HourAllEnabled);
    check('نمط الموقع (تلقائي/يدوي)', (s) => s.locationMode);
    check('تفعيل الطقس', (s) => s.weatherEnabled);
    check('تنبيهات الطقس الصوتية', (s) => s.weatherAlertsEnabled);
    check('توجيه التطبيق', (s) => s.appOrientation);

    // Advanced & Missing Options
    check('البلد', (s) => s.country);
    check('المدينة', (s) => s.city);
    check('نمط الثيم (نظام/فاتح/داكن)', (s) => s.themeMode);
    check('تخفيت الصلوات السابقة', (s) => s.dimPastPrayers);
    check('الموقع التلقائي (GPS)', (s) => s.isAutoLocation);
    check('عداد رمضان', (s) => s.ramadanCountdownInjectEnabled);
    check('وقت يدوي', (s) => s.manualTimeValue);
    check('صوت أذان الجمعة', (s) => s.enableJumuaAdhanSound);
    check('إظهار الجمعة (عرضي)', (s) => s.showJumuaInLandscape);
    check('نمط خطبة الجمعة (تلقائي/يدوي)', (s) => s.jumuaKhutbahAutoMode);
    check('وقت خطبة الجمعة', (s) => s.jumuaKhutbahManualTime);
    check('تنبيه ما قبل الفجر', (s) => s.fajrPreAdhanAlertMinutes);
    check('حساب الظهر من العصر', (s) => s.dhuhrFromAsrMinusMinutesEnabled);
    check('نمط الخلفية', (s) => s.bgMode);
    check('الخلفية المختارة', (s) => s.selectedBackgroundId);
    check('منبه قبل الأذان', (s) => s.showPreAdhanBeep);
    check('تفعيل أذكار ما بعد الصلاة', (s) => s.enablePostPrayerAzkar);
    check('تكرار أذكار الصلاة', (s) => s.postPrayerAzkarRepeatOnce);
    check('خلفية أذكار بيضاء', (s) => s.postPrayerWhiteBackground);
    check('شريحة أذكار واحدة 5د', (s) => s.postPrayerShowSingleSlide5Min);

    if (changes.isNotEmpty) {
      final action = 'تعديل ${changes.join("، ")}';
      ref.read(activityLogNotifierProvider.notifier).log(
            source: source,
            action: action,
            details: details,
          );
    }
  }

  Future<void> resetToDefault() async {
    final prefs = ref.read(sharedPreferencesProvider);
    await prefs.remove(_settingsKey);
    state = const AppSettings();
  }

  Future<void> _saveSettings(AppSettings settings) async {
    final oldTickerItems = state.tickerItems;

    // حفظها في التخزين المحلي
    final prefs = ref.read(sharedPreferencesProvider);
    await prefs.setString(_settingsKey, jsonEncode(settings.toJson()));

    // مزامنة مع سيرفر الويب إذا تغيرت الأخبار
    if (settings.tickerItems != oldTickerItems) {
      ref.read(adminServerProvider.notifier).notifyNewsChanged();
    }
  }

  // دوال مساعدة لتغيير إعدادات محددة
  Future<void> updateAdminUsername(String username) async {
    await updateSettings(state.copyWith(adminUsername: username));
  }

  Future<void> toggle24HourFormat() async {
    await updateSettings(state.copyWith(is24HourFormat: !state.is24HourFormat));
  }

  Future<void> toggleAutoLocation(bool value) async {
    await updateSettings(state.copyWith(isAutoLocation: value));
  }

  Future<void> updateMosqueName(String name) async {
    await updateSettings(state.copyWith(mosqueName: name));
  }

  Future<void> updateMosqueIconPath(String? path) async {
    await updateSettings(state.copyWith(mosqueIconPath: path));
  }
}
