// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'localization_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localizationHash() => r'5116b9c88d782ea4cb2d7ff2a36789ed210c02a4';

/// See also [Localization].
@ProviderFor(Localization)
final localizationProvider =
    NotifierProvider<Localization, Map<String, String>>.internal(
  Localization.new,
  name: r'localizationProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$localizationHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Localization = Notifier<Map<String, String>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
