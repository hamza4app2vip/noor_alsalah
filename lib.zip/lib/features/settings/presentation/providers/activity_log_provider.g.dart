// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'activity_log_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$activityLogNotifierHash() =>
    r'c85b9e3c876245b92c5a561b4720d18dad9edc68';

/// See also [ActivityLogNotifier].
@ProviderFor(ActivityLogNotifier)
final activityLogNotifierProvider =
    AsyncNotifierProvider<ActivityLogNotifier, List<ActivityLogItem>>.internal(
  ActivityLogNotifier.new,
  name: r'activityLogNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$activityLogNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ActivityLogNotifier = AsyncNotifier<List<ActivityLogItem>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
