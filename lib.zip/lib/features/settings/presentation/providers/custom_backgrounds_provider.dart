import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';

final customBackgroundsProvider = StateNotifierProvider<CustomBackgroundsNotifier, List<File>>((ref) {
  return CustomBackgroundsNotifier();
});

class CustomBackgroundsNotifier extends StateNotifier<List<File>> {
  CustomBackgroundsNotifier() : super([]) {
    refresh();
  }

  Future<void> refresh() async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final bgDir = Directory('${appDir.path}/custom_backgrounds');
      if (!bgDir.existsSync()) {
        state = [];
        return;
      }
      final files = bgDir
          .listSync()
          .whereType<File>()
          .where((f) => f.path.endsWith('.jpg') || f.path.endsWith('.png'))
          .toList();
      
      // Sort by modified time descending to show newest first
      files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      
      state = files;
    } catch (_) {
      state = [];
    }
  }
}
