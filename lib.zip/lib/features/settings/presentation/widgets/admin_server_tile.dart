import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../../../core/local_server/admin_server_provider.dart';
import '../providers/settings_provider.dart';
import '../../../../core/local_server/auth_service.dart';
import '../../../../core/tv/tv_remote_support.dart';
import '../../../../core/widgets/glass_toast.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/localization/localized_text.dart';

/// QR code, PIN, and connected devices. Placed inside SettingsScreen.
class AdminServerTile extends ConsumerStatefulWidget {
  const AdminServerTile({super.key});

  @override
  ConsumerState<AdminServerTile> createState() => _AdminServerTileState();
}

class _AdminServerTileState extends ConsumerState<AdminServerTile> {
  AppLocalizations get l10n => AppLocalizations.of(context);
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  bool _obscure = true;
  bool _expanded = false;
  bool _saveUsername = false;

  bool _isUserEditing = false;
  final FocusNode _userFocusNode = FocusNode();
  bool _isPassEditing = false;
  final FocusNode _passFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _userFocusNode.addListener(() {
      if (!_userFocusNode.hasFocus && _isUserEditing) {
        setState(() => _isUserEditing = false);
      }
    });
    _passFocusNode.addListener(() {
      if (!_passFocusNode.hasFocus && _isPassEditing) {
        setState(() => _isPassEditing = false);
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final savedUser = ref.read(settingsNotifierProvider).adminUsername;
      if (savedUser.isNotEmpty) {
        _userController.text = savedUser;
        setState(() => _saveUsername = true);
      }
    });
  }

  @override
  void dispose() {
    _userController.dispose();
    _passController.dispose();
    _userFocusNode.dispose();
    _passFocusNode.dispose();
    super.dispose();
  }

  Color get _accent => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFFDCB881)
      : const Color(0xFF1AA85A);

  Color get _textColor => Theme.of(context).brightness == Brightness.dark
      ? Colors.white
      : const Color(0xFF1E293B);

  Color get _subColor => Theme.of(context).brightness == Brightness.dark
      ? Colors.white60
      : Colors.black54;

  Color get _cardColor => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFF1E293B).withValues(alpha: 0.7)
      : Colors.white.withValues(alpha: 0.95);

  void _focusUserField() {
    setState(() => _isUserEditing = true);
    Future.delayed(const Duration(milliseconds: 50), () {
      if (mounted) _userFocusNode.requestFocus();
    });
  }

  void _focusPassField() {
    setState(() => _isPassEditing = true);
    Future.delayed(const Duration(milliseconds: 50), () {
      if (mounted) _passFocusNode.requestFocus();
    });
  }

  void _togglePasswordVisibility() {
    setState(() => _obscure = !_obscure);
  }

  void _toggleSaveUsername() {
    setState(() => _saveUsername = !_saveUsername);
  }

  void _startServerWithCurrentInputs() {
    final user = _userController.text.trim();
    final pass = _passController.text.trim();
    if (pass.length < 4) {
      _showSnack(l10n.tr(ar: 'كلمة المرور قصيرة (4 أحرف على الأقل)', en: 'Password is too short (at least 4 characters)'));
      return;
    }
    ref
        .read(adminServerProvider.notifier)
        .startServer(user, pass, _saveUsername);
  }

  void _handleDigitShortcut(AdminServerState state, int digit) {
    if (state.isRunning) {
      switch (digit) {
        case 1:
          Clipboard.setData(ClipboardData(text: state.url));
          _showSnack(l10n.tr(ar: 'تم نسخ الرابط', en: 'Link copied'));
          return;
        case 2:
          ref.read(adminServerProvider.notifier).stopServer();
          return;
        case 9:
          setState(() => _expanded = !_expanded);
          return;
        default:
          return;
      }
    }

    switch (digit) {
      case 1:
        _focusUserField();
        break;
      case 2:
        _focusPassField();
        break;
      case 3:
        _togglePasswordVisibility();
        break;
      case 4:
        _toggleSaveUsername();
        break;
      case 5:
        _startServerWithCurrentInputs();
        break;
      case 9:
        setState(() => _expanded = !_expanded);
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final serverAsync = ref.watch(adminServerProvider);

    return serverAsync.when(
      loading: () => const SizedBox(
          height: 60, child: Center(child: CircularProgressIndicator())),
      error: (e, _) => _buildError(l10n.tr(ar: 'خطأ: $e', en: 'Error: $e')),
      data: (state) => _buildContent(state),
    );
  }

  Widget _buildError(String msg) => Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.red.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.red.withValues(alpha: 0.3)),
        ),
        child: Text(msg,
            style: const TextStyle(color: Colors.red, fontFamily: 'Cairo')),
      );

  Widget _buildContent(AdminServerState state) {
    final content = Column(
      children: [
        if (state.ipChanged) _buildIpChangeBanner(state),
        Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            color: _cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: state.isRunning
                  ? _accent.withValues(alpha: 0.4)
                  : (Theme.of(context).brightness == Brightness.dark
                      ? Colors.white.withValues(alpha: 0.05)
                      : Colors.black.withValues(alpha: 0.05)),
              width: state.isRunning ? 1.5 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: state.isRunning
                    ? _accent.withValues(alpha: 0.08)
                    : Colors.black.withValues(alpha: 0.03),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            children: [
              TvFocusable(
                autofocus: true,
                borderRadius: BorderRadius.circular(20),
                focusColor: _accent,
                onPressed: () => setState(() => _expanded = !_expanded),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _accent.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(Icons.wifi_tethering_rounded,
                            color: _accent, size: 24),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              l10n.tr(ar: 'لوحة التحكم عن بُعد', en: 'Remote Control Panel'),
                              style: TextStyle(
                                color: _textColor,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Cairo',
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              state.isRunning
                                  ? l10n.tr(ar: '🟢 يعمل — ${state.ip}:${state.port}', en: '🟢 Running — ${state.ip}:${state.port}')
                                  : l10n.tr(ar: '⚪ متوقف — إدارة الشريط من الهاتف', en: '⚪ Stopped — manage ticker from phone'),
                              style: TextStyle(
                                color: _subColor,
                                fontSize: 12,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        _expanded
                            ? Icons.keyboard_arrow_up_rounded
                            : Icons.keyboard_arrow_down_rounded,
                        color: _accent.withValues(alpha: 0.5),
                      ),
                    ],
                  ),
                ),
              ),
              if (_expanded) ...[
                Divider(height: 1, color: Colors.grey.withValues(alpha: 0.1)),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
                  child: state.isRunning
                      ? _buildRunningView(state)
                      : _buildStoppedView(state),
                ),
              ],
            ],
          ),
        ),
      ],
    );

    return Actions(
      actions: <Type, Action<Intent>>{
        TvDigitIntent: CallbackAction<TvDigitIntent>(
          onInvoke: (intent) {
            _handleDigitShortcut(state, intent.digit);
            return null;
          },
        ),
      },
      child: content,
    );
  }

  Widget _buildPendingRequestCard(LoginRequest session) {
    return _GlassPendingRequestCard(
      session: session,
      accent: _accent,
      onDeny: () => ref.read(adminServerProvider.notifier).denyRequest(),
      onConfirm: () => ref.read(adminServerProvider.notifier).confirmRequest(),
    );
  }
  // ─── Running View ─────────────────────────────────────────────────────────────

  Widget _buildRunningView(AdminServerState state) {
    return Column(
      children: [
        if (state.pendingRequest != null) ...[
          _buildPendingRequestCard(state.pendingRequest!),
          const SizedBox(height: 14),
        ],
        // QR Code
        TvFocusable(
          onPressed: () {
            Clipboard.setData(ClipboardData(text: state.url));
            _showSnack(l10n.tr(ar: 'تم نسخ الرابط', en: 'Link copied'));
          },
          borderRadius: BorderRadius.circular(16),
          focusColor: _accent,
          child: TweenAnimationBuilder<double>(
            duration: const Duration(milliseconds: 600),
            curve: Curves.elasticOut,
            tween: Tween(begin: 0.0, end: 1.0),
            builder: (context, value, child) => Transform.scale(
              scale: value,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: _accent.withValues(alpha: 0.15),
                      blurRadius: 24,
                      spreadRadius: 2,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: QrImageView(
                  data: state.url,
                  version: QrVersions.auto,
                  size: 180,
                  backgroundColor: Colors.white,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        TvFocusable(
          onPressed: () {
            Clipboard.setData(ClipboardData(text: state.url));
            _showSnack(l10n.tr(ar: 'تم نسخ الرابط', en: 'Link copied'));
          },
          borderRadius: BorderRadius.circular(10),
          focusColor: _accent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _accent.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _accent.withValues(alpha: 0.25)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.copy_rounded, color: _accent, size: 16),
                const SizedBox(width: 6),
                Text(state.url,
                    style: TextStyle(
                        color: _accent,
                        fontSize: 13,
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Stop Button
        TvFocusable(
          onPressed: () => ref.read(adminServerProvider.notifier).stopServer(),
          borderRadius: BorderRadius.circular(12),
          focusColor: Colors.red,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.red),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.stop_rounded, color: Colors.red),
                const SizedBox(width: 8),
                Text(l10n.tr(ar: 'إيقاف السيرفر', en: 'Stop server'),
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.w700,
                        color: Colors.red)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── Stopped View ─────────────────────────────────────────────────────────────

  Widget _buildStoppedView(AdminServerState state) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          l10n.tr(ar: 'اسم مستخدم المشرف', en: 'Admin username'),
          style: TextStyle(color: _subColor, fontSize: 13, fontFamily: 'Cairo'),
        ),
        const SizedBox(height: 6),
        TvFocusable(
          onPressed: _focusUserField,
          borderRadius: BorderRadius.circular(14),
          focusColor: _accent,
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black.withValues(alpha: 0.15)
                  : const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: Colors.grey.withValues(alpha: 0.1)),
            ),
            child: ExcludeFocus(
              excluding: !_isUserEditing,
              child: IgnorePointer(
                ignoring: !_isUserEditing,
                child: TextField(
                  controller: _userController,
                  focusNode: _userFocusNode,
                  readOnly: !_isUserEditing,
                  onSubmitted: (_) => setState(() => _isUserEditing = false),
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(
                    hintText: 'admin',
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          l10n.tr(ar: 'كلمة المرور للوحة التحكم', en: 'Control panel password'),
          style: TextStyle(color: _subColor, fontSize: 13, fontFamily: 'Cairo'),
        ),
        const SizedBox(height: 6),
        TvFocusable(
          onPressed: _focusPassField,
          borderRadius: BorderRadius.circular(14),
          focusColor: _accent,
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black.withValues(alpha: 0.15)
                  : const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: Colors.grey.withValues(alpha: 0.1)),
            ),
            child: ExcludeFocus(
              excluding: !_isPassEditing,
              child: IgnorePointer(
                ignoring: !_isPassEditing,
                child: TextField(
                  controller: _passController,
                  focusNode: _passFocusNode,
                  readOnly: !_isPassEditing,
                  onSubmitted: (_) => setState(() => _isPassEditing = false),
                  obscureText: _obscure,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                    hintText: '••••••••',
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    suffixIcon: TvFocusable(
                      onPressed: _togglePasswordVisibility,
                      ensureVisibleOnFocus: false,
                      borderRadius: BorderRadius.circular(20),
                      focusColor: _accent,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          _obscure ? Icons.visibility_off : Icons.visibility,
                          color: _subColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Align(
          alignment: Alignment.centerRight,
          child: TvFocusable(
            onPressed: _toggleSaveUsername,
            borderRadius: BorderRadius.circular(8),
            focusColor: _accent,
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                textDirection: TextDirection.rtl,
                children: [
                  ExcludeFocus(
                    child: IgnorePointer(
                      child: Checkbox(
                        value: _saveUsername,
                        activeColor: _accent,
                        onChanged: (val) {},
                      ),
                    ),
                  ),
                  Text(
                    l10n.tr(ar: 'حفظ اسم المستخدم دائمًا', en: 'Always save username'),
                    style: TextStyle(
                        color: _subColor, fontSize: 13, fontFamily: 'Cairo'),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (state.error != null) ...[
          const SizedBox(height: 8),
          Text(state.error!,
              style: const TextStyle(
                  color: Colors.red, fontSize: 13, fontFamily: 'Cairo')),
        ],
        const SizedBox(height: 14),
        TvFocusable(
          onPressed: _startServerWithCurrentInputs,
          borderRadius: BorderRadius.circular(12),
          focusColor: _accent,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: _accent,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.play_arrow_rounded, color: Color(0xFF0F172A)),
                const SizedBox(width: 8),
                Text(l10n.tr(ar: 'تشغيل السيرفر', en: 'Start server'),
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: Color(0xFF0F172A))),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          l10n.tr(ar: '• تسجيل الدخول آمن عبر التصريح من هذه الشاشة\n• السيرفر يعمل فقط عند فتح التطبيق ويتطلب نفس الشبكة', en: '• Login is secure with approval from this screen\n• Server runs only while the app is open and requires the same network'),
          style: TextStyle(
              color: _subColor, fontSize: 11, fontFamily: 'Cairo', height: 1.6),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }

  // ─── IP Change Banner ─────────────────────────────────────────────────────────

  Widget _buildIpChangeBanner(AdminServerState state) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.orange.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.4)),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          const Icon(Icons.warning_rounded, color: Colors.orange, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(l10n.tr(ar: 'تغيّر عنوان IP', en: 'IP address changed'),
                    style: TextStyle(
                        color: Colors.orange,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Cairo',
                        fontSize: 14)),
                Text(
                  l10n.tr(ar: 'الرابط الجديد: ${state.url}\\nيرجى إعادة مسح QR على الأجهزة المتصلة.', en: 'New link: ${state.url}\\nPlease rescan the QR code on connected devices.'),
                  style: const TextStyle(
                      color: Colors.orange, fontSize: 12, fontFamily: 'Cairo'),
                ),
              ],
            ),
          ),
          TvFocusable(
            onPressed: () =>
                ref.read(adminServerProvider.notifier).acknowledgeIpChange(),
            ensureVisibleOnFocus: false,
            borderRadius: BorderRadius.circular(20),
            focusColor: Colors.orange,
            child: const Padding(
              padding: EdgeInsets.all(4.0),
              child: Icon(Icons.close, color: Colors.orange, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  void _showSnack(String msg) {
    GlassToast.show(context, msg);
  }
}

// ─── Sub-Widgets ──────────────────────────────────────────────────────────────

class _PairingCodeWidget extends StatefulWidget {
  final String pin;
  final DateTime expiresAt;
  final VoidCallback onExpire;
  final Color accent;
  final Color subColor;

  const _PairingCodeWidget({
    required this.pin,
    required this.expiresAt,
    required this.onExpire,
    required this.accent,
    required this.subColor,
  });

  @override
  State<_PairingCodeWidget> createState() => _PairingCodeWidgetState();
}

class _PairingCodeWidgetState extends State<_PairingCodeWidget>
    with SingleTickerProviderStateMixin {
  AppLocalizations get l10n => AppLocalizations.of(context);
  late Timer _timer;
  Duration _remaining = Duration.zero;
  late AnimationController _pulseController;
  bool _refreshRequested = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
    _startTimer();
  }

  void _startTimer() {
    _updateRemaining();
    _timer =
        Timer.periodic(const Duration(seconds: 1), (_) => _updateRemaining());
  }

  @override
  void didUpdateWidget(covariant _PairingCodeWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.expiresAt != widget.expiresAt) {
      _refreshRequested = false;
      _updateRemaining();
    }
  }

  void _updateRemaining() {
    final now = DateTime.now();
    final diff = widget.expiresAt.difference(now);

    if (diff.inSeconds <= 0) {
      if (!_refreshRequested) {
        _refreshRequested = true;
        widget.onExpire();
      }
      if (mounted && _remaining != Duration.zero) {
        setState(() => _remaining = Duration.zero);
      }
      return;
    }

    _refreshRequested = false;
    if (mounted) setState(() => _remaining = diff);
  }

  @override
  void dispose() {
    _timer.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return "$m:$s";
  }

  @override
  Widget build(BuildContext context) {
    final isUrgent = _remaining.inSeconds < 60;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: widget.accent.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isUrgent
              ? Colors.orange.withValues(alpha: 0.5)
              : widget.accent.withValues(alpha: 0.2),
          width: isUrgent ? 1.5 : 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            textDirection: TextDirection.rtl,
            children: [
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                    l10n.tr(ar: 'رمز الإقران', en: 'Pairing code'),
                    style: TextStyle(
                        color: widget.subColor,
                        fontSize: 13,
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: isUrgent
                          ? Colors.orange.withValues(alpha: 0.1)
                          : widget.accent.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.timer_outlined,
                            size: 14,
                            color: isUrgent ? Colors.orange : widget.accent),
                        const SizedBox(width: 4),
                        Text(
                          _formatDuration(_remaining),
                          style: TextStyle(
                            color: isUrgent ? Colors.orange : widget.accent,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              TvFocusable(
                onPressed: widget.onExpire,
                ensureVisibleOnFocus: false,
                borderRadius: BorderRadius.circular(20),
                focusColor: widget.accent,
                child:
                    Icon(Icons.refresh_rounded, color: widget.accent, size: 20),
              ),
            ],
          ),
          const SizedBox(height: 12),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            transitionBuilder: (Widget child, Animation<double> animation) {
              return FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.2),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(
                      parent: animation, curve: Curves.easeOutBack)),
                  child: child,
                ),
              );
            },
            child: ScaleTransition(
              key: ValueKey(widget.pin),
              scale: isUrgent
                  ? Tween<double>(begin: 1.0, end: 1.03)
                      .animate(_pulseController)
                  : const AlwaysStoppedAnimation(1.0),
              child: Text(
                widget.pin.split('').join(' '),
                style: TextStyle(
                  color: isUrgent ? Colors.orange : widget.accent,
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 8,
                  fontFamily: 'Cairo',
                  shadows: [
                    Shadow(
                      color: (isUrgent ? Colors.orange : widget.accent)
                          .withValues(alpha: 0.3),
                      blurRadius: 12,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GlassPendingRequestCard extends StatefulWidget {
  final LoginRequest session;
  final VoidCallback onDeny;
  final VoidCallback onConfirm;
  final Color accent;

  const _GlassPendingRequestCard({
    required this.session,
    required this.onDeny,
    required this.onConfirm,
    required this.accent,
  });

  @override
  State<_GlassPendingRequestCard> createState() =>
      _GlassPendingRequestCardState();
}

class _GlassPendingRequestCardState extends State<_GlassPendingRequestCard>
    with TickerProviderStateMixin {
  AppLocalizations get l10n => AppLocalizations.of(context);
  late AnimationController _shineController;
  late Animation<double> _shineAnimation;

  @override
  void initState() {
    super.initState();
    _shineController =
        AnimationController(vsync: this, duration: const Duration(seconds: 4))
          ..repeat();

    _shineAnimation = Tween<double>(begin: -1.5, end: 1.5).animate(
      CurvedAnimation(
        parent: _shineController,
        curve: const Interval(0.0, 0.40, curve: Curves.easeInOut),
      ),
    );
  }

  @override
  void dispose() {
    _shineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : const Color(0xFF111827);
    final iconColor = isDark ? Colors.white70 : const Color(0xFF4B5563);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: isDark
                ? Colors.black.withValues(alpha: 0.3)
                : Colors.black.withValues(alpha: 0.08),
            offset: const Offset(0, 15),
            blurRadius: 30.0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16.0),
        clipBehavior: Clip.antiAlias,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
          child: Container(
            decoration: BoxDecoration(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.02)
                  : Colors.black.withValues(alpha: 0.01),
              borderRadius: BorderRadius.circular(16.0),
              border: Border.all(
                color: Colors.white.withValues(alpha: isDark ? 0.1 : 0.4),
                width: 0.5,
              ),
            ),
            child: Stack(
              children: [
                // Glass Highlights
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16.0),
                      border: Border(
                        top: BorderSide(
                          color: Colors.white
                              .withValues(alpha: isDark ? 0.3 : 0.6),
                          width: 1.5,
                        ),
                        left: BorderSide(
                          color: Colors.white
                              .withValues(alpha: isDark ? 0.2 : 0.4),
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                ),
                // Shine Effect
                Positioned.fill(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15.0),
                    child: AnimatedBuilder(
                      animation: _shineController,
                      builder: (context, child) {
                        return FractionalTranslation(
                          translation: Offset(_shineAnimation.value, 0),
                          child: child,
                        );
                      },
                      child: Transform(
                        transform: Matrix4.skewX(-25 * 3.14159 / 180),
                        alignment: Alignment.center,
                        child: Container(
                          width: double.infinity,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Color.fromRGBO(255, 255, 255, 0),
                                Color.fromRGBO(255, 255, 255, 0.1),
                                Color.fromRGBO(255, 255, 255, 0.4),
                                Color.fromRGBO(255, 255, 255, 0),
                                Color.fromRGBO(255, 255, 255, 0),
                                Color.fromRGBO(255, 255, 255, 0.15),
                                Color.fromRGBO(255, 255, 255, 0),
                                Color.fromRGBO(255, 255, 255, 0),
                              ],
                              stops: [
                                0.0,
                                0.20,
                                0.25,
                                0.30,
                                0.50,
                                0.55,
                                0.60,
                                1.0
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // Content
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        textDirection: TextDirection.rtl,
                        children: [
                          Icon(Icons.phonelink_lock_rounded,
                              color: widget.accent, size: 28),
                          const SizedBox(width: 10),
                          Text(
                            l10n.tr(ar: 'طلب إذن للتحكم عن بُعد', en: 'Remote control permission request'),
                            style: TextStyle(
                              color: textColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Cairo',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        l10n.tr(ar: 'الجهاز "${widget.session.deviceName}" يطلب صلاحية التحكم بالشاشة.', en: 'Device "${widget.session.deviceName}" is requesting screen control permission.'),
                        style: TextStyle(
                          color: iconColor,
                          fontSize: 13.5,
                          fontFamily: 'Cairo',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          TvFocusable(
                            onPressed: widget.onDeny,
                            borderRadius: BorderRadius.circular(12),
                            focusColor: Colors.redAccent,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 12),
                              decoration: BoxDecoration(
                                color: isDark
                                    ? Colors.red.withValues(alpha: 0.15)
                                    : Colors.red.withValues(alpha: 0.08),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: Colors.red
                                      .withValues(alpha: isDark ? 0.4 : 0.2),
                                ),
                              ),
                              child: Text(
                                l10n.tr(ar: 'رفض', en: 'Deny'),
                                style: TextStyle(
                                  color: isDark ? Colors.redAccent : Colors.red,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          TvFocusable(
                            autofocus: true,
                            onPressed: widget.onConfirm,
                            borderRadius: BorderRadius.circular(12),
                            focusColor: Colors.greenAccent,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 12),
                              decoration: BoxDecoration(
                                color: isDark
                                    ? Colors.green.withValues(alpha: 0.15)
                                    : Colors.green.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: Colors.green
                                      .withValues(alpha: isDark ? 0.4 : 0.3),
                                ),
                              ),
                              child: Text(
                                l10n.tr(ar: 'سماح', en: 'Allow'),
                                style: TextStyle(
                                  color: isDark
                                      ? Colors.greenAccent
                                      : Colors.green[700],
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}




