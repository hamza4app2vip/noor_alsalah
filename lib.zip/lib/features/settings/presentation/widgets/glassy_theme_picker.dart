import 'package:flutter/material.dart';
import '../../../../core/tv/tv_remote_support.dart';

class GlassyThemePicker extends StatelessWidget {
  final String currentValue;
  final Function(String) onChanged;

  const GlassyThemePicker({
    super.key,
    required this.currentValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(20),
        border:
            Border.all(color: Colors.white.withValues(alpha: 0.1), width: 0.5),
      ),
      child: Row(
        children: [
          _buildSegment(
            context,
            'SYSTEM',
            'تلقائي',
            Icons.settings_suggest_rounded,
          ),
          _buildSegment(
            context,
            'LIGHT',
            'نهاري',
            Icons.wb_sunny_rounded,
          ),
          _buildSegment(
            context,
            'DARK',
            'ليلي',
            Icons.nightlight_round,
          ),
        ],
      ),
    );
  }

  Widget _buildSegment(
    BuildContext context,
    String value,
    String label,
    IconData icon,
  ) {
    final isActive = currentValue == value;
    const activeColor = Color(0xFFDCB881); // Golden/Beige

    final isDark = Theme.of(context).brightness == Brightness.dark;

    final inactiveTextColor = isDark ? Colors.white60 : Colors.black54;
    final activeTextColor = isDark ? activeColor : const Color(0xFF08452F);

    return Expanded(
      child: TvFocusable(
        onPressed: () => onChanged(value),
        borderRadius: BorderRadius.circular(15),
        focusColor: activeColor,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isActive
                ? activeColor.withValues(alpha: 0.2)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(15),
            border: isActive
                ? Border.all(
                    color: activeColor.withValues(alpha: 0.5), width: 1)
                : Border.all(color: Colors.transparent, width: 1),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: activeColor.withValues(alpha: 0.3),
                      blurRadius: 15,
                      spreadRadius: 1,
                    )
                  ]
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: isActive ? activeTextColor : inactiveTextColor,
                size: 20,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? activeTextColor : inactiveTextColor,
                  fontSize: 12,
                  fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
                  fontFamily: 'Cairo',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
