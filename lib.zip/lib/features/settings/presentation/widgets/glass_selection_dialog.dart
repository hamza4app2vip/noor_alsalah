import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../../core/tv/tv_remote_support.dart';

class GlassSelectionItem<T> {
  final String title;
  final String? subtitle;
  final T value;

  const GlassSelectionItem({
    required this.title,
    this.subtitle,
    required this.value,
  });
}

class GlassSelectionDialog<T> extends StatefulWidget {
  final String title;
  final List<GlassSelectionItem<T>> items;
  final T? initialValue;

  const GlassSelectionDialog({
    super.key,
    required this.title,
    required this.items,
    this.initialValue,
  });

  @override
  State<GlassSelectionDialog<T>> createState() =>
      _GlassSelectionDialogState<T>();
}

class _GlassSelectionDialogState<T> extends State<GlassSelectionDialog<T>> {
  late List<GlassSelectionItem<T>> filteredItems;
  final TextEditingController searchController = TextEditingController();

  bool _isSearchEditing = false;
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    filteredItems = widget.items;
    searchController.addListener(_onSearchChanged);
    _searchFocusNode.addListener(() {
      if (!_searchFocusNode.hasFocus && _isSearchEditing) {
        setState(() {
          _isSearchEditing = false;
        });
      }
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = searchController.text.toLowerCase();
    setState(() {
      filteredItems = widget.items.where((item) {
        return item.title.toLowerCase().contains(query) ||
            (item.subtitle?.toLowerCase().contains(query) ?? false) ||
            item.value.toString().toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? const Color(0xFFDCB881) : const Color(0xFF1AA85A);
    final darkGreenText = isDark ? Colors.white : const Color(0xFF08452F);

    return FocusTraversalGroup(
      policy: OrderedTraversalPolicy(),
      child: Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 500, maxHeight: 800),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border: Border.all(
                  color: isDark
                      ? Colors.white.withValues(alpha: 0.1)
                      : Colors.white.withValues(alpha: 0.4),
                  width: 1,
                ),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: isDark
                      ? [
                          Colors.black.withValues(alpha: 0.3),
                          Colors.black.withValues(alpha: 0.1),
                        ]
                      : [
                          Colors.white.withValues(alpha: 0.4),
                          Colors.white.withValues(alpha: 0.1),
                        ],
                ),
              ),
              child: Column(
                children: [
                  // Header
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        Expanded(
                          child: Text(
                            widget.title,
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: darkGreenText,
                              fontFamily: 'Cairo',
                            ),
                          ),
                        ),
                        TvFocusable(
                          onPressed: () => Navigator.of(context).maybePop(),
                          ensureVisibleOnFocus: false,
                          borderRadius: BorderRadius.circular(20),
                          focusColor: accent,
                          child: Padding(
                            padding: const EdgeInsets.all(6),
                            child: Icon(
                              Icons.close,
                              color: isDark ? Colors.white54 : Colors.black54,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Search Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0),
                    child: TvFocusable(
                      autofocus: true,
                      onPressed: () {
                        setState(() {
                          _isSearchEditing = true;
                        });
                        Future.delayed(const Duration(milliseconds: 50), () {
                          if (mounted) _searchFocusNode.requestFocus();
                        });
                      },
                      borderRadius: BorderRadius.circular(16),
                      focusColor: accent,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        decoration: BoxDecoration(
                          color: isDark
                              ? Colors.white.withValues(alpha: 0.05)
                              : Colors.black.withValues(alpha: 0.05),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: isDark
                                  ? Colors.white.withValues(alpha: 0.05)
                                  : Colors.black.withValues(alpha: 0.05)),
                        ),
                        child: ExcludeFocus(
                          excluding: !_isSearchEditing,
                          child: IgnorePointer(
                            ignoring: !_isSearchEditing,
                            child: TextField(
                              controller: searchController,
                              focusNode: _searchFocusNode,
                              autofocus: false,
                              readOnly: !_isSearchEditing,
                              textAlign: TextAlign.right,
                              textDirection: TextDirection.rtl,
                              onSubmitted: (_) {
                                setState(() {
                                  _isSearchEditing = false;
                                });
                              },
                              style: TextStyle(
                                  color: isDark ? Colors.white : Colors.black87,
                                  fontSize: 16),
                              decoration: InputDecoration(
                                hintText: 'البحث...',
                                hintStyle: TextStyle(
                                  color: isDark
                                      ? Colors.white38
                                      : Colors.black45.withValues(alpha: 0.5),
                                  fontFamily: 'Cairo',
                                ),
                                border: InputBorder.none,
                                prefixIcon:
                                    Icon(Icons.search, color: darkGreenText),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // List View
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      itemCount: filteredItems.length,
                      itemBuilder: (context, index) {
                        final item = filteredItems[index];
                        final isSelected = item.value == widget.initialValue;

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: TvFocusable(
                            onPressed: () {
                              Navigator.of(context).pop(item.value);
                            },
                            borderRadius: BorderRadius.circular(16),
                            focusColor: accent,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? accent.withValues(alpha: 0.1)
                                    : (isDark
                                        ? Colors.white.withValues(alpha: 0.05)
                                        : Colors.white.withValues(alpha: 0.5)),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: isSelected
                                      ? accent.withValues(alpha: 0.3)
                                      : (isDark
                                          ? Colors.white.withValues(alpha: 0.05)
                                          : Colors.white
                                              .withValues(alpha: 0.4)),
                                ),
                              ),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 16),
                              child: Row(
                                textDirection: TextDirection.rtl,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          item.title,
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: isSelected
                                                ? FontWeight.bold
                                                : FontWeight.normal,
                                            color: isSelected
                                                ? darkGreenText
                                                : (isDark
                                                    ? Colors.white
                                                    : Colors.black87),
                                            fontFamily: 'Cairo',
                                          ),
                                        ),
                                        if (item.subtitle != null) ...[
                                          const SizedBox(height: 4),
                                          Text(
                                            item.subtitle!,
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: isDark
                                                  ? Colors.white54
                                                  : Colors.black45,
                                              fontFamily: 'Cairo',
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  if (isSelected)
                                    Icon(Icons.check_circle, color: accent)
                                  else
                                    Icon(Icons.chevron_left,
                                        color: isDark
                                            ? Colors.white24
                                            : Colors.black26),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
