// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'app_settings.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

AppSettings _$AppSettingsFromJson(Map<String, dynamic> json) {
  return _AppSettings.fromJson(json);
}

/// @nodoc
mixin _$AppSettings {
// ====== General Settings ======
  String get adminUsername =>
      throw _privateConstructorUsedError; // اسم المستخدم المحفوظ
  String get country => throw _privateConstructorUsedError;
  String get city => throw _privateConstructorUsedError;
  String get languageCode => throw _privateConstructorUsedError;
  bool get hasSelectedLanguage =>
      throw _privateConstructorUsedError; // هل تم اختيار اللغة من قبل المستخدم
  String get ayatsLanguageCode =>
      throw _privateConstructorUsedError; // لغة ترجمة الآيات
  bool get showHijriDate => throw _privateConstructorUsedError;
  int get hijriOffsetDays =>
      throw _privateConstructorUsedError; // ± أيام للهجري
  bool get is24HourFormat => throw _privateConstructorUsedError;
  bool get showSecondsClock =>
      throw _privateConstructorUsedError; // إظهار الثواني بالساعة
  bool get playAdhanSound => throw _privateConstructorUsedError;
  bool get isAutoLocation => throw _privateConstructorUsedError; // GPS Location
  String get mosqueName => throw _privateConstructorUsedError;
  String? get mosqueIconPath => throw _privateConstructorUsedError;
  String? get customFlagPath =>
      throw _privateConstructorUsedError; // ====== UI & Display ======
  String get themeMode =>
      throw _privateConstructorUsedError; // SYSTEM, LIGHT, DARK
  bool get showMarqueeTicker => throw _privateConstructorUsedError;
  bool get ramadanCountdownInjectEnabled => throw _privateConstructorUsedError;
  List<TickerItem> get tickerItems => throw _privateConstructorUsedError;
  bool get showAdminMessages =>
      throw _privateConstructorUsedError; // إعلانات المسجد
  bool get showBlackScreenDuringPrayer =>
      throw _privateConstructorUsedError; // الشاشة السوداء وقت الصلاة
  int get blackScreenDurationMinutes =>
      throw _privateConstructorUsedError; // مدة الصلاة قبل الرجوع
  bool get dimPastPrayers =>
      throw _privateConstructorUsedError; // تخفيت الصلوات المصلية
  String get fontFamily =>
      throw _privateConstructorUsedError; // ====== FULL SCREENSHOT SETTINGS ======
// A) General Settings
  int get clockOffsetMinutes =>
      throw _privateConstructorUsedError; // ضبط الساعة الرئيسية
// B) Display/Identity Options
  bool get showCountryFlag => throw _privateConstructorUsedError;
  bool get padTimesWithZero =>
      throw _privateConstructorUsedError; // إضافة صفر للأوقات e.g. 04:35
  bool get showFullClock =>
      throw _privateConstructorUsedError; // عرض الساعة 00:00:00
  bool get enableAnalogGlassClock =>
      throw _privateConstructorUsedError; // تفعيل الساعة التناظرية في الثيم الزجاجي
  bool get blackClockModeEnabled =>
      throw _privateConstructorUsedError; // شاشة المواقيت سوداء مع ساعة في المنتصف
  bool get blackClockModeUseGlass =>
      throw _privateConstructorUsedError; // خلفية زجاجية لشاشة الساعة الخاصة
  String? get blackClockModeCustomBgPath =>
      throw _privateConstructorUsedError; // صورة مخصصة لشاشة الساعة الخاصة
  String get analogClockStyle =>
      throw _privateConstructorUsedError; // GLASS, GOLDEN
  bool get showAnalogClockDateFrame =>
      throw _privateConstructorUsedError; // إظهار إطار التاريخ بجانب الساعة (الطولي/الأفقي)
  bool get showAnalogClockNumbers =>
      throw _privateConstructorUsedError; // إظهار أرقام الساعة التناظرية (عام لكل الساعات)
  bool get showNightPrayers =>
      throw _privateConstructorUsedError; // منتصف وثلث الليل
// C) Prayers List Options
  bool get centerPrayerNamesLandscape => throw _privateConstructorUsedError;
  bool get enlargePrayerNamesLandscape => throw _privateConstructorUsedError;
  bool get showIqamaWithClock => throw _privateConstructorUsedError;
  bool get showCountdown => throw _privateConstructorUsedError;
  bool get enlargeCountdown => throw _privateConstructorUsedError;
  bool get showFullscreenCountdownAtThreshold =>
      throw _privateConstructorUsedError;
  bool get useArabicIndicDigits =>
      throw _privateConstructorUsedError; // الأرقام العربية
  bool get hideIqamaTime => throw _privateConstructorUsedError;
  bool get centerPrayerNamesPortrait => throw _privateConstructorUsedError;
  bool get centerNameWithTimesOnSides =>
      throw _privateConstructorUsedError; // توسيط اسم الصلاة، الأذان يمين والإقامة يسار
  bool get showPrayerNameInOtherLanguage =>
      throw _privateConstructorUsedError; // ====== Fonts / Sizes Options ======
  double get prayerNameFontSize => throw _privateConstructorUsedError;
  double get prayerTimeFontSize => throw _privateConstructorUsedError;
  double get iqamaTimeFontSize =>
      throw _privateConstructorUsedError; // D) Adhan/Iqama Screens
  bool get showAdhanScreen => throw _privateConstructorUsedError;
  bool get showIqamaScreen => throw _privateConstructorUsedError;
  bool get swapDateAndMosqueLandscape => throw _privateConstructorUsedError;
  bool get showInternetStatus => throw _privateConstructorUsedError;
  bool get showBackgroundShadingBehindTimes =>
      throw _privateConstructorUsedError;
  bool get useTranslucentScreens =>
      throw _privateConstructorUsedError; // شاشات شبه شفافة
  bool get countdownGreenLast90s => throw _privateConstructorUsedError;
  bool get enlargeNextPrayerCountdown =>
      throw _privateConstructorUsedError; // E) Audio/Visual Alerts
  bool get playVoiceAlertBeforeIqama => throw _privateConstructorUsedError;
  String get voiceAlertMessage => throw _privateConstructorUsedError;
  bool get showHadithBeforeIqama =>
      throw _privateConstructorUsedError; // ====== Khushoo Program (Mute & Black Screen) ======
  bool get isGlobalAudioMuted => throw _privateConstructorUsedError;
  bool get isAzanAudioMuted => throw _privateConstructorUsedError;
  bool get khushooModeEnabled =>
      throw _privateConstructorUsedError; // تفعيل الشاشة السوداء تلقائيا بعد الأذان
  int get khushooModeDuration =>
      throw _privateConstructorUsedError; // مدة الشاشة السوداء بالدقائق
  bool get isKhushooManualActive =>
      throw _privateConstructorUsedError; // تفعيل يدوي للشاشة السوداء
// F) Eid Times
  String get eidAlFitrTime => throw _privateConstructorUsedError;
  String get eidAlAdhaTime =>
      throw _privateConstructorUsedError; // G) MP3 Audio
  bool get useMp3ForAdhan => throw _privateConstructorUsedError;
  bool get useShortAdhan => throw _privateConstructorUsedError;
  bool get useShortIqama =>
      throw _privateConstructorUsedError; // H) Specific Fonts
  String get azkarFontFamily => throw _privateConstructorUsedError;
  String get clockFontFamily => throw _privateConstructorUsedError;
  String get timesFontFamily => throw _privateConstructorUsedError;
  String get textFontFamily =>
      throw _privateConstructorUsedError; // ====== Advanced Time Adjustments (Phase 5) ======
  bool get ramadanIshaPlus30Enabled => throw _privateConstructorUsedError;
  bool get summerPlus1HourEnabled => throw _privateConstructorUsedError;
  bool get manualPlus1HourAllEnabled => throw _privateConstructorUsedError;
  bool get manualMinus1HourAllEnabled => throw _privateConstructorUsedError;
  int get prayerOffsetFajr => throw _privateConstructorUsedError;
  int get prayerOffsetSunrise => throw _privateConstructorUsedError;
  int get prayerOffsetDhuhr => throw _privateConstructorUsedError;
  int get prayerOffsetAsr => throw _privateConstructorUsedError;
  int get prayerOffsetMaghrib => throw _privateConstructorUsedError;
  int get prayerOffsetIsha => throw _privateConstructorUsedError;
  String get timeOffsetMasha =>
      throw _privateConstructorUsedError; // ====== Custom Adhan Sounds ======
  List<AdhanSound> get customAdhanSounds => throw _privateConstructorUsedError;
  String? get defaultAdhanSoundId =>
      throw _privateConstructorUsedError; // null = built-in default
  Map<String, String> get prayerAdhanSoundIds =>
      throw _privateConstructorUsedError; // e.g. "fajr" -> "uuid"
// ====== Manual Time Management ======
  bool get isManualTimeEnabled =>
      throw _privateConstructorUsedError; // true if user picks time manually
  String? get manualTimeValue =>
      throw _privateConstructorUsedError; // The user-picked time in "HH:mm" format if isManualTimeEnabled is true
// ====== Fixed Iqama System (Phase 5) ======
  Map<String, bool> get iqamaIsFixed =>
      throw _privateConstructorUsedError; // e.g. {'fajr': true}
  Map<String, String> get iqamaFixedTimes =>
      throw _privateConstructorUsedError; // e.g. {'fajr': '05:30'}
// ====== Jumua Settings (Phase 5) ======
  bool get jumuaKhutbahAutoMode => throw _privateConstructorUsedError;
  String get jumuaKhutbahManualTime => throw _privateConstructorUsedError;
  bool get showJumuaInLandscape => throw _privateConstructorUsedError;
  bool get enableJumuaAdhanSound =>
      throw _privateConstructorUsedError; // ====== Advanced Alerts & Dhuhr Calculation (Phase 5) ======
  int get fajrPreAdhanAlertMinutes => throw _privateConstructorUsedError;
  bool get dhuhrFromAsrMinusMinutesEnabled =>
      throw _privateConstructorUsedError;
  int get dhuhrEqualsAsrMinusMinutes =>
      throw _privateConstructorUsedError; // ====== Background System (Phase 5) ======
  String get bgMode =>
      throw _privateConstructorUsedError; // MANUAL, PER_PRAYER, PER_DAY, DAILY_RANDOM_FROM_LIST
  String get bgFitMode =>
      throw _privateConstructorUsedError; // COVER, CONTAIN, FILL
  int get selectedBackgroundId => throw _privateConstructorUsedError;
  Map<String, int> get backgroundPerPrayer =>
      throw _privateConstructorUsedError; // e.g. {'fajr': 1}
  Map<String, int> get backgroundPerWeekday =>
      throw _privateConstructorUsedError; // e.g. {'1': 2}
  List<int> get randomBackgroundPool =>
      throw _privateConstructorUsedError; // ====== Iqama & Adhan Adjustments ======
  int get fajrIqamaTime => throw _privateConstructorUsedError;
  int get dhuhrIqamaTime => throw _privateConstructorUsedError;
  int get asrIqamaTime => throw _privateConstructorUsedError;
  int get maghribIqamaTime => throw _privateConstructorUsedError;
  int get ishaIqamaTime => throw _privateConstructorUsedError;
  int get jomoaIqamaTime => throw _privateConstructorUsedError;
  bool get showPreAdhanBeep =>
      throw _privateConstructorUsedError; // منبه قبل الأذان
// ====== Azkar Toggles ======
  bool get enableSabahAzkar => throw _privateConstructorUsedError;
  bool get enableMasaaAzkar => throw _privateConstructorUsedError;
  bool get autoAzkarByTime =>
      throw _privateConstructorUsedError; // الظهور التلقائي حسب أوقات الصباح والمساء
  String get manualAzkarType =>
      throw _privateConstructorUsedError; // SABAH, MASAA, BOTH (في حال التفعيل اليدوي)
  bool get azkarOnlyScreenEnabled =>
      throw _privateConstructorUsedError; // عرض أذكار الصباح/المساء فقط
  bool get azkarOnlyScreenUseGlass =>
      throw _privateConstructorUsedError; // خلفية زجاجية لشاشة الأذكار فقط
  String? get azkarOnlyScreenCustomBgPath =>
      throw _privateConstructorUsedError; // صورة مخصصة لشاشة الأذكار فقط
  bool get enablePostPrayerAzkar =>
      throw _privateConstructorUsedError; // ====== Post-Prayer Azkar (Phase 6) ======
  bool get postPrayerAzkarEnabled => throw _privateConstructorUsedError;
  bool get postPrayerAzkarRepeatOnce => throw _privateConstructorUsedError;
  bool get postPrayerShowSingleSlide5Min => throw _privateConstructorUsedError;
  bool get postPrayerWhiteBackground => throw _privateConstructorUsedError;
  bool get enableSabahAfterFajr => throw _privateConstructorUsedError;
  bool get enableMasaaAfterAsr => throw _privateConstructorUsedError;
  bool get enableMasaaAfterMaghrib => throw _privateConstructorUsedError;
  bool get enableMasaaAfterIsha =>
      throw _privateConstructorUsedError; // ====== Slides & Messages (Phase 6) ======
  bool get slidesEnabled => throw _privateConstructorUsedError;
  bool get slidesShuffle => throw _privateConstructorUsedError;
  int get slideDurationSeconds => throw _privateConstructorUsedError;
  int get mainScreenDurationSeconds => throw _privateConstructorUsedError;
  String get slidesShowMode =>
      throw _privateConstructorUsedError; // AFTER_PRAYER, MANUAL
  List<Map<String, dynamic>> get slidesList =>
      throw _privateConstructorUsedError; // ====== Weather & GPS (Phase 6) ======
  bool get weatherEnabled => throw _privateConstructorUsedError;
  bool get weatherShowNearPrayerTimes => throw _privateConstructorUsedError;
  String get locationMode =>
      throw _privateConstructorUsedError; // AUTO or MANUAL
  double get gpsLat => throw _privateConstructorUsedError;
  double get gpsLng => throw _privateConstructorUsedError;
  bool get weatherAlertsEnabled =>
      throw _privateConstructorUsedError; // تنبيهات الطقس الصوتية
// ====== Orientation (Phase 8) ======
  String get appOrientation =>
      throw _privateConstructorUsedError; // AUTO, PORTRAIT, LANDSCAPE
// ====== Custom Excel Import Settings ======
  bool get useCustomPrayerTimes => throw _privateConstructorUsedError;
  String get customTimesCountry => throw _privateConstructorUsedError;
  String get customTimesCity => throw _privateConstructorUsedError;
  String get customTimesDuration =>
      throw _privateConstructorUsedError; // AUTO, YEAR, MONTH_6, MONTH_2, MONTH_1, WEEK_2, WEEK_1, DAY_2, DAY_1
  String? get customTimesFilePath =>
      throw _privateConstructorUsedError; // ====== Update Settings ======
  String? get selectedCustomBgPath => throw _privateConstructorUsedError;
  bool get showUpdateInSettings => throw _privateConstructorUsedError;
  String get appTheme =>
      throw _privateConstructorUsedError; // EMERALD, PURE_GLASS
  String get pureGlassColor1 => throw _privateConstructorUsedError;
  String get pureGlassColor2 => throw _privateConstructorUsedError;
  String get pureGlassColor3 => throw _privateConstructorUsedError;
  String get pureGlassTextColor => throw _privateConstructorUsedError;
  bool get glassShineEnabled =>
      throw _privateConstructorUsedError; // تفعيل/إيقاف البريق الزجاجي
  String get navbarPosition =>
      throw _privateConstructorUsedError; // FULL, CENTER, SIDE
// ====== Azkar Scheduling ======
  String get sabahStartTime => throw _privateConstructorUsedError;
  String get sabahEndTime => throw _privateConstructorUsedError;
  String get masaaStartTime => throw _privateConstructorUsedError;
  String get masaaEndTime => throw _privateConstructorUsedError;

  /// Serializes this AppSettings to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of AppSettings
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AppSettingsCopyWith<AppSettings> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AppSettingsCopyWith<$Res> {
  factory $AppSettingsCopyWith(
          AppSettings value, $Res Function(AppSettings) then) =
      _$AppSettingsCopyWithImpl<$Res, AppSettings>;
  @useResult
  $Res call(
      {String adminUsername,
      String country,
      String city,
      String languageCode,
      bool hasSelectedLanguage,
      String ayatsLanguageCode,
      bool showHijriDate,
      int hijriOffsetDays,
      bool is24HourFormat,
      bool showSecondsClock,
      bool playAdhanSound,
      bool isAutoLocation,
      String mosqueName,
      String? mosqueIconPath,
      String? customFlagPath,
      String themeMode,
      bool showMarqueeTicker,
      bool ramadanCountdownInjectEnabled,
      List<TickerItem> tickerItems,
      bool showAdminMessages,
      bool showBlackScreenDuringPrayer,
      int blackScreenDurationMinutes,
      bool dimPastPrayers,
      String fontFamily,
      int clockOffsetMinutes,
      bool showCountryFlag,
      bool padTimesWithZero,
      bool showFullClock,
      bool enableAnalogGlassClock,
      bool blackClockModeEnabled,
      bool blackClockModeUseGlass,
      String? blackClockModeCustomBgPath,
      String analogClockStyle,
      bool showAnalogClockDateFrame,
      bool showAnalogClockNumbers,
      bool showNightPrayers,
      bool centerPrayerNamesLandscape,
      bool enlargePrayerNamesLandscape,
      bool showIqamaWithClock,
      bool showCountdown,
      bool enlargeCountdown,
      bool showFullscreenCountdownAtThreshold,
      bool useArabicIndicDigits,
      bool hideIqamaTime,
      bool centerPrayerNamesPortrait,
      bool centerNameWithTimesOnSides,
      bool showPrayerNameInOtherLanguage,
      double prayerNameFontSize,
      double prayerTimeFontSize,
      double iqamaTimeFontSize,
      bool showAdhanScreen,
      bool showIqamaScreen,
      bool swapDateAndMosqueLandscape,
      bool showInternetStatus,
      bool showBackgroundShadingBehindTimes,
      bool useTranslucentScreens,
      bool countdownGreenLast90s,
      bool enlargeNextPrayerCountdown,
      bool playVoiceAlertBeforeIqama,
      String voiceAlertMessage,
      bool showHadithBeforeIqama,
      bool isGlobalAudioMuted,
      bool isAzanAudioMuted,
      bool khushooModeEnabled,
      int khushooModeDuration,
      bool isKhushooManualActive,
      String eidAlFitrTime,
      String eidAlAdhaTime,
      bool useMp3ForAdhan,
      bool useShortAdhan,
      bool useShortIqama,
      String azkarFontFamily,
      String clockFontFamily,
      String timesFontFamily,
      String textFontFamily,
      bool ramadanIshaPlus30Enabled,
      bool summerPlus1HourEnabled,
      bool manualPlus1HourAllEnabled,
      bool manualMinus1HourAllEnabled,
      int prayerOffsetFajr,
      int prayerOffsetSunrise,
      int prayerOffsetDhuhr,
      int prayerOffsetAsr,
      int prayerOffsetMaghrib,
      int prayerOffsetIsha,
      String timeOffsetMasha,
      List<AdhanSound> customAdhanSounds,
      String? defaultAdhanSoundId,
      Map<String, String> prayerAdhanSoundIds,
      bool isManualTimeEnabled,
      String? manualTimeValue,
      Map<String, bool> iqamaIsFixed,
      Map<String, String> iqamaFixedTimes,
      bool jumuaKhutbahAutoMode,
      String jumuaKhutbahManualTime,
      bool showJumuaInLandscape,
      bool enableJumuaAdhanSound,
      int fajrPreAdhanAlertMinutes,
      bool dhuhrFromAsrMinusMinutesEnabled,
      int dhuhrEqualsAsrMinusMinutes,
      String bgMode,
      String bgFitMode,
      int selectedBackgroundId,
      Map<String, int> backgroundPerPrayer,
      Map<String, int> backgroundPerWeekday,
      List<int> randomBackgroundPool,
      int fajrIqamaTime,
      int dhuhrIqamaTime,
      int asrIqamaTime,
      int maghribIqamaTime,
      int ishaIqamaTime,
      int jomoaIqamaTime,
      bool showPreAdhanBeep,
      bool enableSabahAzkar,
      bool enableMasaaAzkar,
      bool autoAzkarByTime,
      String manualAzkarType,
      bool azkarOnlyScreenEnabled,
      bool azkarOnlyScreenUseGlass,
      String? azkarOnlyScreenCustomBgPath,
      bool enablePostPrayerAzkar,
      bool postPrayerAzkarEnabled,
      bool postPrayerAzkarRepeatOnce,
      bool postPrayerShowSingleSlide5Min,
      bool postPrayerWhiteBackground,
      bool enableSabahAfterFajr,
      bool enableMasaaAfterAsr,
      bool enableMasaaAfterMaghrib,
      bool enableMasaaAfterIsha,
      bool slidesEnabled,
      bool slidesShuffle,
      int slideDurationSeconds,
      int mainScreenDurationSeconds,
      String slidesShowMode,
      List<Map<String, dynamic>> slidesList,
      bool weatherEnabled,
      bool weatherShowNearPrayerTimes,
      String locationMode,
      double gpsLat,
      double gpsLng,
      bool weatherAlertsEnabled,
      String appOrientation,
      bool useCustomPrayerTimes,
      String customTimesCountry,
      String customTimesCity,
      String customTimesDuration,
      String? customTimesFilePath,
      String? selectedCustomBgPath,
      bool showUpdateInSettings,
      String appTheme,
      String pureGlassColor1,
      String pureGlassColor2,
      String pureGlassColor3,
      String pureGlassTextColor,
      bool glassShineEnabled,
      String navbarPosition,
      String sabahStartTime,
      String sabahEndTime,
      String masaaStartTime,
      String masaaEndTime});
}

/// @nodoc
class _$AppSettingsCopyWithImpl<$Res, $Val extends AppSettings>
    implements $AppSettingsCopyWith<$Res> {
  _$AppSettingsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AppSettings
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adminUsername = null,
    Object? country = null,
    Object? city = null,
    Object? languageCode = null,
    Object? hasSelectedLanguage = null,
    Object? ayatsLanguageCode = null,
    Object? showHijriDate = null,
    Object? hijriOffsetDays = null,
    Object? is24HourFormat = null,
    Object? showSecondsClock = null,
    Object? playAdhanSound = null,
    Object? isAutoLocation = null,
    Object? mosqueName = null,
    Object? mosqueIconPath = freezed,
    Object? customFlagPath = freezed,
    Object? themeMode = null,
    Object? showMarqueeTicker = null,
    Object? ramadanCountdownInjectEnabled = null,
    Object? tickerItems = null,
    Object? showAdminMessages = null,
    Object? showBlackScreenDuringPrayer = null,
    Object? blackScreenDurationMinutes = null,
    Object? dimPastPrayers = null,
    Object? fontFamily = null,
    Object? clockOffsetMinutes = null,
    Object? showCountryFlag = null,
    Object? padTimesWithZero = null,
    Object? showFullClock = null,
    Object? enableAnalogGlassClock = null,
    Object? blackClockModeEnabled = null,
    Object? blackClockModeUseGlass = null,
    Object? blackClockModeCustomBgPath = freezed,
    Object? analogClockStyle = null,
    Object? showAnalogClockDateFrame = null,
    Object? showAnalogClockNumbers = null,
    Object? showNightPrayers = null,
    Object? centerPrayerNamesLandscape = null,
    Object? enlargePrayerNamesLandscape = null,
    Object? showIqamaWithClock = null,
    Object? showCountdown = null,
    Object? enlargeCountdown = null,
    Object? showFullscreenCountdownAtThreshold = null,
    Object? useArabicIndicDigits = null,
    Object? hideIqamaTime = null,
    Object? centerPrayerNamesPortrait = null,
    Object? centerNameWithTimesOnSides = null,
    Object? showPrayerNameInOtherLanguage = null,
    Object? prayerNameFontSize = null,
    Object? prayerTimeFontSize = null,
    Object? iqamaTimeFontSize = null,
    Object? showAdhanScreen = null,
    Object? showIqamaScreen = null,
    Object? swapDateAndMosqueLandscape = null,
    Object? showInternetStatus = null,
    Object? showBackgroundShadingBehindTimes = null,
    Object? useTranslucentScreens = null,
    Object? countdownGreenLast90s = null,
    Object? enlargeNextPrayerCountdown = null,
    Object? playVoiceAlertBeforeIqama = null,
    Object? voiceAlertMessage = null,
    Object? showHadithBeforeIqama = null,
    Object? isGlobalAudioMuted = null,
    Object? isAzanAudioMuted = null,
    Object? khushooModeEnabled = null,
    Object? khushooModeDuration = null,
    Object? isKhushooManualActive = null,
    Object? eidAlFitrTime = null,
    Object? eidAlAdhaTime = null,
    Object? useMp3ForAdhan = null,
    Object? useShortAdhan = null,
    Object? useShortIqama = null,
    Object? azkarFontFamily = null,
    Object? clockFontFamily = null,
    Object? timesFontFamily = null,
    Object? textFontFamily = null,
    Object? ramadanIshaPlus30Enabled = null,
    Object? summerPlus1HourEnabled = null,
    Object? manualPlus1HourAllEnabled = null,
    Object? manualMinus1HourAllEnabled = null,
    Object? prayerOffsetFajr = null,
    Object? prayerOffsetSunrise = null,
    Object? prayerOffsetDhuhr = null,
    Object? prayerOffsetAsr = null,
    Object? prayerOffsetMaghrib = null,
    Object? prayerOffsetIsha = null,
    Object? timeOffsetMasha = null,
    Object? customAdhanSounds = null,
    Object? defaultAdhanSoundId = freezed,
    Object? prayerAdhanSoundIds = null,
    Object? isManualTimeEnabled = null,
    Object? manualTimeValue = freezed,
    Object? iqamaIsFixed = null,
    Object? iqamaFixedTimes = null,
    Object? jumuaKhutbahAutoMode = null,
    Object? jumuaKhutbahManualTime = null,
    Object? showJumuaInLandscape = null,
    Object? enableJumuaAdhanSound = null,
    Object? fajrPreAdhanAlertMinutes = null,
    Object? dhuhrFromAsrMinusMinutesEnabled = null,
    Object? dhuhrEqualsAsrMinusMinutes = null,
    Object? bgMode = null,
    Object? bgFitMode = null,
    Object? selectedBackgroundId = null,
    Object? backgroundPerPrayer = null,
    Object? backgroundPerWeekday = null,
    Object? randomBackgroundPool = null,
    Object? fajrIqamaTime = null,
    Object? dhuhrIqamaTime = null,
    Object? asrIqamaTime = null,
    Object? maghribIqamaTime = null,
    Object? ishaIqamaTime = null,
    Object? jomoaIqamaTime = null,
    Object? showPreAdhanBeep = null,
    Object? enableSabahAzkar = null,
    Object? enableMasaaAzkar = null,
    Object? autoAzkarByTime = null,
    Object? manualAzkarType = null,
    Object? azkarOnlyScreenEnabled = null,
    Object? azkarOnlyScreenUseGlass = null,
    Object? azkarOnlyScreenCustomBgPath = freezed,
    Object? enablePostPrayerAzkar = null,
    Object? postPrayerAzkarEnabled = null,
    Object? postPrayerAzkarRepeatOnce = null,
    Object? postPrayerShowSingleSlide5Min = null,
    Object? postPrayerWhiteBackground = null,
    Object? enableSabahAfterFajr = null,
    Object? enableMasaaAfterAsr = null,
    Object? enableMasaaAfterMaghrib = null,
    Object? enableMasaaAfterIsha = null,
    Object? slidesEnabled = null,
    Object? slidesShuffle = null,
    Object? slideDurationSeconds = null,
    Object? mainScreenDurationSeconds = null,
    Object? slidesShowMode = null,
    Object? slidesList = null,
    Object? weatherEnabled = null,
    Object? weatherShowNearPrayerTimes = null,
    Object? locationMode = null,
    Object? gpsLat = null,
    Object? gpsLng = null,
    Object? weatherAlertsEnabled = null,
    Object? appOrientation = null,
    Object? useCustomPrayerTimes = null,
    Object? customTimesCountry = null,
    Object? customTimesCity = null,
    Object? customTimesDuration = null,
    Object? customTimesFilePath = freezed,
    Object? selectedCustomBgPath = freezed,
    Object? showUpdateInSettings = null,
    Object? appTheme = null,
    Object? pureGlassColor1 = null,
    Object? pureGlassColor2 = null,
    Object? pureGlassColor3 = null,
    Object? pureGlassTextColor = null,
    Object? glassShineEnabled = null,
    Object? navbarPosition = null,
    Object? sabahStartTime = null,
    Object? sabahEndTime = null,
    Object? masaaStartTime = null,
    Object? masaaEndTime = null,
  }) {
    return _then(_value.copyWith(
      adminUsername: null == adminUsername
          ? _value.adminUsername
          : adminUsername // ignore: cast_nullable_to_non_nullable
              as String,
      country: null == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      languageCode: null == languageCode
          ? _value.languageCode
          : languageCode // ignore: cast_nullable_to_non_nullable
              as String,
      hasSelectedLanguage: null == hasSelectedLanguage
          ? _value.hasSelectedLanguage
          : hasSelectedLanguage // ignore: cast_nullable_to_non_nullable
              as bool,
      ayatsLanguageCode: null == ayatsLanguageCode
          ? _value.ayatsLanguageCode
          : ayatsLanguageCode // ignore: cast_nullable_to_non_nullable
              as String,
      showHijriDate: null == showHijriDate
          ? _value.showHijriDate
          : showHijriDate // ignore: cast_nullable_to_non_nullable
              as bool,
      hijriOffsetDays: null == hijriOffsetDays
          ? _value.hijriOffsetDays
          : hijriOffsetDays // ignore: cast_nullable_to_non_nullable
              as int,
      is24HourFormat: null == is24HourFormat
          ? _value.is24HourFormat
          : is24HourFormat // ignore: cast_nullable_to_non_nullable
              as bool,
      showSecondsClock: null == showSecondsClock
          ? _value.showSecondsClock
          : showSecondsClock // ignore: cast_nullable_to_non_nullable
              as bool,
      playAdhanSound: null == playAdhanSound
          ? _value.playAdhanSound
          : playAdhanSound // ignore: cast_nullable_to_non_nullable
              as bool,
      isAutoLocation: null == isAutoLocation
          ? _value.isAutoLocation
          : isAutoLocation // ignore: cast_nullable_to_non_nullable
              as bool,
      mosqueName: null == mosqueName
          ? _value.mosqueName
          : mosqueName // ignore: cast_nullable_to_non_nullable
              as String,
      mosqueIconPath: freezed == mosqueIconPath
          ? _value.mosqueIconPath
          : mosqueIconPath // ignore: cast_nullable_to_non_nullable
              as String?,
      customFlagPath: freezed == customFlagPath
          ? _value.customFlagPath
          : customFlagPath // ignore: cast_nullable_to_non_nullable
              as String?,
      themeMode: null == themeMode
          ? _value.themeMode
          : themeMode // ignore: cast_nullable_to_non_nullable
              as String,
      showMarqueeTicker: null == showMarqueeTicker
          ? _value.showMarqueeTicker
          : showMarqueeTicker // ignore: cast_nullable_to_non_nullable
              as bool,
      ramadanCountdownInjectEnabled: null == ramadanCountdownInjectEnabled
          ? _value.ramadanCountdownInjectEnabled
          : ramadanCountdownInjectEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      tickerItems: null == tickerItems
          ? _value.tickerItems
          : tickerItems // ignore: cast_nullable_to_non_nullable
              as List<TickerItem>,
      showAdminMessages: null == showAdminMessages
          ? _value.showAdminMessages
          : showAdminMessages // ignore: cast_nullable_to_non_nullable
              as bool,
      showBlackScreenDuringPrayer: null == showBlackScreenDuringPrayer
          ? _value.showBlackScreenDuringPrayer
          : showBlackScreenDuringPrayer // ignore: cast_nullable_to_non_nullable
              as bool,
      blackScreenDurationMinutes: null == blackScreenDurationMinutes
          ? _value.blackScreenDurationMinutes
          : blackScreenDurationMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      dimPastPrayers: null == dimPastPrayers
          ? _value.dimPastPrayers
          : dimPastPrayers // ignore: cast_nullable_to_non_nullable
              as bool,
      fontFamily: null == fontFamily
          ? _value.fontFamily
          : fontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      clockOffsetMinutes: null == clockOffsetMinutes
          ? _value.clockOffsetMinutes
          : clockOffsetMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      showCountryFlag: null == showCountryFlag
          ? _value.showCountryFlag
          : showCountryFlag // ignore: cast_nullable_to_non_nullable
              as bool,
      padTimesWithZero: null == padTimesWithZero
          ? _value.padTimesWithZero
          : padTimesWithZero // ignore: cast_nullable_to_non_nullable
              as bool,
      showFullClock: null == showFullClock
          ? _value.showFullClock
          : showFullClock // ignore: cast_nullable_to_non_nullable
              as bool,
      enableAnalogGlassClock: null == enableAnalogGlassClock
          ? _value.enableAnalogGlassClock
          : enableAnalogGlassClock // ignore: cast_nullable_to_non_nullable
              as bool,
      blackClockModeEnabled: null == blackClockModeEnabled
          ? _value.blackClockModeEnabled
          : blackClockModeEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      blackClockModeUseGlass: null == blackClockModeUseGlass
          ? _value.blackClockModeUseGlass
          : blackClockModeUseGlass // ignore: cast_nullable_to_non_nullable
              as bool,
      blackClockModeCustomBgPath: freezed == blackClockModeCustomBgPath
          ? _value.blackClockModeCustomBgPath
          : blackClockModeCustomBgPath // ignore: cast_nullable_to_non_nullable
              as String?,
      analogClockStyle: null == analogClockStyle
          ? _value.analogClockStyle
          : analogClockStyle // ignore: cast_nullable_to_non_nullable
              as String,
      showAnalogClockDateFrame: null == showAnalogClockDateFrame
          ? _value.showAnalogClockDateFrame
          : showAnalogClockDateFrame // ignore: cast_nullable_to_non_nullable
              as bool,
      showAnalogClockNumbers: null == showAnalogClockNumbers
          ? _value.showAnalogClockNumbers
          : showAnalogClockNumbers // ignore: cast_nullable_to_non_nullable
              as bool,
      showNightPrayers: null == showNightPrayers
          ? _value.showNightPrayers
          : showNightPrayers // ignore: cast_nullable_to_non_nullable
              as bool,
      centerPrayerNamesLandscape: null == centerPrayerNamesLandscape
          ? _value.centerPrayerNamesLandscape
          : centerPrayerNamesLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      enlargePrayerNamesLandscape: null == enlargePrayerNamesLandscape
          ? _value.enlargePrayerNamesLandscape
          : enlargePrayerNamesLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      showIqamaWithClock: null == showIqamaWithClock
          ? _value.showIqamaWithClock
          : showIqamaWithClock // ignore: cast_nullable_to_non_nullable
              as bool,
      showCountdown: null == showCountdown
          ? _value.showCountdown
          : showCountdown // ignore: cast_nullable_to_non_nullable
              as bool,
      enlargeCountdown: null == enlargeCountdown
          ? _value.enlargeCountdown
          : enlargeCountdown // ignore: cast_nullable_to_non_nullable
              as bool,
      showFullscreenCountdownAtThreshold: null ==
              showFullscreenCountdownAtThreshold
          ? _value.showFullscreenCountdownAtThreshold
          : showFullscreenCountdownAtThreshold // ignore: cast_nullable_to_non_nullable
              as bool,
      useArabicIndicDigits: null == useArabicIndicDigits
          ? _value.useArabicIndicDigits
          : useArabicIndicDigits // ignore: cast_nullable_to_non_nullable
              as bool,
      hideIqamaTime: null == hideIqamaTime
          ? _value.hideIqamaTime
          : hideIqamaTime // ignore: cast_nullable_to_non_nullable
              as bool,
      centerPrayerNamesPortrait: null == centerPrayerNamesPortrait
          ? _value.centerPrayerNamesPortrait
          : centerPrayerNamesPortrait // ignore: cast_nullable_to_non_nullable
              as bool,
      centerNameWithTimesOnSides: null == centerNameWithTimesOnSides
          ? _value.centerNameWithTimesOnSides
          : centerNameWithTimesOnSides // ignore: cast_nullable_to_non_nullable
              as bool,
      showPrayerNameInOtherLanguage: null == showPrayerNameInOtherLanguage
          ? _value.showPrayerNameInOtherLanguage
          : showPrayerNameInOtherLanguage // ignore: cast_nullable_to_non_nullable
              as bool,
      prayerNameFontSize: null == prayerNameFontSize
          ? _value.prayerNameFontSize
          : prayerNameFontSize // ignore: cast_nullable_to_non_nullable
              as double,
      prayerTimeFontSize: null == prayerTimeFontSize
          ? _value.prayerTimeFontSize
          : prayerTimeFontSize // ignore: cast_nullable_to_non_nullable
              as double,
      iqamaTimeFontSize: null == iqamaTimeFontSize
          ? _value.iqamaTimeFontSize
          : iqamaTimeFontSize // ignore: cast_nullable_to_non_nullable
              as double,
      showAdhanScreen: null == showAdhanScreen
          ? _value.showAdhanScreen
          : showAdhanScreen // ignore: cast_nullable_to_non_nullable
              as bool,
      showIqamaScreen: null == showIqamaScreen
          ? _value.showIqamaScreen
          : showIqamaScreen // ignore: cast_nullable_to_non_nullable
              as bool,
      swapDateAndMosqueLandscape: null == swapDateAndMosqueLandscape
          ? _value.swapDateAndMosqueLandscape
          : swapDateAndMosqueLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      showInternetStatus: null == showInternetStatus
          ? _value.showInternetStatus
          : showInternetStatus // ignore: cast_nullable_to_non_nullable
              as bool,
      showBackgroundShadingBehindTimes: null == showBackgroundShadingBehindTimes
          ? _value.showBackgroundShadingBehindTimes
          : showBackgroundShadingBehindTimes // ignore: cast_nullable_to_non_nullable
              as bool,
      useTranslucentScreens: null == useTranslucentScreens
          ? _value.useTranslucentScreens
          : useTranslucentScreens // ignore: cast_nullable_to_non_nullable
              as bool,
      countdownGreenLast90s: null == countdownGreenLast90s
          ? _value.countdownGreenLast90s
          : countdownGreenLast90s // ignore: cast_nullable_to_non_nullable
              as bool,
      enlargeNextPrayerCountdown: null == enlargeNextPrayerCountdown
          ? _value.enlargeNextPrayerCountdown
          : enlargeNextPrayerCountdown // ignore: cast_nullable_to_non_nullable
              as bool,
      playVoiceAlertBeforeIqama: null == playVoiceAlertBeforeIqama
          ? _value.playVoiceAlertBeforeIqama
          : playVoiceAlertBeforeIqama // ignore: cast_nullable_to_non_nullable
              as bool,
      voiceAlertMessage: null == voiceAlertMessage
          ? _value.voiceAlertMessage
          : voiceAlertMessage // ignore: cast_nullable_to_non_nullable
              as String,
      showHadithBeforeIqama: null == showHadithBeforeIqama
          ? _value.showHadithBeforeIqama
          : showHadithBeforeIqama // ignore: cast_nullable_to_non_nullable
              as bool,
      isGlobalAudioMuted: null == isGlobalAudioMuted
          ? _value.isGlobalAudioMuted
          : isGlobalAudioMuted // ignore: cast_nullable_to_non_nullable
              as bool,
      isAzanAudioMuted: null == isAzanAudioMuted
          ? _value.isAzanAudioMuted
          : isAzanAudioMuted // ignore: cast_nullable_to_non_nullable
              as bool,
      khushooModeEnabled: null == khushooModeEnabled
          ? _value.khushooModeEnabled
          : khushooModeEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      khushooModeDuration: null == khushooModeDuration
          ? _value.khushooModeDuration
          : khushooModeDuration // ignore: cast_nullable_to_non_nullable
              as int,
      isKhushooManualActive: null == isKhushooManualActive
          ? _value.isKhushooManualActive
          : isKhushooManualActive // ignore: cast_nullable_to_non_nullable
              as bool,
      eidAlFitrTime: null == eidAlFitrTime
          ? _value.eidAlFitrTime
          : eidAlFitrTime // ignore: cast_nullable_to_non_nullable
              as String,
      eidAlAdhaTime: null == eidAlAdhaTime
          ? _value.eidAlAdhaTime
          : eidAlAdhaTime // ignore: cast_nullable_to_non_nullable
              as String,
      useMp3ForAdhan: null == useMp3ForAdhan
          ? _value.useMp3ForAdhan
          : useMp3ForAdhan // ignore: cast_nullable_to_non_nullable
              as bool,
      useShortAdhan: null == useShortAdhan
          ? _value.useShortAdhan
          : useShortAdhan // ignore: cast_nullable_to_non_nullable
              as bool,
      useShortIqama: null == useShortIqama
          ? _value.useShortIqama
          : useShortIqama // ignore: cast_nullable_to_non_nullable
              as bool,
      azkarFontFamily: null == azkarFontFamily
          ? _value.azkarFontFamily
          : azkarFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      clockFontFamily: null == clockFontFamily
          ? _value.clockFontFamily
          : clockFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      timesFontFamily: null == timesFontFamily
          ? _value.timesFontFamily
          : timesFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      textFontFamily: null == textFontFamily
          ? _value.textFontFamily
          : textFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      ramadanIshaPlus30Enabled: null == ramadanIshaPlus30Enabled
          ? _value.ramadanIshaPlus30Enabled
          : ramadanIshaPlus30Enabled // ignore: cast_nullable_to_non_nullable
              as bool,
      summerPlus1HourEnabled: null == summerPlus1HourEnabled
          ? _value.summerPlus1HourEnabled
          : summerPlus1HourEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      manualPlus1HourAllEnabled: null == manualPlus1HourAllEnabled
          ? _value.manualPlus1HourAllEnabled
          : manualPlus1HourAllEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      manualMinus1HourAllEnabled: null == manualMinus1HourAllEnabled
          ? _value.manualMinus1HourAllEnabled
          : manualMinus1HourAllEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      prayerOffsetFajr: null == prayerOffsetFajr
          ? _value.prayerOffsetFajr
          : prayerOffsetFajr // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetSunrise: null == prayerOffsetSunrise
          ? _value.prayerOffsetSunrise
          : prayerOffsetSunrise // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetDhuhr: null == prayerOffsetDhuhr
          ? _value.prayerOffsetDhuhr
          : prayerOffsetDhuhr // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetAsr: null == prayerOffsetAsr
          ? _value.prayerOffsetAsr
          : prayerOffsetAsr // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetMaghrib: null == prayerOffsetMaghrib
          ? _value.prayerOffsetMaghrib
          : prayerOffsetMaghrib // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetIsha: null == prayerOffsetIsha
          ? _value.prayerOffsetIsha
          : prayerOffsetIsha // ignore: cast_nullable_to_non_nullable
              as int,
      timeOffsetMasha: null == timeOffsetMasha
          ? _value.timeOffsetMasha
          : timeOffsetMasha // ignore: cast_nullable_to_non_nullable
              as String,
      customAdhanSounds: null == customAdhanSounds
          ? _value.customAdhanSounds
          : customAdhanSounds // ignore: cast_nullable_to_non_nullable
              as List<AdhanSound>,
      defaultAdhanSoundId: freezed == defaultAdhanSoundId
          ? _value.defaultAdhanSoundId
          : defaultAdhanSoundId // ignore: cast_nullable_to_non_nullable
              as String?,
      prayerAdhanSoundIds: null == prayerAdhanSoundIds
          ? _value.prayerAdhanSoundIds
          : prayerAdhanSoundIds // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
      isManualTimeEnabled: null == isManualTimeEnabled
          ? _value.isManualTimeEnabled
          : isManualTimeEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      manualTimeValue: freezed == manualTimeValue
          ? _value.manualTimeValue
          : manualTimeValue // ignore: cast_nullable_to_non_nullable
              as String?,
      iqamaIsFixed: null == iqamaIsFixed
          ? _value.iqamaIsFixed
          : iqamaIsFixed // ignore: cast_nullable_to_non_nullable
              as Map<String, bool>,
      iqamaFixedTimes: null == iqamaFixedTimes
          ? _value.iqamaFixedTimes
          : iqamaFixedTimes // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
      jumuaKhutbahAutoMode: null == jumuaKhutbahAutoMode
          ? _value.jumuaKhutbahAutoMode
          : jumuaKhutbahAutoMode // ignore: cast_nullable_to_non_nullable
              as bool,
      jumuaKhutbahManualTime: null == jumuaKhutbahManualTime
          ? _value.jumuaKhutbahManualTime
          : jumuaKhutbahManualTime // ignore: cast_nullable_to_non_nullable
              as String,
      showJumuaInLandscape: null == showJumuaInLandscape
          ? _value.showJumuaInLandscape
          : showJumuaInLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      enableJumuaAdhanSound: null == enableJumuaAdhanSound
          ? _value.enableJumuaAdhanSound
          : enableJumuaAdhanSound // ignore: cast_nullable_to_non_nullable
              as bool,
      fajrPreAdhanAlertMinutes: null == fajrPreAdhanAlertMinutes
          ? _value.fajrPreAdhanAlertMinutes
          : fajrPreAdhanAlertMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      dhuhrFromAsrMinusMinutesEnabled: null == dhuhrFromAsrMinusMinutesEnabled
          ? _value.dhuhrFromAsrMinusMinutesEnabled
          : dhuhrFromAsrMinusMinutesEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      dhuhrEqualsAsrMinusMinutes: null == dhuhrEqualsAsrMinusMinutes
          ? _value.dhuhrEqualsAsrMinusMinutes
          : dhuhrEqualsAsrMinusMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      bgMode: null == bgMode
          ? _value.bgMode
          : bgMode // ignore: cast_nullable_to_non_nullable
              as String,
      bgFitMode: null == bgFitMode
          ? _value.bgFitMode
          : bgFitMode // ignore: cast_nullable_to_non_nullable
              as String,
      selectedBackgroundId: null == selectedBackgroundId
          ? _value.selectedBackgroundId
          : selectedBackgroundId // ignore: cast_nullable_to_non_nullable
              as int,
      backgroundPerPrayer: null == backgroundPerPrayer
          ? _value.backgroundPerPrayer
          : backgroundPerPrayer // ignore: cast_nullable_to_non_nullable
              as Map<String, int>,
      backgroundPerWeekday: null == backgroundPerWeekday
          ? _value.backgroundPerWeekday
          : backgroundPerWeekday // ignore: cast_nullable_to_non_nullable
              as Map<String, int>,
      randomBackgroundPool: null == randomBackgroundPool
          ? _value.randomBackgroundPool
          : randomBackgroundPool // ignore: cast_nullable_to_non_nullable
              as List<int>,
      fajrIqamaTime: null == fajrIqamaTime
          ? _value.fajrIqamaTime
          : fajrIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      dhuhrIqamaTime: null == dhuhrIqamaTime
          ? _value.dhuhrIqamaTime
          : dhuhrIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      asrIqamaTime: null == asrIqamaTime
          ? _value.asrIqamaTime
          : asrIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      maghribIqamaTime: null == maghribIqamaTime
          ? _value.maghribIqamaTime
          : maghribIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      ishaIqamaTime: null == ishaIqamaTime
          ? _value.ishaIqamaTime
          : ishaIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      jomoaIqamaTime: null == jomoaIqamaTime
          ? _value.jomoaIqamaTime
          : jomoaIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      showPreAdhanBeep: null == showPreAdhanBeep
          ? _value.showPreAdhanBeep
          : showPreAdhanBeep // ignore: cast_nullable_to_non_nullable
              as bool,
      enableSabahAzkar: null == enableSabahAzkar
          ? _value.enableSabahAzkar
          : enableSabahAzkar // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAzkar: null == enableMasaaAzkar
          ? _value.enableMasaaAzkar
          : enableMasaaAzkar // ignore: cast_nullable_to_non_nullable
              as bool,
      autoAzkarByTime: null == autoAzkarByTime
          ? _value.autoAzkarByTime
          : autoAzkarByTime // ignore: cast_nullable_to_non_nullable
              as bool,
      manualAzkarType: null == manualAzkarType
          ? _value.manualAzkarType
          : manualAzkarType // ignore: cast_nullable_to_non_nullable
              as String,
      azkarOnlyScreenEnabled: null == azkarOnlyScreenEnabled
          ? _value.azkarOnlyScreenEnabled
          : azkarOnlyScreenEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      azkarOnlyScreenUseGlass: null == azkarOnlyScreenUseGlass
          ? _value.azkarOnlyScreenUseGlass
          : azkarOnlyScreenUseGlass // ignore: cast_nullable_to_non_nullable
              as bool,
      azkarOnlyScreenCustomBgPath: freezed == azkarOnlyScreenCustomBgPath
          ? _value.azkarOnlyScreenCustomBgPath
          : azkarOnlyScreenCustomBgPath // ignore: cast_nullable_to_non_nullable
              as String?,
      enablePostPrayerAzkar: null == enablePostPrayerAzkar
          ? _value.enablePostPrayerAzkar
          : enablePostPrayerAzkar // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerAzkarEnabled: null == postPrayerAzkarEnabled
          ? _value.postPrayerAzkarEnabled
          : postPrayerAzkarEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerAzkarRepeatOnce: null == postPrayerAzkarRepeatOnce
          ? _value.postPrayerAzkarRepeatOnce
          : postPrayerAzkarRepeatOnce // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerShowSingleSlide5Min: null == postPrayerShowSingleSlide5Min
          ? _value.postPrayerShowSingleSlide5Min
          : postPrayerShowSingleSlide5Min // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerWhiteBackground: null == postPrayerWhiteBackground
          ? _value.postPrayerWhiteBackground
          : postPrayerWhiteBackground // ignore: cast_nullable_to_non_nullable
              as bool,
      enableSabahAfterFajr: null == enableSabahAfterFajr
          ? _value.enableSabahAfterFajr
          : enableSabahAfterFajr // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAfterAsr: null == enableMasaaAfterAsr
          ? _value.enableMasaaAfterAsr
          : enableMasaaAfterAsr // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAfterMaghrib: null == enableMasaaAfterMaghrib
          ? _value.enableMasaaAfterMaghrib
          : enableMasaaAfterMaghrib // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAfterIsha: null == enableMasaaAfterIsha
          ? _value.enableMasaaAfterIsha
          : enableMasaaAfterIsha // ignore: cast_nullable_to_non_nullable
              as bool,
      slidesEnabled: null == slidesEnabled
          ? _value.slidesEnabled
          : slidesEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      slidesShuffle: null == slidesShuffle
          ? _value.slidesShuffle
          : slidesShuffle // ignore: cast_nullable_to_non_nullable
              as bool,
      slideDurationSeconds: null == slideDurationSeconds
          ? _value.slideDurationSeconds
          : slideDurationSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      mainScreenDurationSeconds: null == mainScreenDurationSeconds
          ? _value.mainScreenDurationSeconds
          : mainScreenDurationSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      slidesShowMode: null == slidesShowMode
          ? _value.slidesShowMode
          : slidesShowMode // ignore: cast_nullable_to_non_nullable
              as String,
      slidesList: null == slidesList
          ? _value.slidesList
          : slidesList // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>,
      weatherEnabled: null == weatherEnabled
          ? _value.weatherEnabled
          : weatherEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      weatherShowNearPrayerTimes: null == weatherShowNearPrayerTimes
          ? _value.weatherShowNearPrayerTimes
          : weatherShowNearPrayerTimes // ignore: cast_nullable_to_non_nullable
              as bool,
      locationMode: null == locationMode
          ? _value.locationMode
          : locationMode // ignore: cast_nullable_to_non_nullable
              as String,
      gpsLat: null == gpsLat
          ? _value.gpsLat
          : gpsLat // ignore: cast_nullable_to_non_nullable
              as double,
      gpsLng: null == gpsLng
          ? _value.gpsLng
          : gpsLng // ignore: cast_nullable_to_non_nullable
              as double,
      weatherAlertsEnabled: null == weatherAlertsEnabled
          ? _value.weatherAlertsEnabled
          : weatherAlertsEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      appOrientation: null == appOrientation
          ? _value.appOrientation
          : appOrientation // ignore: cast_nullable_to_non_nullable
              as String,
      useCustomPrayerTimes: null == useCustomPrayerTimes
          ? _value.useCustomPrayerTimes
          : useCustomPrayerTimes // ignore: cast_nullable_to_non_nullable
              as bool,
      customTimesCountry: null == customTimesCountry
          ? _value.customTimesCountry
          : customTimesCountry // ignore: cast_nullable_to_non_nullable
              as String,
      customTimesCity: null == customTimesCity
          ? _value.customTimesCity
          : customTimesCity // ignore: cast_nullable_to_non_nullable
              as String,
      customTimesDuration: null == customTimesDuration
          ? _value.customTimesDuration
          : customTimesDuration // ignore: cast_nullable_to_non_nullable
              as String,
      customTimesFilePath: freezed == customTimesFilePath
          ? _value.customTimesFilePath
          : customTimesFilePath // ignore: cast_nullable_to_non_nullable
              as String?,
      selectedCustomBgPath: freezed == selectedCustomBgPath
          ? _value.selectedCustomBgPath
          : selectedCustomBgPath // ignore: cast_nullable_to_non_nullable
              as String?,
      showUpdateInSettings: null == showUpdateInSettings
          ? _value.showUpdateInSettings
          : showUpdateInSettings // ignore: cast_nullable_to_non_nullable
              as bool,
      appTheme: null == appTheme
          ? _value.appTheme
          : appTheme // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassColor1: null == pureGlassColor1
          ? _value.pureGlassColor1
          : pureGlassColor1 // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassColor2: null == pureGlassColor2
          ? _value.pureGlassColor2
          : pureGlassColor2 // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassColor3: null == pureGlassColor3
          ? _value.pureGlassColor3
          : pureGlassColor3 // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassTextColor: null == pureGlassTextColor
          ? _value.pureGlassTextColor
          : pureGlassTextColor // ignore: cast_nullable_to_non_nullable
              as String,
      glassShineEnabled: null == glassShineEnabled
          ? _value.glassShineEnabled
          : glassShineEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      navbarPosition: null == navbarPosition
          ? _value.navbarPosition
          : navbarPosition // ignore: cast_nullable_to_non_nullable
              as String,
      sabahStartTime: null == sabahStartTime
          ? _value.sabahStartTime
          : sabahStartTime // ignore: cast_nullable_to_non_nullable
              as String,
      sabahEndTime: null == sabahEndTime
          ? _value.sabahEndTime
          : sabahEndTime // ignore: cast_nullable_to_non_nullable
              as String,
      masaaStartTime: null == masaaStartTime
          ? _value.masaaStartTime
          : masaaStartTime // ignore: cast_nullable_to_non_nullable
              as String,
      masaaEndTime: null == masaaEndTime
          ? _value.masaaEndTime
          : masaaEndTime // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AppSettingsImplCopyWith<$Res>
    implements $AppSettingsCopyWith<$Res> {
  factory _$$AppSettingsImplCopyWith(
          _$AppSettingsImpl value, $Res Function(_$AppSettingsImpl) then) =
      __$$AppSettingsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String adminUsername,
      String country,
      String city,
      String languageCode,
      bool hasSelectedLanguage,
      String ayatsLanguageCode,
      bool showHijriDate,
      int hijriOffsetDays,
      bool is24HourFormat,
      bool showSecondsClock,
      bool playAdhanSound,
      bool isAutoLocation,
      String mosqueName,
      String? mosqueIconPath,
      String? customFlagPath,
      String themeMode,
      bool showMarqueeTicker,
      bool ramadanCountdownInjectEnabled,
      List<TickerItem> tickerItems,
      bool showAdminMessages,
      bool showBlackScreenDuringPrayer,
      int blackScreenDurationMinutes,
      bool dimPastPrayers,
      String fontFamily,
      int clockOffsetMinutes,
      bool showCountryFlag,
      bool padTimesWithZero,
      bool showFullClock,
      bool enableAnalogGlassClock,
      bool blackClockModeEnabled,
      bool blackClockModeUseGlass,
      String? blackClockModeCustomBgPath,
      String analogClockStyle,
      bool showAnalogClockDateFrame,
      bool showAnalogClockNumbers,
      bool showNightPrayers,
      bool centerPrayerNamesLandscape,
      bool enlargePrayerNamesLandscape,
      bool showIqamaWithClock,
      bool showCountdown,
      bool enlargeCountdown,
      bool showFullscreenCountdownAtThreshold,
      bool useArabicIndicDigits,
      bool hideIqamaTime,
      bool centerPrayerNamesPortrait,
      bool centerNameWithTimesOnSides,
      bool showPrayerNameInOtherLanguage,
      double prayerNameFontSize,
      double prayerTimeFontSize,
      double iqamaTimeFontSize,
      bool showAdhanScreen,
      bool showIqamaScreen,
      bool swapDateAndMosqueLandscape,
      bool showInternetStatus,
      bool showBackgroundShadingBehindTimes,
      bool useTranslucentScreens,
      bool countdownGreenLast90s,
      bool enlargeNextPrayerCountdown,
      bool playVoiceAlertBeforeIqama,
      String voiceAlertMessage,
      bool showHadithBeforeIqama,
      bool isGlobalAudioMuted,
      bool isAzanAudioMuted,
      bool khushooModeEnabled,
      int khushooModeDuration,
      bool isKhushooManualActive,
      String eidAlFitrTime,
      String eidAlAdhaTime,
      bool useMp3ForAdhan,
      bool useShortAdhan,
      bool useShortIqama,
      String azkarFontFamily,
      String clockFontFamily,
      String timesFontFamily,
      String textFontFamily,
      bool ramadanIshaPlus30Enabled,
      bool summerPlus1HourEnabled,
      bool manualPlus1HourAllEnabled,
      bool manualMinus1HourAllEnabled,
      int prayerOffsetFajr,
      int prayerOffsetSunrise,
      int prayerOffsetDhuhr,
      int prayerOffsetAsr,
      int prayerOffsetMaghrib,
      int prayerOffsetIsha,
      String timeOffsetMasha,
      List<AdhanSound> customAdhanSounds,
      String? defaultAdhanSoundId,
      Map<String, String> prayerAdhanSoundIds,
      bool isManualTimeEnabled,
      String? manualTimeValue,
      Map<String, bool> iqamaIsFixed,
      Map<String, String> iqamaFixedTimes,
      bool jumuaKhutbahAutoMode,
      String jumuaKhutbahManualTime,
      bool showJumuaInLandscape,
      bool enableJumuaAdhanSound,
      int fajrPreAdhanAlertMinutes,
      bool dhuhrFromAsrMinusMinutesEnabled,
      int dhuhrEqualsAsrMinusMinutes,
      String bgMode,
      String bgFitMode,
      int selectedBackgroundId,
      Map<String, int> backgroundPerPrayer,
      Map<String, int> backgroundPerWeekday,
      List<int> randomBackgroundPool,
      int fajrIqamaTime,
      int dhuhrIqamaTime,
      int asrIqamaTime,
      int maghribIqamaTime,
      int ishaIqamaTime,
      int jomoaIqamaTime,
      bool showPreAdhanBeep,
      bool enableSabahAzkar,
      bool enableMasaaAzkar,
      bool autoAzkarByTime,
      String manualAzkarType,
      bool azkarOnlyScreenEnabled,
      bool azkarOnlyScreenUseGlass,
      String? azkarOnlyScreenCustomBgPath,
      bool enablePostPrayerAzkar,
      bool postPrayerAzkarEnabled,
      bool postPrayerAzkarRepeatOnce,
      bool postPrayerShowSingleSlide5Min,
      bool postPrayerWhiteBackground,
      bool enableSabahAfterFajr,
      bool enableMasaaAfterAsr,
      bool enableMasaaAfterMaghrib,
      bool enableMasaaAfterIsha,
      bool slidesEnabled,
      bool slidesShuffle,
      int slideDurationSeconds,
      int mainScreenDurationSeconds,
      String slidesShowMode,
      List<Map<String, dynamic>> slidesList,
      bool weatherEnabled,
      bool weatherShowNearPrayerTimes,
      String locationMode,
      double gpsLat,
      double gpsLng,
      bool weatherAlertsEnabled,
      String appOrientation,
      bool useCustomPrayerTimes,
      String customTimesCountry,
      String customTimesCity,
      String customTimesDuration,
      String? customTimesFilePath,
      String? selectedCustomBgPath,
      bool showUpdateInSettings,
      String appTheme,
      String pureGlassColor1,
      String pureGlassColor2,
      String pureGlassColor3,
      String pureGlassTextColor,
      bool glassShineEnabled,
      String navbarPosition,
      String sabahStartTime,
      String sabahEndTime,
      String masaaStartTime,
      String masaaEndTime});
}

/// @nodoc
class __$$AppSettingsImplCopyWithImpl<$Res>
    extends _$AppSettingsCopyWithImpl<$Res, _$AppSettingsImpl>
    implements _$$AppSettingsImplCopyWith<$Res> {
  __$$AppSettingsImplCopyWithImpl(
      _$AppSettingsImpl _value, $Res Function(_$AppSettingsImpl) _then)
      : super(_value, _then);

  /// Create a copy of AppSettings
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adminUsername = null,
    Object? country = null,
    Object? city = null,
    Object? languageCode = null,
    Object? hasSelectedLanguage = null,
    Object? ayatsLanguageCode = null,
    Object? showHijriDate = null,
    Object? hijriOffsetDays = null,
    Object? is24HourFormat = null,
    Object? showSecondsClock = null,
    Object? playAdhanSound = null,
    Object? isAutoLocation = null,
    Object? mosqueName = null,
    Object? mosqueIconPath = freezed,
    Object? customFlagPath = freezed,
    Object? themeMode = null,
    Object? showMarqueeTicker = null,
    Object? ramadanCountdownInjectEnabled = null,
    Object? tickerItems = null,
    Object? showAdminMessages = null,
    Object? showBlackScreenDuringPrayer = null,
    Object? blackScreenDurationMinutes = null,
    Object? dimPastPrayers = null,
    Object? fontFamily = null,
    Object? clockOffsetMinutes = null,
    Object? showCountryFlag = null,
    Object? padTimesWithZero = null,
    Object? showFullClock = null,
    Object? enableAnalogGlassClock = null,
    Object? blackClockModeEnabled = null,
    Object? blackClockModeUseGlass = null,
    Object? blackClockModeCustomBgPath = freezed,
    Object? analogClockStyle = null,
    Object? showAnalogClockDateFrame = null,
    Object? showAnalogClockNumbers = null,
    Object? showNightPrayers = null,
    Object? centerPrayerNamesLandscape = null,
    Object? enlargePrayerNamesLandscape = null,
    Object? showIqamaWithClock = null,
    Object? showCountdown = null,
    Object? enlargeCountdown = null,
    Object? showFullscreenCountdownAtThreshold = null,
    Object? useArabicIndicDigits = null,
    Object? hideIqamaTime = null,
    Object? centerPrayerNamesPortrait = null,
    Object? centerNameWithTimesOnSides = null,
    Object? showPrayerNameInOtherLanguage = null,
    Object? prayerNameFontSize = null,
    Object? prayerTimeFontSize = null,
    Object? iqamaTimeFontSize = null,
    Object? showAdhanScreen = null,
    Object? showIqamaScreen = null,
    Object? swapDateAndMosqueLandscape = null,
    Object? showInternetStatus = null,
    Object? showBackgroundShadingBehindTimes = null,
    Object? useTranslucentScreens = null,
    Object? countdownGreenLast90s = null,
    Object? enlargeNextPrayerCountdown = null,
    Object? playVoiceAlertBeforeIqama = null,
    Object? voiceAlertMessage = null,
    Object? showHadithBeforeIqama = null,
    Object? isGlobalAudioMuted = null,
    Object? isAzanAudioMuted = null,
    Object? khushooModeEnabled = null,
    Object? khushooModeDuration = null,
    Object? isKhushooManualActive = null,
    Object? eidAlFitrTime = null,
    Object? eidAlAdhaTime = null,
    Object? useMp3ForAdhan = null,
    Object? useShortAdhan = null,
    Object? useShortIqama = null,
    Object? azkarFontFamily = null,
    Object? clockFontFamily = null,
    Object? timesFontFamily = null,
    Object? textFontFamily = null,
    Object? ramadanIshaPlus30Enabled = null,
    Object? summerPlus1HourEnabled = null,
    Object? manualPlus1HourAllEnabled = null,
    Object? manualMinus1HourAllEnabled = null,
    Object? prayerOffsetFajr = null,
    Object? prayerOffsetSunrise = null,
    Object? prayerOffsetDhuhr = null,
    Object? prayerOffsetAsr = null,
    Object? prayerOffsetMaghrib = null,
    Object? prayerOffsetIsha = null,
    Object? timeOffsetMasha = null,
    Object? customAdhanSounds = null,
    Object? defaultAdhanSoundId = freezed,
    Object? prayerAdhanSoundIds = null,
    Object? isManualTimeEnabled = null,
    Object? manualTimeValue = freezed,
    Object? iqamaIsFixed = null,
    Object? iqamaFixedTimes = null,
    Object? jumuaKhutbahAutoMode = null,
    Object? jumuaKhutbahManualTime = null,
    Object? showJumuaInLandscape = null,
    Object? enableJumuaAdhanSound = null,
    Object? fajrPreAdhanAlertMinutes = null,
    Object? dhuhrFromAsrMinusMinutesEnabled = null,
    Object? dhuhrEqualsAsrMinusMinutes = null,
    Object? bgMode = null,
    Object? bgFitMode = null,
    Object? selectedBackgroundId = null,
    Object? backgroundPerPrayer = null,
    Object? backgroundPerWeekday = null,
    Object? randomBackgroundPool = null,
    Object? fajrIqamaTime = null,
    Object? dhuhrIqamaTime = null,
    Object? asrIqamaTime = null,
    Object? maghribIqamaTime = null,
    Object? ishaIqamaTime = null,
    Object? jomoaIqamaTime = null,
    Object? showPreAdhanBeep = null,
    Object? enableSabahAzkar = null,
    Object? enableMasaaAzkar = null,
    Object? autoAzkarByTime = null,
    Object? manualAzkarType = null,
    Object? azkarOnlyScreenEnabled = null,
    Object? azkarOnlyScreenUseGlass = null,
    Object? azkarOnlyScreenCustomBgPath = freezed,
    Object? enablePostPrayerAzkar = null,
    Object? postPrayerAzkarEnabled = null,
    Object? postPrayerAzkarRepeatOnce = null,
    Object? postPrayerShowSingleSlide5Min = null,
    Object? postPrayerWhiteBackground = null,
    Object? enableSabahAfterFajr = null,
    Object? enableMasaaAfterAsr = null,
    Object? enableMasaaAfterMaghrib = null,
    Object? enableMasaaAfterIsha = null,
    Object? slidesEnabled = null,
    Object? slidesShuffle = null,
    Object? slideDurationSeconds = null,
    Object? mainScreenDurationSeconds = null,
    Object? slidesShowMode = null,
    Object? slidesList = null,
    Object? weatherEnabled = null,
    Object? weatherShowNearPrayerTimes = null,
    Object? locationMode = null,
    Object? gpsLat = null,
    Object? gpsLng = null,
    Object? weatherAlertsEnabled = null,
    Object? appOrientation = null,
    Object? useCustomPrayerTimes = null,
    Object? customTimesCountry = null,
    Object? customTimesCity = null,
    Object? customTimesDuration = null,
    Object? customTimesFilePath = freezed,
    Object? selectedCustomBgPath = freezed,
    Object? showUpdateInSettings = null,
    Object? appTheme = null,
    Object? pureGlassColor1 = null,
    Object? pureGlassColor2 = null,
    Object? pureGlassColor3 = null,
    Object? pureGlassTextColor = null,
    Object? glassShineEnabled = null,
    Object? navbarPosition = null,
    Object? sabahStartTime = null,
    Object? sabahEndTime = null,
    Object? masaaStartTime = null,
    Object? masaaEndTime = null,
  }) {
    return _then(_$AppSettingsImpl(
      adminUsername: null == adminUsername
          ? _value.adminUsername
          : adminUsername // ignore: cast_nullable_to_non_nullable
              as String,
      country: null == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      languageCode: null == languageCode
          ? _value.languageCode
          : languageCode // ignore: cast_nullable_to_non_nullable
              as String,
      hasSelectedLanguage: null == hasSelectedLanguage
          ? _value.hasSelectedLanguage
          : hasSelectedLanguage // ignore: cast_nullable_to_non_nullable
              as bool,
      ayatsLanguageCode: null == ayatsLanguageCode
          ? _value.ayatsLanguageCode
          : ayatsLanguageCode // ignore: cast_nullable_to_non_nullable
              as String,
      showHijriDate: null == showHijriDate
          ? _value.showHijriDate
          : showHijriDate // ignore: cast_nullable_to_non_nullable
              as bool,
      hijriOffsetDays: null == hijriOffsetDays
          ? _value.hijriOffsetDays
          : hijriOffsetDays // ignore: cast_nullable_to_non_nullable
              as int,
      is24HourFormat: null == is24HourFormat
          ? _value.is24HourFormat
          : is24HourFormat // ignore: cast_nullable_to_non_nullable
              as bool,
      showSecondsClock: null == showSecondsClock
          ? _value.showSecondsClock
          : showSecondsClock // ignore: cast_nullable_to_non_nullable
              as bool,
      playAdhanSound: null == playAdhanSound
          ? _value.playAdhanSound
          : playAdhanSound // ignore: cast_nullable_to_non_nullable
              as bool,
      isAutoLocation: null == isAutoLocation
          ? _value.isAutoLocation
          : isAutoLocation // ignore: cast_nullable_to_non_nullable
              as bool,
      mosqueName: null == mosqueName
          ? _value.mosqueName
          : mosqueName // ignore: cast_nullable_to_non_nullable
              as String,
      mosqueIconPath: freezed == mosqueIconPath
          ? _value.mosqueIconPath
          : mosqueIconPath // ignore: cast_nullable_to_non_nullable
              as String?,
      customFlagPath: freezed == customFlagPath
          ? _value.customFlagPath
          : customFlagPath // ignore: cast_nullable_to_non_nullable
              as String?,
      themeMode: null == themeMode
          ? _value.themeMode
          : themeMode // ignore: cast_nullable_to_non_nullable
              as String,
      showMarqueeTicker: null == showMarqueeTicker
          ? _value.showMarqueeTicker
          : showMarqueeTicker // ignore: cast_nullable_to_non_nullable
              as bool,
      ramadanCountdownInjectEnabled: null == ramadanCountdownInjectEnabled
          ? _value.ramadanCountdownInjectEnabled
          : ramadanCountdownInjectEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      tickerItems: null == tickerItems
          ? _value._tickerItems
          : tickerItems // ignore: cast_nullable_to_non_nullable
              as List<TickerItem>,
      showAdminMessages: null == showAdminMessages
          ? _value.showAdminMessages
          : showAdminMessages // ignore: cast_nullable_to_non_nullable
              as bool,
      showBlackScreenDuringPrayer: null == showBlackScreenDuringPrayer
          ? _value.showBlackScreenDuringPrayer
          : showBlackScreenDuringPrayer // ignore: cast_nullable_to_non_nullable
              as bool,
      blackScreenDurationMinutes: null == blackScreenDurationMinutes
          ? _value.blackScreenDurationMinutes
          : blackScreenDurationMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      dimPastPrayers: null == dimPastPrayers
          ? _value.dimPastPrayers
          : dimPastPrayers // ignore: cast_nullable_to_non_nullable
              as bool,
      fontFamily: null == fontFamily
          ? _value.fontFamily
          : fontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      clockOffsetMinutes: null == clockOffsetMinutes
          ? _value.clockOffsetMinutes
          : clockOffsetMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      showCountryFlag: null == showCountryFlag
          ? _value.showCountryFlag
          : showCountryFlag // ignore: cast_nullable_to_non_nullable
              as bool,
      padTimesWithZero: null == padTimesWithZero
          ? _value.padTimesWithZero
          : padTimesWithZero // ignore: cast_nullable_to_non_nullable
              as bool,
      showFullClock: null == showFullClock
          ? _value.showFullClock
          : showFullClock // ignore: cast_nullable_to_non_nullable
              as bool,
      enableAnalogGlassClock: null == enableAnalogGlassClock
          ? _value.enableAnalogGlassClock
          : enableAnalogGlassClock // ignore: cast_nullable_to_non_nullable
              as bool,
      blackClockModeEnabled: null == blackClockModeEnabled
          ? _value.blackClockModeEnabled
          : blackClockModeEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      blackClockModeUseGlass: null == blackClockModeUseGlass
          ? _value.blackClockModeUseGlass
          : blackClockModeUseGlass // ignore: cast_nullable_to_non_nullable
              as bool,
      blackClockModeCustomBgPath: freezed == blackClockModeCustomBgPath
          ? _value.blackClockModeCustomBgPath
          : blackClockModeCustomBgPath // ignore: cast_nullable_to_non_nullable
              as String?,
      analogClockStyle: null == analogClockStyle
          ? _value.analogClockStyle
          : analogClockStyle // ignore: cast_nullable_to_non_nullable
              as String,
      showAnalogClockDateFrame: null == showAnalogClockDateFrame
          ? _value.showAnalogClockDateFrame
          : showAnalogClockDateFrame // ignore: cast_nullable_to_non_nullable
              as bool,
      showAnalogClockNumbers: null == showAnalogClockNumbers
          ? _value.showAnalogClockNumbers
          : showAnalogClockNumbers // ignore: cast_nullable_to_non_nullable
              as bool,
      showNightPrayers: null == showNightPrayers
          ? _value.showNightPrayers
          : showNightPrayers // ignore: cast_nullable_to_non_nullable
              as bool,
      centerPrayerNamesLandscape: null == centerPrayerNamesLandscape
          ? _value.centerPrayerNamesLandscape
          : centerPrayerNamesLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      enlargePrayerNamesLandscape: null == enlargePrayerNamesLandscape
          ? _value.enlargePrayerNamesLandscape
          : enlargePrayerNamesLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      showIqamaWithClock: null == showIqamaWithClock
          ? _value.showIqamaWithClock
          : showIqamaWithClock // ignore: cast_nullable_to_non_nullable
              as bool,
      showCountdown: null == showCountdown
          ? _value.showCountdown
          : showCountdown // ignore: cast_nullable_to_non_nullable
              as bool,
      enlargeCountdown: null == enlargeCountdown
          ? _value.enlargeCountdown
          : enlargeCountdown // ignore: cast_nullable_to_non_nullable
              as bool,
      showFullscreenCountdownAtThreshold: null ==
              showFullscreenCountdownAtThreshold
          ? _value.showFullscreenCountdownAtThreshold
          : showFullscreenCountdownAtThreshold // ignore: cast_nullable_to_non_nullable
              as bool,
      useArabicIndicDigits: null == useArabicIndicDigits
          ? _value.useArabicIndicDigits
          : useArabicIndicDigits // ignore: cast_nullable_to_non_nullable
              as bool,
      hideIqamaTime: null == hideIqamaTime
          ? _value.hideIqamaTime
          : hideIqamaTime // ignore: cast_nullable_to_non_nullable
              as bool,
      centerPrayerNamesPortrait: null == centerPrayerNamesPortrait
          ? _value.centerPrayerNamesPortrait
          : centerPrayerNamesPortrait // ignore: cast_nullable_to_non_nullable
              as bool,
      centerNameWithTimesOnSides: null == centerNameWithTimesOnSides
          ? _value.centerNameWithTimesOnSides
          : centerNameWithTimesOnSides // ignore: cast_nullable_to_non_nullable
              as bool,
      showPrayerNameInOtherLanguage: null == showPrayerNameInOtherLanguage
          ? _value.showPrayerNameInOtherLanguage
          : showPrayerNameInOtherLanguage // ignore: cast_nullable_to_non_nullable
              as bool,
      prayerNameFontSize: null == prayerNameFontSize
          ? _value.prayerNameFontSize
          : prayerNameFontSize // ignore: cast_nullable_to_non_nullable
              as double,
      prayerTimeFontSize: null == prayerTimeFontSize
          ? _value.prayerTimeFontSize
          : prayerTimeFontSize // ignore: cast_nullable_to_non_nullable
              as double,
      iqamaTimeFontSize: null == iqamaTimeFontSize
          ? _value.iqamaTimeFontSize
          : iqamaTimeFontSize // ignore: cast_nullable_to_non_nullable
              as double,
      showAdhanScreen: null == showAdhanScreen
          ? _value.showAdhanScreen
          : showAdhanScreen // ignore: cast_nullable_to_non_nullable
              as bool,
      showIqamaScreen: null == showIqamaScreen
          ? _value.showIqamaScreen
          : showIqamaScreen // ignore: cast_nullable_to_non_nullable
              as bool,
      swapDateAndMosqueLandscape: null == swapDateAndMosqueLandscape
          ? _value.swapDateAndMosqueLandscape
          : swapDateAndMosqueLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      showInternetStatus: null == showInternetStatus
          ? _value.showInternetStatus
          : showInternetStatus // ignore: cast_nullable_to_non_nullable
              as bool,
      showBackgroundShadingBehindTimes: null == showBackgroundShadingBehindTimes
          ? _value.showBackgroundShadingBehindTimes
          : showBackgroundShadingBehindTimes // ignore: cast_nullable_to_non_nullable
              as bool,
      useTranslucentScreens: null == useTranslucentScreens
          ? _value.useTranslucentScreens
          : useTranslucentScreens // ignore: cast_nullable_to_non_nullable
              as bool,
      countdownGreenLast90s: null == countdownGreenLast90s
          ? _value.countdownGreenLast90s
          : countdownGreenLast90s // ignore: cast_nullable_to_non_nullable
              as bool,
      enlargeNextPrayerCountdown: null == enlargeNextPrayerCountdown
          ? _value.enlargeNextPrayerCountdown
          : enlargeNextPrayerCountdown // ignore: cast_nullable_to_non_nullable
              as bool,
      playVoiceAlertBeforeIqama: null == playVoiceAlertBeforeIqama
          ? _value.playVoiceAlertBeforeIqama
          : playVoiceAlertBeforeIqama // ignore: cast_nullable_to_non_nullable
              as bool,
      voiceAlertMessage: null == voiceAlertMessage
          ? _value.voiceAlertMessage
          : voiceAlertMessage // ignore: cast_nullable_to_non_nullable
              as String,
      showHadithBeforeIqama: null == showHadithBeforeIqama
          ? _value.showHadithBeforeIqama
          : showHadithBeforeIqama // ignore: cast_nullable_to_non_nullable
              as bool,
      isGlobalAudioMuted: null == isGlobalAudioMuted
          ? _value.isGlobalAudioMuted
          : isGlobalAudioMuted // ignore: cast_nullable_to_non_nullable
              as bool,
      isAzanAudioMuted: null == isAzanAudioMuted
          ? _value.isAzanAudioMuted
          : isAzanAudioMuted // ignore: cast_nullable_to_non_nullable
              as bool,
      khushooModeEnabled: null == khushooModeEnabled
          ? _value.khushooModeEnabled
          : khushooModeEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      khushooModeDuration: null == khushooModeDuration
          ? _value.khushooModeDuration
          : khushooModeDuration // ignore: cast_nullable_to_non_nullable
              as int,
      isKhushooManualActive: null == isKhushooManualActive
          ? _value.isKhushooManualActive
          : isKhushooManualActive // ignore: cast_nullable_to_non_nullable
              as bool,
      eidAlFitrTime: null == eidAlFitrTime
          ? _value.eidAlFitrTime
          : eidAlFitrTime // ignore: cast_nullable_to_non_nullable
              as String,
      eidAlAdhaTime: null == eidAlAdhaTime
          ? _value.eidAlAdhaTime
          : eidAlAdhaTime // ignore: cast_nullable_to_non_nullable
              as String,
      useMp3ForAdhan: null == useMp3ForAdhan
          ? _value.useMp3ForAdhan
          : useMp3ForAdhan // ignore: cast_nullable_to_non_nullable
              as bool,
      useShortAdhan: null == useShortAdhan
          ? _value.useShortAdhan
          : useShortAdhan // ignore: cast_nullable_to_non_nullable
              as bool,
      useShortIqama: null == useShortIqama
          ? _value.useShortIqama
          : useShortIqama // ignore: cast_nullable_to_non_nullable
              as bool,
      azkarFontFamily: null == azkarFontFamily
          ? _value.azkarFontFamily
          : azkarFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      clockFontFamily: null == clockFontFamily
          ? _value.clockFontFamily
          : clockFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      timesFontFamily: null == timesFontFamily
          ? _value.timesFontFamily
          : timesFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      textFontFamily: null == textFontFamily
          ? _value.textFontFamily
          : textFontFamily // ignore: cast_nullable_to_non_nullable
              as String,
      ramadanIshaPlus30Enabled: null == ramadanIshaPlus30Enabled
          ? _value.ramadanIshaPlus30Enabled
          : ramadanIshaPlus30Enabled // ignore: cast_nullable_to_non_nullable
              as bool,
      summerPlus1HourEnabled: null == summerPlus1HourEnabled
          ? _value.summerPlus1HourEnabled
          : summerPlus1HourEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      manualPlus1HourAllEnabled: null == manualPlus1HourAllEnabled
          ? _value.manualPlus1HourAllEnabled
          : manualPlus1HourAllEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      manualMinus1HourAllEnabled: null == manualMinus1HourAllEnabled
          ? _value.manualMinus1HourAllEnabled
          : manualMinus1HourAllEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      prayerOffsetFajr: null == prayerOffsetFajr
          ? _value.prayerOffsetFajr
          : prayerOffsetFajr // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetSunrise: null == prayerOffsetSunrise
          ? _value.prayerOffsetSunrise
          : prayerOffsetSunrise // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetDhuhr: null == prayerOffsetDhuhr
          ? _value.prayerOffsetDhuhr
          : prayerOffsetDhuhr // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetAsr: null == prayerOffsetAsr
          ? _value.prayerOffsetAsr
          : prayerOffsetAsr // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetMaghrib: null == prayerOffsetMaghrib
          ? _value.prayerOffsetMaghrib
          : prayerOffsetMaghrib // ignore: cast_nullable_to_non_nullable
              as int,
      prayerOffsetIsha: null == prayerOffsetIsha
          ? _value.prayerOffsetIsha
          : prayerOffsetIsha // ignore: cast_nullable_to_non_nullable
              as int,
      timeOffsetMasha: null == timeOffsetMasha
          ? _value.timeOffsetMasha
          : timeOffsetMasha // ignore: cast_nullable_to_non_nullable
              as String,
      customAdhanSounds: null == customAdhanSounds
          ? _value._customAdhanSounds
          : customAdhanSounds // ignore: cast_nullable_to_non_nullable
              as List<AdhanSound>,
      defaultAdhanSoundId: freezed == defaultAdhanSoundId
          ? _value.defaultAdhanSoundId
          : defaultAdhanSoundId // ignore: cast_nullable_to_non_nullable
              as String?,
      prayerAdhanSoundIds: null == prayerAdhanSoundIds
          ? _value._prayerAdhanSoundIds
          : prayerAdhanSoundIds // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
      isManualTimeEnabled: null == isManualTimeEnabled
          ? _value.isManualTimeEnabled
          : isManualTimeEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      manualTimeValue: freezed == manualTimeValue
          ? _value.manualTimeValue
          : manualTimeValue // ignore: cast_nullable_to_non_nullable
              as String?,
      iqamaIsFixed: null == iqamaIsFixed
          ? _value._iqamaIsFixed
          : iqamaIsFixed // ignore: cast_nullable_to_non_nullable
              as Map<String, bool>,
      iqamaFixedTimes: null == iqamaFixedTimes
          ? _value._iqamaFixedTimes
          : iqamaFixedTimes // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
      jumuaKhutbahAutoMode: null == jumuaKhutbahAutoMode
          ? _value.jumuaKhutbahAutoMode
          : jumuaKhutbahAutoMode // ignore: cast_nullable_to_non_nullable
              as bool,
      jumuaKhutbahManualTime: null == jumuaKhutbahManualTime
          ? _value.jumuaKhutbahManualTime
          : jumuaKhutbahManualTime // ignore: cast_nullable_to_non_nullable
              as String,
      showJumuaInLandscape: null == showJumuaInLandscape
          ? _value.showJumuaInLandscape
          : showJumuaInLandscape // ignore: cast_nullable_to_non_nullable
              as bool,
      enableJumuaAdhanSound: null == enableJumuaAdhanSound
          ? _value.enableJumuaAdhanSound
          : enableJumuaAdhanSound // ignore: cast_nullable_to_non_nullable
              as bool,
      fajrPreAdhanAlertMinutes: null == fajrPreAdhanAlertMinutes
          ? _value.fajrPreAdhanAlertMinutes
          : fajrPreAdhanAlertMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      dhuhrFromAsrMinusMinutesEnabled: null == dhuhrFromAsrMinusMinutesEnabled
          ? _value.dhuhrFromAsrMinusMinutesEnabled
          : dhuhrFromAsrMinusMinutesEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      dhuhrEqualsAsrMinusMinutes: null == dhuhrEqualsAsrMinusMinutes
          ? _value.dhuhrEqualsAsrMinusMinutes
          : dhuhrEqualsAsrMinusMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      bgMode: null == bgMode
          ? _value.bgMode
          : bgMode // ignore: cast_nullable_to_non_nullable
              as String,
      bgFitMode: null == bgFitMode
          ? _value.bgFitMode
          : bgFitMode // ignore: cast_nullable_to_non_nullable
              as String,
      selectedBackgroundId: null == selectedBackgroundId
          ? _value.selectedBackgroundId
          : selectedBackgroundId // ignore: cast_nullable_to_non_nullable
              as int,
      backgroundPerPrayer: null == backgroundPerPrayer
          ? _value._backgroundPerPrayer
          : backgroundPerPrayer // ignore: cast_nullable_to_non_nullable
              as Map<String, int>,
      backgroundPerWeekday: null == backgroundPerWeekday
          ? _value._backgroundPerWeekday
          : backgroundPerWeekday // ignore: cast_nullable_to_non_nullable
              as Map<String, int>,
      randomBackgroundPool: null == randomBackgroundPool
          ? _value._randomBackgroundPool
          : randomBackgroundPool // ignore: cast_nullable_to_non_nullable
              as List<int>,
      fajrIqamaTime: null == fajrIqamaTime
          ? _value.fajrIqamaTime
          : fajrIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      dhuhrIqamaTime: null == dhuhrIqamaTime
          ? _value.dhuhrIqamaTime
          : dhuhrIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      asrIqamaTime: null == asrIqamaTime
          ? _value.asrIqamaTime
          : asrIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      maghribIqamaTime: null == maghribIqamaTime
          ? _value.maghribIqamaTime
          : maghribIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      ishaIqamaTime: null == ishaIqamaTime
          ? _value.ishaIqamaTime
          : ishaIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      jomoaIqamaTime: null == jomoaIqamaTime
          ? _value.jomoaIqamaTime
          : jomoaIqamaTime // ignore: cast_nullable_to_non_nullable
              as int,
      showPreAdhanBeep: null == showPreAdhanBeep
          ? _value.showPreAdhanBeep
          : showPreAdhanBeep // ignore: cast_nullable_to_non_nullable
              as bool,
      enableSabahAzkar: null == enableSabahAzkar
          ? _value.enableSabahAzkar
          : enableSabahAzkar // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAzkar: null == enableMasaaAzkar
          ? _value.enableMasaaAzkar
          : enableMasaaAzkar // ignore: cast_nullable_to_non_nullable
              as bool,
      autoAzkarByTime: null == autoAzkarByTime
          ? _value.autoAzkarByTime
          : autoAzkarByTime // ignore: cast_nullable_to_non_nullable
              as bool,
      manualAzkarType: null == manualAzkarType
          ? _value.manualAzkarType
          : manualAzkarType // ignore: cast_nullable_to_non_nullable
              as String,
      azkarOnlyScreenEnabled: null == azkarOnlyScreenEnabled
          ? _value.azkarOnlyScreenEnabled
          : azkarOnlyScreenEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      azkarOnlyScreenUseGlass: null == azkarOnlyScreenUseGlass
          ? _value.azkarOnlyScreenUseGlass
          : azkarOnlyScreenUseGlass // ignore: cast_nullable_to_non_nullable
              as bool,
      azkarOnlyScreenCustomBgPath: freezed == azkarOnlyScreenCustomBgPath
          ? _value.azkarOnlyScreenCustomBgPath
          : azkarOnlyScreenCustomBgPath // ignore: cast_nullable_to_non_nullable
              as String?,
      enablePostPrayerAzkar: null == enablePostPrayerAzkar
          ? _value.enablePostPrayerAzkar
          : enablePostPrayerAzkar // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerAzkarEnabled: null == postPrayerAzkarEnabled
          ? _value.postPrayerAzkarEnabled
          : postPrayerAzkarEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerAzkarRepeatOnce: null == postPrayerAzkarRepeatOnce
          ? _value.postPrayerAzkarRepeatOnce
          : postPrayerAzkarRepeatOnce // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerShowSingleSlide5Min: null == postPrayerShowSingleSlide5Min
          ? _value.postPrayerShowSingleSlide5Min
          : postPrayerShowSingleSlide5Min // ignore: cast_nullable_to_non_nullable
              as bool,
      postPrayerWhiteBackground: null == postPrayerWhiteBackground
          ? _value.postPrayerWhiteBackground
          : postPrayerWhiteBackground // ignore: cast_nullable_to_non_nullable
              as bool,
      enableSabahAfterFajr: null == enableSabahAfterFajr
          ? _value.enableSabahAfterFajr
          : enableSabahAfterFajr // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAfterAsr: null == enableMasaaAfterAsr
          ? _value.enableMasaaAfterAsr
          : enableMasaaAfterAsr // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAfterMaghrib: null == enableMasaaAfterMaghrib
          ? _value.enableMasaaAfterMaghrib
          : enableMasaaAfterMaghrib // ignore: cast_nullable_to_non_nullable
              as bool,
      enableMasaaAfterIsha: null == enableMasaaAfterIsha
          ? _value.enableMasaaAfterIsha
          : enableMasaaAfterIsha // ignore: cast_nullable_to_non_nullable
              as bool,
      slidesEnabled: null == slidesEnabled
          ? _value.slidesEnabled
          : slidesEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      slidesShuffle: null == slidesShuffle
          ? _value.slidesShuffle
          : slidesShuffle // ignore: cast_nullable_to_non_nullable
              as bool,
      slideDurationSeconds: null == slideDurationSeconds
          ? _value.slideDurationSeconds
          : slideDurationSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      mainScreenDurationSeconds: null == mainScreenDurationSeconds
          ? _value.mainScreenDurationSeconds
          : mainScreenDurationSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      slidesShowMode: null == slidesShowMode
          ? _value.slidesShowMode
          : slidesShowMode // ignore: cast_nullable_to_non_nullable
              as String,
      slidesList: null == slidesList
          ? _value._slidesList
          : slidesList // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>,
      weatherEnabled: null == weatherEnabled
          ? _value.weatherEnabled
          : weatherEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      weatherShowNearPrayerTimes: null == weatherShowNearPrayerTimes
          ? _value.weatherShowNearPrayerTimes
          : weatherShowNearPrayerTimes // ignore: cast_nullable_to_non_nullable
              as bool,
      locationMode: null == locationMode
          ? _value.locationMode
          : locationMode // ignore: cast_nullable_to_non_nullable
              as String,
      gpsLat: null == gpsLat
          ? _value.gpsLat
          : gpsLat // ignore: cast_nullable_to_non_nullable
              as double,
      gpsLng: null == gpsLng
          ? _value.gpsLng
          : gpsLng // ignore: cast_nullable_to_non_nullable
              as double,
      weatherAlertsEnabled: null == weatherAlertsEnabled
          ? _value.weatherAlertsEnabled
          : weatherAlertsEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      appOrientation: null == appOrientation
          ? _value.appOrientation
          : appOrientation // ignore: cast_nullable_to_non_nullable
              as String,
      useCustomPrayerTimes: null == useCustomPrayerTimes
          ? _value.useCustomPrayerTimes
          : useCustomPrayerTimes // ignore: cast_nullable_to_non_nullable
              as bool,
      customTimesCountry: null == customTimesCountry
          ? _value.customTimesCountry
          : customTimesCountry // ignore: cast_nullable_to_non_nullable
              as String,
      customTimesCity: null == customTimesCity
          ? _value.customTimesCity
          : customTimesCity // ignore: cast_nullable_to_non_nullable
              as String,
      customTimesDuration: null == customTimesDuration
          ? _value.customTimesDuration
          : customTimesDuration // ignore: cast_nullable_to_non_nullable
              as String,
      customTimesFilePath: freezed == customTimesFilePath
          ? _value.customTimesFilePath
          : customTimesFilePath // ignore: cast_nullable_to_non_nullable
              as String?,
      selectedCustomBgPath: freezed == selectedCustomBgPath
          ? _value.selectedCustomBgPath
          : selectedCustomBgPath // ignore: cast_nullable_to_non_nullable
              as String?,
      showUpdateInSettings: null == showUpdateInSettings
          ? _value.showUpdateInSettings
          : showUpdateInSettings // ignore: cast_nullable_to_non_nullable
              as bool,
      appTheme: null == appTheme
          ? _value.appTheme
          : appTheme // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassColor1: null == pureGlassColor1
          ? _value.pureGlassColor1
          : pureGlassColor1 // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassColor2: null == pureGlassColor2
          ? _value.pureGlassColor2
          : pureGlassColor2 // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassColor3: null == pureGlassColor3
          ? _value.pureGlassColor3
          : pureGlassColor3 // ignore: cast_nullable_to_non_nullable
              as String,
      pureGlassTextColor: null == pureGlassTextColor
          ? _value.pureGlassTextColor
          : pureGlassTextColor // ignore: cast_nullable_to_non_nullable
              as String,
      glassShineEnabled: null == glassShineEnabled
          ? _value.glassShineEnabled
          : glassShineEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
      navbarPosition: null == navbarPosition
          ? _value.navbarPosition
          : navbarPosition // ignore: cast_nullable_to_non_nullable
              as String,
      sabahStartTime: null == sabahStartTime
          ? _value.sabahStartTime
          : sabahStartTime // ignore: cast_nullable_to_non_nullable
              as String,
      sabahEndTime: null == sabahEndTime
          ? _value.sabahEndTime
          : sabahEndTime // ignore: cast_nullable_to_non_nullable
              as String,
      masaaStartTime: null == masaaStartTime
          ? _value.masaaStartTime
          : masaaStartTime // ignore: cast_nullable_to_non_nullable
              as String,
      masaaEndTime: null == masaaEndTime
          ? _value.masaaEndTime
          : masaaEndTime // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AppSettingsImpl implements _AppSettings {
  const _$AppSettingsImpl(
      {this.adminUsername = '',
      this.country = 'SA',
      this.city = 'makkah',
      this.languageCode = 'ar',
      this.hasSelectedLanguage = false,
      this.ayatsLanguageCode = 'ar',
      this.showHijriDate = true,
      this.hijriOffsetDays = 0,
      this.is24HourFormat = true,
      this.showSecondsClock = false,
      this.playAdhanSound = true,
      this.isAutoLocation = false,
      this.mosqueName = 'مسجد نور الإيمان',
      this.mosqueIconPath,
      this.customFlagPath,
      this.themeMode = 'SYSTEM',
      this.showMarqueeTicker = true,
      this.ramadanCountdownInjectEnabled = false,
      final List<TickerItem> tickerItems = const [],
      this.showAdminMessages = true,
      this.showBlackScreenDuringPrayer = false,
      this.blackScreenDurationMinutes = 30,
      this.dimPastPrayers = false,
      this.fontFamily = 'Cairo',
      this.clockOffsetMinutes = 0,
      this.showCountryFlag = true,
      this.padTimesWithZero = true,
      this.showFullClock = false,
      this.enableAnalogGlassClock = false,
      this.blackClockModeEnabled = false,
      this.blackClockModeUseGlass = false,
      this.blackClockModeCustomBgPath,
      this.analogClockStyle = 'GLASS',
      this.showAnalogClockDateFrame = true,
      this.showAnalogClockNumbers = false,
      this.showNightPrayers = true,
      this.centerPrayerNamesLandscape = false,
      this.enlargePrayerNamesLandscape = false,
      this.showIqamaWithClock = false,
      this.showCountdown = true,
      this.enlargeCountdown = false,
      this.showFullscreenCountdownAtThreshold = true,
      this.useArabicIndicDigits = true,
      this.hideIqamaTime = false,
      this.centerPrayerNamesPortrait = false,
      this.centerNameWithTimesOnSides = false,
      this.showPrayerNameInOtherLanguage = false,
      this.prayerNameFontSize = 22.0,
      this.prayerTimeFontSize = 26.0,
      this.iqamaTimeFontSize = 18.0,
      this.showAdhanScreen = true,
      this.showIqamaScreen = true,
      this.swapDateAndMosqueLandscape = true,
      this.showInternetStatus = true,
      this.showBackgroundShadingBehindTimes = true,
      this.useTranslucentScreens = true,
      this.countdownGreenLast90s = true,
      this.enlargeNextPrayerCountdown = false,
      this.playVoiceAlertBeforeIqama = true,
      this.voiceAlertMessage = 'أقيموا صفوفكم وسدوا الخلل',
      this.showHadithBeforeIqama = true,
      this.isGlobalAudioMuted = false,
      this.isAzanAudioMuted = false,
      this.khushooModeEnabled = false,
      this.khushooModeDuration = 5,
      this.isKhushooManualActive = false,
      this.eidAlFitrTime = '08:00',
      this.eidAlAdhaTime = '07:00',
      this.useMp3ForAdhan = true,
      this.useShortAdhan = false,
      this.useShortIqama = false,
      this.azkarFontFamily = 'Uthman',
      this.clockFontFamily = 'Sultan',
      this.timesFontFamily = 'STC',
      this.textFontFamily = 'Cairo',
      this.ramadanIshaPlus30Enabled = false,
      this.summerPlus1HourEnabled = false,
      this.manualPlus1HourAllEnabled = false,
      this.manualMinus1HourAllEnabled = false,
      this.prayerOffsetFajr = 0,
      this.prayerOffsetSunrise = 0,
      this.prayerOffsetDhuhr = 0,
      this.prayerOffsetAsr = 0,
      this.prayerOffsetMaghrib = 0,
      this.prayerOffsetIsha = 0,
      this.timeOffsetMasha = '0',
      final List<AdhanSound> customAdhanSounds = const [],
      this.defaultAdhanSoundId = null,
      final Map<String, String> prayerAdhanSoundIds = const {},
      this.isManualTimeEnabled = false,
      this.manualTimeValue = null,
      final Map<String, bool> iqamaIsFixed = const {},
      final Map<String, String> iqamaFixedTimes = const {},
      this.jumuaKhutbahAutoMode = true,
      this.jumuaKhutbahManualTime = '12:00',
      this.showJumuaInLandscape = false,
      this.enableJumuaAdhanSound = true,
      this.fajrPreAdhanAlertMinutes = 0,
      this.dhuhrFromAsrMinusMinutesEnabled = false,
      this.dhuhrEqualsAsrMinusMinutes = 0,
      this.bgMode = 'MANUAL',
      this.bgFitMode = 'COVER',
      this.selectedBackgroundId = 0,
      final Map<String, int> backgroundPerPrayer = const {},
      final Map<String, int> backgroundPerWeekday = const {},
      final List<int> randomBackgroundPool = const [],
      this.fajrIqamaTime = 20,
      this.dhuhrIqamaTime = 15,
      this.asrIqamaTime = 15,
      this.maghribIqamaTime = 10,
      this.ishaIqamaTime = 15,
      this.jomoaIqamaTime = 0,
      this.showPreAdhanBeep = true,
      this.enableSabahAzkar = true,
      this.enableMasaaAzkar = true,
      this.autoAzkarByTime = false,
      this.manualAzkarType = 'BOTH',
      this.azkarOnlyScreenEnabled = false,
      this.azkarOnlyScreenUseGlass = false,
      this.azkarOnlyScreenCustomBgPath,
      this.enablePostPrayerAzkar = true,
      this.postPrayerAzkarEnabled = true,
      this.postPrayerAzkarRepeatOnce = false,
      this.postPrayerShowSingleSlide5Min = false,
      this.postPrayerWhiteBackground = false,
      this.enableSabahAfterFajr = true,
      this.enableMasaaAfterAsr = true,
      this.enableMasaaAfterMaghrib = true,
      this.enableMasaaAfterIsha = true,
      this.slidesEnabled = false,
      this.slidesShuffle = false,
      this.slideDurationSeconds = 15,
      this.mainScreenDurationSeconds = 12,
      this.slidesShowMode = 'AFTER_PRAYER',
      final List<Map<String, dynamic>> slidesList = const [],
      this.weatherEnabled = false,
      this.weatherShowNearPrayerTimes = true,
      this.locationMode = 'AUTO',
      this.gpsLat = 0.0,
      this.gpsLng = 0.0,
      this.weatherAlertsEnabled = true,
      this.appOrientation = 'AUTO',
      this.useCustomPrayerTimes = false,
      this.customTimesCountry = 'SA',
      this.customTimesCity = 'makkah',
      this.customTimesDuration = 'AUTO',
      this.customTimesFilePath,
      this.selectedCustomBgPath = null,
      this.showUpdateInSettings = true,
      this.appTheme = 'PURE_GLASS',
      this.pureGlassColor1 = '#38BDF8',
      this.pureGlassColor2 = '#818CF8',
      this.pureGlassColor3 = '#E879F9',
      this.pureGlassTextColor = '#FFFFFF',
      this.glassShineEnabled = true,
      this.navbarPosition = 'SIDE',
      this.sabahStartTime = '04:00',
      this.sabahEndTime = '09:00',
      this.masaaStartTime = '15:00',
      this.masaaEndTime = '20:00'})
      : _tickerItems = tickerItems,
        _customAdhanSounds = customAdhanSounds,
        _prayerAdhanSoundIds = prayerAdhanSoundIds,
        _iqamaIsFixed = iqamaIsFixed,
        _iqamaFixedTimes = iqamaFixedTimes,
        _backgroundPerPrayer = backgroundPerPrayer,
        _backgroundPerWeekday = backgroundPerWeekday,
        _randomBackgroundPool = randomBackgroundPool,
        _slidesList = slidesList;

  factory _$AppSettingsImpl.fromJson(Map<String, dynamic> json) =>
      _$$AppSettingsImplFromJson(json);

// ====== General Settings ======
  @override
  @JsonKey()
  final String adminUsername;
// اسم المستخدم المحفوظ
  @override
  @JsonKey()
  final String country;
  @override
  @JsonKey()
  final String city;
  @override
  @JsonKey()
  final String languageCode;
  @override
  @JsonKey()
  final bool hasSelectedLanguage;
// هل تم اختيار اللغة من قبل المستخدم
  @override
  @JsonKey()
  final String ayatsLanguageCode;
// لغة ترجمة الآيات
  @override
  @JsonKey()
  final bool showHijriDate;
  @override
  @JsonKey()
  final int hijriOffsetDays;
// ± أيام للهجري
  @override
  @JsonKey()
  final bool is24HourFormat;
  @override
  @JsonKey()
  final bool showSecondsClock;
// إظهار الثواني بالساعة
  @override
  @JsonKey()
  final bool playAdhanSound;
  @override
  @JsonKey()
  final bool isAutoLocation;
// GPS Location
  @override
  @JsonKey()
  final String mosqueName;
  @override
  final String? mosqueIconPath;
  @override
  final String? customFlagPath;
// ====== UI & Display ======
  @override
  @JsonKey()
  final String themeMode;
// SYSTEM, LIGHT, DARK
  @override
  @JsonKey()
  final bool showMarqueeTicker;
  @override
  @JsonKey()
  final bool ramadanCountdownInjectEnabled;
  final List<TickerItem> _tickerItems;
  @override
  @JsonKey()
  List<TickerItem> get tickerItems {
    if (_tickerItems is EqualUnmodifiableListView) return _tickerItems;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_tickerItems);
  }

  @override
  @JsonKey()
  final bool showAdminMessages;
// إعلانات المسجد
  @override
  @JsonKey()
  final bool showBlackScreenDuringPrayer;
// الشاشة السوداء وقت الصلاة
  @override
  @JsonKey()
  final int blackScreenDurationMinutes;
// مدة الصلاة قبل الرجوع
  @override
  @JsonKey()
  final bool dimPastPrayers;
// تخفيت الصلوات المصلية
  @override
  @JsonKey()
  final String fontFamily;
// ====== FULL SCREENSHOT SETTINGS ======
// A) General Settings
  @override
  @JsonKey()
  final int clockOffsetMinutes;
// ضبط الساعة الرئيسية
// B) Display/Identity Options
  @override
  @JsonKey()
  final bool showCountryFlag;
  @override
  @JsonKey()
  final bool padTimesWithZero;
// إضافة صفر للأوقات e.g. 04:35
  @override
  @JsonKey()
  final bool showFullClock;
// عرض الساعة 00:00:00
  @override
  @JsonKey()
  final bool enableAnalogGlassClock;
// تفعيل الساعة التناظرية في الثيم الزجاجي
  @override
  @JsonKey()
  final bool blackClockModeEnabled;
// شاشة المواقيت سوداء مع ساعة في المنتصف
  @override
  @JsonKey()
  final bool blackClockModeUseGlass;
// خلفية زجاجية لشاشة الساعة الخاصة
  @override
  final String? blackClockModeCustomBgPath;
// صورة مخصصة لشاشة الساعة الخاصة
  @override
  @JsonKey()
  final String analogClockStyle;
// GLASS, GOLDEN
  @override
  @JsonKey()
  final bool showAnalogClockDateFrame;
// إظهار إطار التاريخ بجانب الساعة (الطولي/الأفقي)
  @override
  @JsonKey()
  final bool showAnalogClockNumbers;
// إظهار أرقام الساعة التناظرية (عام لكل الساعات)
  @override
  @JsonKey()
  final bool showNightPrayers;
// منتصف وثلث الليل
// C) Prayers List Options
  @override
  @JsonKey()
  final bool centerPrayerNamesLandscape;
  @override
  @JsonKey()
  final bool enlargePrayerNamesLandscape;
  @override
  @JsonKey()
  final bool showIqamaWithClock;
  @override
  @JsonKey()
  final bool showCountdown;
  @override
  @JsonKey()
  final bool enlargeCountdown;
  @override
  @JsonKey()
  final bool showFullscreenCountdownAtThreshold;
  @override
  @JsonKey()
  final bool useArabicIndicDigits;
// الأرقام العربية
  @override
  @JsonKey()
  final bool hideIqamaTime;
  @override
  @JsonKey()
  final bool centerPrayerNamesPortrait;
  @override
  @JsonKey()
  final bool centerNameWithTimesOnSides;
// توسيط اسم الصلاة، الأذان يمين والإقامة يسار
  @override
  @JsonKey()
  final bool showPrayerNameInOtherLanguage;
// ====== Fonts / Sizes Options ======
  @override
  @JsonKey()
  final double prayerNameFontSize;
  @override
  @JsonKey()
  final double prayerTimeFontSize;
  @override
  @JsonKey()
  final double iqamaTimeFontSize;
// D) Adhan/Iqama Screens
  @override
  @JsonKey()
  final bool showAdhanScreen;
  @override
  @JsonKey()
  final bool showIqamaScreen;
  @override
  @JsonKey()
  final bool swapDateAndMosqueLandscape;
  @override
  @JsonKey()
  final bool showInternetStatus;
  @override
  @JsonKey()
  final bool showBackgroundShadingBehindTimes;
  @override
  @JsonKey()
  final bool useTranslucentScreens;
// شاشات شبه شفافة
  @override
  @JsonKey()
  final bool countdownGreenLast90s;
  @override
  @JsonKey()
  final bool enlargeNextPrayerCountdown;
// E) Audio/Visual Alerts
  @override
  @JsonKey()
  final bool playVoiceAlertBeforeIqama;
  @override
  @JsonKey()
  final String voiceAlertMessage;
  @override
  @JsonKey()
  final bool showHadithBeforeIqama;
// ====== Khushoo Program (Mute & Black Screen) ======
  @override
  @JsonKey()
  final bool isGlobalAudioMuted;
  @override
  @JsonKey()
  final bool isAzanAudioMuted;
  @override
  @JsonKey()
  final bool khushooModeEnabled;
// تفعيل الشاشة السوداء تلقائيا بعد الأذان
  @override
  @JsonKey()
  final int khushooModeDuration;
// مدة الشاشة السوداء بالدقائق
  @override
  @JsonKey()
  final bool isKhushooManualActive;
// تفعيل يدوي للشاشة السوداء
// F) Eid Times
  @override
  @JsonKey()
  final String eidAlFitrTime;
  @override
  @JsonKey()
  final String eidAlAdhaTime;
// G) MP3 Audio
  @override
  @JsonKey()
  final bool useMp3ForAdhan;
  @override
  @JsonKey()
  final bool useShortAdhan;
  @override
  @JsonKey()
  final bool useShortIqama;
// H) Specific Fonts
  @override
  @JsonKey()
  final String azkarFontFamily;
  @override
  @JsonKey()
  final String clockFontFamily;
  @override
  @JsonKey()
  final String timesFontFamily;
  @override
  @JsonKey()
  final String textFontFamily;
// ====== Advanced Time Adjustments (Phase 5) ======
  @override
  @JsonKey()
  final bool ramadanIshaPlus30Enabled;
  @override
  @JsonKey()
  final bool summerPlus1HourEnabled;
  @override
  @JsonKey()
  final bool manualPlus1HourAllEnabled;
  @override
  @JsonKey()
  final bool manualMinus1HourAllEnabled;
  @override
  @JsonKey()
  final int prayerOffsetFajr;
  @override
  @JsonKey()
  final int prayerOffsetSunrise;
  @override
  @JsonKey()
  final int prayerOffsetDhuhr;
  @override
  @JsonKey()
  final int prayerOffsetAsr;
  @override
  @JsonKey()
  final int prayerOffsetMaghrib;
  @override
  @JsonKey()
  final int prayerOffsetIsha;
  @override
  @JsonKey()
  final String timeOffsetMasha;
// ====== Custom Adhan Sounds ======
  final List<AdhanSound> _customAdhanSounds;
// ====== Custom Adhan Sounds ======
  @override
  @JsonKey()
  List<AdhanSound> get customAdhanSounds {
    if (_customAdhanSounds is EqualUnmodifiableListView)
      return _customAdhanSounds;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_customAdhanSounds);
  }

  @override
  @JsonKey()
  final String? defaultAdhanSoundId;
// null = built-in default
  final Map<String, String> _prayerAdhanSoundIds;
// null = built-in default
  @override
  @JsonKey()
  Map<String, String> get prayerAdhanSoundIds {
    if (_prayerAdhanSoundIds is EqualUnmodifiableMapView)
      return _prayerAdhanSoundIds;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_prayerAdhanSoundIds);
  }

// e.g. "fajr" -> "uuid"
// ====== Manual Time Management ======
  @override
  @JsonKey()
  final bool isManualTimeEnabled;
// true if user picks time manually
  @override
  @JsonKey()
  final String? manualTimeValue;
// The user-picked time in "HH:mm" format if isManualTimeEnabled is true
// ====== Fixed Iqama System (Phase 5) ======
  final Map<String, bool> _iqamaIsFixed;
// The user-picked time in "HH:mm" format if isManualTimeEnabled is true
// ====== Fixed Iqama System (Phase 5) ======
  @override
  @JsonKey()
  Map<String, bool> get iqamaIsFixed {
    if (_iqamaIsFixed is EqualUnmodifiableMapView) return _iqamaIsFixed;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_iqamaIsFixed);
  }

// e.g. {'fajr': true}
  final Map<String, String> _iqamaFixedTimes;
// e.g. {'fajr': true}
  @override
  @JsonKey()
  Map<String, String> get iqamaFixedTimes {
    if (_iqamaFixedTimes is EqualUnmodifiableMapView) return _iqamaFixedTimes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_iqamaFixedTimes);
  }

// e.g. {'fajr': '05:30'}
// ====== Jumua Settings (Phase 5) ======
  @override
  @JsonKey()
  final bool jumuaKhutbahAutoMode;
  @override
  @JsonKey()
  final String jumuaKhutbahManualTime;
  @override
  @JsonKey()
  final bool showJumuaInLandscape;
  @override
  @JsonKey()
  final bool enableJumuaAdhanSound;
// ====== Advanced Alerts & Dhuhr Calculation (Phase 5) ======
  @override
  @JsonKey()
  final int fajrPreAdhanAlertMinutes;
  @override
  @JsonKey()
  final bool dhuhrFromAsrMinusMinutesEnabled;
  @override
  @JsonKey()
  final int dhuhrEqualsAsrMinusMinutes;
// ====== Background System (Phase 5) ======
  @override
  @JsonKey()
  final String bgMode;
// MANUAL, PER_PRAYER, PER_DAY, DAILY_RANDOM_FROM_LIST
  @override
  @JsonKey()
  final String bgFitMode;
// COVER, CONTAIN, FILL
  @override
  @JsonKey()
  final int selectedBackgroundId;
  final Map<String, int> _backgroundPerPrayer;
  @override
  @JsonKey()
  Map<String, int> get backgroundPerPrayer {
    if (_backgroundPerPrayer is EqualUnmodifiableMapView)
      return _backgroundPerPrayer;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_backgroundPerPrayer);
  }

// e.g. {'fajr': 1}
  final Map<String, int> _backgroundPerWeekday;
// e.g. {'fajr': 1}
  @override
  @JsonKey()
  Map<String, int> get backgroundPerWeekday {
    if (_backgroundPerWeekday is EqualUnmodifiableMapView)
      return _backgroundPerWeekday;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_backgroundPerWeekday);
  }

// e.g. {'1': 2}
  final List<int> _randomBackgroundPool;
// e.g. {'1': 2}
  @override
  @JsonKey()
  List<int> get randomBackgroundPool {
    if (_randomBackgroundPool is EqualUnmodifiableListView)
      return _randomBackgroundPool;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_randomBackgroundPool);
  }

// ====== Iqama & Adhan Adjustments ======
  @override
  @JsonKey()
  final int fajrIqamaTime;
  @override
  @JsonKey()
  final int dhuhrIqamaTime;
  @override
  @JsonKey()
  final int asrIqamaTime;
  @override
  @JsonKey()
  final int maghribIqamaTime;
  @override
  @JsonKey()
  final int ishaIqamaTime;
  @override
  @JsonKey()
  final int jomoaIqamaTime;
  @override
  @JsonKey()
  final bool showPreAdhanBeep;
// منبه قبل الأذان
// ====== Azkar Toggles ======
  @override
  @JsonKey()
  final bool enableSabahAzkar;
  @override
  @JsonKey()
  final bool enableMasaaAzkar;
  @override
  @JsonKey()
  final bool autoAzkarByTime;
// الظهور التلقائي حسب أوقات الصباح والمساء
  @override
  @JsonKey()
  final String manualAzkarType;
// SABAH, MASAA, BOTH (في حال التفعيل اليدوي)
  @override
  @JsonKey()
  final bool azkarOnlyScreenEnabled;
// عرض أذكار الصباح/المساء فقط
  @override
  @JsonKey()
  final bool azkarOnlyScreenUseGlass;
// خلفية زجاجية لشاشة الأذكار فقط
  @override
  final String? azkarOnlyScreenCustomBgPath;
// صورة مخصصة لشاشة الأذكار فقط
  @override
  @JsonKey()
  final bool enablePostPrayerAzkar;
// ====== Post-Prayer Azkar (Phase 6) ======
  @override
  @JsonKey()
  final bool postPrayerAzkarEnabled;
  @override
  @JsonKey()
  final bool postPrayerAzkarRepeatOnce;
  @override
  @JsonKey()
  final bool postPrayerShowSingleSlide5Min;
  @override
  @JsonKey()
  final bool postPrayerWhiteBackground;
  @override
  @JsonKey()
  final bool enableSabahAfterFajr;
  @override
  @JsonKey()
  final bool enableMasaaAfterAsr;
  @override
  @JsonKey()
  final bool enableMasaaAfterMaghrib;
  @override
  @JsonKey()
  final bool enableMasaaAfterIsha;
// ====== Slides & Messages (Phase 6) ======
  @override
  @JsonKey()
  final bool slidesEnabled;
  @override
  @JsonKey()
  final bool slidesShuffle;
  @override
  @JsonKey()
  final int slideDurationSeconds;
  @override
  @JsonKey()
  final int mainScreenDurationSeconds;
  @override
  @JsonKey()
  final String slidesShowMode;
// AFTER_PRAYER, MANUAL
  final List<Map<String, dynamic>> _slidesList;
// AFTER_PRAYER, MANUAL
  @override
  @JsonKey()
  List<Map<String, dynamic>> get slidesList {
    if (_slidesList is EqualUnmodifiableListView) return _slidesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_slidesList);
  }

// ====== Weather & GPS (Phase 6) ======
  @override
  @JsonKey()
  final bool weatherEnabled;
  @override
  @JsonKey()
  final bool weatherShowNearPrayerTimes;
  @override
  @JsonKey()
  final String locationMode;
// AUTO or MANUAL
  @override
  @JsonKey()
  final double gpsLat;
  @override
  @JsonKey()
  final double gpsLng;
  @override
  @JsonKey()
  final bool weatherAlertsEnabled;
// تنبيهات الطقس الصوتية
// ====== Orientation (Phase 8) ======
  @override
  @JsonKey()
  final String appOrientation;
// AUTO, PORTRAIT, LANDSCAPE
// ====== Custom Excel Import Settings ======
  @override
  @JsonKey()
  final bool useCustomPrayerTimes;
  @override
  @JsonKey()
  final String customTimesCountry;
  @override
  @JsonKey()
  final String customTimesCity;
  @override
  @JsonKey()
  final String customTimesDuration;
// AUTO, YEAR, MONTH_6, MONTH_2, MONTH_1, WEEK_2, WEEK_1, DAY_2, DAY_1
  @override
  final String? customTimesFilePath;
// ====== Update Settings ======
  @override
  @JsonKey()
  final String? selectedCustomBgPath;
  @override
  @JsonKey()
  final bool showUpdateInSettings;
  @override
  @JsonKey()
  final String appTheme;
// EMERALD, PURE_GLASS
  @override
  @JsonKey()
  final String pureGlassColor1;
  @override
  @JsonKey()
  final String pureGlassColor2;
  @override
  @JsonKey()
  final String pureGlassColor3;
  @override
  @JsonKey()
  final String pureGlassTextColor;
  @override
  @JsonKey()
  final bool glassShineEnabled;
// تفعيل/إيقاف البريق الزجاجي
  @override
  @JsonKey()
  final String navbarPosition;
// FULL, CENTER, SIDE
// ====== Azkar Scheduling ======
  @override
  @JsonKey()
  final String sabahStartTime;
  @override
  @JsonKey()
  final String sabahEndTime;
  @override
  @JsonKey()
  final String masaaStartTime;
  @override
  @JsonKey()
  final String masaaEndTime;

  @override
  String toString() {
    return 'AppSettings(adminUsername: $adminUsername, country: $country, city: $city, languageCode: $languageCode, hasSelectedLanguage: $hasSelectedLanguage, ayatsLanguageCode: $ayatsLanguageCode, showHijriDate: $showHijriDate, hijriOffsetDays: $hijriOffsetDays, is24HourFormat: $is24HourFormat, showSecondsClock: $showSecondsClock, playAdhanSound: $playAdhanSound, isAutoLocation: $isAutoLocation, mosqueName: $mosqueName, mosqueIconPath: $mosqueIconPath, customFlagPath: $customFlagPath, themeMode: $themeMode, showMarqueeTicker: $showMarqueeTicker, ramadanCountdownInjectEnabled: $ramadanCountdownInjectEnabled, tickerItems: $tickerItems, showAdminMessages: $showAdminMessages, showBlackScreenDuringPrayer: $showBlackScreenDuringPrayer, blackScreenDurationMinutes: $blackScreenDurationMinutes, dimPastPrayers: $dimPastPrayers, fontFamily: $fontFamily, clockOffsetMinutes: $clockOffsetMinutes, showCountryFlag: $showCountryFlag, padTimesWithZero: $padTimesWithZero, showFullClock: $showFullClock, enableAnalogGlassClock: $enableAnalogGlassClock, blackClockModeEnabled: $blackClockModeEnabled, blackClockModeUseGlass: $blackClockModeUseGlass, blackClockModeCustomBgPath: $blackClockModeCustomBgPath, analogClockStyle: $analogClockStyle, showAnalogClockDateFrame: $showAnalogClockDateFrame, showAnalogClockNumbers: $showAnalogClockNumbers, showNightPrayers: $showNightPrayers, centerPrayerNamesLandscape: $centerPrayerNamesLandscape, enlargePrayerNamesLandscape: $enlargePrayerNamesLandscape, showIqamaWithClock: $showIqamaWithClock, showCountdown: $showCountdown, enlargeCountdown: $enlargeCountdown, showFullscreenCountdownAtThreshold: $showFullscreenCountdownAtThreshold, useArabicIndicDigits: $useArabicIndicDigits, hideIqamaTime: $hideIqamaTime, centerPrayerNamesPortrait: $centerPrayerNamesPortrait, centerNameWithTimesOnSides: $centerNameWithTimesOnSides, showPrayerNameInOtherLanguage: $showPrayerNameInOtherLanguage, prayerNameFontSize: $prayerNameFontSize, prayerTimeFontSize: $prayerTimeFontSize, iqamaTimeFontSize: $iqamaTimeFontSize, showAdhanScreen: $showAdhanScreen, showIqamaScreen: $showIqamaScreen, swapDateAndMosqueLandscape: $swapDateAndMosqueLandscape, showInternetStatus: $showInternetStatus, showBackgroundShadingBehindTimes: $showBackgroundShadingBehindTimes, useTranslucentScreens: $useTranslucentScreens, countdownGreenLast90s: $countdownGreenLast90s, enlargeNextPrayerCountdown: $enlargeNextPrayerCountdown, playVoiceAlertBeforeIqama: $playVoiceAlertBeforeIqama, voiceAlertMessage: $voiceAlertMessage, showHadithBeforeIqama: $showHadithBeforeIqama, isGlobalAudioMuted: $isGlobalAudioMuted, isAzanAudioMuted: $isAzanAudioMuted, khushooModeEnabled: $khushooModeEnabled, khushooModeDuration: $khushooModeDuration, isKhushooManualActive: $isKhushooManualActive, eidAlFitrTime: $eidAlFitrTime, eidAlAdhaTime: $eidAlAdhaTime, useMp3ForAdhan: $useMp3ForAdhan, useShortAdhan: $useShortAdhan, useShortIqama: $useShortIqama, azkarFontFamily: $azkarFontFamily, clockFontFamily: $clockFontFamily, timesFontFamily: $timesFontFamily, textFontFamily: $textFontFamily, ramadanIshaPlus30Enabled: $ramadanIshaPlus30Enabled, summerPlus1HourEnabled: $summerPlus1HourEnabled, manualPlus1HourAllEnabled: $manualPlus1HourAllEnabled, manualMinus1HourAllEnabled: $manualMinus1HourAllEnabled, prayerOffsetFajr: $prayerOffsetFajr, prayerOffsetSunrise: $prayerOffsetSunrise, prayerOffsetDhuhr: $prayerOffsetDhuhr, prayerOffsetAsr: $prayerOffsetAsr, prayerOffsetMaghrib: $prayerOffsetMaghrib, prayerOffsetIsha: $prayerOffsetIsha, timeOffsetMasha: $timeOffsetMasha, customAdhanSounds: $customAdhanSounds, defaultAdhanSoundId: $defaultAdhanSoundId, prayerAdhanSoundIds: $prayerAdhanSoundIds, isManualTimeEnabled: $isManualTimeEnabled, manualTimeValue: $manualTimeValue, iqamaIsFixed: $iqamaIsFixed, iqamaFixedTimes: $iqamaFixedTimes, jumuaKhutbahAutoMode: $jumuaKhutbahAutoMode, jumuaKhutbahManualTime: $jumuaKhutbahManualTime, showJumuaInLandscape: $showJumuaInLandscape, enableJumuaAdhanSound: $enableJumuaAdhanSound, fajrPreAdhanAlertMinutes: $fajrPreAdhanAlertMinutes, dhuhrFromAsrMinusMinutesEnabled: $dhuhrFromAsrMinusMinutesEnabled, dhuhrEqualsAsrMinusMinutes: $dhuhrEqualsAsrMinusMinutes, bgMode: $bgMode, bgFitMode: $bgFitMode, selectedBackgroundId: $selectedBackgroundId, backgroundPerPrayer: $backgroundPerPrayer, backgroundPerWeekday: $backgroundPerWeekday, randomBackgroundPool: $randomBackgroundPool, fajrIqamaTime: $fajrIqamaTime, dhuhrIqamaTime: $dhuhrIqamaTime, asrIqamaTime: $asrIqamaTime, maghribIqamaTime: $maghribIqamaTime, ishaIqamaTime: $ishaIqamaTime, jomoaIqamaTime: $jomoaIqamaTime, showPreAdhanBeep: $showPreAdhanBeep, enableSabahAzkar: $enableSabahAzkar, enableMasaaAzkar: $enableMasaaAzkar, autoAzkarByTime: $autoAzkarByTime, manualAzkarType: $manualAzkarType, azkarOnlyScreenEnabled: $azkarOnlyScreenEnabled, azkarOnlyScreenUseGlass: $azkarOnlyScreenUseGlass, azkarOnlyScreenCustomBgPath: $azkarOnlyScreenCustomBgPath, enablePostPrayerAzkar: $enablePostPrayerAzkar, postPrayerAzkarEnabled: $postPrayerAzkarEnabled, postPrayerAzkarRepeatOnce: $postPrayerAzkarRepeatOnce, postPrayerShowSingleSlide5Min: $postPrayerShowSingleSlide5Min, postPrayerWhiteBackground: $postPrayerWhiteBackground, enableSabahAfterFajr: $enableSabahAfterFajr, enableMasaaAfterAsr: $enableMasaaAfterAsr, enableMasaaAfterMaghrib: $enableMasaaAfterMaghrib, enableMasaaAfterIsha: $enableMasaaAfterIsha, slidesEnabled: $slidesEnabled, slidesShuffle: $slidesShuffle, slideDurationSeconds: $slideDurationSeconds, mainScreenDurationSeconds: $mainScreenDurationSeconds, slidesShowMode: $slidesShowMode, slidesList: $slidesList, weatherEnabled: $weatherEnabled, weatherShowNearPrayerTimes: $weatherShowNearPrayerTimes, locationMode: $locationMode, gpsLat: $gpsLat, gpsLng: $gpsLng, weatherAlertsEnabled: $weatherAlertsEnabled, appOrientation: $appOrientation, useCustomPrayerTimes: $useCustomPrayerTimes, customTimesCountry: $customTimesCountry, customTimesCity: $customTimesCity, customTimesDuration: $customTimesDuration, customTimesFilePath: $customTimesFilePath, selectedCustomBgPath: $selectedCustomBgPath, showUpdateInSettings: $showUpdateInSettings, appTheme: $appTheme, pureGlassColor1: $pureGlassColor1, pureGlassColor2: $pureGlassColor2, pureGlassColor3: $pureGlassColor3, pureGlassTextColor: $pureGlassTextColor, glassShineEnabled: $glassShineEnabled, navbarPosition: $navbarPosition, sabahStartTime: $sabahStartTime, sabahEndTime: $sabahEndTime, masaaStartTime: $masaaStartTime, masaaEndTime: $masaaEndTime)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AppSettingsImpl &&
            (identical(other.adminUsername, adminUsername) ||
                other.adminUsername == adminUsername) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.languageCode, languageCode) ||
                other.languageCode == languageCode) &&
            (identical(other.hasSelectedLanguage, hasSelectedLanguage) ||
                other.hasSelectedLanguage == hasSelectedLanguage) &&
            (identical(other.ayatsLanguageCode, ayatsLanguageCode) ||
                other.ayatsLanguageCode == ayatsLanguageCode) &&
            (identical(other.showHijriDate, showHijriDate) ||
                other.showHijriDate == showHijriDate) &&
            (identical(other.hijriOffsetDays, hijriOffsetDays) ||
                other.hijriOffsetDays == hijriOffsetDays) &&
            (identical(other.is24HourFormat, is24HourFormat) ||
                other.is24HourFormat == is24HourFormat) &&
            (identical(other.showSecondsClock, showSecondsClock) ||
                other.showSecondsClock == showSecondsClock) &&
            (identical(other.playAdhanSound, playAdhanSound) ||
                other.playAdhanSound == playAdhanSound) &&
            (identical(other.isAutoLocation, isAutoLocation) ||
                other.isAutoLocation == isAutoLocation) &&
            (identical(other.mosqueName, mosqueName) ||
                other.mosqueName == mosqueName) &&
            (identical(other.mosqueIconPath, mosqueIconPath) ||
                other.mosqueIconPath == mosqueIconPath) &&
            (identical(other.customFlagPath, customFlagPath) ||
                other.customFlagPath == customFlagPath) &&
            (identical(other.themeMode, themeMode) ||
                other.themeMode == themeMode) &&
            (identical(other.showMarqueeTicker, showMarqueeTicker) ||
                other.showMarqueeTicker == showMarqueeTicker) &&
            (identical(other.ramadanCountdownInjectEnabled, ramadanCountdownInjectEnabled) ||
                other.ramadanCountdownInjectEnabled ==
                    ramadanCountdownInjectEnabled) &&
            const DeepCollectionEquality()
                .equals(other._tickerItems, _tickerItems) &&
            (identical(other.showAdminMessages, showAdminMessages) ||
                other.showAdminMessages == showAdminMessages) &&
            (identical(other.showBlackScreenDuringPrayer, showBlackScreenDuringPrayer) ||
                other.showBlackScreenDuringPrayer ==
                    showBlackScreenDuringPrayer) &&
            (identical(other.blackScreenDurationMinutes, blackScreenDurationMinutes) ||
                other.blackScreenDurationMinutes ==
                    blackScreenDurationMinutes) &&
            (identical(other.dimPastPrayers, dimPastPrayers) ||
                other.dimPastPrayers == dimPastPrayers) &&
            (identical(other.fontFamily, fontFamily) ||
                other.fontFamily == fontFamily) &&
            (identical(other.clockOffsetMinutes, clockOffsetMinutes) ||
                other.clockOffsetMinutes == clockOffsetMinutes) &&
            (identical(other.showCountryFlag, showCountryFlag) ||
                other.showCountryFlag == showCountryFlag) &&
            (identical(other.padTimesWithZero, padTimesWithZero) ||
                other.padTimesWithZero == padTimesWithZero) &&
            (identical(other.showFullClock, showFullClock) ||
                other.showFullClock == showFullClock) &&
            (identical(other.enableAnalogGlassClock, enableAnalogGlassClock) ||
                other.enableAnalogGlassClock == enableAnalogGlassClock) &&
            (identical(other.blackClockModeEnabled, blackClockModeEnabled) ||
                other.blackClockModeEnabled == blackClockModeEnabled) &&
            (identical(other.blackClockModeUseGlass, blackClockModeUseGlass) ||
                other.blackClockModeUseGlass == blackClockModeUseGlass) &&
            (identical(other.blackClockModeCustomBgPath, blackClockModeCustomBgPath) ||
                other.blackClockModeCustomBgPath ==
                    blackClockModeCustomBgPath) &&
            (identical(other.analogClockStyle, analogClockStyle) ||
                other.analogClockStyle == analogClockStyle) &&
            (identical(other.showAnalogClockDateFrame, showAnalogClockDateFrame) || other.showAnalogClockDateFrame == showAnalogClockDateFrame) &&
            (identical(other.showAnalogClockNumbers, showAnalogClockNumbers) || other.showAnalogClockNumbers == showAnalogClockNumbers) &&
            (identical(other.showNightPrayers, showNightPrayers) || other.showNightPrayers == showNightPrayers) &&
            (identical(other.centerPrayerNamesLandscape, centerPrayerNamesLandscape) || other.centerPrayerNamesLandscape == centerPrayerNamesLandscape) &&
            (identical(other.enlargePrayerNamesLandscape, enlargePrayerNamesLandscape) || other.enlargePrayerNamesLandscape == enlargePrayerNamesLandscape) &&
            (identical(other.showIqamaWithClock, showIqamaWithClock) || other.showIqamaWithClock == showIqamaWithClock) &&
            (identical(other.showCountdown, showCountdown) || other.showCountdown == showCountdown) &&
            (identical(other.enlargeCountdown, enlargeCountdown) || other.enlargeCountdown == enlargeCountdown) &&
            (identical(other.showFullscreenCountdownAtThreshold, showFullscreenCountdownAtThreshold) || other.showFullscreenCountdownAtThreshold == showFullscreenCountdownAtThreshold) &&
            (identical(other.useArabicIndicDigits, useArabicIndicDigits) || other.useArabicIndicDigits == useArabicIndicDigits) &&
            (identical(other.hideIqamaTime, hideIqamaTime) || other.hideIqamaTime == hideIqamaTime) &&
            (identical(other.centerPrayerNamesPortrait, centerPrayerNamesPortrait) || other.centerPrayerNamesPortrait == centerPrayerNamesPortrait) &&
            (identical(other.centerNameWithTimesOnSides, centerNameWithTimesOnSides) || other.centerNameWithTimesOnSides == centerNameWithTimesOnSides) &&
            (identical(other.showPrayerNameInOtherLanguage, showPrayerNameInOtherLanguage) || other.showPrayerNameInOtherLanguage == showPrayerNameInOtherLanguage) &&
            (identical(other.prayerNameFontSize, prayerNameFontSize) || other.prayerNameFontSize == prayerNameFontSize) &&
            (identical(other.prayerTimeFontSize, prayerTimeFontSize) || other.prayerTimeFontSize == prayerTimeFontSize) &&
            (identical(other.iqamaTimeFontSize, iqamaTimeFontSize) || other.iqamaTimeFontSize == iqamaTimeFontSize) &&
            (identical(other.showAdhanScreen, showAdhanScreen) || other.showAdhanScreen == showAdhanScreen) &&
            (identical(other.showIqamaScreen, showIqamaScreen) || other.showIqamaScreen == showIqamaScreen) &&
            (identical(other.swapDateAndMosqueLandscape, swapDateAndMosqueLandscape) || other.swapDateAndMosqueLandscape == swapDateAndMosqueLandscape) &&
            (identical(other.showInternetStatus, showInternetStatus) || other.showInternetStatus == showInternetStatus) &&
            (identical(other.showBackgroundShadingBehindTimes, showBackgroundShadingBehindTimes) || other.showBackgroundShadingBehindTimes == showBackgroundShadingBehindTimes) &&
            (identical(other.useTranslucentScreens, useTranslucentScreens) || other.useTranslucentScreens == useTranslucentScreens) &&
            (identical(other.countdownGreenLast90s, countdownGreenLast90s) || other.countdownGreenLast90s == countdownGreenLast90s) &&
            (identical(other.enlargeNextPrayerCountdown, enlargeNextPrayerCountdown) || other.enlargeNextPrayerCountdown == enlargeNextPrayerCountdown) &&
            (identical(other.playVoiceAlertBeforeIqama, playVoiceAlertBeforeIqama) || other.playVoiceAlertBeforeIqama == playVoiceAlertBeforeIqama) &&
            (identical(other.voiceAlertMessage, voiceAlertMessage) || other.voiceAlertMessage == voiceAlertMessage) &&
            (identical(other.showHadithBeforeIqama, showHadithBeforeIqama) || other.showHadithBeforeIqama == showHadithBeforeIqama) &&
            (identical(other.isGlobalAudioMuted, isGlobalAudioMuted) || other.isGlobalAudioMuted == isGlobalAudioMuted) &&
            (identical(other.isAzanAudioMuted, isAzanAudioMuted) || other.isAzanAudioMuted == isAzanAudioMuted) &&
            (identical(other.khushooModeEnabled, khushooModeEnabled) || other.khushooModeEnabled == khushooModeEnabled) &&
            (identical(other.khushooModeDuration, khushooModeDuration) || other.khushooModeDuration == khushooModeDuration) &&
            (identical(other.isKhushooManualActive, isKhushooManualActive) || other.isKhushooManualActive == isKhushooManualActive) &&
            (identical(other.eidAlFitrTime, eidAlFitrTime) || other.eidAlFitrTime == eidAlFitrTime) &&
            (identical(other.eidAlAdhaTime, eidAlAdhaTime) || other.eidAlAdhaTime == eidAlAdhaTime) &&
            (identical(other.useMp3ForAdhan, useMp3ForAdhan) || other.useMp3ForAdhan == useMp3ForAdhan) &&
            (identical(other.useShortAdhan, useShortAdhan) || other.useShortAdhan == useShortAdhan) &&
            (identical(other.useShortIqama, useShortIqama) || other.useShortIqama == useShortIqama) &&
            (identical(other.azkarFontFamily, azkarFontFamily) || other.azkarFontFamily == azkarFontFamily) &&
            (identical(other.clockFontFamily, clockFontFamily) || other.clockFontFamily == clockFontFamily) &&
            (identical(other.timesFontFamily, timesFontFamily) || other.timesFontFamily == timesFontFamily) &&
            (identical(other.textFontFamily, textFontFamily) || other.textFontFamily == textFontFamily) &&
            (identical(other.ramadanIshaPlus30Enabled, ramadanIshaPlus30Enabled) || other.ramadanIshaPlus30Enabled == ramadanIshaPlus30Enabled) &&
            (identical(other.summerPlus1HourEnabled, summerPlus1HourEnabled) || other.summerPlus1HourEnabled == summerPlus1HourEnabled) &&
            (identical(other.manualPlus1HourAllEnabled, manualPlus1HourAllEnabled) || other.manualPlus1HourAllEnabled == manualPlus1HourAllEnabled) &&
            (identical(other.manualMinus1HourAllEnabled, manualMinus1HourAllEnabled) || other.manualMinus1HourAllEnabled == manualMinus1HourAllEnabled) &&
            (identical(other.prayerOffsetFajr, prayerOffsetFajr) || other.prayerOffsetFajr == prayerOffsetFajr) &&
            (identical(other.prayerOffsetSunrise, prayerOffsetSunrise) || other.prayerOffsetSunrise == prayerOffsetSunrise) &&
            (identical(other.prayerOffsetDhuhr, prayerOffsetDhuhr) || other.prayerOffsetDhuhr == prayerOffsetDhuhr) &&
            (identical(other.prayerOffsetAsr, prayerOffsetAsr) || other.prayerOffsetAsr == prayerOffsetAsr) &&
            (identical(other.prayerOffsetMaghrib, prayerOffsetMaghrib) || other.prayerOffsetMaghrib == prayerOffsetMaghrib) &&
            (identical(other.prayerOffsetIsha, prayerOffsetIsha) || other.prayerOffsetIsha == prayerOffsetIsha) &&
            (identical(other.timeOffsetMasha, timeOffsetMasha) || other.timeOffsetMasha == timeOffsetMasha) &&
            const DeepCollectionEquality().equals(other._customAdhanSounds, _customAdhanSounds) &&
            (identical(other.defaultAdhanSoundId, defaultAdhanSoundId) || other.defaultAdhanSoundId == defaultAdhanSoundId) &&
            const DeepCollectionEquality().equals(other._prayerAdhanSoundIds, _prayerAdhanSoundIds) &&
            (identical(other.isManualTimeEnabled, isManualTimeEnabled) || other.isManualTimeEnabled == isManualTimeEnabled) &&
            (identical(other.manualTimeValue, manualTimeValue) || other.manualTimeValue == manualTimeValue) &&
            const DeepCollectionEquality().equals(other._iqamaIsFixed, _iqamaIsFixed) &&
            const DeepCollectionEquality().equals(other._iqamaFixedTimes, _iqamaFixedTimes) &&
            (identical(other.jumuaKhutbahAutoMode, jumuaKhutbahAutoMode) || other.jumuaKhutbahAutoMode == jumuaKhutbahAutoMode) &&
            (identical(other.jumuaKhutbahManualTime, jumuaKhutbahManualTime) || other.jumuaKhutbahManualTime == jumuaKhutbahManualTime) &&
            (identical(other.showJumuaInLandscape, showJumuaInLandscape) || other.showJumuaInLandscape == showJumuaInLandscape) &&
            (identical(other.enableJumuaAdhanSound, enableJumuaAdhanSound) || other.enableJumuaAdhanSound == enableJumuaAdhanSound) &&
            (identical(other.fajrPreAdhanAlertMinutes, fajrPreAdhanAlertMinutes) || other.fajrPreAdhanAlertMinutes == fajrPreAdhanAlertMinutes) &&
            (identical(other.dhuhrFromAsrMinusMinutesEnabled, dhuhrFromAsrMinusMinutesEnabled) || other.dhuhrFromAsrMinusMinutesEnabled == dhuhrFromAsrMinusMinutesEnabled) &&
            (identical(other.dhuhrEqualsAsrMinusMinutes, dhuhrEqualsAsrMinusMinutes) || other.dhuhrEqualsAsrMinusMinutes == dhuhrEqualsAsrMinusMinutes) &&
            (identical(other.bgMode, bgMode) || other.bgMode == bgMode) &&
            (identical(other.bgFitMode, bgFitMode) || other.bgFitMode == bgFitMode) &&
            (identical(other.selectedBackgroundId, selectedBackgroundId) || other.selectedBackgroundId == selectedBackgroundId) &&
            const DeepCollectionEquality().equals(other._backgroundPerPrayer, _backgroundPerPrayer) &&
            const DeepCollectionEquality().equals(other._backgroundPerWeekday, _backgroundPerWeekday) &&
            const DeepCollectionEquality().equals(other._randomBackgroundPool, _randomBackgroundPool) &&
            (identical(other.fajrIqamaTime, fajrIqamaTime) || other.fajrIqamaTime == fajrIqamaTime) &&
            (identical(other.dhuhrIqamaTime, dhuhrIqamaTime) || other.dhuhrIqamaTime == dhuhrIqamaTime) &&
            (identical(other.asrIqamaTime, asrIqamaTime) || other.asrIqamaTime == asrIqamaTime) &&
            (identical(other.maghribIqamaTime, maghribIqamaTime) || other.maghribIqamaTime == maghribIqamaTime) &&
            (identical(other.ishaIqamaTime, ishaIqamaTime) || other.ishaIqamaTime == ishaIqamaTime) &&
            (identical(other.jomoaIqamaTime, jomoaIqamaTime) || other.jomoaIqamaTime == jomoaIqamaTime) &&
            (identical(other.showPreAdhanBeep, showPreAdhanBeep) || other.showPreAdhanBeep == showPreAdhanBeep) &&
            (identical(other.enableSabahAzkar, enableSabahAzkar) || other.enableSabahAzkar == enableSabahAzkar) &&
            (identical(other.enableMasaaAzkar, enableMasaaAzkar) || other.enableMasaaAzkar == enableMasaaAzkar) &&
            (identical(other.autoAzkarByTime, autoAzkarByTime) || other.autoAzkarByTime == autoAzkarByTime) &&
            (identical(other.manualAzkarType, manualAzkarType) || other.manualAzkarType == manualAzkarType) &&
            (identical(other.azkarOnlyScreenEnabled, azkarOnlyScreenEnabled) || other.azkarOnlyScreenEnabled == azkarOnlyScreenEnabled) &&
            (identical(other.azkarOnlyScreenUseGlass, azkarOnlyScreenUseGlass) || other.azkarOnlyScreenUseGlass == azkarOnlyScreenUseGlass) &&
            (identical(other.azkarOnlyScreenCustomBgPath, azkarOnlyScreenCustomBgPath) || other.azkarOnlyScreenCustomBgPath == azkarOnlyScreenCustomBgPath) &&
            (identical(other.enablePostPrayerAzkar, enablePostPrayerAzkar) || other.enablePostPrayerAzkar == enablePostPrayerAzkar) &&
            (identical(other.postPrayerAzkarEnabled, postPrayerAzkarEnabled) || other.postPrayerAzkarEnabled == postPrayerAzkarEnabled) &&
            (identical(other.postPrayerAzkarRepeatOnce, postPrayerAzkarRepeatOnce) || other.postPrayerAzkarRepeatOnce == postPrayerAzkarRepeatOnce) &&
            (identical(other.postPrayerShowSingleSlide5Min, postPrayerShowSingleSlide5Min) || other.postPrayerShowSingleSlide5Min == postPrayerShowSingleSlide5Min) &&
            (identical(other.postPrayerWhiteBackground, postPrayerWhiteBackground) || other.postPrayerWhiteBackground == postPrayerWhiteBackground) &&
            (identical(other.enableSabahAfterFajr, enableSabahAfterFajr) || other.enableSabahAfterFajr == enableSabahAfterFajr) &&
            (identical(other.enableMasaaAfterAsr, enableMasaaAfterAsr) || other.enableMasaaAfterAsr == enableMasaaAfterAsr) &&
            (identical(other.enableMasaaAfterMaghrib, enableMasaaAfterMaghrib) || other.enableMasaaAfterMaghrib == enableMasaaAfterMaghrib) &&
            (identical(other.enableMasaaAfterIsha, enableMasaaAfterIsha) || other.enableMasaaAfterIsha == enableMasaaAfterIsha) &&
            (identical(other.slidesEnabled, slidesEnabled) || other.slidesEnabled == slidesEnabled) &&
            (identical(other.slidesShuffle, slidesShuffle) || other.slidesShuffle == slidesShuffle) &&
            (identical(other.slideDurationSeconds, slideDurationSeconds) || other.slideDurationSeconds == slideDurationSeconds) &&
            (identical(other.mainScreenDurationSeconds, mainScreenDurationSeconds) || other.mainScreenDurationSeconds == mainScreenDurationSeconds) &&
            (identical(other.slidesShowMode, slidesShowMode) || other.slidesShowMode == slidesShowMode) &&
            const DeepCollectionEquality().equals(other._slidesList, _slidesList) &&
            (identical(other.weatherEnabled, weatherEnabled) || other.weatherEnabled == weatherEnabled) &&
            (identical(other.weatherShowNearPrayerTimes, weatherShowNearPrayerTimes) || other.weatherShowNearPrayerTimes == weatherShowNearPrayerTimes) &&
            (identical(other.locationMode, locationMode) || other.locationMode == locationMode) &&
            (identical(other.gpsLat, gpsLat) || other.gpsLat == gpsLat) &&
            (identical(other.gpsLng, gpsLng) || other.gpsLng == gpsLng) &&
            (identical(other.weatherAlertsEnabled, weatherAlertsEnabled) || other.weatherAlertsEnabled == weatherAlertsEnabled) &&
            (identical(other.appOrientation, appOrientation) || other.appOrientation == appOrientation) &&
            (identical(other.useCustomPrayerTimes, useCustomPrayerTimes) || other.useCustomPrayerTimes == useCustomPrayerTimes) &&
            (identical(other.customTimesCountry, customTimesCountry) || other.customTimesCountry == customTimesCountry) &&
            (identical(other.customTimesCity, customTimesCity) || other.customTimesCity == customTimesCity) &&
            (identical(other.customTimesDuration, customTimesDuration) || other.customTimesDuration == customTimesDuration) &&
            (identical(other.customTimesFilePath, customTimesFilePath) || other.customTimesFilePath == customTimesFilePath) &&
            (identical(other.selectedCustomBgPath, selectedCustomBgPath) || other.selectedCustomBgPath == selectedCustomBgPath) &&
            (identical(other.showUpdateInSettings, showUpdateInSettings) || other.showUpdateInSettings == showUpdateInSettings) &&
            (identical(other.appTheme, appTheme) || other.appTheme == appTheme) &&
            (identical(other.pureGlassColor1, pureGlassColor1) || other.pureGlassColor1 == pureGlassColor1) &&
            (identical(other.pureGlassColor2, pureGlassColor2) || other.pureGlassColor2 == pureGlassColor2) &&
            (identical(other.pureGlassColor3, pureGlassColor3) || other.pureGlassColor3 == pureGlassColor3) &&
            (identical(other.pureGlassTextColor, pureGlassTextColor) || other.pureGlassTextColor == pureGlassTextColor) &&
            (identical(other.glassShineEnabled, glassShineEnabled) || other.glassShineEnabled == glassShineEnabled) &&
            (identical(other.navbarPosition, navbarPosition) || other.navbarPosition == navbarPosition) &&
            (identical(other.sabahStartTime, sabahStartTime) || other.sabahStartTime == sabahStartTime) &&
            (identical(other.sabahEndTime, sabahEndTime) || other.sabahEndTime == sabahEndTime) &&
            (identical(other.masaaStartTime, masaaStartTime) || other.masaaStartTime == masaaStartTime) &&
            (identical(other.masaaEndTime, masaaEndTime) || other.masaaEndTime == masaaEndTime));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        adminUsername,
        country,
        city,
        languageCode,
        hasSelectedLanguage,
        ayatsLanguageCode,
        showHijriDate,
        hijriOffsetDays,
        is24HourFormat,
        showSecondsClock,
        playAdhanSound,
        isAutoLocation,
        mosqueName,
        mosqueIconPath,
        customFlagPath,
        themeMode,
        showMarqueeTicker,
        ramadanCountdownInjectEnabled,
        const DeepCollectionEquality().hash(_tickerItems),
        showAdminMessages,
        showBlackScreenDuringPrayer,
        blackScreenDurationMinutes,
        dimPastPrayers,
        fontFamily,
        clockOffsetMinutes,
        showCountryFlag,
        padTimesWithZero,
        showFullClock,
        enableAnalogGlassClock,
        blackClockModeEnabled,
        blackClockModeUseGlass,
        blackClockModeCustomBgPath,
        analogClockStyle,
        showAnalogClockDateFrame,
        showAnalogClockNumbers,
        showNightPrayers,
        centerPrayerNamesLandscape,
        enlargePrayerNamesLandscape,
        showIqamaWithClock,
        showCountdown,
        enlargeCountdown,
        showFullscreenCountdownAtThreshold,
        useArabicIndicDigits,
        hideIqamaTime,
        centerPrayerNamesPortrait,
        centerNameWithTimesOnSides,
        showPrayerNameInOtherLanguage,
        prayerNameFontSize,
        prayerTimeFontSize,
        iqamaTimeFontSize,
        showAdhanScreen,
        showIqamaScreen,
        swapDateAndMosqueLandscape,
        showInternetStatus,
        showBackgroundShadingBehindTimes,
        useTranslucentScreens,
        countdownGreenLast90s,
        enlargeNextPrayerCountdown,
        playVoiceAlertBeforeIqama,
        voiceAlertMessage,
        showHadithBeforeIqama,
        isGlobalAudioMuted,
        isAzanAudioMuted,
        khushooModeEnabled,
        khushooModeDuration,
        isKhushooManualActive,
        eidAlFitrTime,
        eidAlAdhaTime,
        useMp3ForAdhan,
        useShortAdhan,
        useShortIqama,
        azkarFontFamily,
        clockFontFamily,
        timesFontFamily,
        textFontFamily,
        ramadanIshaPlus30Enabled,
        summerPlus1HourEnabled,
        manualPlus1HourAllEnabled,
        manualMinus1HourAllEnabled,
        prayerOffsetFajr,
        prayerOffsetSunrise,
        prayerOffsetDhuhr,
        prayerOffsetAsr,
        prayerOffsetMaghrib,
        prayerOffsetIsha,
        timeOffsetMasha,
        const DeepCollectionEquality().hash(_customAdhanSounds),
        defaultAdhanSoundId,
        const DeepCollectionEquality().hash(_prayerAdhanSoundIds),
        isManualTimeEnabled,
        manualTimeValue,
        const DeepCollectionEquality().hash(_iqamaIsFixed),
        const DeepCollectionEquality().hash(_iqamaFixedTimes),
        jumuaKhutbahAutoMode,
        jumuaKhutbahManualTime,
        showJumuaInLandscape,
        enableJumuaAdhanSound,
        fajrPreAdhanAlertMinutes,
        dhuhrFromAsrMinusMinutesEnabled,
        dhuhrEqualsAsrMinusMinutes,
        bgMode,
        bgFitMode,
        selectedBackgroundId,
        const DeepCollectionEquality().hash(_backgroundPerPrayer),
        const DeepCollectionEquality().hash(_backgroundPerWeekday),
        const DeepCollectionEquality().hash(_randomBackgroundPool),
        fajrIqamaTime,
        dhuhrIqamaTime,
        asrIqamaTime,
        maghribIqamaTime,
        ishaIqamaTime,
        jomoaIqamaTime,
        showPreAdhanBeep,
        enableSabahAzkar,
        enableMasaaAzkar,
        autoAzkarByTime,
        manualAzkarType,
        azkarOnlyScreenEnabled,
        azkarOnlyScreenUseGlass,
        azkarOnlyScreenCustomBgPath,
        enablePostPrayerAzkar,
        postPrayerAzkarEnabled,
        postPrayerAzkarRepeatOnce,
        postPrayerShowSingleSlide5Min,
        postPrayerWhiteBackground,
        enableSabahAfterFajr,
        enableMasaaAfterAsr,
        enableMasaaAfterMaghrib,
        enableMasaaAfterIsha,
        slidesEnabled,
        slidesShuffle,
        slideDurationSeconds,
        mainScreenDurationSeconds,
        slidesShowMode,
        const DeepCollectionEquality().hash(_slidesList),
        weatherEnabled,
        weatherShowNearPrayerTimes,
        locationMode,
        gpsLat,
        gpsLng,
        weatherAlertsEnabled,
        appOrientation,
        useCustomPrayerTimes,
        customTimesCountry,
        customTimesCity,
        customTimesDuration,
        customTimesFilePath,
        selectedCustomBgPath,
        showUpdateInSettings,
        appTheme,
        pureGlassColor1,
        pureGlassColor2,
        pureGlassColor3,
        pureGlassTextColor,
        glassShineEnabled,
        navbarPosition,
        sabahStartTime,
        sabahEndTime,
        masaaStartTime,
        masaaEndTime
      ]);

  /// Create a copy of AppSettings
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AppSettingsImplCopyWith<_$AppSettingsImpl> get copyWith =>
      __$$AppSettingsImplCopyWithImpl<_$AppSettingsImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AppSettingsImplToJson(
      this,
    );
  }
}

abstract class _AppSettings implements AppSettings {
  const factory _AppSettings(
      {final String adminUsername,
      final String country,
      final String city,
      final String languageCode,
      final bool hasSelectedLanguage,
      final String ayatsLanguageCode,
      final bool showHijriDate,
      final int hijriOffsetDays,
      final bool is24HourFormat,
      final bool showSecondsClock,
      final bool playAdhanSound,
      final bool isAutoLocation,
      final String mosqueName,
      final String? mosqueIconPath,
      final String? customFlagPath,
      final String themeMode,
      final bool showMarqueeTicker,
      final bool ramadanCountdownInjectEnabled,
      final List<TickerItem> tickerItems,
      final bool showAdminMessages,
      final bool showBlackScreenDuringPrayer,
      final int blackScreenDurationMinutes,
      final bool dimPastPrayers,
      final String fontFamily,
      final int clockOffsetMinutes,
      final bool showCountryFlag,
      final bool padTimesWithZero,
      final bool showFullClock,
      final bool enableAnalogGlassClock,
      final bool blackClockModeEnabled,
      final bool blackClockModeUseGlass,
      final String? blackClockModeCustomBgPath,
      final String analogClockStyle,
      final bool showAnalogClockDateFrame,
      final bool showAnalogClockNumbers,
      final bool showNightPrayers,
      final bool centerPrayerNamesLandscape,
      final bool enlargePrayerNamesLandscape,
      final bool showIqamaWithClock,
      final bool showCountdown,
      final bool enlargeCountdown,
      final bool showFullscreenCountdownAtThreshold,
      final bool useArabicIndicDigits,
      final bool hideIqamaTime,
      final bool centerPrayerNamesPortrait,
      final bool centerNameWithTimesOnSides,
      final bool showPrayerNameInOtherLanguage,
      final double prayerNameFontSize,
      final double prayerTimeFontSize,
      final double iqamaTimeFontSize,
      final bool showAdhanScreen,
      final bool showIqamaScreen,
      final bool swapDateAndMosqueLandscape,
      final bool showInternetStatus,
      final bool showBackgroundShadingBehindTimes,
      final bool useTranslucentScreens,
      final bool countdownGreenLast90s,
      final bool enlargeNextPrayerCountdown,
      final bool playVoiceAlertBeforeIqama,
      final String voiceAlertMessage,
      final bool showHadithBeforeIqama,
      final bool isGlobalAudioMuted,
      final bool isAzanAudioMuted,
      final bool khushooModeEnabled,
      final int khushooModeDuration,
      final bool isKhushooManualActive,
      final String eidAlFitrTime,
      final String eidAlAdhaTime,
      final bool useMp3ForAdhan,
      final bool useShortAdhan,
      final bool useShortIqama,
      final String azkarFontFamily,
      final String clockFontFamily,
      final String timesFontFamily,
      final String textFontFamily,
      final bool ramadanIshaPlus30Enabled,
      final bool summerPlus1HourEnabled,
      final bool manualPlus1HourAllEnabled,
      final bool manualMinus1HourAllEnabled,
      final int prayerOffsetFajr,
      final int prayerOffsetSunrise,
      final int prayerOffsetDhuhr,
      final int prayerOffsetAsr,
      final int prayerOffsetMaghrib,
      final int prayerOffsetIsha,
      final String timeOffsetMasha,
      final List<AdhanSound> customAdhanSounds,
      final String? defaultAdhanSoundId,
      final Map<String, String> prayerAdhanSoundIds,
      final bool isManualTimeEnabled,
      final String? manualTimeValue,
      final Map<String, bool> iqamaIsFixed,
      final Map<String, String> iqamaFixedTimes,
      final bool jumuaKhutbahAutoMode,
      final String jumuaKhutbahManualTime,
      final bool showJumuaInLandscape,
      final bool enableJumuaAdhanSound,
      final int fajrPreAdhanAlertMinutes,
      final bool dhuhrFromAsrMinusMinutesEnabled,
      final int dhuhrEqualsAsrMinusMinutes,
      final String bgMode,
      final String bgFitMode,
      final int selectedBackgroundId,
      final Map<String, int> backgroundPerPrayer,
      final Map<String, int> backgroundPerWeekday,
      final List<int> randomBackgroundPool,
      final int fajrIqamaTime,
      final int dhuhrIqamaTime,
      final int asrIqamaTime,
      final int maghribIqamaTime,
      final int ishaIqamaTime,
      final int jomoaIqamaTime,
      final bool showPreAdhanBeep,
      final bool enableSabahAzkar,
      final bool enableMasaaAzkar,
      final bool autoAzkarByTime,
      final String manualAzkarType,
      final bool azkarOnlyScreenEnabled,
      final bool azkarOnlyScreenUseGlass,
      final String? azkarOnlyScreenCustomBgPath,
      final bool enablePostPrayerAzkar,
      final bool postPrayerAzkarEnabled,
      final bool postPrayerAzkarRepeatOnce,
      final bool postPrayerShowSingleSlide5Min,
      final bool postPrayerWhiteBackground,
      final bool enableSabahAfterFajr,
      final bool enableMasaaAfterAsr,
      final bool enableMasaaAfterMaghrib,
      final bool enableMasaaAfterIsha,
      final bool slidesEnabled,
      final bool slidesShuffle,
      final int slideDurationSeconds,
      final int mainScreenDurationSeconds,
      final String slidesShowMode,
      final List<Map<String, dynamic>> slidesList,
      final bool weatherEnabled,
      final bool weatherShowNearPrayerTimes,
      final String locationMode,
      final double gpsLat,
      final double gpsLng,
      final bool weatherAlertsEnabled,
      final String appOrientation,
      final bool useCustomPrayerTimes,
      final String customTimesCountry,
      final String customTimesCity,
      final String customTimesDuration,
      final String? customTimesFilePath,
      final String? selectedCustomBgPath,
      final bool showUpdateInSettings,
      final String appTheme,
      final String pureGlassColor1,
      final String pureGlassColor2,
      final String pureGlassColor3,
      final String pureGlassTextColor,
      final bool glassShineEnabled,
      final String navbarPosition,
      final String sabahStartTime,
      final String sabahEndTime,
      final String masaaStartTime,
      final String masaaEndTime}) = _$AppSettingsImpl;

  factory _AppSettings.fromJson(Map<String, dynamic> json) =
      _$AppSettingsImpl.fromJson;

// ====== General Settings ======
  @override
  String get adminUsername; // اسم المستخدم المحفوظ
  @override
  String get country;
  @override
  String get city;
  @override
  String get languageCode;
  @override
  bool get hasSelectedLanguage; // هل تم اختيار اللغة من قبل المستخدم
  @override
  String get ayatsLanguageCode; // لغة ترجمة الآيات
  @override
  bool get showHijriDate;
  @override
  int get hijriOffsetDays; // ± أيام للهجري
  @override
  bool get is24HourFormat;
  @override
  bool get showSecondsClock; // إظهار الثواني بالساعة
  @override
  bool get playAdhanSound;
  @override
  bool get isAutoLocation; // GPS Location
  @override
  String get mosqueName;
  @override
  String? get mosqueIconPath;
  @override
  String? get customFlagPath; // ====== UI & Display ======
  @override
  String get themeMode; // SYSTEM, LIGHT, DARK
  @override
  bool get showMarqueeTicker;
  @override
  bool get ramadanCountdownInjectEnabled;
  @override
  List<TickerItem> get tickerItems;
  @override
  bool get showAdminMessages; // إعلانات المسجد
  @override
  bool get showBlackScreenDuringPrayer; // الشاشة السوداء وقت الصلاة
  @override
  int get blackScreenDurationMinutes; // مدة الصلاة قبل الرجوع
  @override
  bool get dimPastPrayers; // تخفيت الصلوات المصلية
  @override
  String get fontFamily; // ====== FULL SCREENSHOT SETTINGS ======
// A) General Settings
  @override
  int get clockOffsetMinutes; // ضبط الساعة الرئيسية
// B) Display/Identity Options
  @override
  bool get showCountryFlag;
  @override
  bool get padTimesWithZero; // إضافة صفر للأوقات e.g. 04:35
  @override
  bool get showFullClock; // عرض الساعة 00:00:00
  @override
  bool get enableAnalogGlassClock; // تفعيل الساعة التناظرية في الثيم الزجاجي
  @override
  bool get blackClockModeEnabled; // شاشة المواقيت سوداء مع ساعة في المنتصف
  @override
  bool get blackClockModeUseGlass; // خلفية زجاجية لشاشة الساعة الخاصة
  @override
  String? get blackClockModeCustomBgPath; // صورة مخصصة لشاشة الساعة الخاصة
  @override
  String get analogClockStyle; // GLASS, GOLDEN
  @override
  bool
      get showAnalogClockDateFrame; // إظهار إطار التاريخ بجانب الساعة (الطولي/الأفقي)
  @override
  bool
      get showAnalogClockNumbers; // إظهار أرقام الساعة التناظرية (عام لكل الساعات)
  @override
  bool get showNightPrayers; // منتصف وثلث الليل
// C) Prayers List Options
  @override
  bool get centerPrayerNamesLandscape;
  @override
  bool get enlargePrayerNamesLandscape;
  @override
  bool get showIqamaWithClock;
  @override
  bool get showCountdown;
  @override
  bool get enlargeCountdown;
  @override
  bool get showFullscreenCountdownAtThreshold;
  @override
  bool get useArabicIndicDigits; // الأرقام العربية
  @override
  bool get hideIqamaTime;
  @override
  bool get centerPrayerNamesPortrait;
  @override
  bool
      get centerNameWithTimesOnSides; // توسيط اسم الصلاة، الأذان يمين والإقامة يسار
  @override
  bool get showPrayerNameInOtherLanguage; // ====== Fonts / Sizes Options ======
  @override
  double get prayerNameFontSize;
  @override
  double get prayerTimeFontSize;
  @override
  double get iqamaTimeFontSize; // D) Adhan/Iqama Screens
  @override
  bool get showAdhanScreen;
  @override
  bool get showIqamaScreen;
  @override
  bool get swapDateAndMosqueLandscape;
  @override
  bool get showInternetStatus;
  @override
  bool get showBackgroundShadingBehindTimes;
  @override
  bool get useTranslucentScreens; // شاشات شبه شفافة
  @override
  bool get countdownGreenLast90s;
  @override
  bool get enlargeNextPrayerCountdown; // E) Audio/Visual Alerts
  @override
  bool get playVoiceAlertBeforeIqama;
  @override
  String get voiceAlertMessage;
  @override
  bool
      get showHadithBeforeIqama; // ====== Khushoo Program (Mute & Black Screen) ======
  @override
  bool get isGlobalAudioMuted;
  @override
  bool get isAzanAudioMuted;
  @override
  bool get khushooModeEnabled; // تفعيل الشاشة السوداء تلقائيا بعد الأذان
  @override
  int get khushooModeDuration; // مدة الشاشة السوداء بالدقائق
  @override
  bool get isKhushooManualActive; // تفعيل يدوي للشاشة السوداء
// F) Eid Times
  @override
  String get eidAlFitrTime;
  @override
  String get eidAlAdhaTime; // G) MP3 Audio
  @override
  bool get useMp3ForAdhan;
  @override
  bool get useShortAdhan;
  @override
  bool get useShortIqama; // H) Specific Fonts
  @override
  String get azkarFontFamily;
  @override
  String get clockFontFamily;
  @override
  String get timesFontFamily;
  @override
  String
      get textFontFamily; // ====== Advanced Time Adjustments (Phase 5) ======
  @override
  bool get ramadanIshaPlus30Enabled;
  @override
  bool get summerPlus1HourEnabled;
  @override
  bool get manualPlus1HourAllEnabled;
  @override
  bool get manualMinus1HourAllEnabled;
  @override
  int get prayerOffsetFajr;
  @override
  int get prayerOffsetSunrise;
  @override
  int get prayerOffsetDhuhr;
  @override
  int get prayerOffsetAsr;
  @override
  int get prayerOffsetMaghrib;
  @override
  int get prayerOffsetIsha;
  @override
  String get timeOffsetMasha; // ====== Custom Adhan Sounds ======
  @override
  List<AdhanSound> get customAdhanSounds;
  @override
  String? get defaultAdhanSoundId; // null = built-in default
  @override
  Map<String, String> get prayerAdhanSoundIds; // e.g. "fajr" -> "uuid"
// ====== Manual Time Management ======
  @override
  bool get isManualTimeEnabled; // true if user picks time manually
  @override
  String?
      get manualTimeValue; // The user-picked time in "HH:mm" format if isManualTimeEnabled is true
// ====== Fixed Iqama System (Phase 5) ======
  @override
  Map<String, bool> get iqamaIsFixed; // e.g. {'fajr': true}
  @override
  Map<String, String> get iqamaFixedTimes; // e.g. {'fajr': '05:30'}
// ====== Jumua Settings (Phase 5) ======
  @override
  bool get jumuaKhutbahAutoMode;
  @override
  String get jumuaKhutbahManualTime;
  @override
  bool get showJumuaInLandscape;
  @override
  bool
      get enableJumuaAdhanSound; // ====== Advanced Alerts & Dhuhr Calculation (Phase 5) ======
  @override
  int get fajrPreAdhanAlertMinutes;
  @override
  bool get dhuhrFromAsrMinusMinutesEnabled;
  @override
  int get dhuhrEqualsAsrMinusMinutes; // ====== Background System (Phase 5) ======
  @override
  String get bgMode; // MANUAL, PER_PRAYER, PER_DAY, DAILY_RANDOM_FROM_LIST
  @override
  String get bgFitMode; // COVER, CONTAIN, FILL
  @override
  int get selectedBackgroundId;
  @override
  Map<String, int> get backgroundPerPrayer; // e.g. {'fajr': 1}
  @override
  Map<String, int> get backgroundPerWeekday; // e.g. {'1': 2}
  @override
  List<int> get randomBackgroundPool; // ====== Iqama & Adhan Adjustments ======
  @override
  int get fajrIqamaTime;
  @override
  int get dhuhrIqamaTime;
  @override
  int get asrIqamaTime;
  @override
  int get maghribIqamaTime;
  @override
  int get ishaIqamaTime;
  @override
  int get jomoaIqamaTime;
  @override
  bool get showPreAdhanBeep; // منبه قبل الأذان
// ====== Azkar Toggles ======
  @override
  bool get enableSabahAzkar;
  @override
  bool get enableMasaaAzkar;
  @override
  bool get autoAzkarByTime; // الظهور التلقائي حسب أوقات الصباح والمساء
  @override
  String get manualAzkarType; // SABAH, MASAA, BOTH (في حال التفعيل اليدوي)
  @override
  bool get azkarOnlyScreenEnabled; // عرض أذكار الصباح/المساء فقط
  @override
  bool get azkarOnlyScreenUseGlass; // خلفية زجاجية لشاشة الأذكار فقط
  @override
  String? get azkarOnlyScreenCustomBgPath; // صورة مخصصة لشاشة الأذكار فقط
  @override
  bool get enablePostPrayerAzkar; // ====== Post-Prayer Azkar (Phase 6) ======
  @override
  bool get postPrayerAzkarEnabled;
  @override
  bool get postPrayerAzkarRepeatOnce;
  @override
  bool get postPrayerShowSingleSlide5Min;
  @override
  bool get postPrayerWhiteBackground;
  @override
  bool get enableSabahAfterFajr;
  @override
  bool get enableMasaaAfterAsr;
  @override
  bool get enableMasaaAfterMaghrib;
  @override
  bool get enableMasaaAfterIsha; // ====== Slides & Messages (Phase 6) ======
  @override
  bool get slidesEnabled;
  @override
  bool get slidesShuffle;
  @override
  int get slideDurationSeconds;
  @override
  int get mainScreenDurationSeconds;
  @override
  String get slidesShowMode; // AFTER_PRAYER, MANUAL
  @override
  List<Map<String, dynamic>>
      get slidesList; // ====== Weather & GPS (Phase 6) ======
  @override
  bool get weatherEnabled;
  @override
  bool get weatherShowNearPrayerTimes;
  @override
  String get locationMode; // AUTO or MANUAL
  @override
  double get gpsLat;
  @override
  double get gpsLng;
  @override
  bool get weatherAlertsEnabled; // تنبيهات الطقس الصوتية
// ====== Orientation (Phase 8) ======
  @override
  String get appOrientation; // AUTO, PORTRAIT, LANDSCAPE
// ====== Custom Excel Import Settings ======
  @override
  bool get useCustomPrayerTimes;
  @override
  String get customTimesCountry;
  @override
  String get customTimesCity;
  @override
  String
      get customTimesDuration; // AUTO, YEAR, MONTH_6, MONTH_2, MONTH_1, WEEK_2, WEEK_1, DAY_2, DAY_1
  @override
  String? get customTimesFilePath; // ====== Update Settings ======
  @override
  String? get selectedCustomBgPath;
  @override
  bool get showUpdateInSettings;
  @override
  String get appTheme; // EMERALD, PURE_GLASS
  @override
  String get pureGlassColor1;
  @override
  String get pureGlassColor2;
  @override
  String get pureGlassColor3;
  @override
  String get pureGlassTextColor;
  @override
  bool get glassShineEnabled; // تفعيل/إيقاف البريق الزجاجي
  @override
  String get navbarPosition; // FULL, CENTER, SIDE
// ====== Azkar Scheduling ======
  @override
  String get sabahStartTime;
  @override
  String get sabahEndTime;
  @override
  String get masaaStartTime;
  @override
  String get masaaEndTime;

  /// Create a copy of AppSettings
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AppSettingsImplCopyWith<_$AppSettingsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
