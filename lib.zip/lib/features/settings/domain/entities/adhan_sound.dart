import 'package:freezed_annotation/freezed_annotation.dart';

part 'adhan_sound.freezed.dart';
part 'adhan_sound.g.dart';

@freezed
class AdhanSound with _$AdhanSound {
  const factory AdhanSound({
    required String id,
    required String name,
    required String filePath,
  }) = _AdhanSound;

  factory AdhanSound.fromJson(Map<String, dynamic> json) =>
      _$AdhanSoundFromJson(json);
}
