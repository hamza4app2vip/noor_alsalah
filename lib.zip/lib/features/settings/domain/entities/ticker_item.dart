import 'package:freezed_annotation/freezed_annotation.dart';

part 'ticker_item.freezed.dart';
part 'ticker_item.g.dart';

enum TickerScheduleType { daily, jomoa, date }

@freezed
class TickerItem with _$TickerItem {
  const factory TickerItem({
    required String id,
    @Default(true) bool enabled,
    required int order,
    @Default(TickerScheduleType.daily) TickerScheduleType scheduleType,
    String? date, // e.g. "10/01", only used if scheduleType is date
    required String text,
    @Default(86400) int displayDurationSeconds, // Default 24 hours
    DateTime? createdAt,
  }) = _TickerItem;

  factory TickerItem.fromJson(Map<String, dynamic> json) => _$TickerItemFromJson(json);
}
