
enum ActivitySource {
  app,
  web,
}
