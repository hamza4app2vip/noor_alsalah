// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'slide_item.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SlideItem _$SlideItemFromJson(Map<String, dynamic> json) {
  return _SlideItem.fromJson(json);
}

/// @nodoc
mixin _$SlideItem {
  String get id => throw _privateConstructorUsedError;
  String get type =>
      throw _privateConstructorUsedError; // 'TEXT', 'FILE', 'LINK'
  String get content => throw _privateConstructorUsedError;
  bool get enabled => throw _privateConstructorUsedError;
  int get order => throw _privateConstructorUsedError;
  int? get durationSeconds => throw _privateConstructorUsedError;

  /// Serializes this SlideItem to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SlideItem
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SlideItemCopyWith<SlideItem> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SlideItemCopyWith<$Res> {
  factory $SlideItemCopyWith(SlideItem value, $Res Function(SlideItem) then) =
      _$SlideItemCopyWithImpl<$Res, SlideItem>;
  @useResult
  $Res call(
      {String id,
      String type,
      String content,
      bool enabled,
      int order,
      int? durationSeconds});
}

/// @nodoc
class _$SlideItemCopyWithImpl<$Res, $Val extends SlideItem>
    implements $SlideItemCopyWith<$Res> {
  _$SlideItemCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SlideItem
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? type = null,
    Object? content = null,
    Object? enabled = null,
    Object? order = null,
    Object? durationSeconds = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      content: null == content
          ? _value.content
          : content // ignore: cast_nullable_to_non_nullable
              as String,
      enabled: null == enabled
          ? _value.enabled
          : enabled // ignore: cast_nullable_to_non_nullable
              as bool,
      order: null == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int,
      durationSeconds: freezed == durationSeconds
          ? _value.durationSeconds
          : durationSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SlideItemImplCopyWith<$Res>
    implements $SlideItemCopyWith<$Res> {
  factory _$$SlideItemImplCopyWith(
          _$SlideItemImpl value, $Res Function(_$SlideItemImpl) then) =
      __$$SlideItemImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String type,
      String content,
      bool enabled,
      int order,
      int? durationSeconds});
}

/// @nodoc
class __$$SlideItemImplCopyWithImpl<$Res>
    extends _$SlideItemCopyWithImpl<$Res, _$SlideItemImpl>
    implements _$$SlideItemImplCopyWith<$Res> {
  __$$SlideItemImplCopyWithImpl(
      _$SlideItemImpl _value, $Res Function(_$SlideItemImpl) _then)
      : super(_value, _then);

  /// Create a copy of SlideItem
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? type = null,
    Object? content = null,
    Object? enabled = null,
    Object? order = null,
    Object? durationSeconds = freezed,
  }) {
    return _then(_$SlideItemImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      content: null == content
          ? _value.content
          : content // ignore: cast_nullable_to_non_nullable
              as String,
      enabled: null == enabled
          ? _value.enabled
          : enabled // ignore: cast_nullable_to_non_nullable
              as bool,
      order: null == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int,
      durationSeconds: freezed == durationSeconds
          ? _value.durationSeconds
          : durationSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SlideItemImpl implements _SlideItem {
  const _$SlideItemImpl(
      {required this.id,
      required this.type,
      required this.content,
      this.enabled = true,
      this.order = 0,
      this.durationSeconds});

  factory _$SlideItemImpl.fromJson(Map<String, dynamic> json) =>
      _$$SlideItemImplFromJson(json);

  @override
  final String id;
  @override
  final String type;
// 'TEXT', 'FILE', 'LINK'
  @override
  final String content;
  @override
  @JsonKey()
  final bool enabled;
  @override
  @JsonKey()
  final int order;
  @override
  final int? durationSeconds;

  @override
  String toString() {
    return 'SlideItem(id: $id, type: $type, content: $content, enabled: $enabled, order: $order, durationSeconds: $durationSeconds)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SlideItemImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.content, content) || other.content == content) &&
            (identical(other.enabled, enabled) || other.enabled == enabled) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.durationSeconds, durationSeconds) ||
                other.durationSeconds == durationSeconds));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, type, content, enabled, order, durationSeconds);

  /// Create a copy of SlideItem
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SlideItemImplCopyWith<_$SlideItemImpl> get copyWith =>
      __$$SlideItemImplCopyWithImpl<_$SlideItemImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SlideItemImplToJson(
      this,
    );
  }
}

abstract class _SlideItem implements SlideItem {
  const factory _SlideItem(
      {required final String id,
      required final String type,
      required final String content,
      final bool enabled,
      final int order,
      final int? durationSeconds}) = _$SlideItemImpl;

  factory _SlideItem.fromJson(Map<String, dynamic> json) =
      _$SlideItemImpl.fromJson;

  @override
  String get id;
  @override
  String get type; // 'TEXT', 'FILE', 'LINK'
  @override
  String get content;
  @override
  bool get enabled;
  @override
  int get order;
  @override
  int? get durationSeconds;

  /// Create a copy of SlideItem
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SlideItemImplCopyWith<_$SlideItemImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
