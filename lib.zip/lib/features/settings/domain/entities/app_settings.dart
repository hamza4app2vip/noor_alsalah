import 'package:freezed_annotation/freezed_annotation.dart';
import 'ticker_item.dart';
import 'adhan_sound.dart';

part 'app_settings.freezed.dart';
part 'app_settings.g.dart';

@freezed
class AppSettings with _$AppSettings {
  const factory AppSettings({
    // ====== General Settings ======
    @Default('') String adminUsername, // اسم المستخدم المحفوظ
    @Default('SA') String country,
    @Default('makkah') String city,
    @Default('ar') String languageCode,
    @Default(false)
    bool hasSelectedLanguage, // هل تم اختيار اللغة من قبل المستخدم
    @Default('ar') String ayatsLanguageCode, // لغة ترجمة الآيات
    @Default(true) bool showHijriDate,
    @Default(0) int hijriOffsetDays, // ± أيام للهجري
    @Default(true) bool is24HourFormat,
    @Default(false) bool showSecondsClock, // إظهار الثواني بالساعة
    @Default(true) bool playAdhanSound,
    @Default(false) bool isAutoLocation, // GPS Location
    @Default('مسجد نور الإيمان') String mosqueName,
    String? mosqueIconPath,
    String? customFlagPath,

    // ====== UI & Display ======
    @Default('SYSTEM') String themeMode, // SYSTEM, LIGHT, DARK
    @Default(true) bool showMarqueeTicker,
    @Default(false) bool ramadanCountdownInjectEnabled,
    @Default([]) List<TickerItem> tickerItems,
    @Default(true) bool showAdminMessages, // إعلانات المسجد
    @Default(false)
    bool showBlackScreenDuringPrayer, // الشاشة السوداء وقت الصلاة
    @Default(30) int blackScreenDurationMinutes, // مدة الصلاة قبل الرجوع
    @Default(false) bool dimPastPrayers, // تخفيت الصلوات المصلية
    @Default('Cairo') String fontFamily,

    // ====== FULL SCREENSHOT SETTINGS ======

    // A) General Settings
    @Default(0) int clockOffsetMinutes, // ضبط الساعة الرئيسية

    // B) Display/Identity Options
    @Default(true) bool showCountryFlag,
    @Default(true) bool padTimesWithZero, // إضافة صفر للأوقات e.g. 04:35
    @Default(false) bool showFullClock, // عرض الساعة 00:00:00
    @Default(false)
    bool enableAnalogGlassClock, // تفعيل الساعة التناظرية في الثيم الزجاجي
    @Default(false)
    bool blackClockModeEnabled, // شاشة المواقيت سوداء مع ساعة في المنتصف
    @Default(false)
    bool blackClockModeUseGlass, // خلفية زجاجية لشاشة الساعة الخاصة
    String? blackClockModeCustomBgPath, // صورة مخصصة لشاشة الساعة الخاصة
    @Default('GLASS')
    String analogClockStyle, // GLASS, GOLDEN, ROYAL, GREEN_GOLD
    @Default(true)
    bool
        showAnalogClockDateFrame, // إظهار إطار التاريخ بجانب الساعة (الطولي/الأفقي)
    @Default(false)
    bool
        showAnalogClockNumbers, // إظهار أرقام الساعة التناظرية (عام لكل الساعات)
    @Default(true) bool showNightPrayers, // منتصف وثلث الليل

    // C) Prayers List Options
    @Default(false) bool centerPrayerNamesLandscape,
    @Default(false) bool enlargePrayerNamesLandscape,
    @Default(false) bool showIqamaWithClock,
    @Default(true) bool showCountdown,
    @Default(false) bool enlargeCountdown,
    @Default(true) bool showFullscreenCountdownAtThreshold,
    @Default(true) bool useArabicIndicDigits, // الأرقام العربية
    @Default(false) bool hideIqamaTime,
    @Default(false) bool centerPrayerNamesPortrait,
    @Default(false)
    bool
        centerNameWithTimesOnSides, // توسيط اسم الصلاة، الأذان يمين والإقامة يسار
    @Default(false) bool showPrayerNameInOtherLanguage,

    // ====== Fonts / Sizes Options ======
    @Default(22.0) double prayerNameFontSize,
    @Default(26.0) double prayerTimeFontSize,
    @Default(18.0) double iqamaTimeFontSize,

    // D) Adhan/Iqama Screens
    @Default(true) bool showAdhanScreen,
    @Default(true) bool showIqamaScreen,
    @Default(true) bool swapDateAndMosqueLandscape,
    @Default(true) bool showInternetStatus,
    @Default(true) bool showBackgroundShadingBehindTimes,
    @Default(true) bool useTranslucentScreens, // شاشات شبه شفافة
    @Default(true) bool countdownGreenLast90s,
    @Default(false) bool enlargeNextPrayerCountdown,

    // E) Audio/Visual Alerts
    @Default(true) bool playVoiceAlertBeforeIqama,
    @Default('أقيموا صفوفكم وسدوا الخلل') String voiceAlertMessage,
    @Default(true) bool showHadithBeforeIqama,

    // ====== Khushoo Program (Mute & Black Screen) ======
    @Default(false) bool isGlobalAudioMuted,
    @Default(false) bool isAzanAudioMuted,
    @Default(false)
    bool khushooModeEnabled, // تفعيل الشاشة السوداء تلقائيا بعد الأذان
    @Default(5) int khushooModeDuration, // مدة الشاشة السوداء بالدقائق
    @Default(false) bool isKhushooManualActive, // تفعيل يدوي للشاشة السوداء

    // F) Eid Times
    @Default('08:00') String eidAlFitrTime,
    @Default('07:00') String eidAlAdhaTime,

    // G) MP3 Audio
    @Default(true) bool useMp3ForAdhan,
    @Default(false) bool useShortAdhan,
    @Default(false) bool useShortIqama,

    // H) Specific Fonts
    @Default('Uthman') String azkarFontFamily,
    @Default('Sultan') String clockFontFamily,
    @Default('STC') String timesFontFamily,
    @Default('Cairo') String textFontFamily,

    // ====== Advanced Time Adjustments (Phase 5) ======
    @Default(false) bool ramadanIshaPlus30Enabled,
    @Default(false) bool summerPlus1HourEnabled,
    @Default(false) bool manualPlus1HourAllEnabled,
    @Default(false) bool manualMinus1HourAllEnabled,
    @Default(0) int prayerOffsetFajr,
    @Default(0) int prayerOffsetSunrise,
    @Default(0) int prayerOffsetDhuhr,
    @Default(0) int prayerOffsetAsr,
    @Default(0) int prayerOffsetMaghrib,
    @Default(0) int prayerOffsetIsha,
    @Default('0') String timeOffsetMasha,

    // ====== Custom Adhan Sounds ======
    @Default([]) List<AdhanSound> customAdhanSounds,
    @Default(null) String? defaultAdhanSoundId, // null = built-in default
    @Default({})
    Map<String, String> prayerAdhanSoundIds, // e.g. "fajr" -> "uuid"

    // ====== Manual Time Management ======
    @Default(false)
    bool isManualTimeEnabled, // true if user picks time manually
    @Default(null)
    String?
        manualTimeValue, // The user-picked time in "HH:mm" format if isManualTimeEnabled is true

    // ====== Fixed Iqama System (Phase 5) ======
    @Default({}) Map<String, bool> iqamaIsFixed, // e.g. {'fajr': true}
    @Default({}) Map<String, String> iqamaFixedTimes, // e.g. {'fajr': '05:30'}

    // ====== Jumua Settings (Phase 5) ======
    @Default(true) bool jumuaKhutbahAutoMode,
    @Default('12:00') String jumuaKhutbahManualTime,
    @Default(false) bool showJumuaInLandscape,
    @Default(true) bool enableJumuaAdhanSound,

    // ====== Advanced Alerts & Dhuhr Calculation (Phase 5) ======
    @Default(0) int fajrPreAdhanAlertMinutes,
    @Default(false) bool dhuhrFromAsrMinusMinutesEnabled,
    @Default(0) int dhuhrEqualsAsrMinusMinutes,

    // ====== Background System (Phase 5) ======
    @Default('MANUAL')
    String bgMode, // MANUAL, PER_PRAYER, PER_DAY, DAILY_RANDOM_FROM_LIST
    @Default('COVER') String bgFitMode, // COVER, CONTAIN, FILL
    @Default(0) int selectedBackgroundId,
    @Default({}) Map<String, int> backgroundPerPrayer, // e.g. {'fajr': 1}
    @Default({}) Map<String, int> backgroundPerWeekday, // e.g. {'1': 2}
    @Default([]) List<int> randomBackgroundPool,

    // ====== Iqama & Adhan Adjustments ======
    @Default(20) int fajrIqamaTime,
    @Default(15) int dhuhrIqamaTime,
    @Default(15) int asrIqamaTime,
    @Default(10) int maghribIqamaTime,
    @Default(15) int ishaIqamaTime,
    @Default(0) int jomoaIqamaTime,
    @Default(true) bool showPreAdhanBeep, // منبه قبل الأذان

    // ====== Azkar Toggles ======
    @Default(true) bool enableSabahAzkar,
    @Default(true) bool enableMasaaAzkar,
    @Default(false)
    bool autoAzkarByTime, // الظهور التلقائي حسب أوقات الصباح والمساء
    @Default('BOTH')
    String manualAzkarType, // SABAH, MASAA, BOTH (في حال التفعيل اليدوي)
    @Default(false) bool azkarOnlyScreenEnabled, // عرض أذكار الصباح/المساء فقط
    @Default(false)
    bool azkarOnlyScreenUseGlass, // خلفية زجاجية لشاشة الأذكار فقط
    String? azkarOnlyScreenCustomBgPath, // صورة مخصصة لشاشة الأذكار فقط
    @Default(true) bool enablePostPrayerAzkar,

    // ====== Post-Prayer Azkar (Phase 6) ======
    @Default(true) bool postPrayerAzkarEnabled,
    @Default(false) bool postPrayerAzkarRepeatOnce,
    @Default(false) bool postPrayerShowSingleSlide5Min,
    @Default(false) bool postPrayerWhiteBackground,
    @Default(true) bool enableSabahAfterFajr,
    @Default(true) bool enableMasaaAfterAsr,
    @Default(true) bool enableMasaaAfterMaghrib,
    @Default(true) bool enableMasaaAfterIsha,

    // ====== Slides & Messages (Phase 6) ======
    @Default(false) bool slidesEnabled,
    @Default(false) bool slidesShuffle,
    @Default(15) int slideDurationSeconds,
    @Default(12) int mainScreenDurationSeconds,
    @Default('AFTER_PRAYER') String slidesShowMode, // AFTER_PRAYER, MANUAL
    @Default([]) List<Map<String, dynamic>> slidesList,

    // ====== Weather & GPS (Phase 6) ======
    @Default(false) bool weatherEnabled,
    @Default(true) bool weatherShowNearPrayerTimes,
    @Default('AUTO') String locationMode, // AUTO or MANUAL
    @Default(0.0) double gpsLat,
    @Default(0.0) double gpsLng,
    @Default(true) bool weatherAlertsEnabled, // تنبيهات الطقس الصوتية

    // ====== Orientation (Phase 8) ======
    @Default('AUTO') String appOrientation, // AUTO, PORTRAIT, LANDSCAPE

    // ====== Custom Excel Import Settings ======
    @Default(false) bool useCustomPrayerTimes,
    @Default('SA') String customTimesCountry,
    @Default('makkah') String customTimesCity,
    @Default('AUTO')
    String
        customTimesDuration, // AUTO, YEAR, MONTH_6, MONTH_2, MONTH_1, WEEK_2, WEEK_1, DAY_2, DAY_1
    String? customTimesFilePath,

    // ====== Update Settings ======
    @Default(null) String? selectedCustomBgPath,
    @Default(true) bool showUpdateInSettings,
    @Default('PURE_GLASS') String appTheme, // EMERALD, PURE_GLASS
    @Default('#38BDF8') String pureGlassColor1,
    @Default('#818CF8') String pureGlassColor2,
    @Default('#E879F9') String pureGlassColor3,
    @Default('#FFFFFF') String pureGlassTextColor,
    @Default(true) bool glassShineEnabled, // تفعيل/إيقاف البريق الزجاجي
    @Default('SIDE') String navbarPosition, // FULL, CENTER, SIDE

    // ====== Azkar Scheduling ======
    @Default('04:00') String sabahStartTime,
    @Default('09:00') String sabahEndTime,
    @Default('15:00') String masaaStartTime,
    @Default('20:00') String masaaEndTime,
  }) = _AppSettings;

  factory AppSettings.fromJson(Map<String, dynamic> json) =>
      _$AppSettingsFromJson(json);
}
// force rebuild
