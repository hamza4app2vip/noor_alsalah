import 'package:freezed_annotation/freezed_annotation.dart';
import 'activity_source.dart';

part 'activity_log_item.freezed.dart';
part 'activity_log_item.g.dart';

@freezed
class ActivityLogItem with _$ActivityLogItem {
  const factory ActivityLogItem({
    required String id,
    required DateTime timestamp,
    required ActivitySource source,
    required String action, // e.g., "تغيير اسم المسجد"
    required Map<String, dynamic> details, // e.g., {"old": "A", "new": "B"}
  }) = _ActivityLogItem;

  factory ActivityLogItem.fromJson(Map<String, dynamic> json) =>
      _$ActivityLogItemFromJson(json);
}
