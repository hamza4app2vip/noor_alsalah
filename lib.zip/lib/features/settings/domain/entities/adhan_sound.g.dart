// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'adhan_sound.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AdhanSoundImpl _$$AdhanSoundImplFromJson(Map<String, dynamic> json) =>
    _$AdhanSoundImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      filePath: json['filePath'] as String,
    );

Map<String, dynamic> _$$AdhanSoundImplToJson(_$AdhanSoundImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'filePath': instance.filePath,
    };
