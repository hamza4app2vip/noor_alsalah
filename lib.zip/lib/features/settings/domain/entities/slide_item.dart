import 'package:freezed_annotation/freezed_annotation.dart';

part 'slide_item.freezed.dart';
part 'slide_item.g.dart';

@freezed
class SlideItem with _$SlideItem {
  const factory SlideItem({
    required String id,
    required String type, // 'TEXT', 'FILE', 'LINK'
    required String content,
    @Default(true) bool enabled,
    @Default(0) int order,
    int? durationSeconds, // مدة مخصصة لهذه الشريحة بالثواني
  }) = _SlideItem;

  factory SlideItem.fromJson(Map<String, dynamic> json) => _$SlideItemFromJson(json);
}
