// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticker_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$TickerItemImpl _$$TickerItemImplFromJson(Map<String, dynamic> json) =>
    _$TickerItemImpl(
      id: json['id'] as String,
      enabled: json['enabled'] as bool? ?? true,
      order: (json['order'] as num).toInt(),
      scheduleType: $enumDecodeNullable(
              _$TickerScheduleTypeEnumMap, json['scheduleType']) ??
          TickerScheduleType.daily,
      date: json['date'] as String?,
      text: json['text'] as String,
      displayDurationSeconds:
          (json['displayDurationSeconds'] as num?)?.toInt() ?? 86400,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
    );

Map<String, dynamic> _$$TickerItemImplToJson(_$TickerItemImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'enabled': instance.enabled,
      'order': instance.order,
      'scheduleType': _$TickerScheduleTypeEnumMap[instance.scheduleType]!,
      'date': instance.date,
      'text': instance.text,
      'displayDurationSeconds': instance.displayDurationSeconds,
      'createdAt': instance.createdAt?.toIso8601String(),
    };

const _$TickerScheduleTypeEnumMap = {
  TickerScheduleType.daily: 'daily',
  TickerScheduleType.jomoa: 'jomoa',
  TickerScheduleType.date: 'date',
};
