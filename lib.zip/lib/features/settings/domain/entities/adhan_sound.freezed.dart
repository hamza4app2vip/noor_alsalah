// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'adhan_sound.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

AdhanSound _$AdhanSoundFromJson(Map<String, dynamic> json) {
  return _AdhanSound.fromJson(json);
}

/// @nodoc
mixin _$AdhanSound {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get filePath => throw _privateConstructorUsedError;

  /// Serializes this AdhanSound to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of AdhanSound
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AdhanSoundCopyWith<AdhanSound> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AdhanSoundCopyWith<$Res> {
  factory $AdhanSoundCopyWith(
          AdhanSound value, $Res Function(AdhanSound) then) =
      _$AdhanSoundCopyWithImpl<$Res, AdhanSound>;
  @useResult
  $Res call({String id, String name, String filePath});
}

/// @nodoc
class _$AdhanSoundCopyWithImpl<$Res, $Val extends AdhanSound>
    implements $AdhanSoundCopyWith<$Res> {
  _$AdhanSoundCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AdhanSound
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? filePath = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      filePath: null == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AdhanSoundImplCopyWith<$Res>
    implements $AdhanSoundCopyWith<$Res> {
  factory _$$AdhanSoundImplCopyWith(
          _$AdhanSoundImpl value, $Res Function(_$AdhanSoundImpl) then) =
      __$$AdhanSoundImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String id, String name, String filePath});
}

/// @nodoc
class __$$AdhanSoundImplCopyWithImpl<$Res>
    extends _$AdhanSoundCopyWithImpl<$Res, _$AdhanSoundImpl>
    implements _$$AdhanSoundImplCopyWith<$Res> {
  __$$AdhanSoundImplCopyWithImpl(
      _$AdhanSoundImpl _value, $Res Function(_$AdhanSoundImpl) _then)
      : super(_value, _then);

  /// Create a copy of AdhanSound
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? filePath = null,
  }) {
    return _then(_$AdhanSoundImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      filePath: null == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AdhanSoundImpl implements _AdhanSound {
  const _$AdhanSoundImpl(
      {required this.id, required this.name, required this.filePath});

  factory _$AdhanSoundImpl.fromJson(Map<String, dynamic> json) =>
      _$$AdhanSoundImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final String filePath;

  @override
  String toString() {
    return 'AdhanSound(id: $id, name: $name, filePath: $filePath)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AdhanSoundImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.filePath, filePath) ||
                other.filePath == filePath));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, name, filePath);

  /// Create a copy of AdhanSound
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AdhanSoundImplCopyWith<_$AdhanSoundImpl> get copyWith =>
      __$$AdhanSoundImplCopyWithImpl<_$AdhanSoundImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AdhanSoundImplToJson(
      this,
    );
  }
}

abstract class _AdhanSound implements AdhanSound {
  const factory _AdhanSound(
      {required final String id,
      required final String name,
      required final String filePath}) = _$AdhanSoundImpl;

  factory _AdhanSound.fromJson(Map<String, dynamic> json) =
      _$AdhanSoundImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  String get filePath;

  /// Create a copy of AdhanSound
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AdhanSoundImplCopyWith<_$AdhanSoundImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
