// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'activity_log_item.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ActivityLogItem _$ActivityLogItemFromJson(Map<String, dynamic> json) {
  return _ActivityLogItem.fromJson(json);
}

/// @nodoc
mixin _$ActivityLogItem {
  String get id => throw _privateConstructorUsedError;
  DateTime get timestamp => throw _privateConstructorUsedError;
  ActivitySource get source => throw _privateConstructorUsedError;
  String get action =>
      throw _privateConstructorUsedError; // e.g., "تغيير اسم المسجد"
  Map<String, dynamic> get details => throw _privateConstructorUsedError;

  /// Serializes this ActivityLogItem to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ActivityLogItem
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ActivityLogItemCopyWith<ActivityLogItem> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ActivityLogItemCopyWith<$Res> {
  factory $ActivityLogItemCopyWith(
          ActivityLogItem value, $Res Function(ActivityLogItem) then) =
      _$ActivityLogItemCopyWithImpl<$Res, ActivityLogItem>;
  @useResult
  $Res call(
      {String id,
      DateTime timestamp,
      ActivitySource source,
      String action,
      Map<String, dynamic> details});
}

/// @nodoc
class _$ActivityLogItemCopyWithImpl<$Res, $Val extends ActivityLogItem>
    implements $ActivityLogItemCopyWith<$Res> {
  _$ActivityLogItemCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ActivityLogItem
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? timestamp = null,
    Object? source = null,
    Object? action = null,
    Object? details = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      timestamp: null == timestamp
          ? _value.timestamp
          : timestamp // ignore: cast_nullable_to_non_nullable
              as DateTime,
      source: null == source
          ? _value.source
          : source // ignore: cast_nullable_to_non_nullable
              as ActivitySource,
      action: null == action
          ? _value.action
          : action // ignore: cast_nullable_to_non_nullable
              as String,
      details: null == details
          ? _value.details
          : details // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ActivityLogItemImplCopyWith<$Res>
    implements $ActivityLogItemCopyWith<$Res> {
  factory _$$ActivityLogItemImplCopyWith(_$ActivityLogItemImpl value,
          $Res Function(_$ActivityLogItemImpl) then) =
      __$$ActivityLogItemImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      DateTime timestamp,
      ActivitySource source,
      String action,
      Map<String, dynamic> details});
}

/// @nodoc
class __$$ActivityLogItemImplCopyWithImpl<$Res>
    extends _$ActivityLogItemCopyWithImpl<$Res, _$ActivityLogItemImpl>
    implements _$$ActivityLogItemImplCopyWith<$Res> {
  __$$ActivityLogItemImplCopyWithImpl(
      _$ActivityLogItemImpl _value, $Res Function(_$ActivityLogItemImpl) _then)
      : super(_value, _then);

  /// Create a copy of ActivityLogItem
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? timestamp = null,
    Object? source = null,
    Object? action = null,
    Object? details = null,
  }) {
    return _then(_$ActivityLogItemImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      timestamp: null == timestamp
          ? _value.timestamp
          : timestamp // ignore: cast_nullable_to_non_nullable
              as DateTime,
      source: null == source
          ? _value.source
          : source // ignore: cast_nullable_to_non_nullable
              as ActivitySource,
      action: null == action
          ? _value.action
          : action // ignore: cast_nullable_to_non_nullable
              as String,
      details: null == details
          ? _value._details
          : details // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ActivityLogItemImpl implements _ActivityLogItem {
  const _$ActivityLogItemImpl(
      {required this.id,
      required this.timestamp,
      required this.source,
      required this.action,
      required final Map<String, dynamic> details})
      : _details = details;

  factory _$ActivityLogItemImpl.fromJson(Map<String, dynamic> json) =>
      _$$ActivityLogItemImplFromJson(json);

  @override
  final String id;
  @override
  final DateTime timestamp;
  @override
  final ActivitySource source;
  @override
  final String action;
// e.g., "تغيير اسم المسجد"
  final Map<String, dynamic> _details;
// e.g., "تغيير اسم المسجد"
  @override
  Map<String, dynamic> get details {
    if (_details is EqualUnmodifiableMapView) return _details;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_details);
  }

  @override
  String toString() {
    return 'ActivityLogItem(id: $id, timestamp: $timestamp, source: $source, action: $action, details: $details)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ActivityLogItemImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.timestamp, timestamp) ||
                other.timestamp == timestamp) &&
            (identical(other.source, source) || other.source == source) &&
            (identical(other.action, action) || other.action == action) &&
            const DeepCollectionEquality().equals(other._details, _details));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, timestamp, source, action,
      const DeepCollectionEquality().hash(_details));

  /// Create a copy of ActivityLogItem
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ActivityLogItemImplCopyWith<_$ActivityLogItemImpl> get copyWith =>
      __$$ActivityLogItemImplCopyWithImpl<_$ActivityLogItemImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ActivityLogItemImplToJson(
      this,
    );
  }
}

abstract class _ActivityLogItem implements ActivityLogItem {
  const factory _ActivityLogItem(
      {required final String id,
      required final DateTime timestamp,
      required final ActivitySource source,
      required final String action,
      required final Map<String, dynamic> details}) = _$ActivityLogItemImpl;

  factory _ActivityLogItem.fromJson(Map<String, dynamic> json) =
      _$ActivityLogItemImpl.fromJson;

  @override
  String get id;
  @override
  DateTime get timestamp;
  @override
  ActivitySource get source;
  @override
  String get action; // e.g., "تغيير اسم المسجد"
  @override
  Map<String, dynamic> get details;

  /// Create a copy of ActivityLogItem
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ActivityLogItemImplCopyWith<_$ActivityLogItemImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
