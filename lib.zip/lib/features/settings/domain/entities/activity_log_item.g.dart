// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'activity_log_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ActivityLogItemImpl _$$ActivityLogItemImplFromJson(
        Map<String, dynamic> json) =>
    _$ActivityLogItemImpl(
      id: json['id'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      source: $enumDecode(_$ActivitySourceEnumMap, json['source']),
      action: json['action'] as String,
      details: json['details'] as Map<String, dynamic>,
    );

Map<String, dynamic> _$$ActivityLogItemImplToJson(
        _$ActivityLogItemImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'timestamp': instance.timestamp.toIso8601String(),
      'source': _$ActivitySourceEnumMap[instance.source]!,
      'action': instance.action,
      'details': instance.details,
    };

const _$ActivitySourceEnumMap = {
  ActivitySource.app: 'app',
  ActivitySource.web: 'web',
};
