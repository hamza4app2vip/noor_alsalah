// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'slide_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SlideItemImpl _$$SlideItemImplFromJson(Map<String, dynamic> json) =>
    _$SlideItemImpl(
      id: json['id'] as String,
      type: json['type'] as String,
      content: json['content'] as String,
      enabled: json['enabled'] as bool? ?? true,
      order: (json['order'] as num?)?.toInt() ?? 0,
      durationSeconds: (json['durationSeconds'] as num?)?.toInt(),
    );

Map<String, dynamic> _$$SlideItemImplToJson(_$SlideItemImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'type': instance.type,
      'content': instance.content,
      'enabled': instance.enabled,
      'order': instance.order,
      'durationSeconds': instance.durationSeconds,
    };
